'use strict';
 
const chai = require('chai');  
const expect = require('chai').expect;
var should    = require("should");
var util      = require('util');
chai.use(require('chai-http'));
const app = require('../app.js'); // Our app
var sinon = require('sinon');
var request = require('supertest');


/**
 * Testing api call for search Receptor by name
 */
 describe('POST Search', function() {
  it('should return id for Receptor CCR3', function(done) {
     request(app).post('/search')
         .send({
             term: 'CCR3'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             console.log(res.body);
         });
   });
});


/**
 * Testing api call for search Receptor by name
 */
 describe('POST Search', function() {
  it('should return id for Receptor CX3CR1', function(done) {
     request(app).post('/search')
         .send({
             term: 'CX3CR1'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             console.log(res.body);
         });
   });
});


/**
 * Testing api call for search Ligand by name
 */
 describe('POST Search', function() {
  it('should return id for Ligand CXCL6', function(done) {
     request(app).post('/search')
         .send({
             term: 'CXCL6'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             console.log(res.body);
         });
   });
});


 /**
 * Testing api call for search Ligand by name
 */
 describe('POST Search', function() {
  it('should return id for Ligand XCL2', function(done) {
     request(app).post('/search')
         .send({
             term: 'XCL2'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             console.log(res.body);
         });
   });
});