'use strict';
 
const chai = require('chai');  
const expect = require('chai').expect;
var should    = require("should");
var util      = require('util');
chai.use(require('chai-http'));
const app = require('../app.js'); // Our app
var sinon = require('sinon');
var request = require('supertest');


/**
 * Testing api call for getting IUPHAR data for Receptor 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Receptor CCR1', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'REC1'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});

/**
 * Testing api call for getting IUPHAR data for Receptor 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Receptor CCR10', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'REC10'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});

 /**
 * Testing api call for getting IUPHAR data for Receptor 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Receptor CCRL2', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'REC11'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});

 /**
 * Testing api call for getting IUPHAR data for Receptor 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Receptor ACKR1', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'REC20'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});

 /**
 * Testing api call for getting IUPHAR data for Ligand 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Ligand CCL1', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'LIG1'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});

 /**
 * Testing api call for getting IUPHAR data for Ligand 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Ligand CXCL12_alpha', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'LIG36'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});

  /**
 * Testing api call for getting IUPHAR data for Ligand 
 */
 describe('POST Iuphar', function() {
  it('should get data for Human Ligand XCL1', function(done) {
     request(app).post('/iuphar')
         .send({
             id: 'LIG44'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});
