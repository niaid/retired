'use strict';
 
const chai = require('chai');  
const expect = require('chai').expect;
var should    = require("should");
var util      = require('util');
chai.use(require('chai-http'));
const app = require('../app.js'); // Our app
var sinon = require('sinon');
var request = require('supertest');


/**
 * Testing api call for getting Genbank data for Receptor (Human species)
 */
 describe('POST Genbank', function() {
  it('should get data for Human Receptor CCR1', function(done) {
     request(app).post('/genbank')
         .send({
             id: 'R12'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});

/**
 * Testing api call for getting Genbank data for Receptor (Mouse species)
 */
 describe('POST Genbank', function() {
  it('should get data for Mouse Receptor CCR1', function(done) {
     request(app).post('/genbank')
         .send({
             id: 'R13'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});


/**
 * Testing api call for getting Genbank data for Receptor (Rat species)
 */
 describe('POST Genbank', function() {
  it('should get data for Rat Receptor CCR1', function(done) {
     request(app).post('/genbank')
         .send({
             id: 'R14'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});

/**
 * Testing api call for getting Genbank data for Ligand (Human species)
 */
 describe('POST Genbank', function() {
  it('should get data for Human Ligand CCL2', function(done) {
     request(app).post('/genbank')
         .send({
             id: 'L2'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});

 /**
 * Testing api call for getting Genbank data for Ligand (Mouse species)
 */
 describe('POST Genbank', function() {
  it('should get data for Mouse Ligand CCL2', function(done) {
     request(app).post('/genbank')
         .send({
             id: 'L45'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});


/**
 * Testing api call for getting Genbank data for Ligand (Rat species)
 */
 describe('POST Genbank', function() {
  it('should get data for Rat Ligand CCL2', function(done) {
     request(app).post('/genbank')
         .send({
             id: 'L72'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});