'use strict';
 
const chai = require('chai');  
const expect = require('chai').expect;
var should    = require("should");
var util      = require('util');
chai.use(require('chai-http'));
const app = require('../app.js'); // Our app
var sinon = require('sinon');
var request = require('supertest');


/**
 * Testing api call for getting Function data for Receptor
 */
 describe('POST FunctionData', function() {
  it('should get function data for Receptor CCR1', function(done) {
     request(app).post('/functiondata')
         .send({
             id: 'REC1'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});


/**
 * Testing api call for getting Function data for Receptor (Human Species)
 */
 describe('POST FunctionData', function() {
  it('should get function data for Human Receptor CCR1', function(done) {
     request(app).post('/functiondata')
         .send({
             id: 'R12'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
         });
   });
});
