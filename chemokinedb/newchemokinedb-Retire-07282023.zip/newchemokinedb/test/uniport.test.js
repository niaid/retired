'use strict';
 
const chai = require('chai');  
const expect = require('chai').expect;
var should    = require("should");
var util      = require('util');
chai.use(require('chai-http'));
const app = require('../app.js'); // Our app
var sinon = require('sinon');
var request = require('supertest');


/**
 * Testing api call for getting Uniport data for Receptor (Human species)
 */
 describe('POST Uniport', function() {
  it('should get data for Human Receptor id R12', function(done) {
     request(app).post('/uniprot')
         .send({
             id: 'R12'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});

/**
 * Testing api call for getting Uniport data for Receptor (Mouse species)
 */
 describe('POST Uniport', function() {
  it('should get data for Mouse Receptor id R13', function(done) {
     request(app).post('/uniprot')
         .send({
             id: 'R13'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});


/**
 * Testing api call for getting Uniport data for Receptor (Rat species)
 */
 describe('POST Uniport', function() {
  it('should get data for Rat Receptor id R14', function(done) {
     request(app).post('/uniprot')
         .send({
             id: 'R14'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});

/**
 * Testing api call for getting Uniport data for Ligand (Human species)
 */
 describe('POST Uniport', function() {
  it('should get data for Human Ligand id L2', function(done) {
     request(app).post('/uniprot')
         .send({
             id: 'L2'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});

 /**
 * Testing api call for getting Uniport data for Ligand (Mouse species)
 */
 describe('POST Uniport', function() {
  it('should get data for Mouse Ligand id L45', function(done) {
     request(app).post('/uniprot')
         .send({
             id: 'L45'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});


/**
 * Testing api call for getting Uniport data for Ligand (Rat species)
 */
 describe('POST Uniport', function() {
  it('should get data for Rat Ligand id L72', function(done) {
     request(app).post('/uniprot')
         .send({
             id: 'L72'
         })
         .expect(200)
         .end(function(err, res) {
             done(err);
             //console.log(res.body.arrayData.length);
         });
   });
});