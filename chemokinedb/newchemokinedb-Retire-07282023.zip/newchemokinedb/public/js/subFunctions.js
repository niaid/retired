// This file contains helper functions for functions.js
/**
 * select tree node by id
 * @param {*} id 
 */
function selectTreeNode(id) {
    if (_selected_node != null) {
        $('#tree1').tree('removeFromSelection', _selected_node);
    }
    var node = $('#tree1').tree('getNodeById', id);
    $('#tree1').tree('selectNode', node);
    $('#tree1').tree('scrollToNode', node);
}
/**
 * Displays contents for Endogenous targets on Overview page
 * @param {*} endogenousTargets 
 * @param {*} endogenousTargetsExternal 
 */
function getEndogenousTargets(endogenousTargets, endogenousTargetsExternal) {
    var newHTML = [];
    if (endogenousTargets.length == 0 && endogenousTargetsExternal.length == 0) {
        newHTML.push('unknown');
    } else if (endogenousTargets.length == 0 && endogenousTargetsExternal.length > 0) {
        $.each(endogenousTargetsExternal, function(k, et) {
            if (k == 0)
                newHTML.push('<a><span>' + et.targetName + '</span></a>');
            else
                newHTML.push(' , ' + '<a><span>' + et.targetName + '</span></a>');
        });
    } else {
        $.each(endogenousTargets, function(k, et) {
            if (k == 0)
                newHTML.push('<a><span onclick="selectTreeNode(\'' + et.targetId + '\')">' + et.targetName + '</span></a>');
            else
                newHTML.push(' , ' + '<a><span onclick="selectTreeNode(\'' + et.targetId + '\')">' + et.targetName + '</span></a>');
        });
    }

    return newHTML.join("");
}

/**
 * Displays contents for Database Links for Receptors/Ligands on Overview page
 * @param {*} databaseLinks 
 * @param {*} arraySpecies 
 */
function getDatabaseLinks(databaseLinks, arraySpecies) {
    var countInternal = 0;
    var count = 0;
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table class="table table-bordered table-hover table-striped" style="width:70%"><thead><tr class="matrixHeading"><th>Database</th>');
    $.each(arraySpecies, function(m, arraySpecies) {
        newHTML.push('<th>' + arraySpecies.species + '</th>');
        count += 1;
    });
    newHTML.push('</tr></thead><tbody><tr>');
    var name = "",
        species = "",
        url = "";
    $.each(databaseLinks, function(k, dbLinks) {
        if (name == dbLinks.name) {
            if (species == dbLinks.species && url == dbLinks.url) {
                newHTML.push(', <a href="' + dbLinks.url + '" target="_blank" class="externalURL">' + dbLinks.value + '</a>');
            } else {
                newHTML.push('</td><td><a href="' + dbLinks.url + '" target="_blank" class="externalURL">' + dbLinks.value + '</a>');
            }
            countInternal += 1;
        } else {
            for (p = countInternal;
                (p < count) && (k > 0); p++) {
                newHTML.push('<td></td>');
            }
            newHTML.push('</td></tr><tr><td>' + dbLinks.name + '</td><td><a href="' + dbLinks.url + '" target="_blank" class="externalURL">' + dbLinks.value + '</a>');
            countInternal = 1;
        }
        species = dbLinks.species;
        url = dbLinks.url;
        name = dbLinks.name;
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}

/**
 * Displays contents for Endogenous Ligand for Receptors on Overview page
 * @param {*} array 
 */
function getEndogenousLigand(array) {
    var matrix = [];
    distinctspc = [];
    matrix.push('<div class="text-format-left"><table class="table table-bordered table-hover table-striped" style="width:45%"><thead><tr class="matrixHeading">');
    var count = 0;
    if (array.length == 0) {
        matrix.push('<span>unknown</span>');
    } else {
        matrix.push('<th>Ligand Overview</th>');
    }
    $.each(array, function(j, endogenousLigand) {
        if ($.inArray(endogenousLigand.species, distinctspc) == -1) {
            count += 1;
            matrix.push('<th style="width:25%">' + endogenousLigand.species + ' gene</th>');
            distinctspc.push(endogenousLigand.species);
        }
    });
    matrix.push('</tr></thead><tbody><tr>');
    var countInternal = 0;
    $.each(array, function(i, endogenousLigand) {
        if (ligand == endogenousLigand.name) {
            matrix.push('<td ><a><span onclick="selectTreeNode(\'' + endogenousLigand.id + '\')">' + endogenousLigand.name + '</span></a></td>');
            countInternal += 1;
        } else {
            for (p = countInternal;
                (p < count) && (i > 0); p++)
                matrix.push('<td></td>');

            matrix.push('</tr><tr><td>' + endogenousLigand.name + '</td><td><a><span onclick="selectTreeNode(\'' + endogenousLigand.id + '\')">' + endogenousLigand.name + '</span></a></td>');
            countInternal = 1;
        }
        ligand = endogenousLigand.name;
    });
    matrix.push('</tr></tbody></table></div>');
    return matrix.join('\n');
}
/**
 * 
 * @param {*} data 
 * @param {*} id 
 */
function getJSONArray(data, id) {
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table id=' + id + ' class="table table-bordered table-hover table-striped" style="width:70%"><thead><tr class="matrixHeading">');
    $.each(data[0], function(key, val) {
        newHTML.push('<th>' + key + '</th>');
    });
    newHTML.push('</tr></thead><tbody>');
    $.each(data, function() {
        newHTML.push('<tr>');
        $.each(this, function(key, val) {
            if (val == null)
                val = "";
            newHTML.push('<td>' + val + '</td>');
        });
        newHTML.push('</tr>');
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}

/**
 * Displays contents for function Table when you click on Function button
 * @param {*} funcs 
 */
function getFunctionTable(funcs) {
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table id="functionDataTable" class="table table-bordered table-hover table-striped" style="width:95%"><thead><tr class="matrixHeading"><th>PMID</th><th>Cited For</th><th>Function' +
        '</th><th>Measurement<br>/Technique</th><th>Tissue</th><th>Species</th><th>Refernce Type</th><th>Source</th><th>Title publ.</th><th>Genbank Entrez ID</th></tr></thead><tbody>');
    $.each(funcs, function(m, func) {
        if (func.PMID == null)
            func.PMID = "";
        if (func.Function == null)
            func.Function = "";
        if (func.MeasurementTechnique == null)
            func.MeasurementTechnique = "";
        if (func.Tissue == null)
            func.Tissue = "";
        if (func.Titlepubl == null)
            func.Titlepubl = "";
        newHTML.push('<tr><td><a href="http://www.ncbi.nlm.nih.gov/pubmed/?term=' + func.PMID + '" target="_blank" class="externalURL">' + func.PMID + '</a></td><td>' + func.CitedFor + '</td><td>' + func.Function +
            '</td><td>' + func.MeasurementTechnique + '</td><td>' + func.Tissue + '</td><td>' + func.Species + '</td><td>' + func.RefernceType + '</td><td>' + func.Source + '</td><td>' + func.Titlepubl +
            '</td><td><a href="http://www.ncbi.nlm.nih.gov/gene/?term=' + func.GenbankEntrezID + '" target="_blank" class="externalURL">' + func.GenbankEntrezID + '</a></td></tr>');
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}

/**
 * Displays contents for GO Functions for species on Protein tab
 * @param {*} func 
 */
function getGOFunc(func) {
    var subtype = "";
    var newHTML = [];
    newHTML.push('<div class="text-format-left">');
    $.each(func, function(m, fn) {
        if (subtype == "") {
            newHTML.push('<div><b>' + fn.type + ' - ' + fn.subtype + '</b></div><table class="table table-bordered table-hover table-striped" style="width:50%"><tbody>');
        } else if (fn.subtype != subtype) {
            newHTML.push('</tbody></table><div><b>' + fn.type + ' - ' + fn.subtype + '</b></div><table class="table table-bordered table-hover table-striped" style="width:50%"><tbody>');
        }
        newHTML.push('<tr><td><a href="' + fn.url + '" target="_blank" class="externalURL">' + fn.value + '</a></td></tr>');
        subtype = fn.subtype;
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}

/**
 * Displays Topology Feature Data on Protein tab
 * @param {*} feature 
 */
function getFeature(feature) {
    var type = "";
    var newHTML = [];
    newHTML.push('<br><div class="text-format-left">');
    $.each(feature, function(m, ft) {
        if (type == "") {
            newHTML.push('<div><b class="titleCase">Topology</b></div><table class="table table-bordered table-hover table-striped" style="width:75%"><thead><tr class="matrixHeading">' +
                '<th>Feature Key</th><th>Position(s)</th><th>Length</th><th>Description</th><th>Graphical view</th></tr></thead><tbody>');
        } else if (ft.type != type) {
            newHTML.push('</tbody></table><div><b class="titleCase">' + ft.type + '</b></div><table class="table table-bordered table-hover table-striped" style="width:75%"><thead>' +
                '<tr class="matrixHeading"><th>Feature Key</th><th>Position(s)</th><th>Length</th><th>Description</th><th>Graphical view</th></tr></thead><tbody>');
        }
        newHTML.push('<tr><td>' + ft.feature + '</td><td>' + ft.start + ' - ' + ft.end + '</td><td>' + ft.length + '</td><td>' + ft.desc + '</td><td style="padding-left:10px;">' +
            '<div id="f' + m + '"></td></div></tr>');
        type = ft.type;
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}
/**
 * Displays Graphical view slider for Topology feature section on Protein tab
 * @param {*} arrayFeature 
 */
function triggerFSlider(arrayFeature) {
    $.each(arrayFeature, function(m, tp) {
        var newend = Number(tp.end) + 2;
        //console.log("start is : "+tp.start+" end is : "+newend);
        $("#f" + m).slider({ disabled: true, range: true, min: 1, max: 355, values: [tp.start, newend] });
    });
}
/**
 * Displays Cross-references section on Protein tab
 * @param {*} references 
 */
function getReferences(references) {
    var category = "";
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><h4><b><a>Cross-references</a></b></h4></div><div class="text-format-left">');
    $.each(references, function(m, rf) {
        if (category == "") {
            newHTML.push('<div><b class="titleCase">' + rf.category + '</b></div><table class="table table-bordered table-hover table-striped" style="width:50%"><tbody>');
        } else if (rf.category != category) {
            newHTML.push('</tbody></table><div><b class="titleCase">' + rf.category + '</b></div><table class="table table-bordered table-hover table-striped" style="width:50%"><tbody>');
        }
        newHTML.push('<tr><td style="width:20%">' + rf.type + '</td><td style="width:80%"><a href="' + rf.url + '" target="_blank" class="externalURL">' + rf.id + '</a> ' + rf.value + '</td></tr>');
        category = rf.category;
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}
/**
 * Displays Sequence info on Protein Tab
 * @param {*} sequence 
 */
function getSequence(sequence) {
    var arrayResults = stringsplit(sequence.toString());
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><b>Sequence</b></div><div class="text-format-left" style="border: 1px solid #ddd;width:60%;" ><table class="table" cellspacing="0" cellpadding="0"><tr>');
    $.each(arrayResults, function(index, value) {
        if (index % 5 == 0)
            newHTML.push('</tr><tr>');
        newHTML.push('<td style="padding-right:1em;border:none;">' + value + '</td>');
    });
    newHTML.push('</tr></table></div>');
    return newHTML.join("");
}
/**
 * 
 * @param {*} comment 
 */
function getComments(comment) {
    var type = "";
    var newHTML = [];
    newHTML.push('<div class="text-format-left">');
    $.each(comment, function(m, ft) {
        if (type == "") {
            newHTML.push('<div><b class="titleCase">' + ft.type + '</b></div><table class="table table-bordered table-hover table-striped" style="width:60%"><tbody>');
        } else if (ft.type != type) {
            newHTML.push('</tbody></table><div><b class="titleCase">' + ft.type + '</b></div><table class="table table-bordered table-hover table-striped" style="width:60%"><tbody>');
        }
        newHTML.push('<tr><td>' + ft.ctext + '</td></tr>');
        type = ft.type;
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}
/**
 * Displays Phenotypes data on Gene tab
 * @param {*} phenotypes 
 */
function getPhenotypes(phenotypes) {
    var type = "";
    var newHTML = [];
    newHTML.push('<div class="text-format-left">');
    $.each(phenotypes, function(m, ft) {
        if (type == "") {
            newHTML.push('<div><b>' + ft.type + '</b></div><table class="table table-bordered table-hover table-striped"><tbody>');
        } else if (ft.type != type) {
            newHTML.push('</tbody></table><div><b>' + ft.type + '</b></div><table class="table table-bordered table-hover table-striped"><tbody>');
        }
        newHTML.push('<tr><td>' + ft.description + '<br>' + ft.source + '</td></tr>');
        type = ft.type;
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}

/**
 * Displays Summary info for both Gene and Protein tab
 * @param {*} dataarray 
 */
function getData(dataarray) {
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table class="table table-bordered table-hover table-striped" style="width:70%"><tbody>');
    $.each(dataarray[0], function(key, value) {
        if(value != null){
            newHTML.push('<tr><td style="width:20%">' + key + '</td><td style="width:80%">' + value + '</td></tr>');
        }
    });
    newHTML.push('</tbody></table></div>');
    return newHTML.join("");
}
/**
 * Displays Variation links on Gene tab
 * @param {*} dataarray 
 */
function getValueOnly(dataarray) {
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table class="table table-bordered" style="width:50%">');
    $.each(dataarray[0], function(key, value) {
        newHTML.push('<tr><td style="padding-right:1em;border:none;">' + value + '</td></tr>');
    });
    newHTML.push('</table></div>');
    return newHTML.join("");
}
/**
 * Displays Bibliography section GeneRIFs : Gene References Into Functions on Gene tab
 * @param {*} dataarray 
 * @param {*} allGenerif 
 */
function getGenerifs(dataarray, allGenerif) {
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table class="table table-bordered"><tr><td style="border:none;padding-left:1em;"><b>GeneRIFs: Gene References Into Functions</b></td></tr>');
    $.each(dataarray, function(key, value) {
        newHTML.push('<tr><td style="padding-right:1em;padding-left:1em;border:none;">' + (key + 1) + ". " + value.generif + '</td></tr>');
    });
    newHTML.push('<tr><td style="border:none;padding-left:1em;"><b>' + allGenerif + '</b></td></tr></table></div>');
    return newHTML.join("");
}
/**
 * Displays Bibliography section : Related articles in PubMed on Gene tab
 * @param {*} dataarray 
 * @param {*} allPubmed 
 * @param {*} allHomoloGene 
 */
function getPubmed(dataarray, allPubmed, allHomoloGene) {
    var newHTML = [];
    newHTML.push('<div class="text-format-left"><table class="table table-bordered"><tr><td style="border:none;padding-left:1em;"><b>Related articles in PubMed</b></td></tr>');
    $.each(dataarray, function(key, value) {
        newHTML.push('<tr><td style="padding-right:1em;padding-left:1em;border:none;">' + (key + 1) + ". " + value.pub + '</td></tr>');
    });
    newHTML.push('<tr><td style="border:none;padding-left:1em;"><b>' + allPubmed + '</b></td></tr><tr><td style="border:none;padding-left:1em;"><b>' + allHomoloGene + '</b></td></tr></table></div>');
    return newHTML.join("");
}

/**
 * check for empty object json
 * @param {*} obj 
 */
function isEmpty(obj) {
    return Object.keys(obj).length === 0;
}

/**
 * Displays Gene Ontology data on Gene tab
 * @param {*} geneOntology 
 */
function getGeneOntology(geneOntology) {
    if (geneOntology.length > 0) {
        var type = "";
        var newHTML = [];
        newHTML.push('<div class="text-format-left"><b>Gene Ontology</b></div><div class="text-format-left">');
        $.each(geneOntology, function(m, ft) {
            if (type == "") {
                newHTML.push('<table class="table table-bordered table-hover table-striped" style="width:70%"><thead><tr class="matrixHeading"><th>' + ft.type + '</th><th>Evidence Code</th><th>Pubs</th></tr></thead><tbody>');
            } else if (ft.type != type) {
                newHTML.push('</tbody></table><table class="table table-bordered table-hover table-striped" style="width:70%"><thead><tr class="matrixHeading"><th>' + ft.type + '</th><th>Evidence Code</th><th>Pubs</th></tr></thead><tbody>');
            }
            if (ft.Pubmed != null) {
                newHTML.push('<tr><td style="width:70%">' + ft.Label + '</td><td style="width:15%">' + ft.Evidence + '</td><td style="width:15%">' + ft.Pubmed + '</td></tr>');
            } else {
                newHTML.push('<tr><td style="width:70%">' + ft.Label + '</td><td style="width:15%">' + ft.Evidence + '</td><td style="width:15%"></td></tr>');
            }
            type = ft.type;
        });
        newHTML.push('</tbody></table></div>');
    }
    return newHTML.join("");
}
/**
 * Displays Markers Infomation on Gene tab
 * @param {*} markers 
 */
function getMarkers(markers) {
    if (markers.length > 0) {
        var newHTML = [];
        newHTML.push('<div class="text-format-left"><b>Markers</b></div><div class="text-format-left"><table class="table table-bordered" style="width:50%"><tr>');
        $.each(markers, function(index, value) {
            if (index % 3 == 0)
                newHTML.push('</tr><tr>');
            newHTML.push('<td style="padding-right:1em;border:none;">' + value.marker + '<br>' + value.markerdbid + '</td>');
        });
        newHTML.push('</tr></table></div>');
    }
    return newHTML.join("");
}
/**
 * Displays NCBI Reference Sequences info on Gene tab
 * @param {*} refseq 
 */
function getRefSeq(refseq) {
    var newHTML = [];
    var heading = "";
    if (refseq.length > 0) {
        newHTML.push('<div class="text-format-left">');
        $.each(refseq, function(index, value) {
            if (heading == "")
                newHTML.push('<div class="text-format-left"><span style="line-height: 30px;font-weight: bold;">' + value.heading + '</span>');
            if (heading != "" && heading != value.heading)
                newHTML.push('</div><div class="text-format-left"><span style="line-height: 30px;font-weight: bold;">' + value.heading + '</span>');
            if (value.subheading != null)
                newHTML.push('<div class="text-format-left">' + value.subheading + '</div>');
            newHTML.push('<table class="table table-bordered" style="width:60%;margin-left:35px;"><tr class="matrixHeading"><td colspan=2><i>' + value.type + '</i></td></tr><tr><td colspan=2><b>' + value.accession + '</b></td></tr>');
            if (value.status != null)
                newHTML.push('<tr><td colspan=2><b>Status : ' + value.status + '</b></td></tr>');
            if (value.sourceSeq != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">Source sequence(s) </td><td>' + value.sourceSeq + '</td></tr>');
            if (value.consensus != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">Consensus CDS </td><td>' + value.consensus + '</td></tr>');
            if (value.swissport != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">UniProtKB/Swiss-Prot </td><td>' + value.swissport + '</td></tr>');
            if (value.tremble != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">UniProtKB/TrEMBL </td><td>' + value.tremble + '</td></tr>');
            if (value.related != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">Related </td><td>' + value.related + '</td></tr>');
            if (value.conservedDomains != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">Conserved Domains </td><td>' + value.conservedDomains + '</td></tr>');
            if (value.range != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">Range </td><td>' + value.range + '</td></tr>');
            if (value.download != null)
                newHTML.push('<tr><td style="text-align:right;color:#777777;">Download </td><td>' + value.download + '</td></tr>');
            newHTML.push('</table>');
            heading = value.heading;
        });
        newHTML.push('</div></div>');
    }
    return newHTML.join("");
}

/**
 * This function splits sequence to 10 characters
 * @param {*} str 
 */
function stringsplit(str) {
    var chunks = [];
    var chunkSize = 10;
    while (str) {
        if (str.length < chunkSize) {
            chunks.push(str);
            break;
        } else {
            chunks.push(str.substr(0, chunkSize));
            str = str.substr(chunkSize);
        }
    }
    return chunks;
}