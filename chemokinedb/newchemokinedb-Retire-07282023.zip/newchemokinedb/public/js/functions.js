var ligand = "";
/**
 * This function shows the overview data from IUPHAR database
 * @param {*} id 
 * @param {*} parentName 
 */
function getOverview(id, parentName) {
    contentLoading();
    if (parentName == "Receptor") {
        $.post('iuphar', {
            "id": (id + "")
        }, function(data) {
            cleanup();
            // Adding tabs
            $("#tabs").append('<button class="btn btn-default pull-right" onclick="showFunctionTable(\'' + id + '\')">Function</button>');
            $.each(data.arraySpecies, function(m, sps) {
                $("#tabs").append('<button class="btn btn-default" onclick="selectTreeNode(\'' + sps.speciesId + '\')">' + sps.species + '</button>');
            });
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>OVERVIEW</a></b></h4></div>');
            $("#maincontent").append(getData(data.arrayData));
            //Endogenous Ligands
            $("#maincontent").append('<div class="text-format-left"><b>Endogenous Ligands</b>:</div>' + getEndogenousLigand(data.arrayObj));
            // Details Section
            $('#maincontent').append('<div id="detail_container"><div class="text-format-left"><a class="clickDetails"><h4><b style="float:left;padding-right:5px;">DETAILS</b>' +
                '<i><h5 style="padding-top:2px;">(click to see Details)</h5></i></h4></a></div><div id="detailsSection"></div></div>');
            $("#detailsSection").hide();
            $('.clickDetails').click(function() {
                if ($('#detailsSection').is(":visible")) {
                    $('#detailsSection').hide();
                    $('#clickText').show();
                } else {
                    $('#detailsSection').show();
                    $('#clickText').hide();
                }
            });
            // Adding Gene And Protein Info to Details Section
            if (data.geneNProteinInfo.length > 0)
                $("#detailsSection").append('<div class="text-format-left"><b>Gene and Protein Information</b>:</div>' + getJSONArray(data.geneNProteinInfo));
            // Adding Database Links to Details Section
            if (data.databaseLinks.length > 0)
                $("#detailsSection").append('<div class="text-format-left"><b>Database Links</b>:</div>' + getDatabaseLinks(data.databaseLinks, data.arraySpecies));
            //Adding Agonists to Detail Section
            if (data.arrayAgonists.length > 0)
                $("#detailsSection").append('<div class="text-format-left"><b>Agonists</b>:</div>' + getJSONArray(data.arrayAgonists));
            //Adding Antagonists to Detail Section
            if (data.arrayAntagonists.length > 0)
                $("#detailsSection").append('<div class="text-format-left"><b>Antagonists</b>:</div>' + getJSONArray(data.arrayAntagonists));
            //Adding Primary Transduction to Detail Section
            if (!isEmpty(data.primaryTrans))
                $("#detailsSection").append('<div class="text-format-left"><b>Primary Transduction Mechanisms</b>:</div>' + getJSONArray(data.primaryTrans));
            //Adding Secondary Transduction to Detail Section
            if (!isEmpty(data.secondaryTrans))
                $("#detailsSection").append('<div class="text-format-left"><b>Secondary Transduction Mechanisms</b>:</div>' + getJSONArray(data.secondaryTrans));
        }, 'json');
    } else if (parentName == "Ligand") {
        $.post('iuphar', {
            "id": (id + "")
        }, function(data) {
            cleanup();
            $("#tabs").append('<button class="btn btn-default pull-right" onclick="showFunctionTable(\'' + id + '\')">Function</button>');
            $.each(data.arraySpecies, function(m, sps) {
                $("#tabs").append('<button class="btn btn-default" onclick="selectTreeNode(\'' + sps.speciesId + '\')">' + sps.species + '</button>');
            });
            // Ligand Data
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>OVERVIEW</a></b></h4></div>');
            $("#maincontent").append(getData(data.arrayData));
            $("#maincontent").append('<div class="text-format-left"><table class="table table-bordered table-hover table-striped" style="width:70%"><tbody><tr><td style="width:20%">Endogenous Targets</td><td style="width:80%">' + getEndogenousTargets(data.arrayTargets, data.arrayTargetsExternal) + '</td></tr></tbody></table></div>');
            $("#maincontent").append('<div class="text-format-left"><b>Gene/Precursor:</b><div>');
            $("#maincontent").append(getJSONArray(data.arrayGenePrecursor));
            //Details Section
            $('#maincontent').append('<div id="detail_container"><div class="text-format-left"><a class="clickDetails"><h4><b style="float:left;padding-right:5px;">DETAILS</b>' +
                '<i><h5 style="padding-top:2px;">(click to see Details)</h5></i></h4></a></div><div id="detailsSection"></div></div>');
            $("#detailsSection").hide();
            $('.clickDetails').click(function() {
                if ($('#detailsSection').is(":visible")) {
                    $('#detailsSection').hide();
                    $('#clickText').show();
                } else {
                    $('#detailsSection').show();
                    $('#clickText').hide();
                }
            });
            //Adding Database Links to details section
            $("#detailsSection").append('<div class="text-format-left"><b>Database Links</b>:</div>' + getDatabaseLinks(data.databaseLinks, data.arraySpecies));
            //Adding Agonists to Detail Section
            if (data.arrayAgonists.length > 0) {
                $("#detailsSection").append('<div class="text-format-left"><b>Biological Activity</b>:</div>' + getJSONArray(data.arrayAgonists));
            }
            //Adding Structure to details section
            $("#detailsSection").append('<div class="text-format-left"><b>Structure</b>:</div>' + getJSONArray(data.arrayStructure));
            //Adding Similar Sequences to details section
            if (data.arraySimilarSeq.length > 0)
                $("#detailsSection").append('<div class="text-format-left"><b>Similar Sequences</b>:</div>' + getJSONArray(data.arraySimilarSeq));
        }, 'json');
    }
}

// 
/**
 * This function gets Species Details (Data from NCBI) when user clicks on Gene tab
 * @param {*} id 
 */
function getSpeciesOverview(id) {
    contentLoading();
    $.post('genbank', {
        "id": (id + "")
    }, function(data) {
        cleanup();
        // Adding tabs
        $("#tabs").html('<button class="btn btn-default active">Gene</button><button class="btn btn-default" onclick="getProteinData(\'' + id + '\')">Protein</button>');
        $("#tabs").append('<button class="btn btn-default pull-right" onclick="showFunctionTable(\'' + id + '\')">Function</button>');


        // Summary
        if (data.arrayData.length > 0){
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>Summary</a></b></h4></div>' + getData(data.arrayData));
        }else{
            $("#maincontent").append('<div class="text-format-left"><h4><b>No data available</b></h4></div>');
        }
        // Genomic Context
        if (data.arrayGenomicContext.length > 0)
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>Genomic context</a></b></h4></div>' + getJSONArray(data.arrayGenomicContext));
        // Bibliography
        if (data.arrayGenerifs.length > 0)
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>Bibliography</a></b></h4></div>' + getPubmed(data.arrayPubmed, data.allPubmed, data.allHomoloGene) + getGenerifs(data.arrayGenerifs, data.allGenerifs));
        // Phenotypes
        if (data.arrayPhenotypes.length > 0)
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>Phenotypes</a></b></h4></div>' + getPhenotypes(data.arrayPhenotypes));
        // Variation
        if (data.variationData.length > 0)
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>Variation</a></b></h4></div>' + getValueOnly(data.variationData));
        //HIV Interactions
        if (data.arrayHIVInteraction.length > 0)
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>HIV Interactions</a></b></h4></div>' + getJSONArray(data.arrayHIVInteraction));
        // Interactions
        if (data.arrayInteraction.length > 0)
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>Interactions</a></b></h4></div>' + getJSONArray(data.arrayInteraction));
        // General gene information
        if (data.arrayMarkers.length > 0)
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>General gene information</a></b></h4></div>' + //getMarkers(data.arrayMarkers) +
            '<div class="text-format-left"><b>Homology</b></div>' + getValueOnly(data.homologyData) + getGeneOntology(data.arrayGeneOntology));
        // General protein information
        if (data.generalData.length > 0)
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>General protein information</a></b></h4></div>' + getData(data.generalData));
        // Ref Seq
        if (data.arrayRefSeq.length > 0)
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>NCBI Reference Sequences (RefSeq)</a></b></h4></div>' + getRefSeq(data.arrayRefSeq));
        // Related Seq
        if (data.arrayRelatedSeq.length > 0)
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>Related sequences</a></b></h4></div>' + getJSONArray(data.arrayRelatedSeq));


    }, 'json');
}

/**
 * This function show data from Uniprot when user clicks on Protein tab
 * @param {*} id 
 */
function getProteinData(id) {
    contentLoading();
    $.post('uniprot', {
        "id": (id + "")
    }, function(data) {
        cleanup();
        $("#breadcrumbs").html(getBreadCrumb().replace('Gene', 'Protein'));
        // Adding tabs
        $("#tabs").html('<button class="btn btn-default" onclick="getSpeciesOverview(\'' + id + '\')">Gene</button><button class="btn btn-default active">Protein</button>');
        $("#tabs").append('<button class="btn btn-default pull-right" onclick="showFunctionTable(\'' + id + '\')">Function</button>');


        // Names and Taxonomy
        if (data.arrayData.length > 0){
            $("#maincontent").append('<div class="text-format-left"><h4><b><a>Names & Taxonomy</a></b></h4></div>');
            $("#maincontent").append(getData(data.arrayData));
        }
        // Functions
        if (data.arrayGofunc.length > 0){
        $("#maincontent").append('<div class="text-format-left"><h4><b><a>Function</a></b></h4></div><div class="text-format-left" style="padding-bottom:10px;">' +
            data.functionText + '</div> ' + getGOFunc(data.arrayGofunc));
        }
        // Sequence
        if (data.sequence.length > 0)
            $("#maincontent").append(getSequence(data.sequence));
        // Features
        if (data.arrayFeature.length > 0){
            $("#maincontent").append(getFeature(data.arrayFeature));
            triggerFSlider(data.arrayFeature);
        }

        if (data.arrayInteractions.length > 0)
            $("#maincontent").append('<div class="text-format-left"><b>Binary interactions</b></div>' + getJSONArray(data.arrayInteractions));

        if (data.arrayComments.length > 0)
        $("#maincontent").append(getComments(data.arrayComments));
        // Cross References
        if (data.arraydatabases.length > 0)
        $("#maincontent").append(getReferences(data.arraydatabases));

    }, 'json');
}

/**
 * 
 */
function getContactUs() {
    $('#searchQuery').val('');
    $(document).scrollTop(0);
    $("#breadcrumbs").html('<ol class="breadcrumb"><li><a href="">Home</a></li><li>Contact Us</li></ol>');
    $("#container_outside").html('<div id="overview_container"></div>');
    $("#overview_container").html('<div style="padding:40px;padding-top:10px;"><p class="lead">The NIAID Office of Cyber Infrastructure and Computational Biology Bioinformatics and Computational Biosciences Branch (NIAID/OCICB/BCBB) welcomes your feedback for improvement of the Tuberculosis Regulatory Network Analysis Tool. Please report bugs, provide suggestions for development, and ask questions by sending an email to:<br><h3>scienceapps at niaid.nih.gov</h3></p></div>');
}

/**
 * Shows Loading info while getting data from server
 */
function contentLoading() {
    $("body").css("background-color", "white");
    $("#relatedcontent").html('');
    $("#cdb-maincontent").removeClass('col-md-7');
    $("#cdb-maincontent").addClass('col-md-10');
    $("#breadcrumbs").html('');
    $(document).scrollTop(0);
    $('#searchQuery').val('');
    $("#maincontent").html('<div class="text-format-left"><h4><b>Loading ... <br>Please wait ... </b></h4><br><div class="progress" style="width:90%">' +
        '<div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="40" aria-valuemin="0" ' +
        'aria-valuemax="100" style="width:40%"><span class="sr-only">40% Complete (success)</span></div></div></div>');
}

/**
 * Cleans up contents of main page
 */
function cleanup() {
    $("#maincontent").html('');
    $("#tabs").html('');
    $("#breadcrumbs").html(getBreadCrumb());
}