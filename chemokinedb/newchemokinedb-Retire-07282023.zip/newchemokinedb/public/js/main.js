// Global variables
var _selected_node = null;
var breadcrumbText = "";
var parentName = "";

$(document).ready(function() {
    var externalWarning = true;
    $(document).scrollTop(0);
    $('#searchQuery').val('');

    // Displays warning message
    $('#maincontent').on("click", "a.externalURL", function() {
        if (externalWarning) {
            externalWarning = false;
            alert("You are about to leave the ChemokineDB website and view the content of an external website. NIAID cannot be held responsible for the content of external websites.");
        }
    });

    // This is ajax request to get default tweet data to events page
    $.post('getTweets', function(data) {
        //$('#twitterblock').html(getTweetsResults(data.arrayTweets));
        getTweetsResults(data.arrayTweets);
    }, 'json');

    // Displays tree menu on left side
    $('#tree1').tree({
        data: data,
        buttonLeft: false,
        selectable: true,
        onCreateLi: function(node, $li) {
            /*console.log(node.id);
            if (node.id == 0){
                $('.jqtree-element').removeClass('newcolor');
            }else{
                $('.jqtree-element').addClass('newcolor');
            }*/
        },
        onCanSelectNode: function(node) {
            collapseOtherNodes(node);
            if (node.children.length == 0) {
                setBreadCrumb('<ol class="breadcrumb"><li><a href="">Home</a></li><li>' + node.parent.parent.parent.name + '</li><li>' + node.parent.parent.name + '</li><li><a onclick="selectTreeNode(\'' + node.parent.id + '\')">' + node.parent.name + '</a></li><li>' + node.name + ' Gene</li></ol>');
                getSpeciesOverview(node.id);
            } else if (node.id != 0) {
                parentName = node.parent.name;
                if (node.parent.parent.name != null && node.parent.parent.name != "undefined") {
                    parentName = node.parent.parent.name;
                    if (node.parent.parent.parent.name != null && node.parent.parent.parent.name != "undefined") {
                        parentName = node.parent.parent.parent.name;
                    }
                }
                _selected_node = node;
                setBreadCrumb('<ol class="breadcrumb"><li><a href="">Home</a></li><li>' + node.parent.parent.name + '</li><li>' + node.parent.name + '</li><li><a>' + node.name + '</a></li></ol>');
                getOverview(node.id, parentName);
                return true;
            } else {
                if (node.is_open)
                    $('#tree1').tree('closeNode', node);
                else
                    $('#tree1').tree('openNode', node);
                return false;
            }
        }
    });

    $('#tree1').bind(
        'tree.open',
        function(e) {
            collapseOtherNodes(e.node);
        }
    );

    $('#tree1').bind(
        'tree.click',
        function(event) {
            if (_selected_node != null) {
                $('#tree1').tree('removeFromSelection', _selected_node);
            }
        }
    );

    $('#searchQuery').keypress(function(e) {
        if (e.which == 13) {
            e.preventDefault(); //Enter is key 13
            executeSearch();
        }
    });

    $('#searchbutton').click(function(e) {
        e.preventDefault();
        executeSearch();
    });

    var isScrolledIntoView = function(elem) {
        var $elem = $(elem);
        var $window = $(window);
        var docViewTop = $window.scrollTop();
        var docViewBottom = docViewTop + $window.height();
        var elemTop = $elem.offset().top;
        var elemBottom = elemTop + $elem.height();
        return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
    }

});

/**
 * Sets breadcrumb value
 * @param {*} text 
 */
function setBreadCrumb(text) {
    breadcrumbText = text;
}
/**
 * Gets breadcrumb value
 */
function getBreadCrumb() {
    return breadcrumbText;
}
/**
 * This function shows the function table
 * @param {*} id 
 */
function showFunctionTable(id) {
    $("#maincontent").html('');
    $.post('functiondata', {
        "id": (id + "")
    }, function(data) {
        //Adding Functions
        if (data.arrayFunctions.length > 0) {
            $("#maincontent").append('<div id="func_container" style="width:94%"><div><a><h4><b>FUNCTION ANNOTATION TABLE</b></h4></a></div>');
            $("#maincontent").append(getFunctionTable(data.arrayFunctions));
            var table = $('#functionDataTable').DataTable({
                "paging": false,
                initComplete: function() {
                    this.api().columns().every(function() {
                        var column = this;
                        var select = $('<select><option value=""></option></select>')
                            .appendTo($(column.footer()).empty())
                            .on('change', function() {
                                var val = $.fn.dataTable.util.escapeRegex($(this).val());
                                column.search(val ? '^' + val + '$' : '', true, false).draw();
                            });

                        column.data().unique().sort().each(function(d, j) {
                            select.append('<option value="' + d + '">' + d + '</option>')
                        });
                    });
                },
                dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf'
                ]
            });
        }
        // $('#maincontent').css("height","99%");       
    });
}

/**
 * Sorts an array with property
 * @param {*} property 
 */
function dynamicSort(property) {
    var sortOrder = 1;
    if (property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function(a, b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}

/**
 * Collapses rest of selected nodes
 * @param {*} _node_open 
 */
function collapseOtherNodes(_node_open) {
    var node_level = _node_open.getLevel();
    if (node_level == "1") {
        var node1 = _node_open.getNextSibling();
        if (node1 == null)
            node1 = _node_open.getPreviousSibling();
        closeNodeWithChildren(node1);
    } else if (node_level == "2") {
        closeAllNextSiblings(4, _node_open);
        closeAllPreviousSiblings(4, _node_open);
    } else if (node_level == "3") {
        closeAllNextSiblings(23, _node_open);
        closeAllPreviousSiblings(23, _node_open);
    }
}

/**
 * Closes all the previous sibling nodes in the tree menu
 * @param {*} length 
 * @param {*} node 
 */
function closeAllPreviousSiblings(length, node) {
    //checking previous
    var node2 = node;
    for (i = 0; i < length; i++) {
        if (node2 != null) {
            node2 = node2.getPreviousSibling();
            if (node2 != null)
                closeNodeWithChildren(node2);
        } else
            break;
    }
}

/**
 * Closes all the next sibling nodes in the tree menu
 * @param {*} length 
 * @param {*} node 
 */
function closeAllNextSiblings(length, node) {
    //checking previous
    var node2 = node;
    for (i = 0; i < length; i++) {
        if (node2 != null) {
            node2 = node2.getNextSibling();
            if (node2 != null)
                closeNodeWithChildren(node2);
        } else
            break;
    }
}

/**
 * This func closes node with children nodes
 * @param {*} node 
 */
function closeNodeWithChildren(node) {
    $('#tree1').tree('closeNode', node);
    for (var i = 0; i < node.children.length; i++) {
        $('#tree1').tree('closeNode', node.children[i]);
    }
}

/**
 * Displays Tweets data
 * @param {*} arrayTweets 
 */
function getTweetsResults(arrayTweets) {
    var newHTML = [];
    newHTML.push('<div class="static-header" data-scribe="section:header"><h4 data-scribe="element:title">Tweets</h4></div>');
    $.each(arrayTweets, function(k, val) {
        if (val.retweeted == "null") {
            var turl = "https://twitter.com/ImmuneSpace/status/" + val.id;
            $.getJSON("https://api.twitter.com/1/statuses/oembed.json?id=" + val.id + "&align=center&callback=?",
                function(data) {
                    newHTML.push(data.html);
                });
        }
    });
    setTimeout(function() {
        console.log("html is  :   " + newHTML.join(""));
        $('#twitterblock').html(newHTML.join(""));
        return 1;
    }, 1000);

}

/**
 * Performs search
 */
function executeSearch() {
    $("#maincontent").html('');
    $.post('search', {
        "term": ($('#searchQuery').val() + "")
    }, function(data) {
        console.log("id is " + data.id);
        if (data.id == "none" || data.id == "") {
            $("#breadcrumbs").html('');
            $("#maincontent").html('<div id="overview"></div>');
            $("#overview").html('<div id="inner_container"><div class="text-format-left"><h3>No Results Found</h3></div>');
        } else {
            selectTreeNode(data.id);
            $(window).scrollTop(0);
        }
    }, 'json');
}

/*function getTweetsResults(arrayTweets) {
    var newHTML = [];
    //newHTML.push('<div class="timeline-Widget timeline-Widget--edge" data-iframe-title="Twitter Timeline" lang="en" data-twitter-event-id="0">');
    // newHTML.push('<div class="timeline-Header timeline-InformationCircle-widgetParent" data-scribe="section:header"><h5 class="timeline-Header-title" data-scribe="element:title">Tweets</h5></div>');
    newHTML.push('<div class="static-header" data-scribe="section:header"><h4 data-scribe="element:title">Tweets</h4></div>');

    // newHTML.push('');
    newHTML.push('<div class="timeline-Body customisable-border timeline-Widget">');
    //newHTML.push('<div class="timeline-Viewport"><ol class="timeline-TweetList">');
    $.each(arrayTweets, function(k, val) {
        newHTML.push('<li class="timeline-TweetList-tweet customisable-border">');
        // retweeted information
        if (val.retweeted != "null") {
            newHTML.push('<div class="timeline-Tweet-retweetCredit"><div class="timeline-Tweet-retweetCreditIcon"><div class="Icon Icon--retweetBadge " aria-label="" title="" role="presentation"></div></div>' + val.retweeted + '</div>');
        }
        //author information
        newHTML.push('<div class="timeline-Tweet-author  js-inViewportScribingTarget"><a class="TweetAuthor-avatar  Identity-avatar u-linkBlend" data-scribe="element:user_link" href="https://twitter.com/' + val.screen_name + '" aria-label="' + val.name + ' (screen name: ' + val.screen_name + ')"><img class="Avatar Avatar--edge" alt="UserImage" data-scribe="element:avatar" data-src-1x="' + val.user_profile_image + '" src="' + val.user_profile_image + '"></a>');
        newHTML.push('<div class="TweetAuthor js-inViewportScribingTarget" data-scribe="component:author"><a class="TweetAuthor-link Identity u-linkBlend" data-scribe="element:user_link" href="https://twitter.com/' + val.screen_name + '" aria-label="' + val.name + ' (screen name: ' + val.screen_name + ')">   <div class="TweetAuthor-nameScreenNameContainer"><span class="TweetAuthor-decoratedName">');
        newHTML.push('<span class="TweetAuthor-name Identity-name customisable-highlight" title="' + val.name + '" data-scribe="element:name">' + val.name + '</span> </span><span class="TweetAuthor-screenName Identity-screenName" title="@' + val.screen_name + '" data-scribe="element:screen_name" dir="ltr">@' + val.screen_name + '</span></div></a></div></div>');
        //tweet text
        newHTML.push('<a href="https://twitter.com/' + val.screen_name + '/status/' + val.id + '"><p class="timeline-Tweet-text" lang="en" dir="ltr">' + val.text + '</p></a>');
        //media
        if (val.media != "null") {
            newHTML.push('<div class="timeline-Tweet-media"><article class="MediaCard customisable-border" data-scribe="component:card" dir="ltr"><div class="MediaCard-media"><div class="MediaCard-widthConstraint js-cspForcedStyle" style="max-width: 1024px" data-style="max-width: 1024px"><div class="MediaCard-mediaContainer js-cspForcedStyle" style="padding-right: 5.0000%" data-style="padding-right: 5.0000%"><a href="https://twitter.com/' + val.screen_name + '/status/' + val.id + '"><img class="NaturalImage-image" data-image="' + val.media + '" width="1024" height="768" title="View image on Twitter" alt="View image on Twitter" src="' + val.media + '"></a></div></div></div></article></div>');
        }
        newHTML.push('</li>');
    });
    newHTML.push('</div>');
    //return newHTML.join("</div></ol></div>");
    return newHTML.join("");
}*/