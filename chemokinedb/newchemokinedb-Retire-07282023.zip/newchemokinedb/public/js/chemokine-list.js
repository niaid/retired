

var data = [
            {
                label: 'Receptor', id: 0,
                children: [
                           { label: 'CC', id:  0,
                        	   children: [
                        	              { label: 'R1', id: 'REC1',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R12'},
                        	            	             { label: 'Mouse', id: 'R13'},
                        	            	             { label: 'Rat', id: 'R14'}
                        	            	             ]
                        	              },
                        	              { label: 'R2', id: 'REC2',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R17'},
                        	            	             { label: 'Mouse', id: 'R18'},
                        	            	             { label: 'Rat', id: 'R19'}
                        	            	             ]
                        	              },
                        	              { label: 'R3', id: 'REC3',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R20'},
                        	            	             { label: 'Mouse', id: 'R21'},
                        	            	             { label: 'Rat', id: 'R22'}
                        	            	             ]
                        	              },
                        	              { label: 'R4', id: 'REC4',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R23'},
                        	            	             { label: 'Mouse', id: 'R24'}
                        	            	             ]
                        	              },
                        	              { label: 'R5', id: 'REC5',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R25'},
                        	            	             { label: 'Mouse', id: 'R26'},
                        	            	             { label: 'Rat', id: 'R27'}
                        	            	             ]
                        	              },
                        	              { label: 'R6', id: 'REC6',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R28'},
                        	            	             { label: 'Mouse', id: 'R29'},
                        	            	             { label: 'Rat', id: 'R30'}
                        	            	             ]
                        	              },
                        	              { label: 'R7', id: 'REC7',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R31'},
                        	            	             { label: 'Mouse', id: 'R32'},
                        	            	             { label: 'Rat', id: 'R33'}
                        	            	             ]
                        	              },
                        	              { label: 'R8', id: 'REC8',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R34'},
                        	            	             { label: 'Mouse', id: 'R35'},
                        	            	             { label: 'Rat', id: 'R36'}
                        	            	             ]
                        	              },
                        	              { label: 'R9', id: 'REC9',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R37'},
                        	            	             { label: 'Mouse', id: 'R38'},
                        	            	             { label: 'Rat', id: 'R39'}
                        	            	             ]
                        	              },
                        	              { label: 'R10', id: 'REC10',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R15'},
                        	            	             { label: 'Mouse', id: 'R16'}
                        	            	             ]
                        	              },
                        	              { label: 'RL2', id: 'REC11',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R40'},
                        	            	             { label: 'Mouse', id: 'R41'},
                        	            	             { label: 'Rat', id: 'R42'}
                        	            	             ]
                        	              }
                        	              ]
                           },
                           
                           { label: 'CXC', id: 0 ,
                        	   children: [
                        	              { label: 'R1', id: 'REC12',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R46'},
                        	            	             { label: 'Mouse', id: 'R47'},
                        	            	             { label: 'Rat', id: 'R48'}
                        	            	             ]
                        	              },
                        	              { label: 'R2', id: 'REC13',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R49'},
                        	            	             { label: 'Mouse', id: 'R50'},
                        	            	             { label: 'Rat', id: 'R51'}
                        	            	             ]
                        	              },
                        	              { label: 'R3', id: 'REC14',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R52'},
                        	            	             { label: 'Mouse', id: 'R53'},
                        	            	             { label: 'Rat', id: 'R54'}
                        	            	             ]
                        	              },
                        	              { label: 'R4', id: 'REC15',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R55'},
                        	            	             { label: 'Mouse', id: 'R56'},
                        	            	             { label: 'Rat', id: 'R57'}
                        	            	             ]
                        	              },
                        	              { label: 'R5', id: 'REC16',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R58'},
                        	            	             { label: 'Mouse', id: 'R59'},
                        	            	             { label: 'Rat', id: 'R60'}
                        	            	             ]
                        	              },
                        	              { label: 'R6', id: 'REC17',
                        	            	  children: [
                        	            	             { label: 'Human', id: 'R61'},
                        	            	             { label: 'Mouse', id: 'R62'}
                        	            	             ]
                        	              }
                        	              ]
                           		},
                           	 
                        { label: 'CX3C', id: 0 ,
                             children: [
                                        { label: 'R1', id: 'REC18',
                             	           children: [
                             	            	       { label: 'Human', id: 'R43'},
                             	            	        { label: 'Mouse', id: 'R44'},
                             	            	        { label: 'Rat', id: 'R45'}
                             	            	     ]
                             	              }
                             	              ]
                                },
                        { label: 'XC', id: 0 ,
                            children: [
                                       { label: 'R1', id: 'REC19',
                            	           children: [
                            	            	       { label: 'Human', id: 'R63'},
                            	            	        { label: 'Mouse', id: 'R64'}
                            	            	     ]
                            	              }
                            	              ]
                               },
                       	{ label: 'ACK', id: 0,
                           	children: [
                       		           { label: 'R1', id: 'REC20',
                       		        	   children: [
                       		        	              { label: 'Human', id: 'R1'},
                       		        	              { label: 'Mouse', id: 'R2'}
                       		       	              ]
                       			           },
                       			          { label: 'R2', id: 'REC21',
                       			       	   children: [
                       			       	              { label: 'Human', id: 'R3'},
                       			       	              { label: 'Mouse', id: 'R4'},
                       			       	              { label: 'Rat', id: 'R5'}
                       			       	              ]
                       			           },
                       			           { label: 'R3', id: 'REC22',
                       			        	   children: [
                       			        	              { label: 'Human', id: 'R6'},
                       			        	              { label: 'Mouse', id: 'R7'},
                       			        	              { label: 'Rat', id: 'R8'}
                       			        	              ]
                       			           },
                       			           { label: 'R4', id: 'REC23',
                       			        	   children: [
                       			        	              { label: 'Human', id: 'R9'},
                       			        	              { label: 'Mouse', id: 'R10'},
                       			        	              { label: 'Rat', id: 'R11'}
                       			        	              ]
                       			           }
                       			           ]
                           		},
                        { label: 'Virus', id: 0 ,
                            children: [
                                     { label: 'E1', id:  0,
                                       children: [
                                                  { label: 'equine herpesvirus 2', id: 'R65'}
                                                 ]
                                     },
                                     { label: 'ECRF3', id:  0,
                                       children: [
                                                  { label: 'Herpesvirus saimiri', id: 'R66'}
                                                 ]
                                     },
                                     { label: 'US28', id:  0,
                                       children: [
                                                  { label: 'HHV5', id: 'R67'}
                                                 ]
                                     },
                                     { label: 'U12', id:  0,
                                       children: [
                                                  { label: 'HHV6', id: 'R68'},
                                                  { label: 'HHV7', id: 'R69'}
                                                 ]
                                     },
                                     { label: 'U51', id:  0,
                                       children: [
                                                  { label: 'HHV6', id: 'R70'},
                                                  { label: 'HHV7', id: 'R71'}
                                                 ]
                                     },
                                     { label: 'VGPCR_HHV8P', id:  0,
                                       children: [
                                                  { label: 'HHV8', id: 'R72'}
                                                 ]
                                     },
                                     { label: '74', id:  0,
                                       children: [
                                                  { label: 'equine herpesvirus 2', id: 'R73'}
                                                 ]
                                     },
                                     { label: 'UL33', id:  0,
                                       children: [
                                                  { label: 'HHV5', id: 'R74'}
                                                 ]
                                     }
                                    ]
                         }
                           		

                              ]
            	},            
            	{

                    label: 'Ligand', id: 0,
                    children: [
                               { label: 'CC', id:  0,
                            	   children: [
                            	              { label: 'L1', id: 'LIG1',
                            	            	  children: [
                            	            	             { label: 'Human', id: 'L1'},
                          			        	              { label: 'Mouse', id: 'L44'}
                            	            	             ]
                            	              },
                            	              { label: 'L2', id: 'LIG2',
                            	            	  children: [
                            	            	             	{ label: 'Human', id: 'L2'},
                            	            	             	{ label: 'Mouse', id: 'L45'},
                            	            	             	{ label: 'Rat', id: 'L72'}
                            	            	             ]
                            	              },
                            	              { label: 'L3', id: 'LIG3',
                            	            	  children: [
                            	            	             	{ label: 'Human', id: 'L3'},
                            	            	             	{ label: 'Mouse', id: 'L46'},
                            	            	             	{ label: 'Rat', id: 'L73'}
                            	            	             ]
                            	              },
                            	              { label: 'L4', id: 'LIG4',
                            	            	  children: [
                            	            	             	{ label: 'Human', id: 'L4'},
                            	            	             	{ label: 'Mouse', id: 'L47'},
                            	            	             	{ label: 'Rat', id: 'L74'}
                            	            	             ]
                            	              },
                            	              { label: 'L5', id: 'LIG5',
                            	            	  children: [
                            	            	             	{ label: 'Human', id: 'L5'},
                            	            	             	{ label: 'Mouse', id: 'L48'},
                            	            	             	{ label: 'Rat', id: 'L75'}
                            	            	             ]
                            	              },
                            	              { label: 'L7', id: 'LIG6',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L6'},
                           			        	              { label: 'Mouse', id: 'L49'}
                            	            	             ]
                            	              },
                            	              { label: 'L8', id: 'LIG7',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L7'},
                           			        	              { label: 'Mouse', id: 'L50'}
                            	            	             ]
                            	              },
                            	              { label: 'L11', id: 'LIG8',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L8'},
                           			        	              { label: 'Mouse', id: 'L51'},
                           			        	              { label: 'Rat', id: 'L77'}
                            	            	             ]
                            	              },
                            	              { label: 'L12', id: 'LIG9',
                            	            	  children: [
                           			        	              { label: 'Mouse', id: 'L52'}
                            	            	             ]
                            	              },
                            	              { label: 'L13', id: 'LIG10',
                            	            	  children: [
                            	            	             { label: 'Human', id: 'L9'}
                            	            	             ]
                            	              },
                            	              { label: 'L14', id: 'LIG11',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L10'}
                            	            	             ]
                            	              },
                            	              { label: 'L15', id: 'LIG12',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L11'}
                            	            	             ]
                            	              },
                            	              { label: 'L16', id: 'LIG13',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L12'}
                            	            	             ]
                            	              },
                            	              { label: 'L17', id: 'LIG14',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L13'}
                            	            	             ]
                            	              },
                            	              { label: 'L19', id: 'LIG15',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L14'},
                           			        	              { label: 'Mouse', id: 'L53'}
                            	            	             ]
                            	              },
                            	              { label: 'L20', id: 'LIG16',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L15'},
                           			        	              { label: 'Mouse', id: 'L54'},
                           			        	              { label: 'Rat', id: 'L78'}
                            	            	             ]
                            	              },
                            	              { label: 'L21', id: 'LIG17',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L16'}
                            	            	             ]
                            	              },
                            	              { label: 'L22', id: 'LIG18',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L17'},
                           			        	              { label: 'Mouse', id: 'L55'}
                            	            	             ]
                            	              },
                            	              { label: 'L23', id: 'LIG19',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L18'}
                            	            	             ]
                            	              },
                            	              { label: 'L24', id: 'LIG20',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L19'},
                           			        	              { label: 'Mouse', id: 'L56'}
                            	            	             ]
                            	              },
                            	              { label: 'L25', id: 'LIG21',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L20'},
                           			        	              { label: 'Mouse', id: 'L57'}
                            	            	             ]
                            	              },
                            	              { label: 'L26', id: 'LIG22',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L21'}
                            	            	             ]
                            	              },
                            	              { label: 'L27', id: 'LIG23',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L22'},
                           			        	              { label: 'Mouse', id: 'L58'}
                            	            	             ]
                            	              },
                            	              { label: 'L28', id: 'LIG24',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L23'},
                           			        	              { label: 'Mouse', id: 'L59'}
                            	            	             ]
                            	              }
                            	              ]
                               },
                               
                               { label: 'CXC', id: 0 ,
                            	   children: [
                            	               { label: 'L1', id: 'LIG25',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L24'},
                           			        	              { label: 'Mouse', id: 'L60'},
                           			        	              { label: 'Rat', id: 'L79'}
                            	            	             ]
                            	              },
                            	              { label: 'L2', id: 'LIG26',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L25'},
                           			        	              { label: 'Mouse', id: 'L61'},
                           			        	              { label: 'Rat', id: 'L80'}
                            	            	             ]
                            	              },
                            	              { label: 'L3', id: 'LIG27',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L26'},
                           			        	              { label: 'Mouse', id: 'L62'},
                           			        	              { label: 'Rat', id: 'L81'}
                            	            	             ]
                            	              },
                            	              { label: 'L4', id: 'LIG28',
                            	            	  children: [
                            	            	             { label: 'Human', id: 'L27'}
                            	            	             ]
                            	              },
                            	              { label: 'L5', id: 'LIG29',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L28'},
                           			        	              { label: 'Mouse', id: 'L63'},
                           			        	              { label: 'Rat', id: 'L82'}
                            	            	             ]
                            	              },
                            	              { label: 'L6', id: 'LIG30',
                            	            	  children: [
                            	            	             { label: 'Human', id: 'L29'}
                            	            	             ]
                            	              },
                            	              { label: 'L7', id: 'LIG31',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L30'}
                            	            	             ]
                            	              },
                            	              { label: 'L8', id: 'LIG32',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L31'}
                            	            	             ]
                            	              },
                            	              { label: 'L9', id: 'LIG33',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L32'},
                           			        	              { label: 'Mouse', id: 'L64'}
                            	            	             ]
                            	              },
                            	              { label: 'L10', id: 'LIG34',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L33'},
                           			        	              { label: 'Mouse', id: 'L65'},
                           			        	              { label: 'Rat', id: 'L83'}
                            	            	             ]
                            	              },
                            	              { label: 'L11', id: 'LIG35',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L34'},
                           			        	              { label: 'Mouse', id: 'L66'}
                            	            	             ]
                            	              },
                            	              { label: 'L12_alpha', id: 'LIG36',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L35'}
                            	            	             ]
                            	              },
                            	              { label: 'L12_beta', id: 'LIG37',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L36'}
                            	            	             ]
                            	              },
                            	              { label: 'L13', id: 'LIG38',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L37'},
                          			        	              { label: 'Mouse', id: 'L67'}
                            	            	             ]
                            	              },
                            	              { label: 'L14', id: 'LIG39',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L38'}
                            	            	             ]
                            	              },
                            	              { label: 'L15', id: 'LIG40',
                            	            	  children: [
                            	            	              { label: 'Mouse', id: 'L68'}
                            	            	             ]
                            	              },
                            	              { label: 'L16', id: 'LIG41',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L39'},
                           			        	              { label: 'Mouse', id: 'L69'},
                           			        	              { label: 'Rat', id: 'L84'}
                            	            	             ]
                            	              },
                            	              { label: 'L17', id: 'LIG42',
                            	            	  children: [
                            	            	              { label: 'Human', id: 'L40'}
                            	            	             ]
                            	              }
                            	              ]
                               		},
                               	 
                            { label: 'CX3C', id: 0 ,
                                 children: [
                                            { label: 'L1', id: 'LIG43',
                                 	           children: [
                                 	            	       	{ label: 'Human', id: 'L41'},
                           			        	            { label: 'Mouse', id: 'L70'},
                           			        	            { label: 'Rat', id: 'L85'}
                                 	            	     ]
                                 	              }
                                 	              ]
                                    },
                            { label: 'XC', id: 0 ,
                                children: [
                                           { label: 'L1', id: 'LIG44',
                                	           children: [
                                	            	       { label: 'Human', id: 'L42'},
                           			        	            { label: 'Mouse', id: 'L71'},
                           			        	            { label: 'Rat', id: 'L86'}
                                	            	     ]
                            	              },
                            	              { label: 'L2', id: 'LIG45',
                                       	           children: [
                                       	            	       { label: 'Human', id: 'L43'}
                                       	            	     ]
                                       	              }
                                	              ]
                                   },
                            { label: 'Virus', id: 0 ,
                                children: [
                                           { label: 'vCXCL1', id: '0',
                                             children: [
                                                       { label: 'HHV5', id: 'L87'}
                                                     ]
                                            },
                                            { label: 'vCXCL2', id: '0',
                                             children: [
                                                       { label: 'HHV5', id: 'L97'}
                                                     ]
                                            },
                                            { label: 'vCCL4', id: '0',
                                             children: [
                                                       { label: 'HHV6b', id: 'L88'}
                                                     ]
                                            },
                                            { label: 'vMIP-I', id: '0',
                                             children: [
                                                       { label: 'HHV8', id: 'L89'}
                                                     ]
                                            },
                                            { label: 'vMIP-II', id: '0',
                                             children: [
                                                       { label: 'HHV8', id: 'L90'}
                                                     ]
                                            },
                                            { label: 'vMIP-III', id: '0',
                                             children: [
                                                       { label: 'HHV8', id: 'L91'}
                                                     ]
                                            },
                                            { label: 'MC148R/vMCC-I', id: '0',
                                             children: [
                                                       { label: 'MOCV', id: 'L92'}
                                                     ]
                                            },
                                            { label: 'gL', id: '0',
                                             children: [
                                                       { label: 'HHV2', id: 'L93'},
                                                       { label: 'HHV4', id: 'L94'}
                                                     ]
                                            },
                                            { label: 'UL128', id: '0',
                                             children: [
                                                       { label: 'HHV5', id: 'L95'}
                                                     ]
                                            },
                                            { label: 'UL130', id: '0',
                                             children: [
                                                       { label: 'HHV5', id: 'L96'}
                                                     ]
                                            },
                                            
                                            { label: 'mCK-2', id: '0',
                                             children: [
                                                       { label: 'MCMV', id: 'L98'}
                                                     ]
                                            }
                                          ]
                                   }
                                    
                                    
                               		]
                	
            	}
            ]