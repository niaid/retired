/* This route gets function data for a Receptor or Ligand from Neo4j database */
var express = require('express');
var router = express.Router();

router.post('/functiondata', function(req, res) {
  var dbconnectString = 'http://'
                    + req.app.get('config').db.username + ':'
                    + req.app.get('config').db.password + '@'
                    + req.app.get('config').db.host + ':'
                    + req.app.get('config').db.port ;

  var cypher = require('cypher-stream')(dbconnectString);
  var ckId = req.body.id;
  console.log(ckId);
  var resultdata={};  
  var arrayFunctions=[];
  var transaction = cypher.transaction()
        .on('data', function (result) {
            if(result["source"] != null){
                item = {}
                item["PMID"] = result["pubmed_id"];
                item["CitedFor"] = result["cited_for"];
                item["Function"] = result["function"]; 
                item["MeasurementTechnique"] = result["techinque"]; 
                item["Tissue"] = result["tissue"]; 
                item["Species"] = result["species"]; 
                item["RefernceType"] = "Primary"; 
                item["Source"] = result["source"]; 
                item["Titlepubl"] = result["title"]; 
                item["GenbankEntrezID"] = result["genbank_id"];      
                arrayFunctions.push(item);
            }
    });

    //Getting function data 
    if(ckId.indexOf("R") === 0){ 

      //NCBI data 
      if(ckId.indexOf("REC") === 0){
        transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkReceptor{ck_parent_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENERIFS]-(g) RETURN g.pmid as pubmed_id, "Function" as cited_for, "" as techinque, "" as tissue, r2.ncbiGeneRif as function, g.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })
         transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkReceptor{ck_parent_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_ONTOLOGY]-(g) OPTIONAL MATCH (b:PubMed) WHERE  b.pmid = toint(last(r2.goPubmed) ) RETURN last(r2.goPubmed) as pubmed_id, case g.goType  WHEN "Function" THEN "Molecular function" WHEN "Process" THEN "Biological process" WHEN "Component" THEN "Cellular component" END as cited_for, r2.goEvidence as techinque, "" as tissue, g.goLabel as function, b.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })
      }else{
        transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENERIFS]-(g) RETURN g.pmid as pubmed_id, "Function" as cited_for, "" as techinque, "" as tissue, r2.ncbiGeneRif as function, g.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })
        transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_ONTOLOGY]-(g) OPTIONAL MATCH (b:PubMed) WHERE  b.pmid = toint(last(r2.goPubmed) ) RETURN last(r2.goPubmed) as pubmed_id, case g.goType  WHEN "Function" THEN "Molecular function" WHEN "Process" THEN "Biological process" WHEN "Component" THEN "Cellular component" END as cited_for, r2.goEvidence as techinque, "" as tissue, g.goLabel as function, b.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })

      }  

      // Iuphar function data
      transaction.write({
      statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[o:CK_IUPHAR]-(p)-[q:CKFUNCTION_DATA_PUBMED]-(r)<-[t:ENTREZGENE_GENERIFS]-(s)  RETURN r.pmid as pubmed_id, q.ckFunctionCitedFor as cited_for, q.ckFunctionTechnique as techinque, q.ckFunctionTissue as tissue, q.ckFunction as function, q.ckFunctionTitle as title, q.ckFunctionSource as source, s.ncbiGeneId as genbank_id, q.ckFunctionSpecies as species, "primary" as refernceType',
        parameters : { ckid: ckId }
         });
      // Uniprot function data
      transaction.write({
      statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[o:CK_UNIPROT]-(p)-[q:CKFUNCTION_DATA_PUBMED]-(r)<-[t:ENTREZGENE_GENERIFS]-(s)  RETURN r.pmid as pubmed_id, q.ckFunctionCitedFor as cited_for, q.ckFunctionTechnique as techinque, q.ckFunctionTissue as tissue, q.ckFunction as function, q.ckFunctionTitle as title, q.ckFunctionSource as source, s.ncbiGeneId as genbank_id, q.ckFunctionSpecies as species, "primary" as refernceType',
        parameters : { ckid: ckId }
         });
    }else{

      //NCBI data 
      if(ckId.indexOf("LIG") === 0){
       transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENERIFS]-(g) RETURN g.pmid as pubmed_id, "Function" as cited_for, "" as techinque, "" as tissue, r2.ncbiGeneRif as function, g.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })
       transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkLigand{ck_parent_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_ONTOLOGY]-(g) OPTIONAL MATCH (b:PubMed) WHERE  b.pmid = toint(last(r2.goPubmed) ) RETURN last(r2.goPubmed) as pubmed_id, case g.goType  WHEN "Function" THEN "Molecular function" WHEN "Process" THEN "Biological process" WHEN "Component" THEN "Cellular component" END as cited_for, r2.goEvidence as techinque, "" as tissue, g.goLabel as function, b.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })

      }else{
       transaction.write({
        statement  : 'match (s)-[:SPECIES]-(n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENERIFS]-(g) RETURN g.pmid as pubmed_id, "Function" as cited_for, "" as techinque, "" as tissue, r2.ncbiGeneRif as function, g.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
        parameters : { ckid: ckId }
      })
       transaction.write({
          statement  : 'match (s)-[:SPECIES]-(n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_ONTOLOGY]-(g) OPTIONAL MATCH (b:PubMed) WHERE  b.pmid = toint(last(r2.goPubmed) ) RETURN last(r2.goPubmed) as pubmed_id, case g.goType  WHEN "Function" THEN "Molecular function" WHEN "Process" THEN "Biological process" WHEN "Component" THEN "Cellular component" END as cited_for, r2.goEvidence as techinque, "" as tissue, g.goLabel as function, b.pubmedTitle as title, "UNIGENE" as source, p.ncbiGeneId as genbank_id, s.ck_species as species, "primary" as refernceType',
          parameters : { ckid: ckId }
        })
     }
        // Iuphar function data
        transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[o:CK_IUPHAR]-(p)-[q:CKFUNCTION_DATA_PUBMED]-(r)<-[t:ENTREZGENE_GENERIFS]-(s)  RETURN r.pmid as pubmed_id, q.ckFunctionCitedFor as cited_for, q.ckFunctionTechnique as techinque, q.ckFunctionTissue as tissue, q.ckFunction as function, q.ckFunctionTitle as title, q.ckFunctionSource as source, s.ncbiGeneId as genbank_id, q.ckFunctionSpecies as species, "primary" as refernceType',
          parameters : { ckid: ckId }
           });
       // Uniprot function data
         transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[o:CK_UNIPROT]-(p)-[q:CKFUNCTION_DATA_PUBMED]-(r)<-[t:ENTREZGENE_GENERIFS]-(s)  RETURN r.pmid as pubmed_id, q.ckFunctionCitedFor as cited_for, q.ckFunctionTechnique as techinque, q.ckFunctionTissue as tissue, q.ckFunction as function, q.ckFunctionTitle as title, q.ckFunctionSource as source, s.ncbiGeneId as genbank_id, q.ckFunctionSpecies as species, "primary" as refernceType',
          parameters : { ckid: ckId }
           });

    }
  transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {      
        resultdata["arrayFunctions"] = arrayFunctions;      
        res.json(resultdata);
    });
});


module.exports = router;