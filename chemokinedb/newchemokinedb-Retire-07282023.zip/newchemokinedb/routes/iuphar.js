/* This route gets IUPHAR related data drom neo4j database */

var express = require('express');
var router = express.Router();

router.post('/iuphar', function(req, res) {
   var dbconnectString = 'http://'
                    + req.app.get('config').db.username + ':'
                    + req.app.get('config').db.password + '@'
                    + req.app.get('config').db.host + ':'
                    + req.app.get('config').db.port ;

   var cypher = require('cypher-stream')(dbconnectString);
  
    var ckId = req.body.id;
    console.log(ckId);
    var resultdata={};
    if(ckId.indexOf("R") === 0){    
       var arraySpecies=[], arrayData=[], arrayObj=[], geneNProteinInfo=[], databaseLinks=[], arrayAgonists=[], arrayAntagonists=[], primaryTrans=[], secondaryTrans=[];
        var transaction = cypher.transaction()
        .on('data', function (result) {
            if(result["speciesId"] != null){
                item = {}
                item ["speciesId"] = result["speciesId"];
                item ["species"] = result["species"];
                arraySpecies.push(item);
            }
            if(result["targetId"] != null){
                item = {}
                item ["Nomenclature"] = result["nomenclature"];
                item ["Previous and unofficial names"] = result["synonym"].replace(/\|/g, ", ");
                item ["Target Id"] = result["targetId"];
                item ["Family"] = result["family"];  
                arrayData.push(item);
            }
            if(result["ligandId"] != null){
                item = {}
                item ["id"] = result["ligandId"];
                item ["name"] = result["ligandName"];
                item ["species"] = result["ligandSpecies"]; 
                arrayObj.push(item);
            }
            if(result["aa"] != null){
                item = {}
                item ["AA"] = result["aa"];
                item ["Chromosomal Location"] = result["chromoLoc"];
                item ["Gene Symbol"] = result["geneSym"]; 
                item ["TM"] = result["tm"]; 
                item ["Gene Name"] = result["geneName"]; 
                item ["Species"] = result["species"]; 
                geneNProteinInfo.push(item);
            }
            if(result["dbname"] != null){
                item = {}
                item ["name"] = result["dbname"];
                item ["value"] = result["value"];
                //console.log(result["dbname"]+"\t"+result["value"]+"\t"+result["url"]+"\t"+result["species"]);
                if(null != result["url"]){        
                    item ["url"] = result["url"].replace("$PLACEHOLDER", result["value"]); 
                }else{
                    item ["url"] = result["url"]; 
                }
                
                item ["species"] = result["species"]; 
                if(result["dbname"] != "UniProtKB ID/Entry name")
                    databaseLinks.push(item);
            }
            if(result["ligand"] != null){
                item = {}
                item ["Ligand"] = result["ligand"];
                item ["Species"] = result["species"];
                item ["Action"] = result["action"]; 
                item ["Affinity"] = result["affinity"]; 
                item ["Units"] = result["units"]; 
                arrayAgonists.push(item);
            }
            if(result["ligandA"] != null){
                item = {}
                item ["Ligand"] = result["ligandA"];
                item ["Species"] = result["species"];
                item ["Action"] = result["action"]; 
                item ["Affinity"] = result["affinity"]; 
                item ["Units"] = result["units"]; 
                arrayAntagonists.push(item);
            }
            if(result["transducer"] != null){
                item = {}
                item ["Transducer"] = result["transducer"];
                item ["Effector/Response"] = result["effector"];
                item ["Comments"] = result["comments"]; 
                primaryTrans.push(item);
            }
            if(result["transducerS"] != null || result["effectorS"] != null){
                item = {}
                item ["Transducer"] = result["transducerS"];
                item ["Effector/Response"] = result["effectorS"];
                item ["Comments"] = result["comments"]; 
                secondaryTrans.push(item);
            }
    });
    //Getting Species Information
    transaction.write({
        statement  : 'match (n:CkReceptor{ck_parent_id: {ckid}})-[r:SPECIES]->(g) return n.ck_receptor_id as speciesId,g.ck_species as species order by g.ck_species',
        parameters : { ckid: ckId }
    });
     //Getting Overview Information
    transaction.write({
        //statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[:IUPHAR_RECEPTOR_2_FAMILY]-(f) return m.iupharTargetId as targetId,n.ck_receptor_name as nomenclature,f.iupharFamilyName as family,m.iupharTargetSynonyms as synonym',
        statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m) return m.iupharTargetId as targetId,n.ck_receptor_name as nomenclature,m.iupharTargetFamilyName as family,m.iupharTargetSynonyms as synonym',
        parameters : { ckid: ckId }
    });
    //Getting Endogenous Ligands Information
    transaction.write({
        statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[r:IUPHAR_INTERACTION]->(i),(l:CkLigand)-[:SPECIES]->(sp) where replace(replace(replace(replace(i.iupharLigandName,"</sub>",""),"<sub>",""),"&","_"),";","") = l.ck_ligand_name return distinct l.ck_ligand_id as ligandId,l.ck_ligand_name as ligandName,sp.ck_species as ligandSpecies ORDER BY l.ck_ligand_name, sp.ck_species',
         parameters : { ckid: ckId }
    });
    //Getting Gene and Protein Information
    transaction.write({
        statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[:IUPHAR_GENE_PROTEIN_INFO]-(o)-[:SPECIES]-(sp) return o.iupharTargetAminoAcids as aa,o.iupharTargetGenomicLocation as chromoLoc,o.iupharTargetGeneName as geneSym,o.iupharTargetTransmembraneDomains as tm,o.iupharTargetGeneLongName as geneName,sp.ck_species as species ORDER BY sp.ck_species',
        parameters : { ckid: ckId }
    });
    //Getting Database Links Information
    transaction.write({
        statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[:IUPHAR_DATABASE_LINK]-(l)-[:IUPHAR_DATABASE]-(d),(l)-[:SPECIES]->(s) return d.iupharDatabaseName as dbname,l.iupharDatabasePlaceholder as value,  d.iupharDatabaseUrl as url,s.ck_species as species ORDER BY d.iupharDatabaseName, s.ck_species',
        parameters : { ckid: ckId }
    });
    //Getting Agonists Information
    transaction.write({
        statement  : 'match(n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[r:IUPHAR_INTERACTION]-(i) where r.iupharInteractionType ="Agonist" return i.iupharLigandName as ligand,r.iupharInteractionAffinityUnits as units,r.iupharInteractionAction as action,CASE round(10*toFloat(r.iupharInteractionAffinityMedian))/10 WHEN null THEN toString(round(10*toFloat(r.iupharInteractionAffinityLow))/10)+"-"+toString(round(10*toFloat(r.iupharInteractionAffinityHigh))/10) ELSE round(10*toFloat(r.iupharInteractionAffinityMedian))/10 END as affinity,r.iupharInteractionTargetSpecies as species ORDER by units DESC',
        parameters : { ckid: ckId }
    });
    //Getting Antagonist Information
    transaction.write({
        statement  : 'match(n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[r:IUPHAR_INTERACTION]-(i) where r.iupharInteractionType ="Antagonist" return i.iupharLigandName as ligandA,r.iupharInteractionAffinityUnits as units,r.iupharInteractionAction as action, CASE round(10*toFloat(r.iupharInteractionAffinityMedian))/10 WHEN null THEN toString(round(10*toFloat(r.iupharInteractionAffinityLow))/10)+"-"+toString(round(10*toFloat(r.iupharInteractionAffinityHigh))/10) ELSE round(10*toFloat(r.iupharInteractionAffinityMedian))/10 END as affinity, r.iupharInteractionTargetSpecies as species ORDER by units DESC',
        parameters : { ckid: ckId }
    });
    //Getting Primary Transduction Information
    transaction.write({
        statement  : 'match(n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[r:IUPHAR_TRANSDUCTION]-(i) where i.iupharTransductionSecondary="0" return i.iupharTransducer as transducer, i.iupharEffector as effector, i.iupharTransductionComments as comments',
        parameters : { ckid: ckId }
    });
    //Getting Secondary Transduction Information
    transaction.write({
        statement  : 'match(n:CkReceptor{ck_receptor_id: {ckid}})-[:CK_IUPHAR]->(m)-[r:IUPHAR_TRANSDUCTION]-(i) where i.iupharTransductionSecondary="1" return i.iupharTransducer as transducerS, i.iupharEffector as effectorS, i.iupharTransductionComments as comments',
        parameters : { ckid: ckId }
    });
   
    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {      
        resultdata["arraySpecies"] = arraySpecies;
        resultdata["arrayData"] = arrayData;
        resultdata["arrayObj"] = arrayObj;
        resultdata["geneNProteinInfo"] = geneNProteinInfo;
        resultdata["databaseLinks"] = databaseLinks;
        resultdata["arrayAgonists"] = arrayAgonists;
        resultdata["arrayAntagonists"] = arrayAntagonists;
        resultdata["primaryTrans"] = primaryTrans;
        resultdata["secondaryTrans"] = secondaryTrans;
        res.json(resultdata);
    });
}
else{
    //console.log(ckId);
   var arraySpecies=[], arrayData=[], arrayTargets=[], arrayGenePrecursor=[], arrayLinks=[], arrayAgonists=[], arrayStructure=[], 
   arraySimilarSeq=[], arrayTargetsExternal=[];
        var transaction = cypher.transaction()
        .on('data', function (result) {
            if(result["speciesId"] != null){
                item = {}
                item ["speciesId"] = result["speciesId"];
                item ["species"] = result["species"];
                arraySpecies.push(item);
            }
            if(result["ligandName"] != null){
                item = {}
                item ["Ligand Name"] = result["ligandName"];
                item ["Species"] = result["species"];
                arrayData.push(item);
            }
            if(result["target_name"] != null){
                item = {}
                item ["targetName"] = result["target_name"];
                item ["targetId"] = result["targer_id"];
                arrayTargets.push(item);
            }
              if(result["target_name_external"] != null){
                item = {}
                item ["targetName"] = result["target_name_external"];
                arrayTargetsExternal.push(item);
            }
            if(result["gene_name"] != null){
                item = {}
                item ["Gene symbol"] = result["gene_symbol"];
                item ["Gene name"] = result["gene_name"];
                item ["Species"] = result["species"];
                item ["Precursor protein name"] = result["protein_name"];
                item ["Synonyms"] = result["synonyms"];
                arrayGenePrecursor.push(item);
            }
            if(result["dbname"] != null){
                item = {}
                item ["name"] = result["dbname"];
                item ["value"] = result["value"];
               
                item ["species"] = result["species"];

                 if(null != result["url"]){        
                    item ["url"] = result["url"].replace("$PLACEHOLDER", result["value"]); 
                }else{
                    item ["url"] = result["url"]; 
                }

                arrayLinks.push(item);
            }
            if(result["target"] != null){
                item = {}
                item ["Target"] = result["target"];
                item ["Species"] = result["species"];
                item ["Action"] = result["action"];
                item ["Type"] = result["type"];
                item ["Affinity"] = result["affinity"];
                item ["Units"] = result["units"];
                arrayAgonists.push(item);
            }
            if(result["one_letter_s"] != null){
                item = {}
                item ["One Letter Sequence"] = result["one_letter_s"];
                item ["Three Letter Sequence"] = result["three_letter_s"];
                item ["Post-transitional Modification"] = result["ptm"];
                item ["Species"] = result["species"];
                arrayStructure.push(item);
            }
            if(result["sim_ligand"] != null){
                item = {}
                item ["Ligands"] = result["sim_ligand"];
                item ["Species"] = result["species"];
                arraySimilarSeq.push(item);
            }
            
            
            
    });
    //Getting Species Information
    transaction.write({
        statement  : 'match (n:CkLigand{ck_parent_id: {ckid}})-[r:SPECIES]->(g) return n.ck_ligand_id as speciesId,g.ck_species as species order by g.ck_species',
        parameters : { ckid: ckId }
    });
    //Getting Overview Information
    transaction.write({
        statement  : 'match (n:CkLigand{ck_parent_id: {ckid}})-[r:SPECIES]->(g) return n.ck_ligand_name as ligandName, collect(g.ck_species) as species',
        parameters : { ckid: ckId }
    });
    //getting Endogenous targets
     transaction.write({
        statement  : 'MATCH (ck:CkLigand{ck_parent_id : {ckid}})-[:CK_IUPHAR]-(k)-[:IUPHAR_INTERACTION]-(t)-[:CK_IUPHAR]-(c) where c.ck_parent_id ="ROOT" return c.ck_receptor_name as target_name , c.ck_receptor_id as targer_id order by target_name',
        parameters : { ckid: ckId }
    });
    //getting endogenous targets if they are not there in Chemokinedb
    transaction.write({
        statement  : 'MATCH (ck:CkLigand{ck_parent_id : {ckid}})-[:CK_IUPHAR]-(k)-[:IUPHAR_INTERACTION]-(t) return t.iupharTargetName as target_name_external order by target_name_external',
        parameters : { ckid: ckId }
    });
    //getting Gene and Precursor Information
     transaction.write({
        statement  : 'MATCH (ck:CkLigand{ck_parent_id : {ckid}})-[:CK_IUPHAR]-(k)-[:IUPHAR_GENE_AND_PRECURSOR]-(t) return t.iupharPrecursorProteinName as protein_name, t.iupharPrecursorSynonyms as synonyms, k.iupharLigandName as gene_symbol,t.iupharPrecursorGeneName as gene_name, t.iupharPrecursorSpecies as species',
        parameters : { ckid: ckId }
    });
    //Getting Database Links Information
    transaction.write({
        statement  : 'MATCH (ck:CkLigand{ck_parent_id : {ckid}})-[:CK_IUPHAR]-(k)-[:IUPHAR_DATABASE_LINK]-(l)-[:IUPHAR_DATABASE]-(d),(l)-[:SPECIES]->(s) return d.iupharDatabaseName as dbname,l.iupharDatabasePlaceholder as value,  d.iupharDatabaseUrl as url,s.ck_species as species ORDER BY d.iupharDatabaseName, s.ck_species',
        parameters : { ckid: ckId }
    });
    //Getting Agonists Information
    transaction.write({
        statement  : 'MATCH (ck:CkLigand{ck_parent_id : {ckid}})-[:CK_IUPHAR]-(m)-[r:IUPHAR_INTERACTION]-(i) return i.iupharTargetName as target,r.iupharInteractionAffinityUnits as units,r.iupharInteractionAction as action,r.iupharInteractionType as type, CASE round(10*toFloat(r.iupharInteractionAffinityMedian))/10 WHEN null THEN toString(round(10*toFloat(r.iupharInteractionAffinityLow))/10)+"-"+toString(round(10*toFloat(r.iupharInteractionAffinityHigh))/10) ELSE round(10*toFloat(r.iupharInteractionAffinityMedian))/10 END as affinity,r.iupharInteractionTargetSpecies as species ORDER by affinity DESC',
        parameters : { ckid: ckId }
    });
    //Getting Structure Information
    transaction.write({
        statement  : 'MATCH (ck:CkLigand{ck_parent_id : {ckid}})-[r:CK_IUPHAR]-(m),(ck)-[:SPECIES]->(s) return m.iupharLigandOneLetterSeq as one_letter_s,m.iupharLigandThreeLetterSeq as three_letter_s, m.iupharLigandPTM as ptm,s.ck_species as species',
        parameters : { ckid: ckId }
    });
    //Getting Similar Sequences Information
    transaction.write({
        statement  : 'match (ck:CkLigand{ck_parent_id: {ckid}})-[:IUPHAR]->(n)-[:SIMILAR_SEQUENCE]->(s),(l:IupharLigand)-[:SIMILAR_SEQUENCE]->(s),(ck)-[:SPECIES]->(sp)  return l.ligand_name as sim_ligand,sp.species as species',
        parameters : { ckid: ckId }
    });

    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {      
        resultdata["arraySpecies"] = arraySpecies;
        resultdata["arrayData"] = arrayData;
        resultdata["arrayTargets"] = arrayTargets;
        resultdata["arrayTargetsExternal"] = arrayTargetsExternal;    
        resultdata["arrayGenePrecursor"] = arrayGenePrecursor;
        resultdata["databaseLinks"] = arrayLinks;
        resultdata["arrayAgonists"] = arrayAgonists;
        resultdata["arrayStructure"] = arrayStructure;
        resultdata["arraySimilarSeq"] = arraySimilarSeq;
        res.json(resultdata);
    });
}
});


module.exports = router;
