/* This route gets Genbank related data drom neo4j database */

var express = require('express');
var router = express.Router();

//exports.genbank = function(req, res) {
router.post('/genbank', function(req, res) {
    var dbconnectString = 'http://' +
        req.app.get('config').db.username + ':' +
        req.app.get('config').db.password + '@' +
        req.app.get('config').db.host + ':' +
        req.app.get('config').db.port;

    var cypher = require('cypher-stream')(dbconnectString);
    var ckId = req.body.id;
    console.log(ckId);
    var resultdata = {};
    var arrayData = [],
        generalData = [],
        variationData = [],
        homologyData = [],
        arrayGenomicContext = [],
        allGenerifs = {},
        allPubmed = {},
        allHomoloGene = {},
        arrayPubmed = [],
        arrayGenerifs = [],
        arrayPhenotypes = [],
        arrayHIVInteraction = [],
        arrayInteraction = [],
        arrayMarkers = [],
        arrayGeneOntology = [],
        generalData = [],
        arrayRefSeq = [],
        arrayRelatedSeq = [],
        databaseList = [];
    var arrayRelated;
    var transaction = cypher.transaction()
        .on('data', function(result) {
            // Creating an array to store list of databases 
            if (result["databaseName"] != null) {
                item = {}
                item["name"] = result["databaseName"];
                item["url"] = result["databaseUrl"];
                databaseList.push(item);
            }
            // Creating an array to store Summary Information 
            if (result["u.ncbiGeneId"] != null) {
                item = {}
                item["Official Symbol"] = result["u.ncbiGeneSymbol"];
                item["Official Full Name"] = result["u.ncbiGeneDescription"];
                item["Gene Source"] = result["u.ncbiGeneSource"];
                item["Gene Type"] = result["u.ncbiGeneType"];
                item["RefSeq Status"] = result["u.ncbiRefseqStatus"];
                item["Organism"] = result["u.ncbiGeneOrganism"];
                item["Lineage"] = result["u.ncbiGeneLineage"];
                item["Synonyms"] = result["u.ncbiGeneSynonyms"];
                item["Summary"] = result["u.ncbiGeneSummary"];
                arrayData.push(item);
                item2 = {}
                item2["Names"] = result["u.ncbiGeneSummaryNames"];
                item2["Preferred Names"] = result["u.ncbiGenePreferredNames"];
                generalData.push(item2);
                item3 = {}
                item3["geneVar"] = result["u.ncbiGeneGeneVarUrl"];
                item3["dbVar"] = result["u.ncbiGeneDbVarUrl"];
                item3["orthodb"] = result["u.ncbiGeneOrthodbUrl"];
                variationData.push(item3);
                item4 = {}
                item4["homoloGene"] = "<a href='" + result["u.ncbiGeneHomologGeneUrl"] + "' target='_blank'>Homologs of the " + result["u.ncbiGeneSymbol"] + " gene</a>";
                //item4["mapViewer"] = result["u.ncbiGeneMapViewerUrl"];
                homologyData.push(item4);
                item5 = {}
                item5["Names"] = result["u.ncbiGeneSummaryNames"];
                item5["Preferred Names"] = result["u.ncbiGenePreferredNames"];
                generalData.push(item5);
                allGenerifs = result["u.ncbiGeneAllGenerifsUrl"];
                allPubmed = result["u.ncbiGeneAllPubmedUrl"];
                allHomoloGene = result["u.ncbiGeneAllHomologeneUrl"];
            }
            // Creating an array to store Genomic Context Information
            if (result["location"] != null) {
                var database = "";
                database = getItemByName(databaseList, "Assembly");
                item = {}
                item["Annotation Release"] = result["annotation_release"];
                item["Status"] = result["status"];
                item["Assembly"] = result["assembly"] + " (<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["assemblyId"]) + "' target='_blank'>" + result["assemblyId"] + "</a>)";
                item["Chromosome"] = result["chromosome"]; // add link url here  https://www.ncbi.nlm.nih.gov/genome/annotation_euk/Homo_sapiens/108/
                item["Location"] = result["location"];
                arrayGenomicContext.push(item);
            }
            // Creating an array to store Pubmed Information
            if (result["pmid"] != null) {
                var database = "";
                database = getItemByName(databaseList, "Pubmed");
                item = {}
                item["pub"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["pmid"]) + "' target='_blank'>" + result["pmtitle"] + "</a>";
                arrayPubmed.push(item);
            }
            // Creating an array to store Generif Information
            if (result["generif"] != null) {
                var database = "";
                database = getItemByName(databaseList, "Pubmed");
                item = {}
                item["generif"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["pubmedId"]) + "' target='_blank'>" + result["generif"] + "</a>";
                arrayGenerifs.push(item);
            }
            // Creating an array to store Phenotypes Information
            if (result["source"] != null) {
                var database = "";
                item = {}
                if (result["type"].toLowerCase().includes("nhgri gwa catalog")) {
                    database = getItemByName(databaseList, "NHGRI GWA Catalog");
                    item["source"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["source"]) + "' target='_blank'>NHGRI GWA Catalog</a>, ";
                    database = getItemByName(databaseList, "Pubmed");
                    item["source"] += "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["source"]) + "' target='_blank'>PubMed</a>";
                }
                item["description"] = result["description"];
                item["type"] = result["type"];
                arrayPhenotypes.push(item);
            }
            // Creating an array to store HIV Interaction Information
            if (result["gene"] != null) {
                var database = "";
                item = {}
                database = getItemByName(databaseList, "Protein");
                item["Protein"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["proteinId"]) + "' target='_blank'>" + result["protein"] + "</a>";
                database = getItemByName(databaseList, "Gene");
                item["Gene"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["geneId"]) + "' target='_blank'>" + result["gene"] + "</a>";
                item["Interaction"] = result["interaction"];
                database = getItemByName(databaseList, "Pubmed");
                item["Pubs"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["pubmed"]) + "' target='_blank'>PubMed</a>";
                arrayHIVInteraction.push(item);
            }
            // Creating an array to store Interaction Information
            if (result["iproduct"] != null) {
                var database = "";
                item = {}
                database = getItemByName(databaseList, "Protein");
                item["Products"] = result["iproduct"];
                if (null != result["idb"] && result["idb"].toLowerCase().includes("protein")) {
                    item["Interactant"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["iid"]) + "' target='_blank'>" + result["iinteractant"] + "</a>";
                } else {
                    item["Interactant"] = result["iinteractant"];
                }
                database = getItemByName(databaseList, "Gene");
                item["Other Gene"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["igeneid"]) + "' target='_blank'>" + result["igene"] + "</a>";
                item["Source"] = result["isource"];
                database = getItemByName(databaseList, "Pubmed");
                item["Pubs"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["ipubmed"]) + "' target='_blank'>PubMed</a>";
                item["Description"] = result["idescription"];
                arrayInteraction.push(item);
            }
            // Creating an array to store marker information
            if (result["marker"] != null) {
                var database = "";
                item = {}
                database = getItemByName(databaseList, "Probe");
                item["marker"] = result["marker"];
                if (database) {
                    item["markerdbid"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["markerId"]).replace("$SOURCE", result["markersource"]) + "' target='_blank'>" + result["markerdbId"] + "</a>";
                }
                arrayMarkers.push(item);
            }
            // Creating an array to store Gene Ontology information
            if (result["evidence"] != null) {
                var database = "";
                item = {}
                database = getItemByName(databaseList, "Evidence codes");
                item["Evidence"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["evidence"].toLowerCase()) + "' target='_blank'>" + result["evidence"] + "</a>";
                if (result["pubmed"] != null) {
                    database = getItemByName(databaseList, "Pubmed");
                    item["Pubmed"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["pubmed"]) + "' target='_blank'>PubMed</a>";
                }
                database = getItemByName(databaseList, "Amigo");
                if (database)
                    item["Label"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["goid"]) + "' target='_blank'>" + result["label"] + "</a>";
                item["type"] = result["type"];
                arrayGeneOntology.push(item);
            }
            // Creating an array to store Refseq information
            if (result["heading"] != null) {
                var database = "";
                item = {}
                database = getItemByName(databaseList, "Gene");
                item["heading"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["geneId"]) + "' target='_blank'>" + result["heading"] + "</a>";
                item["subheading"] = result["sub_heading"];
                item["type"] = result["type"];
                item["accession"] = result["accession"];
                if (result["proteinNcbiRefseqAccesion"] != null) {
                    item["type"] = item["type"] + "and Protein(s) ";
                    database = getItemByName(databaseList, "Nucleotide");
                    item["accession"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["accession"]) + "' target='_blank'>" + result["accession"] + "</a>";
                    database = getItemByName(databaseList, "Protein");
                    item["accession"] += " -> " + "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["proteinNcbiRefseqAccesion"]) + "' target='_blank'>" + result["proteinNcbiRefseqAccesion"] + "</a> " + result["ncbiRefseqDescription"];
                }
                item["status"] = result["status"];
                if (result["source_seq"] != null) {
                    database = getItemByName(databaseList, "Nucleotide");
                    item["sourceSeq"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["source_seq"]) + "' target='_blank'>" + result["source_seq"] + "</a>";
                }
                item["range"] = result["range"];
                if (result["range"]) {
                    database = getItemByName(databaseList, "GenBank");
                    item["download"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["accession"]).replace("$FROM", result["rangefrom"]).replace("$TO", result["rangeto"]) + "' target='_blank'>GenBank</a>";
                    database = getItemByName(databaseList, "FASTA");
                    item["download"] += ", <a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["accession"]).replace("$FROM", result["rangefrom"]).replace("$TO", result["rangeto"]) + "' target='_blank'>FASTA</a>";
                    database = getItemByName(databaseList, "Sequence Viewer");
                    item["download"] += ", <a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["accession"]).replace("$FROM", result["rangefrom"]).replace("$TO", result["rangeto"]) + "' target='_blank'>Sequence Viewer (Graphics)</a>";
                }
                if (result["ncbiRefseqDatabaseInfo"]) {
                    var related = "";
                    for (i = 0; i < result["ncbiRefseqDatabaseInfo"].length; i++) {
                        database = getItemByName(databaseList, "Uniprot");
                        if (result["ncbiRefseqDatabaseInfo"][i][0].toLowerCase().includes("trembl")) {
                            if (database)
                                item["tremble"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["ncbiRefseqDatabaseInfo"][i][1]) + "' target='_blank'>" + result["ncbiRefseqDatabaseInfo"][i][1] + "</a>";
                        } else if (result["ncbiRefseqDatabaseInfo"][i][0].toLowerCase().includes("swiss")) {
                            if (database)
                                item["swissport"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["ncbiRefseqDatabaseInfo"][i][1]) + "' target='_blank'>" + result["ncbiRefseqDatabaseInfo"][i][1] + "</a>";
                        } else if (result["ncbiRefseqDatabaseInfo"][i][0].toLowerCase().includes("vega") || result["ncbiRefseqDatabaseInfo"][i][0].toLowerCase().includes("ensembl")) {
                            database = getItemByName(databaseList, result["ncbiRefseqDatabaseInfo"][i][0]);
                            if (related.length != 0) {
                                related = related + ", ";
                            }
                            related += "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["ncbiRefseqDatabaseInfo"][i][1]) + "' target='_blank'>" + result["ncbiRefseqDatabaseInfo"][i][1] + "</a>";
                        } else if (result["ncbiRefseqDatabaseInfo"][i][0].toLowerCase().includes("ccds")) {
                            database = getItemByName(databaseList, result["ncbiRefseqDatabaseInfo"][i][0]);
                            item["consensus"] = "<a href='" + database["url"].replace("$VIJAYSPLACEHOLDER", result["ncbiRefseqDatabaseInfo"][i][1]) + "' target='_blank'>" + result["ncbiRefseqDatabaseInfo"][i][1] + "</a>";
                        } else if (result["ncbiRefseqDatabaseInfo"][i][0].toLowerCase().includes("protein")) {
                            item["conservedDomains"] = result["ncbiRefseqDatabaseInfo"][i][1];
                        }
                    }
                    item["related"] = related;
                }
                arrayRefSeq.push(item);
            }

            // Getting Related seq information
            if (result["ncbiGeneRelatedSequences"] != null) {
                for (i = 0; i < result["ncbiGeneRelatedSequences"].length; i++) {
                    if (result["ncbiGeneRelatedSequences"][i].length !== 0) {
                        arrayRelated = result["ncbiGeneRelatedSequences"][i].split(";");
                        item = {}
                        item["Heading"] = arrayRelated[0];
                        item["Accession and Version"] = arrayRelated[1];
                        item["Protein"] = arrayRelated[2];
                        if (arrayRelated[2]) {
                            arrayRelatedSeq.push(item);
                        }
                    }
                }
            }

        });

    // Getting list of databases
    transaction.write({
        statement: 'MATCH (n:NcbiDatabase) RETURN n.ncbiDatabaseName as databaseName, n.ncbiDatabaseUrl as databaseUrl'
    });

    // Getting Summary Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]->(u) return u.ncbiGeneSymbol, u.ncbiGeneDescription, u.ncbiGeneType, u.ncbiRefseqStatus, u.ncbiGeneLineage, u.ncbiGeneOrganism, u.ncbiGeneSource, u.ncbiGeneSynonyms, u.ncbiGeneSummary, u.ncbiGeneSummaryNames, u.ncbiGenePreferredNames, u.ncbiGeneGeneVarUrl, u.ncbiGeneDbVarUrl, u.ncbiGeneOrthodbUrl, u.ncbiGeneHomologGeneUrl, u.ncbiGeneMapViewerUrl, u.ncbiGeneAllGenerifsUrl, u.ncbiGeneAllPubmedUrl, u.ncbiGeneAllHomologeneUrl, u.ncbiGeneId',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]->(u) return u.ncbiGeneSymbol, u.ncbiGeneDescription, u.ncbiGeneType, u.ncbiRefseqStatus, u.ncbiGeneLineage, u.ncbiGeneOrganism, u.ncbiGeneSource, u.ncbiGeneSynonyms, u.ncbiGeneSummary, u.ncbiGeneSummaryNames, u.ncbiGenePreferredNames, u.ncbiGeneGeneVarUrl, u.ncbiGeneDbVarUrl, u.ncbiGeneOrthodbUrl, u.ncbiGeneHomologGeneUrl, u.ncbiGeneMapViewerUrl, u.ncbiGeneAllGenerifsUrl, u.ncbiGeneAllPubmedUrl, u.ncbiGeneAllHomologeneUrl, u.ncbiGeneId',
            parameters: { ckid: ckId }
        });
    }

    // Getting Genomic Context Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENOMIC_CONTEXT]-(g) RETURN  r2.ncbiGenomeAnnotationLocation as location, g.ncbiGenomeAnnotationStatus as status, g.ncbiGenomeAssemblyName as assembly, g.ncbiGenomeAssemblyId as assemblyId, r2.ncbiGenomeAnnotationChromosome as chromosome, g.ncbiGenomeAnnotationRelease as annotation_release',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENOMIC_CONTEXT]-(g) RETURN  r2.ncbiGenomeAnnotationLocation as location, g.ncbiGenomeAnnotationStatus as status, g.ncbiGenomeAssemblyName as assembly, g.ncbiGenomeAssemblyId as assemblyId, r2.ncbiGenomeAnnotationChromosome as chromosome, g.ncbiGenomeAnnotationRelease as annotation_release',
            parameters: { ckid: ckId }
        });
    }

    // Getting Pubmed Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_RELATED_PUBMED]-(g) RETURN g.pmid as pmid, g.pubmedTitle as pmtitle limit 10',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_RELATED_PUBMED]-(g) RETURN g.pmid as pmid, g.pubmedTitle as pmtitle limit 10',
            parameters: { ckid: ckId }
        });
    }

    // Getting Generif Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENERIFS]-(g) RETURN r2.ncbiGeneRif as generif, g.pmid as pubmedId limit 10',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_GENERIFS]-(g) RETURN r2.ncbiGeneRif as generif, g.pmid as pubmedId limit 10',
            parameters: { ckid: ckId }
        });
    }

    // Getting Phenotypes Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_PHENOTYPES]-(g) RETURN g.ncbiPhenotypeSourceId as source, g.ncbiPhenotypeDescription as description, g.ncbiPhenotypeType as type',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_PHENOTYPES]-(g) RETURN g.ncbiPhenotypeSourceId as source, g.ncbiPhenotypeDescription as description, g.ncbiPhenotypeType as type',
            parameters: { ckid: ckId }
        });
    }

    // Getting HIV Interaction Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_HIV_INTERACTIONS]-(g) RETURN g.ncbiGeneSymbol as gene,g.ncbiGeneId as geneId, r2.ncbiHivInteractionsProteinName as protein, r2.ncbiHivInteractionsProteinId as proteinId, r2.ncbiHivInteractionsPubmed as pubmed, r2.ncbiHivInteraction as interaction order by gene',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_HIV_INTERACTIONS]-(g) RETURN g.ncbiGeneSymbol as gene,g.ncbiGeneId as geneId, r2.ncbiHivInteractionsProteinName as protein, r2.ncbiHivInteractionsProteinId as proteinId, r2.ncbiHivInteractionsPubmed as pubmed, r2.ncbiHivInteraction as interaction order by gene',
            parameters: { ckid: ckId }
        });
    }

    // Getting Interaction Information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_INTERACTIONS]-(g) return CASE r2.ncbiInteractionsProductName WHEN null THEN r2.ncbiInteractionsProductDb+":"+r2.ncbiInteractionsProductId ELSE r2.ncbiInteractionsProductName END as iproduct, g.ncbiGeneSymbol as igene,  CASE r2.ncbiInteractionsInteractantName WHEN null THEN r2.ncbiInteractionsInteractantDb+":"+r2.ncbiInteractionsInteractantId ELSE r2.ncbiInteractionsInteractantName END as iinteractant, r2.ncbiInteractionsSource as isource, r2.ncbiInteractionsPubmed as ipubmed, r2.ncbiInteractionsDescription as idescription, r2.ncbiInteractionsInteractantDb as idb, r2.ncbiInteractionsInteractantId as iid, g.ncbiGeneId as igeneid',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_INTERACTIONS]-(g) return CASE r2.ncbiInteractionsProductName WHEN null THEN r2.ncbiInteractionsProductDb+":"+r2.ncbiInteractionsProductId ELSE r2.ncbiInteractionsProductName END as iproduct, g.ncbiGeneSymbol as igene,  CASE r2.ncbiInteractionsInteractantName WHEN null THEN r2.ncbiInteractionsInteractantDb+":"+r2.ncbiInteractionsInteractantId ELSE r2.ncbiInteractionsInteractantName END as iinteractant, r2.ncbiInteractionsSource as isource, r2.ncbiInteractionsPubmed as ipubmed, r2.ncbiInteractionsDescription as idescription, r2.ncbiInteractionsInteractantDb as idb, r2.ncbiInteractionsInteractantId as iid, g.ncbiGeneId as igeneid',
            parameters: { ckid: ckId }
        });
    }

    // Getting marker information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_MARKERS]-(g) RETURN g.ncbiMarkerName as marker, g.ncbiMarkerSource as markersource, g.ncbiMarkerDbId as markerdbId, g.ncbiMarkerId as markerId',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_MARKERS]-(g) RETURN g.ncbiMarkerName as marker, g.ncbiMarkerSource as markersource, g.ncbiMarkerDbId as markerdbId, g.ncbiMarkerId as markerId',
            parameters: { ckid: ckId }
        });
    }

    // Getting Gene Ontology information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_ONTOLOGY]-(g) return r2.goEvidence as evidence, r2.goPubmed as pubmed, g.goLabel as label, g.goType as type, g.goId as goid order by type',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_ONTOLOGY]-(g) return r2.goEvidence as evidence, r2.goPubmed as pubmed, g.goLabel as label, g.goType as type, g.goId as goid order by type',
            parameters: { ckid: ckId }
        });
    }

    // Getting Refseq information
    if (ckId.indexOf("R") === 0) {
        // Getting RefSeq genomic data
        transaction.write({
            //statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:GENBANK_ANNOTATIONS]->(u)-[:GENBANK_REFSEQ]->(g) return g.heading, g.sub_heading, g.type, g.accession, g.status, g.source_seq, g.consensus, g.swiss_prot, g.trembl, g.related, g.range, g.download',
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_REFSEQ]-(g) where g.ncbiRefseqType= "genomic" return g.ncbiRefseqHeading as heading, g.ncbiRefseqSubHeading as sub_heading, g.ncbiRefseqType as type, g.ncbiRefseqAccesion as accession, g.ncbiRefseqStatus as status, g.ncbiRefseqSource as source_seq, r2.ncbiRefseqRange as range, r2.ncbiRefseqFrom as rangefrom, r2.ncbiRefseqTo as rangeto, p.ncbiGeneId as geneId',
            parameters: { ckid: ckId }
        });
        // Getting RefSeq mRNA data
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_REFSEQ]-(g), (k:NcbiRefSeq)-[h]-(i) where k.ncbiRefseqAccesion = g.ncbiRefseqAccesion and g.ncbiRefseqType= "mRNA" return g.ncbiRefseqHeading as heading, g.ncbiRefseqSubHeading as sub_heading, g.ncbiRefseqType as type, g.ncbiRefseqAccesion as accession, g.ncbiRefseqStatus as status, g.ncbiRefseqSource as source_seq, r2.ncbiRefseqRange as range, p.ncbiGeneId as geneId, collect([i.ncbiRefseqDatabase , coalesce(i.ensemblId , i.uniprotId, i.vegaId , i.ncbiRefseqConservedDomains , i.ccdsId) ]) as ncbiRefseqDatabaseInfo, collect(distinct(coalesce(i.ncbiRefseqDescription))) as ncbiRefseqDescription,collect(distinct(coalesce(i.ncbiRefseqAccesion))) as proteinNcbiRefseqAccesion',
            parameters: { ckid: ckId }
        });
    } else {
        // Getting RefSeq genomic data
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_REFSEQ]-(g) where g.ncbiRefseqType= "genomic" return g.ncbiRefseqHeading as heading, g.ncbiRefseqSubHeading as sub_heading, g.ncbiRefseqType as type, g.ncbiRefseqAccesion as accession, g.ncbiRefseqStatus as status, g.ncbiRefseqSource as source_seq, r2.ncbiRefseqRange as range, r2.ncbiRefseqFrom as rangefrom, r2.ncbiRefseqTo as rangeto, p.ncbiGeneId as geneId',
            parameters: { ckid: ckId }
        });
        // Getting RefSeq mRNA data
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]-(p)-[r2:ENTREZGENE_REFSEQ]-(g), (k:NcbiRefSeq)-[h]-(i) where k.ncbiRefseqAccesion = g.ncbiRefseqAccesion and g.ncbiRefseqType= "mRNA" return g.ncbiRefseqHeading as heading, g.ncbiRefseqSubHeading as sub_heading, g.ncbiRefseqType as type, g.ncbiRefseqAccesion as accession, g.ncbiRefseqStatus as status, g.ncbiRefseqSource as source_seq, r2.ncbiRefseqRange as range, p.ncbiGeneId as geneId, collect([i.ncbiRefseqDatabase , coalesce(i.ensemblId , i.uniprotId, i.vegaId , i.ncbiRefseqConservedDomains , i.ccdsId) ]) as ncbiRefseqDatabaseInfo, collect(distinct(coalesce(i.ncbiRefseqDescription))) as ncbiRefseqDescription,collect(distinct(coalesce(i.ncbiRefseqAccesion))) as proteinNcbiRefseqAccesion',
            parameters: { ckid: ckId }
        });
    }

    // Getting Related seq information
    if (ckId.indexOf("R") === 0) {
        transaction.write({
            statement: 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]->(u) return u.ncbiGeneRelatedSequences as ncbiGeneRelatedSequences',
            parameters: { ckid: ckId }
        });
    } else {
        transaction.write({
            statement: 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:ENTREZGENE_ANNOTATIONS]->(u) return u.ncbiGeneRelatedSequences as ncbiGeneRelatedSequences',
            parameters: { ckid: ckId }
        });
    }

    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {
        resultdata["arrayData"] = arrayData;
        resultdata["generalData"] = generalData;
        resultdata["variationData"] = variationData;
        resultdata["homologyData"] = homologyData;
        resultdata["arrayGenomicContext"] = arrayGenomicContext;
        resultdata["allGenerifs"] = allGenerifs;
        resultdata["allPubmed"] = allPubmed;
        resultdata["allHomoloGene"] = allHomoloGene;
        resultdata["arrayPubmed"] = arrayPubmed;
        resultdata["arrayGenerifs"] = arrayGenerifs;
        resultdata["arrayPhenotypes"] = arrayPhenotypes;
        resultdata["arrayHIVInteraction"] = arrayHIVInteraction;
        resultdata["arrayInteraction"] = arrayInteraction;
        resultdata["arrayMarkers"] = arrayMarkers;
        resultdata["arrayGeneOntology"] = arrayGeneOntology;
        resultdata["generalData"] = generalData;
        resultdata["arrayRefSeq"] = arrayRefSeq;
        resultdata["arrayRelatedSeq"] = arrayRelatedSeq;
        res.json(resultdata);
    });
});

module.exports = router;

/**
 * 
 * @param {*} array 
 * @param {*} name 
 */
function getItemByName(array, name) {
    for (var i = 0; i < array.length; i += 1) {
        if (array[i].name.toUpperCase() === name.toUpperCase()) {
            return array[i];
        }
    }
}