/* This route gets Uniprot related data drom neo4j database */
var express = require('express');
var router = express.Router();

router.post('/uniprot', function(req, res) {
    var dbconnectString = 'http://'
                    + req.app.get('config').db.username + ':'
                    + req.app.get('config').db.password + '@'
                    + req.app.get('config').db.host + ':'
                    + req.app.get('config').db.port

    var cypher = require('cypher-stream')(dbconnectString);

    var ckId = req.body.id;
    console.log(ckId);
    var resultdata={};  
    var arrayData=[], functionText =[], sequence=[], arrayGofunc=[], arraydatabases =[], arrayFeature=[], arrayInteractions=[], arrayComments=[], databaseList=[];
    var arrayRef, arrayft, arrayCmt;
    var transaction = cypher.transaction()
        .on('data', function (result) {
            if(result["databaseUrl"] != null){
                item = {}
                item["url"] = result["databaseUrl"];
                item["name"] = result["databaseName"];
                item["id"] = result["databaseId"];
                item["category"] = result["databaseCategory"];
                databaseList.push(item);
            }
            if(result["gene_names"] != null){
                item = {}
                var uniprotProteinNames =result["protein_names"][0].replace("recommendedName","Recommended name:").replace(/>/g, "<br>").replace(/;/g, "<br>&emsp;")+"<br>Alternative Name(s):<br>";
                for(i=0;i<result["protein_names"].length;i++){
                    if(!result["protein_names"][i].includes("recommendedName"))
                      uniprotProteinNames += "&emsp;"+result["protein_names"][i].replace(/alternativeName>/g,"").replace(/;/g,"<br>");
                }
                //console.log(uniprotProteinNames);
                item["Protein Names"] = uniprotProteinNames;
                item["Gene Names"] = result["gene_names"];
                item["Organism"] = result["organism"];
                item["Taxonomic identifier"] = result["taxonomic_identifier"];
                item["Taxonomic lineage"] = result["taxonomic_lineage"];
                item["Proteomes"] = result["proteomes"];
                arrayData.push(item);
                functionText.push(result["function"]);
                sequence.push(result["sequence"]);
            }
            if(result["uniprotreference"] != null){  
                for(i=0;i<result["uniprotreference"].length;i++){
                    if(result["uniprotreference"][i].length !== 0){
                        item = {}
                        arrayRef = result["uniprotreference"][i].split("\t");
                        //console.log(arrayRef[0]+"\t"+arrayRef[1]+"\t"+arrayRef[2]+"\t"+arrayRef[3]);
                            
                        var database = getItemByName(databaseList,arrayRef[0]);
                        if(database != undefined){
                            item["url"] = database["url"].replace(/%s/g, arrayRef[1]).replace(/%u/g, result["uniprotId"]).replace(/%d/g, arrayRef[3]);
                            item["category"] = database["category"];   
                        } else{
                           // console.log(arrayRef[0]);
                        }                  
                                
                        item["type"] = arrayRef[0];
                        item["id"] = arrayRef[1];
                        //GO Functions          
                        if(arrayRef[0] == "GO"){
                            //console.log(arrayRef[0]+"\t"+arrayRef[1]+"\t"+arrayRef[2].substring(0, 1)+"\t"+arrayRef[2].substring(2));
                            if(arrayRef[2].substring(0, 1) == "C")
                                item["subtype"] = "Cellular Component";
                            else if (arrayRef[2].substring(0, 1) == "F")
                                item["subtype"] = "Molecular Function";
                            else if (arrayRef[2].substring(0, 1) == "P")
                                item["subtype"] = "Biological Process";

                            item["value"] = arrayRef[2].substring(2).split(',ECO')[0];    
                            arrayGofunc.push(item);
                        }else{
                            //console.log(arrayRef[0]+"\t"+arrayRef[1]+"\t"+arrayRef[2]+"\t"+arrayRef[3]+"\t"+item["url"]+"\t"+item["category"]);
                            item["value"] = arrayRef[2]; 
                            if(item["category"] != undefined){
                                arraydatabases.push(item);
                            }
                            
                        }
                    }
                }                             
            }
            if(result["uniprotfeature"] != null){  
                for(i=0;i<result["uniprotfeature"].length;i++){
                    if(result["uniprotfeature"][i].length !== 0){
                        arrayft = result["uniprotfeature"][i].split("\t");
                        item = {}
                        item["feature"] = arrayft[0];
                        item["start"] = arrayft[1];
                        item["end"] = arrayft[2];
                        item["length"] = arrayft[3];
                        item["desc"] = arrayft[4];
                        item["featureIdentifier"] = arrayft[5];
                        item["type"] = arrayft[6];
                        arrayFeature.push(item);
                    }
                }
                arrayFeature.sort(SortMyObjects);
            }
            if(result["exp_no"] != null){
                item = {}
                item["With"] = result["label"];
                item["Entry"] = result["entry"];
                item["#Exp"] = result["exp_no"];
                item["IntAct"] = result["int_act"];
                arrayInteractions.push(item);
            }
            if(result["uniprotcomments"] != null){
                  for(i=0;i<result["uniprotcomments"].length;i++){
                    if(result["uniprotcomments"][i].length !== 0){
                        arrayCmt = result["uniprotcomments"][i].split("|");
                        item = {}
                        item["type"] = arrayCmt[0];
                        item["ctext"] = arrayCmt[1];     
                        arrayComments.push(item);
                    }
                }
            }
        

    });

    transaction.write({
            statement  : 'MATCH (n:UniProtDatabases) RETURN n.uniprotDatabaseTemplateUrl as databaseUrl, n.uniprotDatabaseName as databaseName, n.uniprotDatabaseId as databaseId, n.uniprotDatabaseCategory as databaseCategory'
    });

    //Getting Names and Taxonomy Information
    if(ckId.indexOf("R") === 0){  
         transaction.write({
            statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotGeneNames as gene_names,u.uniprotProteinNames as protein_names,u.uniprotTaxonomicIdentifier as taxonomic_identifier,u.uniprotOrganism as organism, u.uniprotProteomes  as proteomes ,u.uniprotTaxonomicLineage as taxonomic_lineage, u.uniprotFunction as function, u.uniprotSequence as sequence',
            parameters : { ckid: ckId }
    });
    }else{
     transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotGeneNames as gene_names,u.uniprotProteinNames as protein_names,u.uniprotTaxonomicIdentifier as taxonomic_identifier,u.uniprotOrganism as organism, u.uniprotProteomes  as proteomes ,u.uniprotTaxonomicLineage as taxonomic_lineage, u.uniprotFunction as function, u.uniprotSequence as sequence',
        parameters : { ckid: ckId }
     });
    }
   
    //Getting GO Function Information
    if(ckId.indexOf("R") === 0){  
         transaction.write({
            statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotReference as uniprotreference, u.uniprotId as uniprotId',
            parameters : { ckid: ckId }
    });
    }else{
     transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotReference as uniprotreference, u.uniprotId as uniprotId',
        parameters : { ckid: ckId }
     });
    }

    //Getting Feature Information
    if(ckId.indexOf("R") === 0){  
         transaction.write({
            statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotFeature as uniprotfeature',
            parameters : { ckid: ckId }
    });
    }else{
     transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotFeature as uniprotfeature',
        parameters : { ckid: ckId }
     });
    }

    //Getting Interactions Information
    if(ckId.indexOf("R") === 0){  
         transaction.write({
            statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:UNIPROT]->(u)-[:UNIPROT_INTERACTION]->(i) return i.label as label,i.entry as entry,i.exp_no as exp_no,i.int_act as int_act',
            parameters : { ckid: ckId }
    });
    }else{
     transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:UNIPROT]->(u)-[:UNIPROT_INTERACTION]->(i) return i.label as label,i.entry as entry,i.exp_no as exp_no,i.int_act as int_act',
        parameters : { ckid: ckId }
     });
    }

    //Getting Comments Information
    if(ckId.indexOf("R") === 0){  
         transaction.write({
            statement  : 'match (n:CkReceptor{ck_receptor_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotComments as uniprotcomments',
            parameters : { ckid: ckId }
    });
    }else{
     transaction.write({
        statement  : 'match (n:CkLigand{ck_ligand_id: {ckid}})-[r:CK_UNIPROT]->(u) return u.uniprotComments as uniprotcomments',
        parameters : { ckid: ckId }
     });
    }
   
    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {      
        resultdata["arrayData"] = arrayData;
        resultdata["functionText"] = functionText.toString().split("|")[0];
        resultdata["sequence"] = sequence;
        resultdata["arrayGofunc"] = arrayGofunc;
        resultdata["arraydatabases"] = arraydatabases;
        resultdata["arrayFeature"] = arrayFeature;
        resultdata["arrayInteractions"] = arrayInteractions;
        resultdata["arrayComments"] = arrayComments;
        res.json(resultdata);
    });
});


module.exports = router;

function dynamicSort(property, property2) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}

function SortMyObjects(a, b) 
{
   if (a.type < b.type)
      return -1;

   if (a.type > b.type)
      return 1;

   // a.x == b.x so compare y values
   if (parseInt(a.start) < parseInt(b.start))
      return -1;

   if (parseInt(a.start) > parseInt(b.start))
      return 1;

   // perfect equality
   return 0;
}

function getItemByName(array,name) {
    for (var i = 0; i < array.length; i += 1) {
        if (array[i].name.toUpperCase() === name.toUpperCase()) {
            return array[i];
        }
    }
}

