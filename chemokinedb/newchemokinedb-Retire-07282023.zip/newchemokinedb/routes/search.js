/* This route searches particular Receptor and Ligand by name */
var express = require('express');
var router = express.Router();

router.post('/search', function(req, res) {
  	var dbconnectString = 'http://'
                      + req.app.get('config').db.username + ':'
                      + req.app.get('config').db.password + '@'
                      + req.app.get('config').db.host + ':'
                      + req.app.get('config').db.port ;

    var cypher = require('cypher-stream')(dbconnectString);
  	var searchtext = req.body.term;
    searchtext = searchtext.toUpperCase();
  	var resultdata={};  
    var id = "";
  	var transaction = cypher.transaction()
          .on('data', function (result) {
              if(result["ckid"] != null){
                  id = result["ckid"];
              }
      });

      
      if(searchtext.includes("R")){       	
     		 	transaction.write({
    			statement  : 'match (n:CkReceptor{ck_receptor_name: {name}}) where n.ck_parent_id ="ROOT" return n.ck_receptor_id as ckid',
         		parameters : { name: searchtext }
         		 });     
    	}
      else if(searchtext.includes("L")){
    			transaction.write({
     			statement  : 'match (n:CkLigand{ck_ligand_name: {name}}) where n.ck_parent_id ="ROOT" return n.ck_ligand_id as ckid',
           	parameters : { name: searchtext }
       	 	});
    		
    	}
  	  transaction.commit();
      transaction.on('error', function(error) {
          console.log(error);
      });
      transaction.on('end', function() {      
          resultdata["id"] = id;      
          res.json(resultdata);
      });
});


module.exports = router;