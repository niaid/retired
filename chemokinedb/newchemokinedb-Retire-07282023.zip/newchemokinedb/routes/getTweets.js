var express = require('express');
var router = express.Router();
var Twit = require('twit')

/* GET Tweets. */
router.post('/getTweets', function(req, res) {
  var resultdata={};
  var arrayTweets=[];

  var T = new Twit({
    consumer_key:         req.app.get('config').twitter.consumerKey,
    consumer_secret:      req.app.get('config').twitter.consumerSecret,
    access_token:         req.app.get('config').twitter.accessToken,
    access_token_secret:  req.app.get('config').twitter.accessTokenSecret,
    timeout_ms:           req.app.get('config').twitter.timeoutMs,  // optional HTTP request timeout to apply to all requests.
    strictSSL:            req.app.get('config').twitter.strictssl,     // optional - requires SSL certificates to be valid.
    SameSite:             req.app.get('config').twitter.SameSite, // SameSite = None

  })

   T.get('search/tweets', { q: '#Chemokine OR #Cytokine', count: 500 }, function(err, tweets, response) {
        //console.log('total tweets: ' + tweets.search_metadata.count);
        for(var t in tweets.statuses){
            //console.log(tweets.statuses[t].text);
            //console.log(tweets.statuses[t].user.name);
             var item = {};
             //console.log(tweets.statuses[t].retweeted_status);
             if(tweets.statuses[t].retweeted_status === undefined){
                item ["retweeted"] = "null";
                item ["text"] = tweets.statuses[t].text;
                item ["name"] = tweets.statuses[t].user.name;
                item ["user_profile_image"] = tweets.statuses[t].user.profile_image_url_https;
                item ["screen_name"] = tweets.statuses[t].user.screen_name;
                item ["id"] = tweets.statuses[t].id_str;
              }else{
                item ["retweeted"] = tweets.statuses[t].user.name + " Retweeted";
                item ["text"] = tweets.statuses[t].retweeted_status.text;
                item ["name"] = tweets.statuses[t].retweeted_status.user.name;
                item ["user_profile_image"] = tweets.statuses[t].retweeted_status.user.profile_image_url_https;
                item ["screen_name"] = tweets.statuses[t].retweeted_status.user.screen_name;
                item ["id"] = tweets.statuses[t].retweeted_status.id_str;
              }
              if(tweets.statuses[t].entities.media)
                item["media"] = tweets.statuses[t].entities.media[0].media_url_https;
              else
                item["media"] = "null";
              arrayTweets.push(item);
        }
    })
    setTimeout(function() {
        //console.log("size is "+arrayTweets.length);
        resultdata["arrayTweets"] = arrayTweets;
        res.json(resultdata);

    }, 1000);


});

module.exports = router;