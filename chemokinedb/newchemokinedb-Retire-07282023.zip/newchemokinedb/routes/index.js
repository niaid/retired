// This is the default route for the homepage
var express = require('express');
var router = express.Router();

router.get('/', function(req, res) {
    var dbconnectString = 'http://' +
        req.app.get('config').db.username + ':' +
        req.app.get('config').db.password + '@' +
        req.app.get('config').db.host + ':' +
        req.app.get('config').db.port;

    var cypher = require('cypher-stream')(dbconnectString);

    var resultdata = {};
    var arrayEvents = [],
        arrayPubs = [];
    var transaction = cypher.transaction()
        .on('data', function(result) {
            // Creates an array with events infomation
            if (result["etitle"] != null) {
                item = {}
                item["etitle"] = result["etitle"];
                item["estartDate"] = result["estartDate"];
                item["elocation"] = result["elocation"];
                item["eurl"] = result["eurl"];
                arrayEvents.push(item);
            }
            // Creates an array with Publication info
            if (result["pmtitle"] != null) {
                item = {}
                item["pmtitle"] = result["pmtitle"];
                item["pmid"] = result["pmid"];
                item["year"] = result["pmdate"].substring(0, 4);
                item["journal"] = result["journal"];
                arrayPubs.push(item);
            }
        });
    // Getting Events Information from database
    transaction.write('MATCH (n:Events) where n.title =~ "(?i).*cytokine.*" or n.title =~ "(?i).*chemokine.*" RETURN n.title as etitle, n.startDate as estartDate, n.location as elocation,n.url as eurl');

    // Getting Publication Information from database
    transaction.write('MATCH (n:Publication) where n.title =~ "(?i).*cytokine.*" or n.title =~ "(?i).*chemokine.*" RETURN n.title as pmtitle, n.pmid as pmid, n.pm_date as pmdate, n.iSOAbbreviation as journal order by n.pm_timestamp desc');

    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {
        resultdata["arrayEvents"] = arrayEvents;
        resultdata["arrayPubs"] = arrayPubs;
        res.render('default', { title: 'home', data: resultdata });
    });
});


module.exports = router;