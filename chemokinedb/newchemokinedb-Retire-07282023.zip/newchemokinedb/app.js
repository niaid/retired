// Required modules
var config  = require('./config');
var express = require('express');
var bodyParser = require("body-parser");
var app = express();
const helmet = require('helmet');

// Routes
var routes = require('./routes');
var index = require('./routes/index');
var genbankRoute = require('./routes/genbank');
var iupharRoute = require('./routes/iuphar');
var uniprotRoute = require('./routes/uniprot');
var functionDataRoute = require('./routes/functiondata');
var searchRoute = require('./routes/search');
var getTweets = require('./routes/getTweets');

app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json 
app.use(bodyParser.json());


app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Setting configuration file

app.set('config', config); 

//---DEBUG---//
if(config.debug) {
  app.use(function(req, res, next) {
    console.log('(%s)[%s] %s', req.ip, req.method, req.path);
    next();
  });
}

// Sets "Strict-Transport-Security: max-age=31536001; includeSubDomains, preload: true".
const sixtyDaysInSeconds = 31536001
app.use(helmet.hsts({
  maxAge: sixtyDaysInSeconds,
  preload: true
}));

// set the static files location /public/images will be /images for users
app.use(config.app.wwwroot, express.static(__dirname + '/public'));

// Adding routes
app.use(config.app.wwwroot, index);
app.use(config.app.wwwroot, iupharRoute);
app.use(config.app.wwwroot, uniprotRoute);
app.use(config.app.wwwroot, functionDataRoute);
app.use(config.app.wwwroot, searchRoute);
app.use(config.app.wwwroot, getTweets);
app.use(config.app.wwwroot, genbankRoute);


app.use('*', function(req, res) {
	res.status(404).send('Bad Route');
  //res.send('Bad Route', 404);
});

// startup our app at http://localhost:3000
var server = app.listen(config.app.port, function() {
  console.log('Listening on port '+ config.app.port);
}); 

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function(err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

module.exports = app;
