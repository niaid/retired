#!/bin/bash

trap 'stop' SIGINT

function errdie() {
  echo -e "\n\n${1}"
  exit 1
}

# This script is the entrypoint for starting the Abctransporter  application in a running container.
# It's split into three phases; pre-start, start, and post-start to split up tasks that
# should run at those different stages of starting the application

#
# Pre-start
#

prestart(){
    echo "[3dswarms][info] - Running pre-start steps..."
    
    echo "[3dswarms][info] - Finished pre-start steps."
}


#
# Start
#

start(){
  echo "[3dswarms][info] - Starting Tomcat..."
  catalina.sh run
  echo "[3dswarms][info] - Finished start steps."
}


#
# Post-start
#

poststart(){
    echo "[3dswarms][info] - Running post-start steps..."
    # Run any scripts or commands here that should happen after the Apache has started.

    printf "[3dswarms][info] - HTTP GET returns: "
    curl -sL -w "%{http_code}" "http://localhost:8888" -o /dev/null
    echo

    echo "[3dswarms][info] - Finished post-start steps."
}

#
# Stop
#

stop(){
    echo "[3dswarms][info] - Stopping application..."
    exit 0
}

# entrypoint

echo "[3dswarms][info] - Begining controlled startup..."
prestart
start
poststart
echo "[3dswarms][info] - Controlled startup finished!"

#
# run indefinitely, until error, or SIGINT
#
while true
do
    # nothing..
    sleep 100
done


