library(shiny)
library(shinydashboard)
library(rhandsontable)
library(shinyFiles)
library(randtoolbox)
library(lhs)
library(Rcpp)
library(randomForest)
options(rgl.useNULL = TRUE)
library(ggplot2)
library(rgl)
library(gplots)
library(randomForest)
library(plot3D)
library(Rcpp)
library(DT)

##generate parameter grids
func_gen_prm_grids <- function(prm.ranges){
  max.num.grids = max(prm.ranges$"number of grids")
  prm.grids = data.frame(matrix(NA, nrow = nrow(prm.ranges), ncol = max.num.grids + 1))
  colnames(prm.grids) = c("names", "min", paste0("V",2:(max(prm.ranges$"number of grids")-1)), "max")
  prm.grids$names = prm.ranges$names
  
  for(i in 1:nrow(prm.ranges)){
    if(prm.ranges$log.scale[i] == TRUE){
      grids.temp = exp(log(prm.ranges$min[i]) + (log(prm.ranges$max[i])-log(prm.ranges$min[i]))/(prm.ranges$"number of grids"[i]-1)*(1:prm.ranges$"number of grids"[i]-1))
      print(grids.temp)
      prm.grids[i,c(1+1,max.num.grids+1)] = grids.temp[c(1,prm.ranges$"number of grids"[i])]
      if(prm.ranges$"number of grids"[i] >2){
        prm.grids[i,(2+1):(prm.ranges$"number of grids"[i])] = grids.temp[2:(prm.ranges$"number of grids"[i]-1)]
      }
      
    }else{
      grids.temp = prm.ranges$min[i] + (prm.ranges$max[i]-prm.ranges$min[i])/(prm.ranges$"number of grids"[i]-1)*(1:prm.ranges$"number of grids"[i]-1)
      prm.grids[i,c(1+1,max.num.grids+1)] = grids.temp[c(1,prm.ranges$"number of grids"[i])]
      prm.grids[i,(2+1):(prm.ranges$"number of grids"[i])] = grids.temp[2:(prm.ranges$"number of grids"[i]-1)]
    }
    
  }
  
  prm.grids[,2:ncol(prm.grids)] = signif( prm.grids[,2:ncol(prm.grids)],6)
  return(prm.grids)
}


##generate parameter keys
sourceCpp("prm_gen_R.cpp")


##generate parameter combinations (pseudorandom, sobol', latin hypercube)
func_gen_prm_combs <- function(prm.ranges, prm.comb.num, sampling.meth, prm.grids = NULL){
  if(sampling.meth == "unif_grid"){
    if(!is.null(prm.grids)){
      prm.combinations = data.frame(matrix(NA, nrow = prm.comb.num, ncol = nrow(prm.ranges)))
      colnames(prm.combinations) = prm.ranges$names
      set.seed(1)
      for(i in 1:nrow(prm.ranges)){
        prm.combinations[,i] = sample.int(n = prm.ranges$"number of grids"[i], replace = T, size = prm.comb.num)
        prm.combinations[prm.combinations[,i] == prm.ranges$"number of grids"[i] ,i] = max(prm.ranges$"number of grids")
        vec.temp = as.numeric(prm.combinations[,i])
        prm.combinations[,i] = t(prm.grids[i,vec.temp+1])
        prm.combinations[,i] = signif(prm.combinations[,i],digits = 6)
      }
      return(prm.combinations)
    }
  }else if(sampling.meth == "pseudorandom"){
    prm.combs.pseudorand = matrix(NA, nrow = prm.comb.num, ncol = nrow(prm.ranges))
    colnames(prm.combs.pseudorand) = prm.ranges$names
    prm.combinations = prm.combs.pseudorand
    prm.combinations.z = prm.combs.pseudorand
    set.seed(1)
    for(i in 1:nrow(prm.ranges)){
      prm.combs.pseudorand[,i] = runif(prm.comb.num)
      prm.combinations[,i] = prm.combs.pseudorand[,i]
      prm.combinations.z[,i] = prm.combs.pseudorand[,i]
      
      if(prm.ranges$log.scale[i] == TRUE){
        prm.combinations[,i] = exp(log(prm.ranges$min[i]) + (log(prm.ranges$max[i])-log(prm.ranges$min[i]))*prm.combinations[,i])
      }else{
        prm.combinations[,i] = prm.ranges$min[i] + (prm.ranges$max[i]-prm.ranges$min[i])*prm.combinations[,i]
      }
      prm.combinations[,i] = signif(prm.combinations[,i],digits = 6)
      prm.combinations.z[,i] = signif(prm.combinations.z[,i],digits = 6)
    }
    prm.combinations.z = scale(prm.combinations.z)
    return(list(raw.smpl = prm.combs.pseudorand, prm.combs = prm.combinations, prm.combs.z = prm.combinations.z))
           
  }else if(sampling.meth == "sobol'"){
    set.seed(1)
    prm.combs.sobol = sobol(prm.comb.num, dim=nrow(prm.ranges), scrambling = 3)
    colnames(prm.combs.sobol) = prm.ranges$names
    prm.combinations = prm.combs.sobol
    prm.combinations.z = scale(prm.combs.sobol)
      
    colnames(prm.combinations) = prm.ranges$names
    for(i in 1:nrow(prm.ranges)){
      if(prm.ranges$log.scale[i] == TRUE){
        prm.combinations[,i] = exp(log(prm.ranges$min[i]) + (log(prm.ranges$max[i])-log(prm.ranges$min[i]))*prm.combinations[,i])
        prm.combinations.z[,1] 
      }else{
        prm.combinations[,i] = prm.ranges$min[i] + (prm.ranges$max[i]-prm.ranges$min[i])*prm.combinations[,i]
      }
      prm.combinations[,i] = signif(prm.combinations[,i],digits = 6)
      prm.combinations.z[,i] = signif(prm.combinations.z[,i],digits = 6)
    }
    
    return(list(raw.smpl = prm.combs.sobol, prm.combs = prm.combinations, prm.combs.z = prm.combinations.z))
           
    
  }else if(sampling.meth == "latin_hyp"){
    ##warning don't try optimumLHS for prm.comb.num > 100,
    set.seed(1)
    #prm.combinations = data.frame(optimumLHS(prm.comb.num, nrow(prm.ranges), 10))
    prm.combs.lhs = randomLHS(prm.comb.num, nrow(prm.ranges))
    colnames(prm.combs.lhs) = prm.ranges$names
    prm.combinations =  prm.combs.lhs
    prm.combinations.z = scale(prm.combs.lhs)
   
    for(i in 1:nrow(prm.ranges)){
      if(prm.ranges$log.scale[i] == TRUE){
        prm.combinations[,i] = exp(log(prm.ranges$min[i]) + (log(prm.ranges$max[i])-log(prm.ranges$min[i]))*prm.combinations[,i])
      }else{
        prm.combinations[,i] = prm.ranges$min[i] + (prm.ranges$max[i]-prm.ranges$min[i])*prm.combinations[,i]
      }
      prm.combinations[,i] = signif(prm.combinations[,i],digits = 6)
      prm.combinations.z[,i] = signif(prm.combinations.z[,i],digits = 6)
    }
    return(list(raw.smpl = prm.combs.lhs, prm.combs = prm.combinations, prm.combs.z = prm.combinations.z))
    
  }
  #names(prm.combinations) = c("pkey", prm.ranges$names)
  
}


##09152017 subranges centered on each selected parameter combination for zoom-in sampling
#prm.comb: a selected parameter combination
#prm.ranges: whole parameter ranges
func_gen_prm_subranges <- function(prm.comb, prm.ranges, sampling.meth, prm.grids = NULL) {
  #fraction of whole ranges
  prm.ranges$frac.range
  
  subranges = data.frame(matrix(NA, nrow = nrow(prm.ranges), ncol = 4))
  names(subranges) = c("names", "min", "max", "log.scale")
  subranges$log.scale = prm.ranges$log.scale
  subranges$names = prm.ranges$names
  
  if(sampling.meth != "unif_grid"){
    for(i in 1:nrow(prm.ranges)){
      print(prm.comb[1])
      if(prm.ranges$log.scale[i] == TRUE){
        print(log(prm.comb[i]))
        print((log(prm.ranges$max[i])-log(prm.ranges$min[i]))*prm.ranges$frac.range[i]/2)
        subranges[i,"min"] = log(prm.comb[i]) - (log(prm.ranges$max[i])-log(prm.ranges$min[i]))*prm.ranges$frac.range[i]
        subranges[i,"max"] = log(prm.comb[i]) + (log(prm.ranges$max[i])-log(prm.ranges$min[i]))*prm.ranges$frac.range[i]
        subranges[i,"min"] = exp(subranges[i,"min"])
        subranges[i,"max"] = exp(subranges[i,"max"])
        if(subranges[i,"min"]< prm.ranges$min[i]){
          subranges[i,"min"] = prm.ranges$min[i]
        }
        if(subranges[i,"max"]> prm.ranges$max[i]){
          subranges[i,"max"] = prm.ranges$max[i]
        }
      }else{
        print(prm.comb[i])
        print(prm.ranges[i,])
        print((prm.ranges$max[i]-prm.ranges$min[i]))
        print(prm.ranges$frac.range[i]/2)
        subranges[i,"min"] = prm.comb[i] -  (prm.ranges$max[i]-prm.ranges$min[i])*prm.ranges$frac.range[i]
        subranges[i,"max"] = prm.comb[i] +  (prm.ranges$max[i]-prm.ranges$min[i])*prm.ranges$frac.range[i]
        if(subranges[i,"min"]< prm.ranges$min[i]){
          subranges[i,"min"] = prm.ranges$min[i]
        }
        if(subranges[i,"max"]> prm.ranges$max[i]){
          subranges[i,"max"] = prm.ranges$max[i]
        }
      }
    }
  }else{
    for(i in 1:nrow(prm.ranges)){
      idx.temp = which(prm.grids[i,] == prm.comb[,i])
      print(prm.grids[i,])
      print(prm.comb[,i])
      print(prm.grids[i,] == prm.comb[,i])
      print(which(prm.grids[i,] == prm.comb[,i]))
      print(idx.temp)
      
      if(prm.grids$max[i] != prm.grids$min[i]){
        if(names(prm.grids)[idx.temp] != "min"){
          subranges[i,"min"] = prm.grids[i,idx.temp-1]
        }else{
          subranges[i,"min"] = prm.comb[i]
        }
        
        if(names(prm.grids)[idx.temp] != "max"){
          if(!is.na(prm.grids[i,idx.temp+1])){
            subranges[i,"max"] = prm.grids[i,idx.temp+1]
          }else{
            subranges[i,"max"] = prm.grids[i,"max"]
          }
        }else{
          subranges[i,"max"] = prm.comb[i]
        }
      }else{
        subranges[i,"min"] = prm.comb[i]
        subranges[i,"max"] = prm.comb[i]
      }
      subranges$"number of grids" = prm.ranges$"number of grids"
    }
  }
  
  
  subranges[,c("min", "max")] = signif(subranges[,c("min", "max")] ,digits = 6)   
  
  return(subranges)
  # 
  # if(sampling.meth == "unif_grid"){
  #   
  # }else if(sampling.meth == "pseudorandom"){
  #   
  # }else if(sampling.meth == "sobol'"){
  #   
  # }else if(sampling.meth == "latin_hyp"){
  #   
  # }
  # 
  # 
  # 
  
  
  
}




####phasespace


vec.plot.bc.mod = function (model1, model2, X, i.var, prm.ranges ,grid.lines = 100, 
                            zoom = 1, limitY = F, zlim, gap, three.dim = T, moreArgs = list(), ...) {
  library(scales)
  #library(plot3D)
  d = length(i.var)
  
  scales = lapply(i.var, function(i) {
    rXi = range(prm.ranges[,i])
    span = abs(rXi[2] - rXi[1]) * zoom/2
    center = mean(rXi)
    seq(center - span, center + span, length.out = grid.lines)
  })
  
  anchor.points = as.matrix(expand.grid(scales), dimnames = NULL)
  #colnames(X) = colnames(prm.ranges)
  names(X) = colnames(prm.ranges)
  Xgeneralized = as.numeric(X)
  Xtest.vec = data.frame(t(replicate(dim(anchor.points)[1],  Xgeneralized)))
  names(Xtest.vec) = colnames(prm.ranges)
  Xtest.vec[, i.var] = anchor.points
  yhat.vec = predict(model1, Xtest.vec) - predict(model2, Xtest.vec)
  yhat.pt = predict(model1,Xgeneralized) - predict(model2, Xgeneralized)
  values.to.plot =X[ i.var]
  
  if (d == 2) {
    color.gradient <- function(x, colors=c("blue", "green","yellow","red"), colsteps=100) {
      return( colorRampPalette(colors) (colsteps) [ findInterval(x, seq(zlim[1],zlim[2], length.out=colsteps)) ] )
    }
    
    if(three.dim == T){
      
      plot3d(x = anchor.points[,1], y = anchor.points[,2], z = yhat.vec, xlab =i.var[1], ylab =i.var[2],
             main = "Prediction", zlim =zlim, zlab = "Phenotype")
      plot3d(x = values.to.plot[1], y = values.to.plot[2], z = yhat.pt + abs(gap*yhat.pt), xlab = i.var[1], ylab = i.var[2], 
             main = "Prediction", col = "red", size = 7, add = TRUE, zlim = zlim)
      surface3d(x = scales[[1]], y = scales[[2]], 
                z = yhat.vec, col = color.gradient(yhat.vec), size = 4, alpha = 0.4, zlim = zlim)
      
      
    }else{
      
      image2D( matrix(yhat.vec, nrow = grid.lines), x = scales[[1]], y = scales[[2]], contour = T, zlim = zlim, xlab = i.var[1], ylab =i.var[2]  )
      points(x = values.to.plot[1], y = values.to.plot[2], pch =  19 )
      
      
      if(0){
        gg.data = data.frame( anchor.points[,1], anchor.points[,2], cor.max = yhat.vec)
        names(gg.data)[1:2] = names(X)[i.var]
        #ggplot(gg.data, aes(x= gg.data[,1], y =gg.data[,2])) + geom_tile(aes( fill = gg.data[,3]))+ scale_colour_manual(values =color.gradient(yhat.vec) )+  theme_bw() +xlab(label = names(gg.data)[1]) + ylab(label = names(gg.data)[2])
        ggplot(gg.data, aes(x= gg.data[,1], y =gg.data[,2])) + geom_tile(aes( fill = cor.max)) + theme_bw() +xlab(label = names(gg.data)[1]) + ylab(label = names(gg.data)[2]) +
          scale_fill_gradientn(colours=c("blue", "green","yellow","red"),
                               values=rescale(c(zlim[1], zlim[1] + (zlim[2]-zlim[1])/3, zlim[1] + 2*(zlim[2]-zlim[1])/3, zlim[2])),
                               guide="colorbar",
                               limits = zlim)
        #names(gg.data)[1]
        #names(gg.data)[2]
      }
    }
    
  }
  # else {
  #   if (limitY) {
  #     ylim = range(model$y)
  #   }
  #   else {
  #     ylim = NULL
  #   }
  #   plotArgs.std = alist(x = scales[[1]], y = yhat.vec, type = "l",
  #                        xlab = names(X)[i.var][1], col = "red", ylim = ylim)
  #   plotArgs.all = append.overwrite.alists(list(...), plotArgs.std)
  #   do.call(plot, plotArgs.all)
  #   pointsArgs.std = alist(x = values.to.plot, y = yhat.obs,
  #                          col = "#DD202030")
  #   pointsArgs.all = append.overwrite.alists(moreArgs, pointsArgs.std)
  #   do.call(points, pointsArgs.all)
  # }
  
  return(Xtest.vec)
}


fun.scale.conv = function(sample_meth, prm.ranges, prm.grids, prm.combs, z.to.org = TRUE){
  temp.num.prm = nrow(prm.ranges)
  
  temp.num.grids = prm.ranges$"number of grids"
  temp.prm.combs.val.z = prm.combs
  temp.prm.combs.val = prm.combs
  
  if(z.to.org == TRUE){
    if(sample_meth == "unif_grid"){
      for(i in 1:temp.num.prm){
        if(prm.ranges$log.scale[i] == FALSE){
          temp.mean = mean(as.numeric(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))]))
          #print(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))])
          temp.std = sd(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))])
          # print(temp.mean)
          # print(temp.std)
          temp.prm.combs.val[,i] =  temp.prm.combs.val.z[,i]*temp.std + temp.mean
          
        }else{
          temp.mean = mean(as.numeric(log(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))])))
          #print(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))])
          temp.std = sd(log(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))]))
          # print(temp.mean)
          # print(temp.std)
          temp.prm.combs.val[,i] =  exp(temp.prm.combs.val.z[,i]*temp.std + temp.mean)
          #print(temp.prm.combs.val.z[,i])
        }
      }
    }else{
      ##for other sampling schemes
    }
    names(temp.prm.combs.val) <- prm.ranges$names
    return(temp.prm.combs.val)
  }else if(z.to.org == FALSE){
    if(sample_meth == "unif_grid"){
      for(i in 1:temp.num.prm){
        if(prm.ranges$log.scale[i] == FALSE){
          temp.mean = mean(as.numeric(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))]))
          temp.std = sd(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))])
          
          if(temp.std != 0){
            temp.prm.combs.val.z[,i] =  (temp.prm.combs.val[,i] - temp.mean)/temp.std 
          }else{
            temp.prm.combs.val.z[,i] =  temp.prm.combs.val[,i] - temp.mean
          }
          
        }else{
          temp.mean = mean(as.numeric(log(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))])))
          
          temp.std = sd(log(prm.grids[i,c(2:(temp.num.grids[i]),max(temp.num.grids+1))]))
          
          if(temp.std != 0){
            temp.prm.combs.val.z[,i] =  (log(temp.prm.combs.val[,i]) - temp.mean)/temp.std  
          }else {
            temp.prm.combs.val.z[,i] =  log(temp.prm.combs.val[,i]) - temp.mean
          }
        }
      }
    }else{
      ##for other sampling schemes
    }
    names(temp.prm.combs.val.z) <- prm.ranges$names
    return(temp.prm.combs.val.z)
    
  }
  
  
  
}


