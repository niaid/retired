This folder contains random forest models, which sometimes have sizes more than 100MB.
The file type, .Rds, is taken care of by git-lfs.
