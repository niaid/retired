#####Proto web version for deploying to Monarch######
#####Only contain two gene simple network ###########
options(shiny.maxRequestSize=10000*1024^2)

#load("~/Dropbox/Codes/project_sim_ml/analysis/Figures/two_gene.RData")
#load("~/Dropbox/Codes/project_sim_ml/packaging/two_gene_phasespace.RData")

ggdata = data.frame() ## how to make this local? to be able to load data by user input
#load("~/Dropbox/Codes/project_sim_ml/analysis/visualization/rf.two.gene.combined.bc.rda")
source("classes.R")

server <- function(input, output) { 
  #####################################
  ############## Overview #############
  #####################################
  # observe({
  #   if(input$side_menu_tab == "exp_phase_tab"){
  #     load("~/Dropbox/Codes/project_sim_ml/analysis/Figures/two_gene.RData")
  #     load("~/Dropbox/Codes/project_sim_ml/analysis/visualization/rf.two.gene.combined.bc.rda")
  #   }
  # })
  # 
  
  #####################################
  ######### Workspace##################
  #####################################
  phasespace <- reactiveValues()
  
  ##create a new phasespace
  # observeEvent(input$new_phasespace,{
  #  phasespace$object <- new(Class = "Phasespace", input$phasespace_name) 
  # })
  
  ##load from a file
  # observe({
  #   if(!is.null(input$file_phasespace)){
  #     phasespace$object <- readRDS(input$file_phasespace$datapath)
  #     
  #   }
  # })
  
  ##save phasespace object as .rds
  # output$save_phasespace <- downloadHandler(
  #     filename = function() {
  #       input$file_phasespace_name
  #     },
  #     content = function(file) {
  #       saveRDS(phasespace$object, file)
  #     }
  # 
  #   )
  
  # observe({
  #   volumes <- c("roots"= "~/")
  #   shinyFileSave(input, "save_phasespace", roots = volumes)
  #   #print(input$save_phasespace)
  #   file.info <- parseSavePath(volumes, input$save_phasespace)
  #   #print(file.info)
  #   
  #   if(nrow(file.info) > 0){
  #     saveRDS(phasespace$object, file = as.character(file.info$datapath))
  #   }
  #   })
  # 
  
  
  
  
  output$current_phasespace_name <- renderUI({
    phasespace$object <- readRDS("two_gene_phasespace.Rds")
    phasespace.name <-NULL
    if(!is.null(phasespace$object)){
      phasespace.name <- get.phasespace.name(phasespace$object)
    }
    isolate({
      list(
        selectInput("show_phasespace",label = h4("Current phasespace"),choices = phasespace.name, size = 1, multiple = TRUE, selectize = FALSE)
      )
    })
  })
  
  
  
  output$list_prm_ranges <- renderUI({
    prm.ranges.names <- NULL
    if(!is.null(phasespace$object)){
      prm.ranges.names <- get.prm.ranges.name(phasespace$object)
    }
    isolate({
      list(
           selectInput("show_prm_ranges_list",label = h4("Parameter ranges"),choices =  prm.ranges.names,size = 3,multiple = TRUE, selectize = FALSE))
    })
  })
  
  output$list_init_prm_combs <- renderUI({
    init.prm.combs.names <- NULL
    if(!is.null(phasespace$object) && !is.null(get.init.prm.combs.name(phasespace$object))){
      init.prm.combs.names <- get.init.prm.combs.name(phasespace$object)
      init.prm.combs.names <- unlist(init.prm.combs.names )
      names(init.prm.combs.names) <- NULL
    }
    isolate({
      list(
        selectInput("show_prm_combinations_list",label = h4("Initial parameter sets"),choices =   init.prm.combs.names, size = 3,multiple = TRUE, selectize = FALSE)
        )
    })
    
  })
    
  
  output$list_addit_prm_combs <- renderUI({
    addit.prm.combs.names <- NULL
    if(!is.null(phasespace$object) && !is.null(get.addit.prm.combs.name(phasespace$object))){
      addit.prm.combs.names <- get.addit.prm.combs.name(phasespace$object)
      addit.prm.combs.names <- unlist(addit.prm.combs.names)
      names(addit.prm.combs.names) <- NULL
    }
    isolate({
      list(
        selectInput("show_addit_prm_combs_list",label = h4("Additional parameter sets"),choices =   addit.prm.combs.names, size = 3,multiple = TRUE, selectize = FALSE)
      )
    })
  })
  
  
  
  #####################################
  ######### Initial sampling ##########
  #####################################
#   
#   prm.ranges <- reactiveValues()
#   prm.grids <- reactiveValues()
#   prm.combinations <- reactiveValues()
# 
# 
# 
#   ###side panel###
#   output$list_init_prm_combs_ui <- renderUI({
#     init.prm.combs.names <- NULL
#     if(!is.null(phasespace$object)){
#       init.prm.combs.names <- get.init.prm.combs.name(phasespace$object)
#       init.prm.combs.names <- unlist(init.prm.combs.names)
#       names(init.prm.combs.names) <- NULL
#     }
#     isolate({
#       list(
#         selectInput("show_prm_combinations_list_tab",label = h4("Initial parameter combinations"),choices =   init.prm.combs.names, size = 3,multiple = TRUE, selectize = FALSE)
#       )
#     })
#   })
#   
#   
#   observeEvent(input$init_prm_combs_save2ps,{
#     
#     if(!is.null(prm.combinations$DF) && !is.null(input$init_prm_combs_name)){
#       prm.ranges$DF <- hot_to_r(input$parameter_ranges)
#       
#       if(input$sampling_meth == "unif_grid"){
#         temp.prm.combs.z <- fun.scale.conv(sample_meth = input$sampling_meth, prm.ranges = prm.ranges$DF, prm.grids = prm.grids$DF, prm.combs = prm.combinations$DF[,-1], z.to.org = FALSE )
#         temp.prm.combs.z <- cbind( prm.combinations$DF[,1], temp.prm.combs.z)
#         add.init.prm.combs(phasespace$object) <- list(prm.ranges.name = prm.combinations$prm.ranges.name ,
#                                                       name = input$init_prm_combs_name,
#                                                       method = input$sampling_meth,
#                                                       log.scale = prm.ranges$DF[,c("names","log.scale")], 
#                                                       num.grids = prm.ranges$DF[,c("names","number of grids")], 
#                                                       prm.grids = prm.grids$DF, 
#                                                       prm.combs = prm.combinations$DF,
#                                                       prm.combs.z =  temp.prm.combs.z )
#       }else{
#         add.init.prm.combs(phasespace$object) <- list(prm.ranges.name = prm.combinations$prm.ranges.name ,
#                                                       name = input$init_prm_combs_name,
#                                                       method = input$sampling_meth,
#                                                       log.scale = prm.ranges$DF[,c("names","log.scale")], 
#                                                       #num.grids = prm.ranges$DF[,c("names","number of grids")], 
#                                                       #prm.grids = prm.grids$DF, 
#                                                       raw.smpl = prm.combinations$raw.smpl,
#                                                       prm.combs = prm.combinations$DF,
#                                                       prm.combs.z =  prm.combinations$prm.combs.z )
#       }
#       
#       
#       
#       }
#   })
#   
#   ###main panel###
#   
#   ##action for sampling option and  reset button.
#   observe({
#     if(input$reset[[1]] == 0){
#       isolate(prm.ranges$DF <-data.frame(names = paste0("k",(1:10)), min = rep(0,10), max = rep(0,10),log.scale = rep(FALSE,10),stringsAsFactors = F ))
#     }else if(input$reset[[1]] != 0){
#       isolate({
#         nrow.temp <- nrow(prm.ranges$DF)
#         #print("a")
#         prm.ranges$DF <-data.frame(names = paste0("k",(1:nrow.temp)), min = rep(0,nrow.temp), max = rep(0,nrow.temp),log.scale = rep(FALSE,nrow.temp), stringsAsFactors = F)
#         #prm.ranges$DF <-data.frame(names = paste0("k",(1:10)), min = rep(0,10), max = rep(0,10),log.scale = rep(FALSE,10),stringsAsFactors = F )
#         #print(prm.ranges$DF)
#       })
#     }
# 
# 
#     isolate(prm.grids$DF <- NULL)
#     isolate(prm.combinations$DF <- NULL)
# 
# 
#   })
# 
#   observe({
#     if(!is.null(input$file_prm_ranges)){
#       prm.ranges$DF <- cbind(read.table(input$file_prm_ranges$datapath, header = T, stringsAsFactors = F), log.scale = FALSE)
#     }
#   })
# 
# 
# 
#   #adding or removing rows
#   observeEvent(input$prm_num,{
#     prm.ranges$DF = hot_to_r(input$parameter_ranges)
#     current.nrow = nrow(prm.ranges$DF)
#     if(input$prm_num - current.nrow  > 0 ){
# 
#       if( input$sampling_meth == "unif_grid"){
#         add.prm.ranges = data.frame(names = paste0("k",(current.nrow+1):input$prm_num), min = rep(0,input$prm_num - current.nrow), max = rep(0,input$prm_num - current.nrow),log.scale = rep(FALSE,input$prm_num - current.nrow), stringsAsFactors = F)
#         add.prm.ranges = cbind(add.prm.ranges,  "number of grids" = 10)
#       } else if ( input$sampling_meth != "unif_grid"){
#         add.prm.ranges = data.frame(names = paste0("k",(current.nrow+1):input$prm_num), min = rep(0,input$prm_num - current.nrow), max = rep(0,input$prm_num - current.nrow),log.scale = rep(FALSE,input$prm_num - current.nrow), stringsAsFactors = F)
#       }
#       prm.ranges$DF = rbind(prm.ranges$DF, add.prm.ranges)
#     }else if(input$prm_num - current.nrow  < 0){
#       prm.ranges$DF = prm.ranges$DF[-((input$prm_num+1):current.nrow),]
#     }
#     row.names(prm.ranges$DF) <- 1:nrow(prm.ranges$DF)
#   })
# 
#   output$file_ui <- renderUI({
#     input$reset
#     fileInput("file_prm_ranges", h5("Input from a file (.txt, .csv)."))
#   })
# 
#   output$prm_ranges_select_ui <- renderUI({
#     prm.ranges.names <- NULL
#     if(!is.null(phasespace$object)){
#       prm.ranges.names <- get.prm.ranges.name(phasespace$object)
#     }
#     
#     isolate({
#       list(
#         selectInput("prm_ranges_select",label = h5("Parameter ranges"),choices =  prm.ranges.names,selected = NULL, size = 3,multiple = FALSE, selectize = FALSE))
#     })
#   })
#   
#   ##update prm.ranges table in accordance with the selection
#   observeEvent(input$load,{
#     if(!is.null(input$prm_ranges_select)){
#       temp.DF <- get.prm.ranges(phasespace$object,input$prm_ranges_select)
#       if(nrow(temp.DF) == nrow(prm.ranges$DF)){
#         prm.ranges$DF[, c("names", "min","max")] <-  temp.DF
#       }else{
#         prm.ranges$DF = data.frame( temp.DF, log.scale = FALSE, stringsAsFactors = F)
#         if( input$sampling_meth == "unif_grid"){
#           prm.ranges$DF = cbind(prm.ranges$DF,  "number of grids" = 10)
#         } else {}
#       }          
#       
#     }
#                       
#     
#   })
#   
#   
#   output$prm_num_ui <- renderUI({
#     numericInput("prm_num", label = h5("Number of parameters"), value = nrow(prm.ranges$DF),min = 1, max = 1000)
#   })
# 
#   output$prm_grids_gen_ui <- renderUI({
#     if(input$sampling_meth == "unif_grid"){
#       actionButton("gen_prm_grids", "Generate parameter grids")
#     }
#   })
# 
# 
# 
#   #display of parameter ranges
#   output$parameter_ranges <- renderRHandsontable({
#     input$reset
#     DF <- prm.ranges$DF
#     # print(DF)
#     ncol.temp = ncol(DF)
#     isolate({
#       if(input$sampling_meth == "unif_grid"){
#         rhandsontable(DF, digit = 10, contextMenu = FALSE )  %>% hot_col(col = "log.scale", type = "checkbox") %>% hot_col(col = c("min","max"),renderer=htmlwidgets::JS("safeHtmlRenderer"))  %>% hot_col(col = ncol.temp,renderer=htmlwidgets::JS("safeHtmlRenderer")) ## to show all digits
#       } else {
#         rhandsontable(DF, digit = 10, contextMenu = FALSE )  %>% hot_col(col = "log.scale", type = "checkbox") %>% hot_col(col = c("min","max"),renderer=htmlwidgets::JS("safeHtmlRenderer"))
#       }
#     })
#   })
# 
#   #setting for log scale
#   observeEvent(input$sel_desel_all, {
#     prm.ranges$DF <- hot_to_r(input$parameter_ranges)
#     if(all.equal(prm.ranges$DF[["log.scale"]], rep(TRUE, nrow(prm.ranges$DF))) != TRUE){
#       prm.ranges$DF["log.scale"] = TRUE
#     }else{
#       prm.ranges$DF["log.scale"] = FALSE
#     }
#   })
# 
#   #setting for uniform grid
#   observe({
#     #input$parameter_ranges
#     # input$sampling_meth
#     # print(input$sampling_meth)
#     if(is.null(prm.ranges$DF$"number of grids") && input$sampling_meth == "unif_grid"){
#       isolate(prm.ranges$DF <- cbind(prm.ranges$DF, "number of grids" = 10))
#       #isolate(print(prm.ranges$DF))
#     } else if ( input$sampling_meth != "unif_grid"){
#       isolate(prm.ranges$DF <- prm.ranges$DF[,c("names", "min", "max", "log.scale")])
#     }
#   })
# 
# 
#   ##Saving again without changing file path does not work.
#   observe({
#     volumes = c("roots"= "~/")
#     shinyFileSave(input, "save", roots = volumes)
#     #print(input$save)
#     file.info = parseSavePath(volumes, input$save)
#     #print(file.info)
#     if(nrow(file.info) > 0){
#       if(file.info$type == "text"){
#         isolate({prm.ranges$DF <- hot_to_r(input$parameter_ranges)
#         write.table(prm.ranges$DF[,c("names", "min", "max")],file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
#       }else if (file.info$type == "csv"){
#         isolate({prm.ranges$DF <- hot_to_r(input$parameter_ranges)
#         write.csv(prm.ranges$DF[,c("names", "min", "max")],file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
#       }
#      
#       
#      
#       
#     }
#   })
# 
#   ##add to phasespace##
#   observeEvent(input$prm_ranges_save2ps,{
#     if(!is.null(input$prm_ranges_name)){
#       add.prm.ranges(phasespace$object) <- list(prm.ranges =prm.ranges$DF[,c("names", "min", "max")], name = input$prm_ranges_name )
#       #add.prm.ranges(phasespace$object, prm.ranges$DF[,c("names", "min", "max")], input$prm_ranges_name)
#     }
#   })
#   
# 
# 
#   output$prm_grids_ui <- renderUI({
#     input$gen_prm_grids
#     if(input$sampling_meth == "unif_grid" && !is.null(prm.grids$DF)){
#       list(hr(),
#            h4("Parameter grids"),
#            DT::dataTableOutput("prm_grids"),
#            #shinySaveButton("save_prm_grids", "Save parameter grids", "Save parameter combinations as ...", filetype=list(text="txt", csv = "csv")))
#            downloadButton("save_prm_grids", "Save parameter grids"))
#     }
#   })
# 
# 
# 
# 
# 
# 
#   #generate parameter grids, later implement filter for nonzero value
#   observeEvent(input$gen_prm_grids,{
#     prm.ranges$DF <- hot_to_r(input$parameter_ranges)
#     prm.grids$DF <-  func_gen_prm_grids(prm.ranges = prm.ranges$DF)
#   })
# 
#   output$prm_grids <- DT::renderDataTable({
#     prm.grids$DF
#   })
# 
#   output$save_prm_grids <- downloadHandler(
#     filename = function() {
#       paste("Untitled", ".txt", sep = "")
#     },
#     content = function(file) {
#       write.table(prm.grids$DF,file  ,quote = FALSE, col.names = TRUE, row.names = FALSE)
#     }
#   )
# 
# 
# 
# 
#   # observe({
#   #   volumes = c("roots"= "~/")
#   #   shinyFileSave(input, "save_prm_grids", roots = volumes)
#   #   print(input$save_prm_grids)
#   #   file.info = parseSavePath(volumes, input$save_prm_grids)
#   #   print(file.info)
#   #   if(nrow(file.info) > 0){
#   #     if(file.info$type == "text"){
#   #       isolate({
#   #       write.table(prm.grids$DF,file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
#   #     }else if (file.info$type == "csv"){
#   #       isolate({
#   #       write.csv(prm.grids$DF,file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
#   #     }
#   #   }
#   # })
#   #
# 
# 
# 
# 
# 
# 
#   output$prm_comb_ui <- renderUI({
#     input$gen_prm_combs
#     if(!is.null(prm.combinations$DF)){
#       list(hr(),
#            h4("Parameter combinations"),
#            DT::dataTableOutput("prm_combs"))
#     }
#   })
#   
#   output$prm_combs <-DT::renderDataTable({
#     prm.combinations$DF
#   })
# 
# 
# 
# 
#   #generate parameter combinations
# 
#   observeEvent(input$gen_prm_combs,{
# 
# 
#     ##1.generate parameter keys (convention: date + "_" + 8 digit LETTER barcodes)
#     let.to.num = c(0:25)
#     names(let.to.num) = LETTERS
#     p.index = as.numeric(let.to.num[strsplit(input$pkey_digits,"")[[1]]])
#   
#     temp.date = input$pkey_date
#     temp.date = format(temp.date, "%m%d%Y")
#     temp.date = as.character(temp.date)
#     temp.pkey = gen_prm_keys(input$prm_comb_num,  temp.date, p.index, nchar(input$pkey_digits))
# 
#     ##2.generate parameter combinations
#     isolate(prm.ranges$DF <-  hot_to_r(input$parameter_ranges))
#     temp.DF <- func_gen_prm_combs(prm.ranges$DF, input$prm_comb_num, input$sampling_meth, prm.grids$DF)
#     
#     if(input$sampling_meth == "unif_grid"){
#       prm.combinations$DF <- data.frame(pkey = temp.pkey$pkey, temp.DF, stringsAsFactors = F)
#       prm.combinations$method = input$sampling_meth
#       names(prm.combinations$DF)[-1] = prm.ranges$DF$names
#       prm.combinations$prm.ranges.name <- input$prm_ranges_select
#     }else{
#       prm.combinations$DF <- data.frame(pkey = temp.pkey$pkey, temp.DF$prm.combs, stringsAsFactors = F)
#       prm.combinations$raw.smpl <- data.frame(pkey = temp.pkey$pkey,temp.DF$raw.smpl, stringsAsFactors = F)
#       prm.combinations$prm.combs.z <- data.frame(pkey = temp.pkey$pkey,temp.DF$prm.combs.z, stringsAsFactors = F)
#       prm.combinations$method = input$sampling_meth
#       names(prm.combinations$DF)[-1] = prm.ranges$DF$names
#       names(prm.combinations$raw.smpl)[-1] = prm.ranges$DF$names
#       names(prm.combinations$prm.combs.z)[-1] = prm.ranges$DF$names
#       prm.combinations$prm.ranges.name <- input$prm_ranges_select
#     }
#    
# 
#   })
# 
#   ##save parameter combinations
#   # output$save_prm_combs_ui <- renderUI({
#   # shiny save file doesn't work
#   #   if(!is.null( prm.combinations$DF)){
#   #     shinySaveButton("save_prm_combs", "Save parameter combinations", "Save parameter combinations as ...", filetype=list(text="txt", csv = "csv"))
#   #   }
#   # })
#   #
#   shinyFileSave(input, "save_prm_combs", roots = c("roots"= "~/"))
#   observe({
#     # if(!is.null(prm.combinations$DF)){
#     #
#     # }
#    # print(input$save_prm_combs)
#     file.info = parseSavePath(c("roots"= "~/"), input$save_prm_combs)
#     #print(file.info)
#     if(nrow(file.info) > 0){
#       if(file.info$type == "text"){
#         isolate({
#           write.table( prm.combinations$DF,file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
#       }else if (file.info$type == "csv"){
#         isolate({
#           write.csv(prm.combinations$DF,file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
#       }
#     }
#   })
# 
# 
# 
# 
#   output$test <- renderPrint({
#     input$file_prm_ranges
#     input$reset
#     input$pkey_date[1]
#   })
#   
#   
#   #####################################
#   ######## Additional sampling ########
#   #####################################
# 
#   prm.ranges.add <- reactiveValues()
#   prm.grids.add <- reactiveValues()
#   #prm.combinations.add <- reactiveValues()
#   init.prm.combs <- reactiveValues()
#   prm.combs.selected <- reactiveValues()
#   addit.prm.combs <-reactiveValues()
#   
#   
#   ###side panel###
#   output$list_addit_prm_combs_ui <- renderUI({
#     addit.prm.combs.names <- NULL
#     if(!is.null(phasespace$object)){
#       addit.prm.combs.names <- get.addit.prm.combs.name(phasespace$object)
#       addit.prm.combs.names <- unlist(addit.prm.combs.names)
#       names(addit.prm.combs.names) <- NULL
#     }
#     isolate({
#       list(
#         selectInput("show_addit_prm_combs_list_tab",label = h4("Additional parameter sets"),choices =   addit.prm.combs.names, size = 3,multiple = TRUE, selectize = FALSE)
#       )
#     })
#   })
#   
#   
#   observeEvent(input$addit_prm_combs_save2ps,{
#     if(!is.null(addit.prm.combs$DF)){
#       temp.addit.prms.combs.z <- fun.scale.conv(sample_meth = addit.prm.combs$method, 
#                                                 prm.ranges = prm.ranges.add$DF, 
#                                                 prm.grids = prm.grids.add$DF,
#                                                 prm.combs = addit.prm.combs$DF[,prm.ranges.add$DF$names],
#                                                 z.to.org = FALSE
#                                                 )
#       temp.addit.prms.combs.z <- cbind(addit.prm.combs$DF[,1], temp.addit.prms.combs.z)
#       add.additional.prm.combs(phasespace$object) <- list(prm.ranges.name = input$load_prm_ranges, 
#                                                           init.prm.combs.name = input$load_init_prm_combs, 
#                                                           name = input$addit_prm_combs_name, 
#                                                           method = addit.prm.combs$method, 
#                                                           log.scale = prm.ranges.add$DF$log.scale, 
#                                                           frac.range =  prm.ranges.add$DF$frac.range, 
#                                                           num.grids =  prm.ranges.add$DF$"number of grids",
#                                                           prm.combs.selected = prm.combs.selected$DF,
#                                                           prm.combs = addit.prm.combs$DF, 
#                                                           prm.combs.z = temp.addit.prms.combs.z)
#     }
#   })
#   
#   
#   
#   ###main panel###
#   ##Load existing parameter space (ranges and initial combinations)
#   output$laad_prm_ranges_ui <- renderUI({
#     prm.ranges.names <- NULL
#     if(!is.null(phasespace$object)){
#       prm.ranges.names <- get.prm.ranges.name(phasespace$object)
#     }
#     isolate({
#       list(
#         selectInput("load_prm_ranges",label = h5("Parameter ranges"),choices =  prm.ranges.names,selected = NULL, size = 3,multiple = FALSE, selectize = FALSE))
#     })
#   })
#   
#   output$load_init_prm_combs_ui <- renderUI({
#     init.prm.combs.names <- NULL
#     if(!is.null(phasespace$object)){
#       if(!is.null(input$load_prm_ranges)){ 
#         init.prm.combs.names <- get.init.prm.combs.name(phasespace$object)
#         init.prm.combs.names <- init.prm.combs.names[[input$load_prm_ranges]]
#       }
#     }
#       list(
#         selectInput("load_init_prm_combs",label = h5("Initial parameter combinations"),choices = init.prm.combs.names ,selected = NULL, size = 3,multiple = FALSE, selectize = FALSE))
#     
#   })
#   
#   
#   observeEvent(input$load_prm_ranges,{
#     print(input$load_prm_ranges)
#     prm.ranges.add$DF <- get.prm.ranges(phasespace$object,input$load_prm_ranges)
#   })
#   
#   observeEvent(input$load_init_prm_combs,{
#     print(input$load_init_prm_combs)
#     if(!is.null(input$load_init_prm_combs)){
#       init.prm.combs$DF <- get.init.prm.combs(phasespace$object,input$load_init_prm_combs,input$load_prm_ranges)
#       prm.ranges.add$DF <- data.frame(prm.ranges.add$DF[,c("names", "min", "max")], log.scale =  init.prm.combs$DF$log.scale$log.scale)
#         if(init.prm.combs$DF$method == "unif_grid"){
#           prm.ranges.add$DF$frac.range = 1
#           prm.ranges.add$DF$"number of grids" = init.prm.combs$DF$num.grids$"number of grids"
#         }else{
#           prm.ranges.add$DF$frac.range = 0.1
#         }
#       prm.grids.add$DF <-init.prm.combs$DF$prm.grids
#     }else{
#       prm.ranges.add$DF$log.scale <- NULL
#       prm.ranges.add$DF$frac.range <- NULL
#       prm.ranges.add$DF$"number of grids" <- NULL
#       prm.grids.add$DF <- NULL
#     }
#   })
#   
#   # #setting for uniform grid
#   # observe({
#   #   if(!is.null(init.prm.combs$DF)){
#   #     prm.ranges.add$DF$log.scale <- init.prm.combs$DF$log.scale
#   #     prm.ranges.add$DF$"number of grids" <- init.prm.combs$DF$"number of grids"
#   #     if(init.prm.combs$DF$method == "unif_grid" ){
#   #       prm.ranges.add$DF$frac.range <- 1
#   #     }else{
#   #       prm.ranges.add$DF$frac.range <- 0.1
#   #     }
#   #   }else{
#   #     prm.ranges.add$DF$log.scale <- NULL
#   #     prm.ranges.add$DF$"number of grids" <- NULL
#   #     prm.ranges.add$DF$frac.range <- NULL
#   #   }
#   # )}
#   
#   # if(is.null(prm.ranges.add$DF$"number of grids") && input$add_sampling_meth == "unif_grid"){
#   #   isolate({prm.ranges.add$DF <- cbind(prm.ranges.add$DF, "number of grids" = 10)
#   #   prm.ranges.add$DF$frac.range <- 1})
#   #   #isolate(print(prm.ranges.add$DF))
#   # } else if ( input$add_sampling_meth != "unif_grid"){
#   #   isolate({prm.ranges.add$DF <- prm.ranges.add$DF[,c("names", "min", "max", "log.scale", 'frac.range')]
#   #   prm.ranges.add$DF$frac.range = 0.1})
#   # }
# # })
#   
#   
#   ##input selected parameter combinations
#   output$file_prm_selected_ui <- renderUI({
#     input$add_reset
#     fileInput("file_prm_selected", h5("Input from a file (.txt, .csv)."))
#   })
#   
#   
#   observe({
#     if(!is.null(input$file_prm_selected)){
#       isolate(prm.combs.selected$DF <- read.table(input$file_prm_selected$datapath, header = T, stringsAsFactors = F)
#       )
#     }
#     print(prm.combs.selected$DF)
#   })
#   
# 
# 
#   output$prm_space_selected_tab_ui <- renderUI({
#     if(!is.null(input$load_prm_ranges) && is.null(input$load_init_prm_combs) && is.null(prm.combs.selected$DF)){
#       tabBox(id = "prm_space_selected", selected = NULL, width = 12,
#                 tabPanel(title = "Parameter ranges", value = "tab_prm_ranges_select",
#                          uiOutput("add_prm_num_ui"),
#                          fluidRow(
#                            column(6,rHandsontableOutput("parameter_ranges_add")
#                            ),
#                            column(3,h5("Log scale"),
#                                   actionButton("add_sel_desel_all", label = "Select/Deselect All"))
#                          
#                            ),
#                          br(),
#                          fluidRow(
#                            column(3, shinySaveButton("add_save", "Save parameter ranges", "Save parameter ranges as ...", filetype=list(text="txt", csv = "csv")))
#                            #column(3, uiOutput("add_prm_grid_gen"))
#                            )
#                          )
#              )
#     }else if(!is.null(input$load_prm_ranges) && !is.null(input$load_init_prm_combs) && is.null(prm.combs.selected$DF)){
#       if(init.prm.combs$DF[["method"]] == "unif_grid") {
#         tabBox(id = "prm_space_selected", selected = NULL, width = 12,
#                tabPanel(title = "Parameter ranges", value = "tab_prm_ranges_select",
#                         uiOutput("add_prm_num_ui"),
#                         fluidRow(
#                           column(6,rHandsontableOutput("parameter_ranges_add")
#                           ),
#                           column(3,h5("Log scale"),
#                                  actionButton("add_sel_desel_all", label = "Select/Deselect All"))
#                           
#                         ),
#                         br(),
#                         fluidRow(
#                           column(3, shinySaveButton("add_save", "Save parameter ranges", "Save parameter ranges as ...", filetype=list(text="txt", csv = "csv")))
#                           #column(3, uiOutput("add_prm_grid_gen"))
#                         )
#                ),
#                tabPanel(title = "Parameter grids", value = "tab_prm_grids_select",
#                         uiOutput("file_prm_grids_ui") 
#                ),
#                tabPanel(title = "Initial parameter set", value = "tab_init_prm_combs_select",
#                        uiOutput("init_prm_combs_add_ui")
#                )
#         )
#       }else{
#         tabBox(id = "prm_space_selected", selected = NULL, width = 12,
#                tabPanel(title = "Parameter ranges", value = "tab_prm_ranges_select",
#                         uiOutput("add_prm_num_ui"),
#                         fluidRow(
#                           column(6,rHandsontableOutput("parameter_ranges_add")
#                           ),
#                           column(3,h5("Log scale"),
#                                  actionButton("add_sel_desel_all", label = "Select/Deselect All"))
#                           
#                         ),
#                         br(),
#                         fluidRow(
#                           column(3, shinySaveButton("add_save", "Save parameter ranges", "Save parameter ranges as ...", filetype=list(text="txt", csv = "csv")))
#                           #column(3, uiOutput("add_prm_grid_gen"))
#                         )
#                ),
#                tabPanel(title = "Initial parameter set", value = "tab_init_prm_combs_select",
#                         uiOutput("init_prm_combs_add_ui")
#                )
#         )
#       }
#       
#     }else if(!is.null(input$load_prm_ranges) && !is.null(input$load_init_prm_combs) && !is.null(prm.combs.selected$DF)){
#       if(init.prm.combs$DF[["method"]] == "unif_grid") {
#         tabBox(id = "prm_space_selected", selected = NULL, width = 12,
#                tabPanel(title = "Parameter ranges", value = "tab_prm_ranges_select",
#                         uiOutput("add_prm_num_ui"),
#                         fluidRow(
#                           column(6,rHandsontableOutput("parameter_ranges_add")
#                           ),
#                           column(3,h5("Log scale"),
#                                  actionButton("add_sel_desel_all", label = "Select/Deselect All"))
#                           
#                         ),
#                         br(),
#                         fluidRow(
#                           column(3, shinySaveButton("add_save", "Save parameter ranges", "Save parameter ranges as ...", filetype=list(text="txt", csv = "csv")))
#                           #column(3, uiOutput("add_prm_grid_gen"))
#                         )
#                ),
#                tabPanel(title = "Parameter grids", value = "tab_prm_grids_select",
#                         uiOutput("file_prm_grids_ui") 
#                ),
#                tabPanel(title = "Initial parameter set", value = "tab_init_prm_combs_select",
#                         uiOutput("init_prm_combs_add_ui")
#                ),
#                tabPanel(title = "selected parameter combinations", value = "tab_selected_prm_combs",
#                         uiOutput("prm_comb_sel_ui")
#                )
#         )
#       }else{
#         tabBox(id = "prm_space_selected", selected = NULL, width = 12,
#                tabPanel(title = "Parameter ranges", value = "tab_prm_ranges_select",
#                         uiOutput("add_prm_num_ui"),
#                         fluidRow(
#                           column(6,rHandsontableOutput("parameter_ranges_add")
#                           ),
#                           column(3,h5("Log scale"),
#                                  actionButton("add_sel_desel_all", label = "Select/Deselect All"))
#                           
#                         ),
#                         br(),
#                         fluidRow(
#                           column(3, shinySaveButton("add_save", "Save parameter ranges", "Save parameter ranges as ...", filetype=list(text="txt", csv = "csv")))
#                           #column(3, uiOutput("add_prm_grid_gen"))
#                         )
#                ),
#                tabPanel(title = "Initial parameter set", value = "tab_init_prm_combs_select",
#                         uiOutput("init_prm_combs_add_ui")
#                ),
#                tabPanel(title = "selected parameter combinations", value = "tab_selected_prm_combs",
#                         uiOutput("prm_comb_sel_ui")
#                )
#         )
#       }
#       
#     }
#      
#   })
#   
# 
#   
#   
#   ##action for sampling option and  reset button.
#   # observe({
#   #   if(input$add_reset[[1]] == 0){
#   #     isolate(prm.ranges.add$DF <-data.frame(names = paste0("k",(1:10)), min = rep(0,10), max = rep(0,10),log.scale = rep(FALSE,10), frac.range = rep(0.1,10), stringsAsFactors = F ))
#   #   }else if(input$add_reset[[1]] != 0){
#   #     isolate({
#   #       nrow.temp <- nrow(prm.ranges.add$DF)
#   #       # print("a")
#   #       prm.ranges.add$DF <-data.frame(names = paste0("k",(1:nrow.temp)), min = rep(0,nrow.temp), max = rep(0,nrow.temp),log.scale = rep(FALSE,nrow.temp), frac.range = rep(0.1,nrow.temp), stringsAsFactors = F)
#   #       #prm.ranges.add$DF <-data.frame(names = paste0("k",(1:10)), min = rep(0,10), max = rep(0,10),log.scale = rep(FALSE,10),stringsAsFactors = F )
#   #       #print(prm.ranges.add$DF)
#   #     })
#   #   }
#   # 
#   #   isolate(prm.grids.add$DF <- NULL)
#   #   #isolate(prm.combinations.add$DF <- NULL)
#   #   isolate(prm.combs.selected$DF <- NULL)
#   #   isolate(addit.prm.combs$DF <- NULL)
#   #   isolate(init.prm.combs$DF <- NULL)
#   # 
#   # })
# 
#  
#   #adding or removing rows
#   # observeEvent(input$add_prm_num,{
#   #   prm.ranges.add$DF = hot_to_r(input$parameter_ranges_add)
#   #   current.nrow = nrow(prm.ranges.add$DF)
#   #   if(input$add_prm_num - current.nrow  > 0 ){
#   # 
#   #     if( input$add_sampling_meth == "unif_grid"){
#   #       add.prm.ranges.add = data.frame(names = paste0("k",(current.nrow+1):input$add_prm_num), min = rep(0,input$add_prm_num - current.nrow), max = rep(0,input$add_prm_num - current.nrow),log.scale = rep(FALSE,input$add_prm_num - current.nrow), frac.range = rep(0.1,input$add_prm_num - current.nrow), stringsAsFactors = F)
#   #       add.prm.ranges.add = cbind(add.prm.ranges.add,  "number of grids" = 10)
#   #     } else if ( input$add_sampling_meth != "unif_grid"){
#   #       add.prm.ranges.add = data.frame(names = paste0("k",(current.nrow+1):input$add_prm_num), min = rep(0,input$add_prm_num - current.nrow), max = rep(0,input$add_prm_num - current.nrow),log.scale = rep(FALSE,input$add_prm_num - current.nrow), frac.range = rep(0.1,input$add_prm_num - current.nrow), stringsAsFactors = F)
#   #     }
#   #     prm.ranges.add$DF = rbind(prm.ranges.add$DF, add.prm.ranges.add)
#   #   }else if(input$add_prm_num - current.nrow  < 0){
#   #     prm.ranges.add$DF = prm.ranges.add$DF[-((input$add_prm_num+1):current.nrow),]
#   #   }
#   #   row.names(prm.ranges.add$DF) <- 1:nrow(prm.ranges.add$DF)
#   # })
# 
# 
#   output$add_prm_num_ui <- renderUI({
#     numericInput("add_prm_num", label = h5("Number of parameters"), value = nrow(prm.ranges.add$DF),min = 1, max = 1000)
#   })
# 
#  
#   #display of parameter ranges
#   output$parameter_ranges_add <- renderRHandsontable({
#     input$add_reset
#     if(!is.null(prm.ranges.add$DF)){
#       DF <- prm.ranges.add$DF
#       ncol.temp = ncol(DF)
#       isolate({
#         if(ncol.temp == length(c("names", "min", "max"))){
#           rhandsontable(DF, digit = 10, contextMenu = FALSE )   %>% hot_col(col = c("min","max"),renderer=htmlwidgets::JS("safeHtmlRenderer")) 
#         }else if(!is.null(input$load_init_prm_combs)){ #if(!is.null(init.prm.combs$DF)){
#             if(init.prm.combs$DF$method == "unif_grid"){
#               rhandsontable(DF, digit = 10, contextMenu = FALSE )  %>% hot_col(col = "log.scale", type = "checkbox") %>% hot_col(col = c("min","max","frac.range"),renderer=htmlwidgets::JS("safeHtmlRenderer"))  %>% hot_col(col = ncol.temp,renderer=htmlwidgets::JS("safeHtmlRenderer")) ## to show all digits
#             } else {
#               rhandsontable(DF, digit = 10, contextMenu = FALSE )  %>% hot_col(col = "log.scale", type = "checkbox") %>% hot_col(col = c("min","max","frac.range"),renderer=htmlwidgets::JS("safeHtmlRenderer"))
#             }
#         }
#       })
#     }
#   })
# 
#   #setting for log scale
#   observeEvent(input$add_sel_desel_all, {
#     prm.ranges.add$DF <- hot_to_r(input$parameter_ranges_add)
#     if(all.equal(prm.ranges.add$DF[["log.scale"]], rep(TRUE, nrow(prm.ranges.add$DF))) != TRUE){
#       prm.ranges.add$DF["log.scale"] = TRUE
#     }else{
#       prm.ranges.add$DF["log.scale"] = FALSE
#     }
#   })
# 
#   # #setting for uniform grid
#   # observe({
#   #   if(!is.null(init.prm.combs$DF)){
#   #     prm.ranges.add$DF$log.scale <- init.prm.combs$DF$log.scale
#   #     prm.ranges.add$DF$"number of grids" <- init.prm.combs$DF$"number of grids"
#   #     if(init.prm.combs$DF$method == "unif_grid" ){
#   #       prm.ranges.add$DF$frac.range <- 1
#   #     }else{
#   #       prm.ranges.add$DF$frac.range <- 0.1
#   #     }
#   #   }else{
#   #     prm.ranges.add$DF$log.scale <- NULL
#   #     prm.ranges.add$DF$"number of grids" <- NULL
#   #     prm.ranges.add$DF$frac.range <- NULL
#   #   }
#   
#     # if(is.null(prm.ranges.add$DF$"number of grids") && input$add_sampling_meth == "unif_grid"){
#     #   isolate({prm.ranges.add$DF <- cbind(prm.ranges.add$DF, "number of grids" = 10)
#     #   prm.ranges.add$DF$frac.range <- 1})
#     #   #isolate(print(prm.ranges.add$DF))
#     # } else if ( input$add_sampling_meth != "unif_grid"){
#     #   isolate({prm.ranges.add$DF <- prm.ranges.add$DF[,c("names", "min", "max", "log.scale", 'frac.range')]
#     #   prm.ranges.add$DF$frac.range = 0.1})
#     # }
# #  })
# 
#   output$file_prm_grids_ui <- renderUI({
#     if(init.prm.combs$DF[["method"]] == "unif_grid"){
#       input$add_reset
#       list(
#            DT::dataTableOutput("prm_grids_add")
#       )
#   
#     }
#   })
#   
#   output$init_prm_combs_add_ui <- renderUI({
#     list(
#       h5("Initial parameter set"),
#       DT::dataTableOutput("init_prm_combs_add")
#     )
#   })
# 
#  
# 
#   output$prm_grids_add <- DT::renderDataTable({
#     if(!is.null(init.prm.combs$DF[["prm.grids"]])){
#       init.prm.combs$DF[["prm.grids"]]
#     }
#   })
#   
#   output$init_prm_combs_add <- DT::renderDataTable({
#     init.prm.combs$DF[["prm.combs"]]
#     
#   })
# 
# 
# 
#   ##Saving again without changing file path does not work.
#   observe({
#     volumes = c("roots"= "~/")
#     shinyFileSave(input, "add_save", roots = volumes)
#     #print(input$add_save)
#     file.info = parseSavePath(volumes, input$add_save)
#     # print(file.info)
#     if(nrow(file.info) > 0){
#       if(file.info$type == "text"){
#         isolate({prm.ranges.add$DF <- hot_to_r(input$parameter_ranges_add)
#         write.table(prm.ranges.add$DF[,c("names", "min", "max")],file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
#       }else if (file.info$type == "csv"){
#         isolate({prm.ranges.add$DF <- hot_to_r(input$parameter_ranges_add)
#         write.csv(prm.ranges.add$DF[,c("names", "min", "max")],file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
#       }
#     }
#   })
# 
# 
#   ##display selected parameter combinations
#   output$prm_comb_sel_ui <- renderUI({
#     input$file_prm_selected
#     isolate({
#       if(!is.null(prm.combs.selected$DF)){
#         list(DT::dataTableOutput("prm_combs_selected"))
#       }
#     })
#   })
#   
#   output$prm_combs_selected <- DT::renderDataTable({
#     prm.combs.selected$DF
#   })
#   
#   
# 
#   #generate zoom-in parameter combinations
# 
#   observeEvent(input$gen_prm_combs_zoomin,{
# 
#     ##1.generate parameter keys (convention: date + "_" + 8 digit LETTER barcodes)
#     let.to.num = c(0:25)
#     names(let.to.num) = LETTERS
#     p.index = as.numeric(let.to.num[strsplit(input$add_pkey_digits,"")[[1]]])
# 
#     temp.date = input$add_pkey_date
#     temp.date = format(temp.date, "%m%d%Y")
#     temp.date = as.character(temp.date)
#     temp.pkey = gen_prm_keys(input$add_prm_comb_num*nrow(prm.combs.selected$DF),  temp.date, p.index, nchar(input$add_pkey_digits))
#     temp.subranges = NULL
#     temp.subgrids = NULL
#     ##2.generate zoom-in parameter combinations
#     ##2.1.generate subranges
#     temp.DF <- data.frame()
#     prm.ranges.add$DF <-  hot_to_r(input$parameter_ranges_add)
#     if(input$add_sampling_meth != "unif_grid"){
#       prm.grids.add$DF = NULL
#     }
#     for(i in 1:nrow(prm.combs.selected$DF)){
#       temp.subranges <- func_gen_prm_subranges(prm.comb = prm.combs.selected$DF[i,2:ncol(prm.combs.selected$DF)],prm.ranges = prm.ranges.add$DF, sampling.meth = input$add_sampling_meth,prm.grids = prm.grids.add$DF)
#       if(input$add_sampling_meth == "unif_grid"){
#         temp.subgrids  = func_gen_prm_grids(temp.subranges)
#       }
#       temp.DF <- rbind(temp.DF, func_gen_prm_combs(temp.subranges, input$add_prm_comb_num, input$add_sampling_meth, temp.subgrids))
#     }
#    addit.prm.combs$DF <- data.frame(pkey = temp.pkey$pkey, temp.DF,stringsAsFactors = F)
#    addit.prm.combs$method <- input$add_sampling_meth
#    
#   })
# 
#   output$prm_comb_zoomin_ui <- renderUI({
#     if(!is.null(addit.prm.combs$DF)){
#       list(hr(),
#            h4("Zoom-in parameter combinations"),
#            DT::dataTableOutput("prm_combs_zoomin"))
#     }
#   })
#   output$prm_combs_zoomin <-DT::renderDataTable({
#    addit.prm.combs$DF
#   })
# 
# 
# 
# 
# 
#   ##save parameter combinations
#   # output$save_prm_combs_ui <- renderUI({
#   # shiny save file doesn't work
#   #   if(!is.null( prm.combinations.add$DF)){
#   #     shinySaveButton("save_prm_combs", "Save parameter combinations", "Save parameter combinations as ...", filetype=list(text="txt", csv = "csv"))
#   #   }
#   # })
#   #
#   shinyFileSave(input, "save_prm_combs_zoomin", roots = c("roots"= "~/"))
#   observe({
#     # if(!is.null(prm.combinations.add$DF)){
#     #
#     # }
#     # print(input$save_prm_combs_zoomin)
#     file.info = parseSavePath(c("roots"= "~/"), input$save_prm_combs_zoomin)
#     # print(file.info)
#     if(nrow(file.info) > 0){
#       if(file.info$type == "text"){
#         isolate({
#           write.table(addit.prm.combs$DF,file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
#       }else if (file.info$type == "csv"){
#         isolate({
#           write.csv(addit.prm.combs$DF,file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
#       }
#     }
#   })
# 
# 
#   output$add_test <- renderPrint({
#     input$file_prm_ranges
#     input$add_reset
#     input$add_pkey_date[1]
#   })
#   
  #####################################
  ######## Explore Phase space ########
  #####################################
  #load data
  
  phenotype.loaded <- reactiveValues()
  
  
  
  output$list_phenotypes_tab_ui <- renderUI({
    phenotypes.names <- NULL
    if(!is.null(phasespace$object)){
      
      phenotypes.names <-  get.phenotypes.name(phasespace$object)
      phenotypes.names <- append("None", phenotypes.names)
    }
    isolate({
      list(
        selectInput("load_phenotype",label = h4("Select a phenotype"),choices =   phenotypes.names, size = 3,multiple = FALSE, selectize = FALSE)
      )
    })
    
  })
  
  observe({
    if(!is.null(input$load_phenotype)){
      if(input$load_phenotype != "None"){
        phenotype.loaded$list <- get.phenotypes(phasespace$object,input$load_phenotype)
      }else{
        phenotype.loaded$list <- NULL
      }
    }else{
      phenotype.loaded$list <- NULL
    }
  })
  
  output$list_prm_sets_tab_ui <- renderUI({
    prm.sets.names <- NULL
    if(!is.null(input$load_phenotype)&& input$load_phenotype != "None"){
      prm.sets.names <- names(phenotype.loaded$list)
    }else if(!is.null(input$load_phenotype) && input$load_phenotype == "None"){
      prm.sets.names <- append(unlist(get.init.prm.combs.name(phasespace$object)), 
                               unlist(get.addit.prm.combs.name(phasespace$object)))
      names(prm.sets.names) <- NULL
    }
    isolate({
      list(
        selectInput("load_parameter_sets",label = h4("Select parameter sets"),choices =   prm.sets.names, size = 3,multiple = TRUE, selectize = FALSE)
      )
    })
  })
  
  output$list_ml.models_tab_ui <- renderUI({
    ml.models.names <- NULL
    if(!is.null(phasespace$object)){
      if(!is.null(input$load_phenotype) && input$load_phenotype != "None"){
        ml.models.names <- get.ml.models.name(phasespace$object)
        names(ml.models.names) <- get.phenotypes.name(phasespace$object)
        ml.models.names <- ml.models.names[[input$load_phenotype]]
        names(ml.models.names) <- NULL
      }
    }else{}
    isolate({
      list(
        selectInput("load_ml.model",label = h4("Select a ML model"),choices =   ml.models.names, size = 3,multiple = FALSE, selectize = FALSE)
      )
    })
  })
  
  
  output$test_exp_phase_tab <- renderText({
    input$launch_exp_phase
  })
  
  
  #phase space   
  tsne_range = reactiveValues(x=c(-30,30), y = c(-30,30))
  prm.sets.selected <- reactiveValues()
  phenotype.values.selected <- reactiveValues()
  prm.ranges.selected <- reactiveValues()
  prm.ranges.z.selected <- reactiveValues()

  prm.grids.selected <- reactiveValues()
  prm.set.method <- reactiveValues()
  ml.model.selected <- reactiveValues()
  local.importance <- reactiveValues()
  
  #parameters
  ##number of parameters
  numPrm <- reactiveValues() # = 10 ## later to be detected automatically
  parameters <- reactiveValues()  #names(data.clust.z.combined)[2:(numPrm+1)]
  
  
  
  ##loading parameter sets with accordance with the selection above
  observeEvent(input$launch_exp_phase,{
    prm.sets.selected$tsne <- data.frame(stringsAsFactors = F)
    prm.sets.selected$original <- data.frame(stringsAsFactors = F)
    prm.sets.selected$rescaled <- data.frame(stringsAsFactors = F)
    phenotype.values.selected$DF <- data.frame(stringsAsFactors = F)
    
    if(!is.null(input$load_parameter_sets)){
      for(i in 1:length(input$load_parameter_sets)){
        prm.sets.selected$tsne <- rbind(prm.sets.selected$tsne, get.tsne.coord(phasespace$object,input$load_parameter_sets[i] ) )
        temp.prm.ranges.names <- get.prm.ranges.name(object = phasespace$object)
        temp.prm.names.init <- get.init.prm.combs.name(object = phasespace$object)
        temp.prm.names.addit <- get.addit.prm.combs.name(object = phasespace$object)
        
        
        ##to obtain corresponding parameter ranges for selected initial parameter space
        if(any(unlist( temp.prm.names.init) == input$load_parameter_sets[i]) ){
          temp.idx <- unlist(
            apply(matrix(temp.prm.ranges.names), 1,
                  function(name, prm.names, input.name){
                    any(prm.names[[name]] == input.name) }, 
                  prm.names = temp.prm.names.init, input.name = input$load_parameter_sets[i])
            )
          temp.range.name <- temp.prm.ranges.names[temp.idx]
          temp.prm.combs <- get.init.prm.combs(phasespace$object,input$load_parameter_sets[i], temp.range.name )
          
          
          
          prm.ranges.z.selected$DF <- apply( temp.prm.combs$prm.combs.z[-1], 2, range)
          prm.ranges.selected$DF <- get.prm.ranges(object = phasespace$object,name = temp.range.name )
          prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, log.scale = temp.prm.combs$log.scale$log.scale, stringsAsFactors = F)
          
          prm.set.method$method <- temp.prm.combs$method 
          if(temp.prm.combs$method == "unif_grid"){
            prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, temp.prm.combs$num.grids$`number of grids`, stringsAsFactors = F)
            names(prm.ranges.selected$DF)[5] = "number of grids"
          }
          
          
          
          prm.grids.selected$DF <- temp.prm.combs$prm.grids
            
          prm.sets.selected$original <-rbind(prm.sets.selected$original, temp.prm.combs$prm.combs )
          prm.sets.selected$rescaled <-rbind(prm.sets.selected$rescaled, temp.prm.combs$prm.combs.z )
          temp.prm.combs <- NULL
          
        }else{
          
          
          
          ##to obtain corresponding parameter ranges and inital parameter set for selected additional parameter space
          temp.idx <- unlist(
            apply(matrix(temp.prm.ranges.names), 1,
                  function(name, prm.names, input.name){
                    any(unlist(prm.names[[name]]) == input.name) }, 
                  prm.names = temp.prm.names.addit, input.name = input$load_parameter_sets[i])
          )
          temp.range.name <- temp.prm.ranges.names[temp.idx]
          temp.idx <- unlist(
            apply(matrix(unlist(temp.prm.names.init)), 1,
                  function(name, prm.range.name, prm.names, input.name){
                    any(prm.names[[ prm.range.name]][[name]] == input.name) }, 
                  prm.range.name = temp.range.name, prm.names = temp.prm.names.addit, input.name = input$load_parameter_sets[i])
          )
          temp.prm.name.init <- unlist(temp.prm.names.init)[temp.idx]
          
          temp.prm.combs <- get.addit.prm.combs(phasespace$object,input$load_parameter_sets[i], temp.range.name,temp.prm.name.init )
          temp.prm.combs.init <- get.init.prm.combs(phasespace$object, temp.prm.name.init, temp.range.name )
          
          prm.ranges.z.selected$DF <- apply( temp.prm.combs.init$prm.combs.z[,-1],2, range)
          prm.ranges.selected$DF <- get.prm.ranges(object = phasespace$object,name = temp.range.name)
          prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, log.scale = temp.prm.combs.init$log.scale$log.scale, stringsAsFactors = F)
         
          prm.set.method$method <- temp.prm.combs.init$method 
           if(temp.prm.combs.init$method == "unif_grid"){
            prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, temp.prm.combs.init$num.grids$`number of grids`, stringsAsFactors = F)
            names(prm.ranges.selected$DF)[5] = "number of grids"
          }
         
          prm.grids.selected$DF <- temp.prm.combs.init$prm.grids
          
          prm.sets.selected$original <-rbind(prm.sets.selected$original, temp.prm.combs$prm.combs )
          prm.sets.selected$rescaled <-rbind(prm.sets.selected$rescaled, temp.prm.combs$prm.combs.z )
          temp.prm.combs <- NULL
          temp.prm.combs.init <- NULL
          
        }
        if(input$load_phenotype != "None"){
          phenotype.values.selected$DF <- rbind( phenotype.values.selected$DF, phenotype.loaded$list[[input$load_parameter_sets[i]]] )
        }else{
          phenotype.values.selected$DF <- NULL
        }
      }
    }else{
      prm.sets.selected$tsne <- NULL
      prm.sets.selected$original <- NULL
      prm.sets.selected$rescaled <- NULL
      phenotype.values.selected$DF <- NULL
      prm.ranges.selected$DF <- NULL
      prm.ranges.z.selected$DF <- NULL
      prm.grids.selected$DF <- NULL
      prm.set.method$method <- NULL
      
    }
    
    if(!is.null(input$load_ml.model)){
      temp.ml.model.path <- get.ml.models.path(phasespace$object)
      
      ml.model.selected$ml.model <- readRDS(temp.ml.model.path[1])
      if(!is.null(temp.ml.model.path[2])){
        ml.model.selected$ml.model.res <- readRDS(temp.ml.model.path[2])
      }
      
      local.importance$DF <- data.frame(pkey =  ml.model.selected$ml.model$pkey, t( ml.model.selected$ml.model$localImportance), stringsAsFactors = F)
      
    }else{
      ml.model.selected$ml.model <-NULL
      ml.model.selected$ml.model.res <-NULL
      local.importance$DF <- NULL
    }
    
    
    if(!is.null(prm.sets.selected$original)){
      numPrm$prmset <- nrow(prm.ranges.selected$DF)
      parameters$prmset <- prm.ranges.selected$DF$names
    }else{
      numPrm$prmset <- NULL
      parameters$prmset <- NULL
    }
    
    if(!is.null(ml.model.selected$ml.model)){
      numPrm$ml.model <- nrow(ml.model.selected$ml.model$localImportance)
      parameters$ml.model <- row.names(ml.model.selected$ml.model$localImportance)
    }else{
      numPrm$ml.model <- NULL
      parameters$ml.model <- NULL
    }
    
  })
  
  #####side bar
  phen.range <- reactiveValues()
  
  observeEvent(input$launch_exp_phase,{
    if(!is.null(phenotype.values.selected$DF)){
      phen.range$DF <- signif(range(phenotype.values.selected$DF[,2]),1)
      temp.range <- range(phenotype.values.selected$DF[,2])
      
      if(phen.range$DF[1]>temp.range[1]){
        
      }
      
      if(phen.range$DF[2] < temp.range[2]){
        
      }
      
    }else{
      phen.range$DF <- NULL
    }
  })
  
  
  
  output$exp_phase_side_ui <- renderUI({
    if(!is.null(phen.range$DF) ){
      list(sliderInput("phen.range", label = h5("Range of phenotype"),
                       min = phen.range$DF[1], max = phen.range$DF[2], step = (phen.range$DF[2]-phen.range$DF[1])/500, value = c(phen.range$DF[1],phen.range$DF[2])),# min = -0.5, max = 1, step = 0.01, value = c(0.5, 1)),
           sliderInput("phen.mid.color", label = h5("Value of mid color"),
                       min = phen.range$DF[1], max = phen.range$DF[2], step = (phen.range$DF[2]-phen.range$DF[1])/500, value = (phen.range$DF[1] + phen.range$DF[2])/2),
           sliderInput("point.size", label = h5("Size of points"),
                       min = 0, max = 2, step = 0.1, value = 1),
           sliderInput("point.alpha", label = h5("Alpha of points"), 
                       min = 0, max = 1, step = 0.1, value = 0.5),
           verbatimTextOutput("info"))
    }else{
      list(
           sliderInput("point.size", label = h5("Size of points"),
                       min = 0, max = 2, step = 0.1, value = 1),
           sliderInput("point.alpha", label = h5("Alpha of points"), 
                       min = 0, max = 1, step = 0.1, value = 0.5),
           verbatimTextOutput("info"))
      
    }
   
  })
  
  
  
  
  
  output$t_SNE <- renderPlot({
    
    #updating global variable
    
    if(!is.null(prm.sets.selected$tsne)){
    
      if(isolate(input$load_phenotype) == "None"){
        ggdata <<- data.frame(prm.sets.selected$tsne, stringsAsFactors = F)
        names(ggdata) <<- c("pkey", "tSNE1","tSNE2")
        p1 = ggplot(ggdata, aes_string(x = "tSNE1", y = "tSNE2"))#, color = input$load_phenotype))
        p1 = p1+geom_point(size = input$point.size, alpha = input$point.alpha, color = "black") +# +scale_colour_gradient2(low="blue", high="red", midpoint = 0.4) + #labs(title =paste0( "tsne for original data"))  +
          #xlim(-30,30) +ylim(-30,30) +
          coord_cartesian(xlim = tsne_range$x, ylim = tsne_range$y, expand = FALSE) +
          theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
        p1
        
      } else{
        ggdata <<- data.frame(prm.sets.selected$tsne, phenotype.values.selected$DF[[isolate(input$load_phenotype)]], stringsAsFactors = F)
        names(ggdata) <<- c("pkey", "tSNE1","tSNE2", isolate(input$load_phenotype))
        ggdata <<- ggdata[ggdata[[isolate(input$load_phenotype)]] >= input$phen.range[1] & ggdata[[isolate(input$load_phenotype)]] < input$phen.range[2] , ]
        
        p1 = ggplot(ggdata, aes_string(x = "tSNE1", y = "tSNE2", color = isolate(input$load_phenotype)))
        p1 = p1+geom_point(size = input$point.size, alpha = input$point.alpha) +scale_colour_gradient2(low="blue", high="red", midpoint = input$phen.mid.color) + #labs(title =paste0( "tsne for original data"))  +
          #xlim(-30,30) +ylim(-30,30) +
          coord_cartesian(xlim = tsne_range$x, ylim = tsne_range$y, expand = FALSE) +
          theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
        p1
        
      }     
    }
  })



  ##zoom-in
  ##brush and double click
  observeEvent(input$tsne_dblclick,{
    brush <- input$tsne_brush
    if(!is.null(brush)){
      tsne_range$x = c(brush$xmin,brush$xmax)
      tsne_range$y = c(brush$ymin,brush$ymax)
    }else{
      tsne_range$x = c(-30,30)
      tsne_range$y = c(-30,30)
    }
  })


  ##specifying parameter ranges
  # prm.z.ranges = matrix(NA, nrow = 2, ncol = numPrm$ml.model )
  # colnames(prm.z.ranges) = parameters$ml.model
  # for(i in 2:(numPrm$ml.model+1)){
  #   prm.z.ranges[1,i-1] = signif(min(data.clust.z.combined[,i]), 4)
  #   prm.z.ranges[2,i-1] = signif(max(data.clust.z.combined[,i]), 4)
  # }
  # 
  # 

  ##point-select
  selected = reactiveValues()



  observeEvent(input$tsne_click,{
    selected_temp = nearPoints(ggdata, input$tsne_click,  maxpoints = 1)
    selected_pkey = selected_temp$pkey
    
  
    if(nrow(selected_temp) !=0){
      selected$pkey = selected_pkey
      selected$point <- data.frame(Parameter = parameters$prmset,
                                   Rescaled = t(prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey == selected_pkey, -1]),
                                   Original = t(prm.sets.selected$original[prm.sets.selected$original$pkey == selected_pkey, -1]), stringsAsFactors = F)
      names(selected$point) <- c("parameter", "rescaled", "original")
    }else {
      selected$pkey <- NULL
      selected$point <- NULL
    }
  })

  output$info <- renderPrint({
    #nearPoints(ggdata, input$tsne_click,  maxpoints = 1)$pkey
    cat(selected$pkey)
  })

  ## output of selected point
  output$parmeter_values <- renderTable(
    selected$point, align = "c", spacing = "xs", width = "200px"
  )




  ##automatic generation of sliders
  output$parameters <- renderUI({
    if(!is.null(numPrm$ml.model)){
      prmInput = vector("list", numPrm$ml.model)
      for(i in 1:numPrm$ml.model){
        prmInput[[i]] <- list(sliderInput(paste0("prm",i),
                                          parameters$ml.model[i],
                                          min = signif(min(prm.sets.selected$rescaled[,2:(numPrm$ml.model+1)]),3),
                                          max = signif(max(prm.sets.selected$rescaled[,2:(numPrm$ml.model+1)]),3),
                                          value = 0, step =.01))
      }
      return(prmInput)
    }
  })


  #Variable importance
  library(gridExtra)
  output$global_varImp <- renderPlot({
    if(!is.null( ml.model.selected$ml.model)){
      imp = importance( ml.model.selected$ml.model)
      ggdata.imp = data.frame( imp)
      ggdata.imp$names = factor(row.names(imp), levels=row.names(ggdata.imp)[order(ggdata.imp$X.IncMSE)])
  
      p1 = ggplot(data=ggdata.imp[order(ggdata.imp$X.IncMSE, decreasing = T),], aes(x =names , y =  X.IncMSE))
      p1 = p1+geom_point(size = 2, color= "black", stat = "identity") + xlab("") + ylab("")+ #labs(title =paste0( "tsne for original data")) +
        theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
  
      ggdata.imp = data.frame( imp)
      ggdata.imp$names = factor(row.names(imp), levels=row.names(ggdata.imp)[order(ggdata.imp$IncNodePurity)])
  
      p2 = ggplot(data=ggdata.imp[order(ggdata.imp$X.IncMSE, decreasing = T),], aes(x =names , y =IncNodePurity ))
      p2 = p2+geom_point(size = 2, color= "black", stat = "identity")+ xlab("") + ylab("") + #labs(title =paste0( "tsne for original data")) +
        theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
  
      grid.arrange(p1,p2, ncol = 2, nrow =1)
    }

  })

  #local.imp.combined = data.frame(pkey = data.clust.z.combined$pkey, t(rf.two.gene.combined.bc$localImportance))

  output$local_varImp <- renderPlot({
    if(!is.null(selected$pkey) && !is.null(ml.model.selected$ml.model)){
      #rf.two.gene.combined$localImportance[order(rf.two.gene.combined$localImportance[,1027], decreasing = TRUE),1027]
      idx.pt = which(local.importance$DF$pkey == selected$pkey)
      ggdata.imp = data.frame( imp = as.numeric(t(local.importance$DF[idx.pt ,-1])))
      ggdata.imp$names = colnames(local.importance$DF)[-1]
      ggdata.imp = ggdata.imp[order(ggdata.imp$imp),]
      ggdata.imp$names = factor(ggdata.imp$names, levels=ggdata.imp$names)
      p1 = ggplot(data=ggdata.imp, aes(x =names , y =  imp))
      p1 = p1+geom_point(size = 2, color= "black", stat = "identity") + xlab("Parameters") + ylab("Avg. increase in squared OOB residuals")+ labs(title = selected$pkey) +
        theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
      p1
    }
  })



  #perturbation

  #validation parameter combinations
  prm.combs.val.z <- reactiveValues()
  prm.combs.val <- reactiveValues()



  output$parameter_choice1 <- renderUI({
    selectInput(inputId = "parameter_choice1",
                label = "Choose the first parameter:",
                choices = parameters$ml.model, selected = parameters$ml.model[1])
  })

  output$parameter_choice2 <- renderUI({
    selectInput(inputId = "parameter_choice2",
                label = "Choose the second parameter:",
                choices = parameters$ml.model, selected = parameters$ml.model[1])
  })

  ##generate a plot only when a point is selected and two selected parameters are different.

  output$perturb_plot <- renderUI({
    input$plot_gen
    isolate(if( !is.null(ml.model.selected$ml.model)){
      if(input$plot_type == "2D"){
        return(plotOutput("perturb_plot_2d",height = "450px", width = "450px"))
      } else if(input$plot_type == "3D"){
        return(rglwidgetOutput("perturb_plot_3d",height = "450px", width = "450px"))
      }
    })
  })

  output$perturb_plot_2d <- renderPlot({
    input$plot_gen
    isolate(if( !is.null(ml.model.selected$ml.model)){
      if(is.null(input$parameter_choice1) | is.null(input$parameter_choice2)  ){
        return()
      }else if((input$parameter_choice1 != input$parameter_choice2) & (nrow(nearPoints(ggdata, input$tsne_click,  maxpoints = 1)) != 0)){
        prm.combs.val.z$DF <- vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,t(selected$point$rescaled)[,1:numPrm$ml.model],
                                              c(input$parameter_choice1, input$parameter_choice2),prm.ranges.z.selected$DF[,1:numPrm$ml.model], grid.lines = input$num_grids_val, zoom = 1, zlim = c(-0.2,1.2), gap = 0 , three.dim = F)
        prm.combs.val.z$pkey = selected$pkey
        prm.combs.val.z$prm.comb.selected.rescaled = selected$point$rescaled
        prm.combs.val.z$prm.comb.selected.original = selected$point$original
        names(prm.combs.val.z$prm.comb.selected.rescaled) <-  selected$point$parameter
        names(prm.combs.val.z$prm.comb.selected.original) <-  selected$point$parameter
        #print( selected$point$original )
      }


    })

  })

  output$perturb_plot_3d <- renderRglwidget({

    input$plot_gen
    isolate({if( !is.null(ml.model.selected$ml.model)){
      if(is.null(input$parameter_choice1) |is.null(input$parameter_choice2)  ){
        return()
      }else if((input$parameter_choice1 != input$parameter_choice2) & (nrow(nearPoints(ggdata, input$tsne_click,  maxpoints = 1)) != 0)){
        try(rgl.close(), silent = TRUE)
        prm.combs.val.z$DF <-  vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,t(selected$point$rescaled)[,1:numPrm$ml.model],
                                               c(input$parameter_choice1, input$parameter_choice2),prm.ranges.z.selected$DF[,1:numPrm$ml.model], grid.lines =input$num_grids_val, zoom = 1, zlim = c(-0.2,1.2), gap = 0 , three.dim = T)
        prm.combs.val.z$pkey = selected$pkey
        
        prm.combs.val.z$prm.comb.selected.rescaled = selected$point$rescaled
        prm.combs.val.z$prm.comb.selected.original = selected$point$original
        names(prm.combs.val.z$prm.comb.selected.rescaled) <-  selected$point$parameter
        names(prm.combs.val.z$prm.comb.selected.original) <-  selected$point$parameter
        
        scene1<- scene3d()
        rglwidget(scene1)

      }
    }})
  })


  output$gen_prm_combs_val_ui <- renderUI(
    if(!is.null(prm.combs.val.z$DF)){
      list(actionButton("gen_prm_combs_val", "Generate validation parameter combinations"),
           fluidRow(
             column(4,dateInput("pkey_date_val", label = h6("Current date"), format = "mmddyyyy")),
             column(4,textInput("pkey_digits_val", label = h6("Starting digit"))),
             #column(4,numericInput("num_grids_val", label = h6("Number of grids"),value = 30, min = 2, max = 100)),
             DT::dataTableOutput("prm_combs_val"),
             downloadButton("save_prm_combs_val", "Save validation parameter combinations")
           ))

    }
  )

  observeEvent(input$gen_prm_combs_val,{


    ##1.generate parameter keys (convention: date + "_" + 8 digit LETTER barcodes)
    let.to.num = c(0:25)
    names(let.to.num) = LETTERS
    p.index = as.numeric(let.to.num[strsplit(input$pkey_digits_val,"")[[1]]])
    temp.date = input$pkey_date_val
    temp.date = format(temp.date, "%m%d%Y")
    temp.date = as.character(temp.date)
    temp.pkey = gen_prm_keys(input$num_grids_val^2,  temp.date, p.index, nchar(input$pkey_digits_val))

    temp.pkey$pkey = append(prm.combs.val.z$pkey ,temp.pkey$pkey) ## adding the pkey of the selcted parameter combination
    temp.chosen.prms = c(input$parameter_choice1, input$parameter_choice2)

    ##2.generate validation parameter combinations
    #adding the selected parameter combination
    temp.prm.combs.val.z = rbind(data.frame(  t( prm.combs.val.z$prm.comb.selected.rescaled))[,1:numPrm$ml.model], prm.combs.val.z$DF)

    ##for this demo
    if(0){
      prm.combs.val.z$DF$kYp <- 0
      prm.combs.val.z$DF$dYp <- 0
      prm.combs.val.z$DF$n <- 0
      prm.combs.val.z$DF$K <- 0

    }
   
    
    temp.prm.combs.val <- fun.scale.conv(prm.set.method$method, 
                                         prm.ranges.selected$DF[1:numPrm$ml.model,], 
                                         prm.grids.selected$DF[1:numPrm$ml.model,], 
                                         temp.prm.combs.val.z[-1,], 
                                         z.to.org = TRUE)
    temp.prm.combs.val  = rbind(data.frame(  t( prm.combs.val.z$prm.comb.selected.original))[,1:numPrm$ml.model],  temp.prm.combs.val )
    
    if(1){
      temp.prm.combs.val[,parameters$prmset[(numPrm$ml.model+1):numPrm$prmset]] <- 
        t(matrix(
        rep(prm.grids.selected$DF[(numPrm$ml.model+1):numPrm$prmset,2],nrow( temp.prm.combs.val)), 
        nrow = numPrm$prmset - numPrm$ml.model))
      
    }
    
    
    
    prm.combs.val$DF  <- data.frame(pkey = temp.pkey$pkey, temp.prm.combs.val, stringsAsFactors = F)
    prm.combs.val$DF[,-1] <- signif(prm.combs.val$DF[,-1], digits = 6) ## as in "~/Dropbox/Codes/project_sim_ml/analysis/visualization/vec.plot.R"

    prm.combs.val$DF <-  rbind( prm.combs.val$DF[1,],prm.combs.val$DF)
    prm.combs.val$DF[1,] = NA
    prm.combs.val$DF[1,1] = "perturbed_prms"
    prm.combs.val$DF[1,input$parameter_choice1] = 1
    prm.combs.val$DF[1,input$parameter_choice2] = 2
  })


  # shinyFileSave(input, "save_prm_combs", roots = c("roots"= "~/"))
  # observe({
  #   # if(!is.null(prm.combinations$DF)){
  #   #
  #   # }
  #   print(input$save_prm_combs)
  #   file.info = parseSavePath(c("roots"= "~/"), input$save_prm_combs)
  #   print(file.info)
  #   if(nrow(file.info) > 0){
  #     if(file.info$type == "text"){
  #       isolate({
  #         write.table( prm.combinations$DF,file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
  #     }else if (file.info$type == "csv"){
  #       isolate({
  #         write.csv(prm.combinations$DF,file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
  #     }
  #   }
  # })
  #
  output$prm_combs_val <- renderDataTable({
    input$gen_prm_combs_val
    if(!is.null(prm.combs.val$DF )){
      isolate({
        prm.combs.val$DF[3:nrow(prm.combs.val$DF),]
      })
    }


  })


  output$save_prm_combs_val <- downloadHandler(
    filename = function() {
      paste0(selected$pkey, "_",input$parameter_choice1, "_", input$parameter_choice2,  ".txt")
    },
    content = function(file) {
      write.table(prm.combs.val$DF, file, row.names = FALSE,quote =FALSE)
    }

  )


  ##Generate validation plots
  prms.combs.val.sim <-reactiveValues()

  
  
  

  output$gen_validation_ui <- renderUI({
    list(
      selectInput(inputId = "plot_type_val",
                  label = "Plot type:",
                  choices = c("2D", "3D")),
      actionButton("gen_val_plots", "Generate validation plots")
    )
  })
  
  
  ## implement for retaining prm.val.z from generation.
  observeEvent(input$gen_val_plots,{
    if(!is.null(input$file_validation)){
      prms.combs.val.sim$DF <- read.table(input$file_validation$datapath, header = T, stringsAsFactors = F)
    }
    
    
    if(!is.null( ml.model.selected$ml.model) && !is.null(prms.combs.val.sim$DF) ){
      prms.combs.val.sim$selected_pkey = prms.combs.val.sim$DF[2,1]
      
      prms.combs.val.sim$DF_z = fun.scale.conv(prm.set.method$method, 
                                               prm.ranges.selected$DF, 
                                               prm.grids.selected$DF, 
                                               prms.combs.val.sim$DF[-1,-1], 
                                               z.to.org = FALSE)
      #print(prms.combs.val.sim$DF[2,2:(nrow(prm.ranges.phase)+1)])
      prms.combs.val.sim$selected_prm_comb_z = prms.combs.val.sim$DF_z[1,]
      
      #print( prms.combs.val.sim$DF_z[1,])
      prms.combs.val.sim$DF_z = prms.combs.val.sim$DF_z[-1,]
      prms.combs.val.sim$perturbed_prm1 = colnames(prms.combs.val.sim$DF)[which(prms.combs.val.sim$DF[1,] == 1)]
      prms.combs.val.sim$perturbed_prm2 = colnames(prms.combs.val.sim$DF)[which(prms.combs.val.sim$DF[1,] == 2)]
      prms.combs.val.sim$num_grids = sqrt(nrow(prms.combs.val.sim$DF)-2)
      
      prms.combs.val.sim$phenotype = colnames(prms.combs.val.sim$DF)[ncol(prms.combs.val.sim$DF)]
      
      prms.combs.val.sim$selected_prm_comb_z_pred = predict( ml.model.selected$ml.model,  prms.combs.val.sim$selected_prm_comb_z[,1:numPrm$ml.model]) - predict( ml.model.selected$ml.model.res,  prms.combs.val.sim$selected_prm_comb_z[,1:numPrm$ml.model])
      prms.combs.val.sim$selected_prm_comb_z_simulated = prms.combs.val.sim$DF[2, prms.combs.val.sim$phenotype]
      prms.combs.val.sim$pred = predict( ml.model.selected$ml.model,  prms.combs.val.sim$DF_z[,1:numPrm$ml.model]) - predict( ml.model.selected$ml.model.res,  prms.combs.val.sim$DF_z[,1:numPrm$ml.model])
      prms.combs.val.sim$simulated = prms.combs.val.sim$DF[-c(1,2), prms.combs.val.sim$phenotype]
      
      print( prms.combs.val.sim$perturbed_prm1 )
      print(prms.combs.val.sim$perturbed_prm2)
    }
  })
  
  
  
  

  output$validation_plots <- renderUI({
    # if(input$gen_val_plots[[1]] == 0){
    #   return(0)
    # }else{
    input$gen_val_plots
    if(!is.null(prms.combs.val.sim$DF)){
      isolate({
        if(input$plot_type_val == "2D"){
          list(
            column(4,plotOutput("val_plot_pred_2d", width = "400px")),
            column(4,plotOutput("val_plot_sim_2d", width = "400px")),
            column(4,plotOutput("val_plot_corr", width = "400px"))
          )
        }else if(input$plot_type_val == "3D"){
          list(
            column(4,rglwidgetOutput("val_plot_pred_3d", width = "400px")),
            column(4,rglwidgetOutput("val_plot_sim_3d", width = "400px")),
            column(4,plotOutput("val_plot_corr", width = "400px"))
          )
        }
      })
    }
  })

  
 


  output$val_plot_pred_2d <- renderPlot({
    input$gen_val_plots
    print(prms.combs.val.sim$selected_prm_comb_z)
    #since rf models were trained without kYp, dYp, n, K
    isolate({if(!is.null( ml.model.selected$ml.model)){
      if(0){
        vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,prms.combs.val.sim$selected_prm_comb_z[1:numPrm$ml.model],
                        c(prms.combs.val.sim$perturbed_prm1, prms.combs.val.sim$perturbed_prm2),prm.ranges.z.selected$DF[,1:numPrm$ml.model], grid.lines =  prms.combs.val.sim$num_grids, zoom = 1, zlim = c(-0.2,1.2), gap = 0 , three.dim = F)
      }

      if(1){
        image2D(matrix( prms.combs.val.sim$pred, nrow = prms.combs.val.sim$num_grids), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]), contour = T, zlim = c(-0.2,1.2),xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2)
        points(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], pch =  19 )
      }
    }})


  })

  output$val_plot_sim_2d <- renderPlot({
    input$gen_val_plots
    isolate({if(!is.null( ml.model.selected$ml.model)){
      image2D(matrix(prms.combs.val.sim$simulated, nrow =prms.combs.val.sim$num_grids), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]), contour = T, zlim = c(-0.2,1.2),xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2)
      points(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], pch =  19 )
    }})
  })


  output$val_plot_pred_3d <- renderRglwidget({
    input$gen_val_plots
    #since rf models were trained without kYp, dYp, n, K
    isolate({if(!is.null( ml.model.selected$ml.model)){
      try(rgl.close(), silent = TRUE)

      if(0){
        vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,prms.combs.val.sim$selected_prm_comb_z[1:numPrm$ml.model],
                        c(prms.combs.val.sim$perturbed_prm1, prms.combs.val.sim$perturbed_prm2),prm.ranges.z.selected$DF[,1:numPrm$ml.model], grid.lines =  prms.combs.val.sim$num_grids, zoom = 1, zlim = c(-0.2,1.2), gap = 0 , three.dim = T)
      }

      if(1){
        color.gradient <- function(x, colors=c("blue", "green","yellow","red"), colsteps=100) {
          return( colorRampPalette(colors) (colsteps) [ findInterval(x, seq(-0.2, 1.2, length.out=colsteps)) ] )
        }
        plot3d(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2],
               z = prms.combs.val.sim$pred, zlim = c(-0.2,1.2), xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2, zlab = prms.combs.val.sim$phenotype)
        plot3d(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], z =   prms.combs.val.sim$selected_prm_comb_z_pred, xlab = prms.combs.val.sim$perturbed_prm1, ylab = prms.combs.val.sim$perturbed_prm2,
               main = "Prediction", col = "red", size = 7, add = TRUE, zlim = c(-0.2,1.2))
        surface3d(unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]),
                  z = prms.combs.val.sim$pred, col = color.gradient( prms.combs.val.sim$pred), size = 4, alpha = 0.4, zlim = c(0,1))

      }
      scene2<- scene3d()
      rglwidget(scene2)
      
    }})
   

  })

  output$val_plot_sim_3d <- renderRglwidget({
    input$gen_val_plots
    isolate({if(!is.null( ml.model.selected$ml.model)){
      try(rgl.close(), silent = TRUE)
      color.gradient <- function(x, colors=c("blue", "green","yellow","red"), colsteps=100) {
        return( colorRampPalette(colors) (colsteps) [ findInterval(x, seq(-0.2, 1.2, length.out=colsteps)) ] )
      }
      plot3d(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2],
             z = prms.combs.val.sim$simulated, zlim = c(-0.2,1.2), xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2, zlab = prms.combs.val.sim$phenotype)
      plot3d(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], z = prms.combs.val.sim$selected_prm_comb_z_simulated, xlab = prms.combs.val.sim$perturbed_prm1, ylab = prms.combs.val.sim$perturbed_prm2,
             main = "Simulation", col = "red", size = 7, add = TRUE, zlim = c(-0.2,1.2))
      surface3d(unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]),
                z = prms.combs.val.sim$simulated, col = color.gradient(prms.combs.val.sim$simulated), size = 4, alpha = 0.4, zlim = c(0,1))

      scene3<- scene3d()
      rglwidget(scene3)
    }})

  })


  output$val_plot_corr <- renderPlot({
    input$gen_val_plots

    isolate({if(!is.null( ml.model.selected$ml.model)){
      df <- data.frame(x = prms.combs.val.sim$simulated, y = prms.combs.val.sim$pred )
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(-0.2,1) +ylim(-0.2,1) + ggtitle(paste0("Pred VS Sim for ", prms.combs.val.sim$perturbed_prm1," and ", prms.combs.val.sim$perturbed_prm2, ": corr = ", signif(cor( prms.combs.val.sim$simulated, prms.combs.val.sim$pred), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }})
  })







  #h-clustering for prm.z and localVarImp
  output$gen_hclust_ui <- renderUI({
    list(
      actionButton("gen_hclust","Generate hierachical clustering plots!")
    )

  })


  brush.points <- reactiveValues()
  observeEvent(input$gen_hclust,{
    if(!is.null(input$tsne_brush)){
      brush.points$rtsne = brushedPoints(ggdata, input$tsne_brush)
      
      
      if(!is.null(ml.model.selected$ml.model)){
        brush.points$loc.imp = local.importance$DF[local.importance$DF$pkey %in% brush.points$rtsne$pkey,1:(numPrm$ml.model+1)]
        row.names(brush.points$loc.imp) = brush.points$loc.imp$pkey
        brush.points$loc.imp = brush.points$loc.imp[,-1]
      }else{
        numPrm$ml.model <- num.Prm$prmset
      }
      brush.points$prm.z = prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey %in% brush.points$rtsne$pkey,1:(numPrm$ml.model+1)]
      row.names( brush.points$prm.z) = brush.points$prm.z$pkey
      brush.points$prm.z = brush.points$prm.z[,-1]
      
      
      
      
    }else{
      brush.points$rtsne <- NULL
      brush.points$prm.z <- NULL
      brush.points$loc.imp <- NULL
    }
   
  })

  myfun <- function(x) hclust(x, method = "ward.D")

  output$hclust_prms <- renderPlot({
    if(!is.null(brush.points$prm.z)){
      isolate({
        colors <- c(seq(-1.5,1.5,length=100))
        heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun, Rowv = TRUE, Colv = FALSE, trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
      })
    }
  })

  output$hclust_local_varimp <- renderPlot({
      if(!is.null(brush.points$loc.imp)){
        isolate({
        colors <- c(seq(-0.2,0.2,length=100))
        heatmap.2(as.matrix(brush.points$loc.imp), hclustfun = myfun, Rowv = TRUE, Colv = FALSE, trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance") )
        })
      }
    
  })

  
}

