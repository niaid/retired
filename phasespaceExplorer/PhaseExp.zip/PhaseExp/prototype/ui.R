#####Proto web version for deploying to Monarch######
#####Only contain two gene simple network ###########


ui <- dashboardPage(
  dashboardHeader(title = "Stochastic simulation and phase space exploration",titleWidth = 700),
  dashboardSidebar(
    sidebarMenu(id = "side_menu_tab",
      menuItem("Overview", tabName = "overview_tab"),
      menuItem("Workspace", tabName = "workspace_tab"),
      # menuItem("Parameter combination sampling", tabName = "prm_smpl_tab",
      #          menuSubItem("Inital sampling", tabName = "init_smpl_tab"),
      #          menuSubItem("Additional sampling", tabName = "add_smpl_tab")),
      menuItem("Explore phase space", tabName = "exp_phase_tab")
    )
    
  ),
  dashboardBody(
    tabItems(
      tabItem("overview_tab",
                tags$div(img(src = "images/figure1.png", width = "800"))
                    ),
      tabItem("workspace_tab",
              # fluidRow(
              #   
              #   column(3,h4("Create a new phasespace."), 
              #          textInput("phasespace_name", "Phasespace name."),
              #          actionButton("new_phasespace","Create!")),
              #   column(4,fileInput("file_phasespace", 
              #                      h4("Open an existing phasespace."))),
              #   column(3,h4("Save the current phasespace (.Rds)"),
              #          #textInput("file_phasespace_name", "File name.", value=".Rds"),
              #          #downloadButton("save_phasespace","Save!")),
              #          shinySaveButton("save_phasespace", "Save!", "Save as ...", filetype=list(Rds="Rds"))
              #   )
              # ),
              # br(),
              # hr(),
              fluidPage(
                column(4,uiOutput("current_phasespace_name"))
              ),
              
              fluidRow(
                column(4, uiOutput("list_prm_ranges")),
                column(4, uiOutput("list_init_prm_combs")),
                column(4, uiOutput("list_addit_prm_combs"))
                ),
              
              fluidRow(
                column(4)
              )
              
              
              ),
      
      
      # tabItem("init_smpl_tab",
      #         
      #         #h1("Parameter combination generation"),
      #         sidebarLayout(
      #            sidebarPanel(selectInput("sampling_meth", label = h5("Select a sampling method."),
      #                                    choices = list("Uniform grid" = "unif_grid", "Pseudorandom" = "pseudorandom", "Sobol'" = "sobol'", "Latin hypercube" = "latin_hyp")),
      #                        numericInput("prm_comb_num", label = h5("Number of parameter combinations"), value = 1000, min = 1, max = 10000000),
      #                        h5("Parameter keys"),
      #                        fluidRow(
      #                          column(6,dateInput("pkey_date", label = h6("Current date"), format = "mmddyyyy")),
      #                          column(6,textInput("pkey_digits", label = h6("Starting digit")))
      #                        ),
      #                        actionButton("gen_prm_combs", "Generate!"),
      #                        #uiOutput("save_prm_combs_ui")
      #                        shinySaveButton("save_prm_combs", "Save as a file", "Save parameter combinations as ...", filetype=list(text="txt", csv = "csv")),
      #                        br(),
      #                        textInput("init_prm_combs_name",label = h5("Enter a name for this parameter set")),
      #                        actionButton("init_prm_combs_save2ps", "Add to Phasespace"),
      #                        uiOutput("list_init_prm_combs_ui"),
      #                        verbatimTextOutput("test")
      #           ),
      # 
      # 
      # 
      #           mainPanel(h4("Load parameter ranges"),
      #                      
      #                     fluidRow(
      #                        column(4, uiOutput("file_ui")), 
      #                        column(4, uiOutput("prm_ranges_select_ui")),
      #                        column(2,actionButton("reset", "Reset"),
      #                               actionButton("load", "Load"))
      #                     ),
      #                     
      #                     fluidRow(
      #                       column(3, uiOutput("prm_num_ui")),
      #                       column(3,h5("Log scale"),
      #                              actionButton("sel_desel_all", label = "Select/Deselect All"))
      #                     ),  
      #                     fluidRow(
      #                       column(6,rHandsontableOutput("parameter_ranges")
      #                       )
      #                      
      #                     ),
      #                     br(),
      #                     fluidRow(
      #                       column(3, textInput("prm_ranges_name", h5("Name of parameter ranges")),
      #                              actionButton("prm_ranges_save2ps",label = "Add to Phasespace"),
      #                              shinySaveButton("save", "Save as a file", "Save parameter ranges as ...", filetype=list(text="txt", csv = "csv"))),
      #                       column(3, uiOutput("prm_grids_gen_ui"))
      #                     ),
      # 
      #                     uiOutput("prm_grids_ui"),
      # 
      #                     uiOutput("prm_comb_ui")
      # 
      #                     #tableOutput("prm.ranges.dup")
      # 
      # 
      #                     )
      # 
      #           )
      # 
      #         
      #         ),
      # tabItem("add_smpl_tab",
      #        # h1("Parameter combination zoom-in"),
      #         sidebarLayout(
      #           sidebarPanel(selectInput("add_sampling_meth", label = h5("Select a sampling method."),
      #                                    choices = list("Uniform grid" = "unif_grid", "Pseudorandom" = "pseudorandom", "Sobol'" = "sobol'", "Latin hypercube" = "latin_hyp")),
      #                        numericInput("add_prm_comb_num", label = h5("Number of sampling per each selected combination"), value = 100, min = 1, max = 10000000),
      # 
      #                        h5("Parameter keys"),
      #                        fluidRow(
      #                          column(6,dateInput("add_pkey_date", label = h6("Current date"), format = "mmddyyyy")),
      #                          column(6,textInput("add_pkey_digits", label = h6("Starting digit")))
      #                        ),
      # 
      # 
      #                        actionButton("gen_prm_combs_zoomin", "Generate!"),
      #                        #uiOutput("save_prm_combs_ui")
      #                        shinySaveButton("save_prm_combs_zoomin", "Save as a file", "Save parameter combinations as ...", filetype=list(text="txt", csv = "csv")),
      #                        br(),
      #                        textInput("addit_prm_combs_name",label = h5("Enter a name for this parameter set")),
      #                        actionButton("addit_prm_combs_save2ps", "Add to Phasespace"),
      #                        uiOutput("list_addit_prm_combs_ui"),
      #                        
      #                        verbatimTextOutput("add_test")
      #           ),
      # 
      # 
      # 
      #           mainPanel(h4("Load an existing parameter space"),
      #                     fluidRow(
      #                       column(4,uiOutput("laad_prm_ranges_ui")),
      #                       column(4,uiOutput("load_init_prm_combs_ui")),        
      #                       column(2,actionButton("add_reset", "Reset"))
      #                     ),
      #                     
      #                     h4("Selected parameter combinations"),
      #                     uiOutput("file_prm_selected_ui"),
      #                     
      #                     
      #                     fluidRow(
      #                       uiOutput("prm_space_selected_tab_ui")
      #                     ),
      #                  
      #                     uiOutput("prm_comb_zoomin_ui")
      #             
      #                     )
      # 
      #           )
      # 
      #         ),
      # 
      tabItem("exp_phase_tab",
              fluidRow(
                column(3, uiOutput("list_phenotypes_tab_ui")),
                column(3, uiOutput("list_prm_sets_tab_ui")),
                column(3, uiOutput("list_ml.models_tab_ui")),
                column(3, actionButton("launch_exp_phase",label = "Launch!"),
                       verbatimTextOutput("test_exp_phase_tab"))
              ),
              
              fluidRow(
                column(7,
                       "Parameter space in t-SNE",
                       sidebarLayout(
                        
                         sidebarPanel(
                           uiOutput("exp_phase_side_ui"), width = 3
                         ),
                         
                         mainPanel(plotOutput("t_SNE", 
                                              dblclick = "tsne_dblclick",
                                              click = "tsne_click",
                                              brush = brushOpts(
                                                id = "tsne_brush",
                                                resetOnNew = TRUE
                                              )),width = 9)
                       )
                ),
                column(3,h5("Global variable importance"),
                       plotOutput("global_varImp",height = "300px")
                       ),
                
                column(2,
                       br(),
                       br(),
                       tableOutput("parmeter_values")
                )
              ),
              br(),
              br(),
              fluidRow(
                tabBox(id = "selection", selected = NULL, width = 12, #type = "pills",
                            tabPanel("Heatmap for selected points", value = "tab_hclust",
                                    
                                     fluidRow(
                                       uiOutput("gen_hclust_ui")
                                     ),
                                     fluidRow(
                                       column(6,
                                              plotOutput("hclust_prms",height = "600px")),
                                       column(6,
                                              plotOutput("hclust_local_varimp",height = "600px"))
                                     )),
                            
                            tabPanel("Variable importance and parameter perturbation", value = "tab_varImp_perturb",
                                     
                                     fluidRow(
                                       column(4,
                                              "Local  importance",
                                              #plotOutput("global_varImp",height = "300px"),
                                              plotOutput("local_varImp", height = "300px")
                                       ),
                                       column(8,
                                              "Perturbation",
                                              #choice of parameters to perturb and the type. actionbutton for generation
                                              fluidRow(
                                                column(3,
                                                       uiOutput("parameter_choice1"),
                                                       uiOutput("parameter_choice2"),
                                                       selectInput(inputId = "plot_type",
                                                                   label = "Plot type:",
                                                                   choices = c("2D", "3D")),
                                                       numericInput("num_grids_val", label = h6("Number of grids"),value = 30, min = 2, max = 100),
                                                       actionButton(inputId = "plot_gen",
                                                                    label = "Generate a plot!")
                                                ),
                                                column(9,
                                                       uiOutput("perturb_plot")
                                                ),
                                                uiOutput("gen_prm_combs_val_ui")
                                                
                                              )
                                       )
                                     )
                            
                                     ),
                            tabPanel("Validation", value = "tab_val",
                                    
                                     fileInput("file_validation", "Load a validation simulation result (.txt, .csv)."),
                                     uiOutput("gen_validation_ui"),
                                     uiOutput("validation_plots")
                            
                                     ),
                            tabPanel("Navigation", value = "tab_nav",
                                    
                                     fluidRow(
                                       ##parameter sliders
                                       column(6, wellPanel(id = "tPanel",
                                                           style = "overflow-y:scroll; max-height: 300px",
                                                           uiOutput("parameters")))
                                       
                                     
                                       )
                                     
                            
                                     )
                            
                
                            )
                
              
                )
              
              )
    )
  )
)