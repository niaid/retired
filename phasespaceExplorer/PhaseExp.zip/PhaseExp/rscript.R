pkgs = c("httpuv", "shiny", "shinydashboard", "shinyBS", "rhandsontable", "shinyFiles", "randtoolbox", "Rcpp", "lhs", "randomForest", "ggplot2", "plot3D", "rgl",  "gplots", "shinyFiles", "DT",  "lattice", "caret", "gridExtra")
install.packages(pkgs, repos='https://cran.rstudio.com/')

