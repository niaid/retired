source("classes.R")
source("global.R")

two.gene.phase = new(Class = "Phasespace", name = "Two-gene simple network")
get.prm.space(two.gene.phase)
get.phenotypes(two.gene.phase)

test.object <- readRDS("test.Rds")
test.object@phasespace.name


####construct phasespaces in the paper.
##############################
########two_gene_smpl#########
##############################
load("~/Dropbox/Codes/project_sim_ml/analysis/two_gene/run_Sep29_HPC/analysis.RData")
load("~/Dropbox/Codes/project_sim_ml/analysis/Figures/two_gene.RData")
load("~/Dropbox/Codes/project_sim_ml/packaging/two_gene_phasespace.RData")



###initial parameter combinations
two_gene_smpl_mod_unifgrid_init <- read.table("~/Dropbox/Codes/project_sim_ml/simrun/HPC/two_gene/run_Sep29/prmsets_042015.txt",stringsAsFactors = F )
two_gene_smpl_mod_unifgrid_init  <- two_gene_smpl_mod_unifgrid_init[,c(1,3:16)]
names(two_gene_smpl_mod_unifgrid_init) <- names(data.clust)[1:15]
two_gene_smpl_mod_unifgrid_init

## use this parameter grids match the number of sinificant digits
prm.grids.old <- read.table("~/Dropbox/Codes/project_sim_ml/simrun/HPC/two_gene/prm_grids_revised_040815.txt", stringsAsFactors = F)
prm.grids.old <- t(prm.grids.old)
prm.grids.old <- data.frame(names = names(data.clust)[2:15], prm.grids.old, stringsAsFactors = F)
names(prm.grids.old) = names(two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$prm.grids)





two_gene_smpl <- readRDS("~/Dropbox/Codes/project_sim_ml/packaging/proto_app_OOBenv/two_gene_phasespace.Rds")
#initial parameter set from 100000 parameters
two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$prm.combs <- two_gene_smpl_mod_unifgrid_init
two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$prm.grids <- prm.grids.old


temp.prm.ranges <- data.frame(two_gene_smpl@prm.space$prm.ranges$two_gene_smpl_mod,
                              log.scale = two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$log.scale$log.scale,
                              `number of grids` = two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$num.grids$`number of grids`,
                              stringsAsFactors = F)
names(temp.prm.ranges)[5] = "number of grids"
two_gene_smpl_mod_unifgrid_init.z <- fun.scale.conv(sample_meth = two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$method, 
                                                    prm.ranges = temp.prm.ranges, 
                                                    prm.grids = prm.grids.old,
                                                    prm.combs = two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$prm.combs[,2:15], 
                                                    z.to.org = FALSE 
                                                    )
two_gene_smpl_mod_unifgrid_init.z <- data.frame(pkey = two_gene_smpl_mod_unifgrid_init$pkey, two_gene_smpl_mod_unifgrid_init.z, stringsAsFactors = F)
two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$prm.combs.z <- two_gene_smpl_mod_unifgrid_init.z

#compare with two_gene_smpl_mod_unifgrid_init.z and data.clust.z
temp.to.compare.z <- two_gene_smpl_mod_unifgrid_init.z[two_gene_smpl_mod_unifgrid_init.z$pkey %in% data.clust.z$pkey,]
data.clust.z.ordered <- data.clust.z[order(data.clust.z$pkey),]
temp.to.compare <- two_gene_smpl_mod_unifgrid_init[two_gene_smpl_mod_unifgrid_init$pkey %in% data.clust$pkey,]
data.clust.ordered <- data.clust[order(data.clust$pkey),]


row.names(data.clust.z.ordered) <- NULL
row.names(temp.to.compare.z) <- NULL
all.equal(temp.to.compare.z[,2:11], data.clust.z.ordered[,2:11])

row.names(data.clust.ordered) <- NULL
row.names(temp.to.compare) <- NULL
all.equal(temp.to.compare[,2:11], data.clust.ordered[,2:11])


###additional parameter combinations
two_gene_smpl_mod_unifgrid_selected <- 
two_gene_smpl_mod_unifgrid_addit <- read.table("~/Dropbox/Codes/project_sim_ml/analysis/two_gene/run_Sep29_HPC/run_Dec23/prmsets_122315_zoom.txt",stringsAsFactors = F )
two_gene_smpl_mod_unifgrid_addit <- two_gene_smpl_mod_unifgrid_addit[,c(1,3:16)]
names(two_gene_smpl_mod_unifgrid_addit) <- names(data.clust)[1:15]
two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$two_gene_smpl_mod_unifgrid_add$prm.combs <- two_gene_smpl_mod_unifgrid_addit 

two_gene_smpl_mod_unifgrid_addit.z <- fun.scale.conv(sample_meth = two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$two_gene_smpl_mod_unifgrid_add$method,
                                                   prm.ranges = temp.prm.ranges, 
                                                   prm.grids = prm.grids.old,
                                                   prm.combs =two_gene_smpl_mod_unifgrid_addit[,2:15],
                                                   z.to.org = FALSE
                                                   )
two_gene_smpl_mod_unifgrid_addit.z <- data.frame(pkey = two_gene_smpl_mod_unifgrid_addit$pkey, two_gene_smpl_mod_unifgrid_addit.z, stringsAsFactors = F)
temp.to.compare.z.add <- two_gene_smpl_mod_unifgrid_addit.z[ two_gene_smpl_mod_unifgrid_addit.z$pkey %in% data.clust.zoom1.z$pkey,]
all.equal(temp.to.compare.z.add$pkey, data.clust.zoom1.z$pkey )
row.names(temp.to.compare.z.add) <- NULL
row.names(data.clust.zoom1.z) <- NULL

all.equal(temp.to.compare.z.add[,2:11], data.clust.zoom1.z[,2:11] )

two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$two_gene_smpl_mod_unifgrid_add$prm.combs.z <- two_gene_smpl_mod_unifgrid_addit.z
two_gene_smpl_mod_unifgrid_init_selected <- data.clust.zoom[order(data.clust.zoom$pkey),1:15]
two_gene_smpl_mod_unifgrid_init_selected1 <- temp.to.compare[data.clust.ordered$mxmy.max >0.7, ]

all.equal(two_gene_smpl_mod_unifgrid_init_selected, two_gene_smpl_mod_unifgrid_init_selected1,check.attributes = FALSE)
two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$two_gene_smpl_mod_unifgrid_add$prm.combs.selected <- two_gene_smpl_mod_unifgrid_init_selected

saveRDS(two_gene_smpl, file ="two_gene_phasespace.Rds")

two_gene_smpl@analysis <-list()
two_gene_smpl@model <- list()
two_gene_smpl@simulation <- list()
two_gene_smpl@phasespace.name
 

#phenotypes
names(data.clust.ordered)[16:27]
data.clust.zoom1.phen <- read.csv("~/Dropbox/Codes/project_sim_ml/analysis/two_gene/run_Sep29_HPC/run_Dec23/corr_zoom.csv", stringsAsFactors = F)
all.equal(temp.to.compare.z.add$pkey , data.clust.zoom1.phen$pkey)




for(i in 16:27){
  add.phenotypes(two_gene_smpl) <- list(name = names(data.clust.ordered)[i], 
                                        prm.combs.name = "two_gene_smpl_mod_unifgrid",
                                        phenotype = data.frame(pkey = data.clust.ordered$pkey,  data.clust.ordered[,i], stringsAsFactors = F) )
  
  names(two_gene_smpl@phenotypes[[names(data.clust.ordered)[i]]][["two_gene_smpl_mod_unifgrid"]])[2] = names(data.clust.ordered)[i]
  
}

for(i in 2:13){
  add.phenotypes(two_gene_smpl) <- list(name = names(data.clust.zoom1.phen)[i], 
                                        prm.combs.name = "two_gene_smpl_mod_unifgrid_add",
                                        phenotype = data.frame(pkey = data.clust.zoom1.phen$pkey,  data.clust.zoom1.phen[,i], stringsAsFactors = F) )
  
  names(two_gene_smpl@phenotypes[[names(data.clust.zoom1.phen)[i]]][["two_gene_smpl_mod_unifgrid_add"]])[2] = names(data.clust.zoom1.phen)[i]
  
}

two_gene_smpl@phenotypes$mxmy.st$two_gene_smpl_mod_unifgrid_add

names(two_gene_smpl@phenotypes)
length(two_gene_smpl@phenotypes)
saveRDS(two_gene_smpl, file ="two_gene_phasespace.Rds")

#mean sd

two_gene_simple <- readRDS("phasespace/two_gene_simple.Rds")
two_gene_simple  <- readRDS("phasespace/two_gene_simple_lags1.Rds")
phen.mean.sd.init <- read.table("../../analysis/two_gene/run_Sep29_HPC/phen.mean.sd.txt", stringsAsFactors = F)
phen.mean.sd.addit <- read.table("../../analysis/two_gene/run_Sep29_HPC/phen.mean.sd.addit.txt", stringsAsFactors = F)


for(i in 2:7){
  add.phenotypes(two_gene_simple) <- list(name = names(phen.mean.sd.init)[i], 
                                        prm.combs.name = "two_gene_smpl_mod_unifgrid",
                                        phenotype = phen.mean.sd.init[,c(1,i)])
  
 
  
}

for(i in 2:7){
  add.phenotypes(two_gene_simple) <- list(name = names(phen.mean.sd.addit)[i], 
                                          prm.combs.name = "two_gene_smpl_mod_unifgrid_add",
                                          phenotype = phen.mean.sd.addit[,c(1,i)])
  
  
  
}

saveRDS(two_gene_simple, file ="phasespace/two_gene_simple.Rds")
saveRDS(two_gene_simple, file ="phasespace/two_gene_simple_lags1.Rds")



#ml.model
two_gene_smpl <- readRDS("~/Dropbox/Codes/project_sim_ml/packaging/proto_app_OOBenv/two_gene_phasespace.Rds")
source("classes.R")
load("~/Dropbox/Codes/project_sim_ml/analysis/visualization/rf.two.gene.combined.bc.rda")
load("~/Dropbox/Codes/project_sim_ml/analysis/visualization/visualization.RData")
saveRDS(rf.two.gene.combined.bc, file ="ml.models/rf.mxmy.max.combined.whole.reg.Rds")
saveRDS(rf.two.gene.combined.res, file ="ml.models/rf.mxmy.max.combined.whole.reg.res.Rds")

all.equal(data.dim.red.comp.add1[1:76532,1:10], data.clust.z[,2:11])
temp.to.compare.z = two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid$prm.combs.z
temp.to.compare.z = temp.to.compare.z[temp.to.compare.z$pkey %in% data.clust.z$pkey, ]
row.names(temp.to.compare.z ) <- NULL                                                                                                      
row.names(data.clust.z) <- NULL
all.equal(data.dim.red.comp.add1[1:76532,1:10],temp.to.compare.z[,2:11])
all.equal(data.clust.z[,2:11],temp.to.compare.z[,2:11])
all.equal(data.clust.z[order(data.clust.z$pkey),2:11],temp.to.compare.z[,2:11], check.attributes = FALSE)
all.equal(data.clust.zoom1$pkey, data.dim.red.comp.add1$pkey[76533:107567])

temp.pkey = data.frame(append(data.clust.z$pkey, data.clust.zoom1$pkey),stringsAsFactors = F)
rf.two.gene.combined.bc$pkey <- append(as.character(data.clust.z$pkey), data.clust.zoom1$pkey)
rf.two.gene.combined.res$pkey <- append(as.character(data.clust.z$pkey), data.clust.zoom1$pkey)

saveRDS(rf.two.gene.combined.bc, file ="ml.models/rf.mxmy.max.combined.whole.reg.Rds")
saveRDS(rf.two.gene.combined.res, file ="ml.models/rf.mxmy.max.combined.whole.reg.res.Rds")

names(two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod)
names(two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid)

add.ml.model(two_gene_smpl) <- list(phenotype.name = "mxmy.max",
                                    name = "rf.mxmy.max.combined.whole.reg", 
                                    ml.model.path = "ml.models/rf.mxmy.max.combined.whole.reg.Rds", 
                                    ml.model.res.path = "ml.models/rf.mxmy.max.combined.whole.reg.res.Rds" ,
                                    mode = "regression",
                                    prm.sets.used = c(names(two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod),
                                                      names(two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid)
                                                      ), 
                                    train.data = "whole", 
                                    test.data = NULL,
                                    class.def = NULL  )

saveRDS(two_gene_smpl, file ="two_gene_phasespace.Rds")



##analysis
two_gene_smpl <- readRDS("~/Dropbox/Codes/project_sim_ml/packaging/proto_app_OOBenv/two_gene_phasespace.Rds")
rtsne.out.corr.ordered <- rtsne.out.corr[order(rtsne.out.corr$pkey),]
rtsne.out.corr.zoom.ordered <- rtsne.out.corr.zoom[order(rtsne.out.corr.zoom$pkey),]
names(rtsne.out.corr.ordered) <- c("pkey", "tSNE1", "tSNE2")
names(rtsne.out.corr.zoom.ordered) <- c("pkey", "tSNE1", "tSNE2")
all.equal(rtsne.out.corr.ordered$pkey, rtsne.out.corr$pkey)
all.equal(rtsne.out.corr.zoom.ordered$pkey, rtsne.out.corr.zoom$pkey)

two_gene_smpl 

add.tsne.coord(two_gene_smpl) <- list( prm.combs.name = names(two_gene_smpl@prm.space$initial.prm.combs$two_gene_smpl_mod), 
                                       tsne.coord = rtsne.out.corr.ordered[,1:3])

add.tsne.coord(two_gene_smpl) <- list( prm.combs.name = names(two_gene_smpl@prm.space$additional.prm.combs$two_gene_smpl_mod$two_gene_smpl_mod_unifgrid), 
                                       tsne.coord = rtsne.out.corr.zoom.ordered[,1:3])
two_gene_smpl@analysis$tsne$two_gene_smpl_mod_unifgrid_add

saveRDS(two_gene_smpl, file ="two_gene_phasespace.Rds")


#simulation
two_gene_smpl@simlulation[["failed"]] <-list()








##three_gene_feedforward
three_gene_feedforward_pnp <- readRDS("three_gene_feedforward_PNP/three_gene_feedforward_pnp.Rds")
load("~/Dropbox/Codes/project_sim_ml/analysis/three_gene_ffd/run_Apr27_2016/analysis.RData")

#prm ranges
prm_range_three_gene_object <- t(prm_range)
prm_range_three_gene_object <- t(prm_range)
prm_range_three_gene_object <- data.frame(prm_range_three_gene_object, stringsAsFactors = F)
prm_range_three_gene_object$names <- row.names(prm_range_three_gene_object)
colnames(prm_range_three_gene_object) <- c("min","max", "names")
prm_range_three_gene_object <- prm_range_three_gene_object[,c("names", "min","max")]
write.table(prm_range_three_gene_object, file="three_gene_feedforward_PNP/prm.range.txt", quote = F, row.names = F)

#initial parameter combinations (generated from the shiny app, pkey is modified later.)
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$method
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$log.scale
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$raw.smpl
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$prm.combs
View(three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$prm.combs
)
all.equal(three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_init_sobol'"$prm.combs[,-1],
          abs(prmset[,c(3:26)]), check.attributes = FALSE )
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$prm.combs[,1] <- as.character(prmset[,1])
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$prm.combs.z[,1] <- as.character(prmset[,1])
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$raw.smpl[,1] <- as.character(prmset[,1])
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_feedforward_all$"three_gene_feedforward_all_init_sobol'"$raw.smpl
saveRDS(three_gene_feedforward_pnp, file ="three_gene_feedforward_PNP/three_gene_feedforward_pnp.Rds")


#change names
names(three_gene_feedforward_pnp@prm.space$prm.ranges) <- "three_gene_ff_all"
names(three_gene_feedforward_pnp@prm.space$initial.prm.combs) <- "three_gene_ff_all"
names(three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_ff_all) <- "three_gene_ff_all_init_sobol'"
three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_ff_all$`three_gene_ff_all_init_sobol'`
saveRDS(three_gene_feedforward_pnp, file ="three_gene_feedforward_PNP/three_gene_feedforward_pnp.Rds")

temp.prmset <- get.init.prm.combs(three_gene_feedforward,name = "three_gene_ff_all_sobol'",prm.ranges.name = "three_gene_ff_all" )



temp.prmset.ppp = temp.prmset$prm.combs[sign1 > 0 & sign2 > 0 & sign3 > 0, ]
temp.prmset.ppn = temp.prmset$prm.combs[sign1 > 0 & sign2 > 0 & sign3 < 0, ]
temp.prmset.pnp = temp.prmset$prm.combs[sign1 > 0 & sign2 < 0 & sign3 > 0, ]
temp.prmset.pnn = temp.prmset$prm.combs[sign1 > 0 & sign2 < 0 & sign3 < 0, ]
temp.prmset.npp = temp.prmset$prm.combs[sign1 < 0 & sign2 > 0 & sign3 > 0, ]
temp.prmset.npn = temp.prmset$prm.combs[sign1 < 0 & sign2 > 0 & sign3 < 0, ]
temp.prmset.nnp = temp.prmset$prm.combs[sign1 < 0 & sign2 < 0 & sign3 > 0, ]
temp.prmset.nnn = temp.prmset$prm.combs[sign1 < 0 & sign2 < 0 & sign3 < 0, ]

temp.prmset.ppp.z = temp.prmset$prm.combs.z[sign1 > 0 & sign2 > 0 & sign3 > 0, ]
temp.prmset.ppn.z = temp.prmset$prm.combs.z[sign1 > 0 & sign2 > 0 & sign3 < 0, ]
temp.prmset.pnp.z = temp.prmset$prm.combs.z[sign1 > 0 & sign2 < 0 & sign3 > 0, ]
temp.prmset.pnn.z = temp.prmset$prm.combs.z[sign1 > 0 & sign2 < 0 & sign3 < 0, ]
temp.prmset.npp.z = temp.prmset$prm.combs.z[sign1 < 0 & sign2 > 0 & sign3 > 0, ]
temp.prmset.npn.z = temp.prmset$prm.combs.z[sign1 < 0 & sign2 > 0 & sign3 < 0, ]
temp.prmset.nnp.z = temp.prmset$prm.combs.z[sign1 < 0 & sign2 < 0 & sign3 > 0, ]
temp.prmset.nnn.z = temp.prmset$prm.combs.z[sign1 < 0 & sign2 < 0 & sign3 < 0, ]

temp.prmset.ppp.raw = temp.prmset$raw.smpl[sign1 > 0 & sign2 > 0 & sign3 > 0, ]
temp.prmset.ppn.raw = temp.prmset$raw.smpl[sign1 > 0 & sign2 > 0 & sign3 < 0, ]
temp.prmset.pnp.raw = temp.prmset$raw.smpl[sign1 > 0 & sign2 < 0 & sign3 > 0, ]
temp.prmset.pnn.raw = temp.prmset$raw.smpl[sign1 > 0 & sign2 < 0 & sign3 < 0, ]
temp.prmset.npp.raw = temp.prmset$raw.smpl[sign1 < 0 & sign2 > 0 & sign3 > 0, ]
temp.prmset.npn.raw = temp.prmset$raw.smpl[sign1 < 0 & sign2 > 0 & sign3 < 0, ]
temp.prmset.nnp.raw = temp.prmset$raw.smpl[sign1 < 0 & sign2 < 0 & sign3 > 0, ]
temp.prmset.nnn.raw = temp.prmset$raw.smpl[sign1 < 0 & sign2 < 0 & sign3 < 0, ]


circuit.type.names<- c("ppp", "ppn", "pnp", "pnn", "npp", "npn", "nnp", "nnn")
prmset.type.names <- paste0("three_gene_ff_",circuit.type.names,"_sobol'")
for(i in 1:8){
  three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all[[prmset.type.names[i]]] <- three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all[["three_gene_ff_all_sobol'"]]
  temp.expr <- paste0("three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all[[prmset.type.names[i]]]$prm.combs <- temp.prmset.",circuit.type.names[i])
  eval(parse(text=temp.expr))
  temp.expr <- paste0("three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all[[prmset.type.names[i]]]$prm.combs.z <- temp.prmset.",circuit.type.names[i],".z")
  eval(parse(text=temp.expr))
  temp.expr <- paste0("three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all[[prmset.type.names[i]]]$raw.smpl <- temp.prmset.",circuit.type.names[i], ".raw")
  eval(parse(text=temp.expr))
  }

nrow(three_gene_feedforward_pnp@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_ppp_init_sobol'"$prm.combs)
get.init.prm.combs.name(object = three_gene_feedforward_pnp)


prmset.dec.ppp = prmset[prmset$pkey %in% ppp.dec,]
prmset.dec.pnp = prmset[prmset$pkey %in% pnp.dec,]
prmset.z.dec.ppp = prmset.z[prmset.z$pkey %in% ppp.dec,]
prmset.z.dec.pnp = prmset.z[prmset.z$pkey %in% pnp.dec,]
prm_sobol.dec.ppp = prm_sobol[prmset.z$pkey %in% ppp.dec,]
prm_sobol.dec.pnp = prm_sobol[prmset.z$pkey %in% pnp.dec,]
prmset.inc.ppp = prmset[prmset$pkey %in% ppp.inc,]
prmset.inc.pnp = prmset[prmset$pkey %in% pnp.inc,]
prmset.z.inc.ppp = prmset.z[prmset.z$pkey %in% ppp.inc,]
prmset.z.inc.pnp = prmset.z[prmset.z$pkey %in% pnp.inc,]
prm_sobol.inc.ppp = prm_sobol[prmset.z$pkey %in% ppp.inc,]
prm_sobol.inc.pnp = prm_sobol[prmset.z$pkey %in% pnp.inc,]



###tried to reproduce additional sampling done in the paper but decided not to do it since I did different way of sampling.
prm.set.dec.ppp.selected <- prmset.dec.ppp[,-c(2,27:31)]
names(prm.set.dec.ppp.selected) <- c("pkey", three_gene_feedforward_pnp@prm.space$prm.ranges$three_gene_ff_all$names)

write.table(prm.set.dec.ppp.selected, file =  "three_gene_ff_ppp_dec_selected.txt", quote = FALSE, col.names = TRUE, row.names = F , sep = "\t")

three_gene_feedforward_pnp@prm.space[["counter"]] <- list()
three_gene_feedforward_pnp@prm.space[["counter"]][["three_gene_ff_all"]]<-list()
three_gene_feedforward_pnp@prm.space[["counter"]][["three_gene_ff_all"]][["sobol'"]] <- 100000

saveRDS(three_gene_feedforward_pnp, file ="three_gene_feedforward_PNP/three_gene_feedforward_pnp.Rds")

three_gene_ff_ppp_dec_addit <- read.table(file = "three_gene_ff_ppp_dec_addit.txt", header = T, stringsAsFactors = F)
three_gene_ff_ppp_dec_addit_filt <- read.table(file = "three_gene_ff_ppp_dec_addit_filt.txt", header = T, stringsAsFactors = F)
nrow(three_gene_ff_ppp_dec_addit_filt)
nrow(prm.sobol.dec.ppp.zoom)

three_gene_feedforward_pnp_2 <- readRDS("three_gene_feedforward_PNP/three_gene_feedforward_pnp_2.Rds")
three_gene_feedforward_pnp_1 <- readRDS("three_gene_feedforward_PNP/three_gene_feedforward_pnp_1.Rds")

three_gene_feedforward_pnp_2@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_init_sobol'_cont"$prm.combs.z
hist(three_gene_feedforward_pnp_2@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_init_sobol'_cont"$prm.combs.z[,2], breaks = 100)
hist(three_gene_feedforward_pnp_2@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_init_sobol'_cont"$prm.combs.z[,4], breaks = 100)

##plug additional parameter combinations

#selected
prmset.dec.ppp = prmset[prmset$pkey %in% ppp.dec,]
prmset.dec.pnp = prmset[prmset$pkey %in% pnp.dec,]
prmset.z.dec.ppp = prmset.z[prmset.z$pkey %in% ppp.dec,]
prmset.z.dec.pnp = prmset.z[prmset.z$pkey %in% pnp.dec,]
prm_sobol.dec.ppp = prm_sobol[prmset.z$pkey %in% ppp.dec,]
prm_sobol.dec.pnp = prm_sobol[prmset.z$pkey %in% pnp.dec,]
prmset.inc.ppp = prmset[prmset$pkey %in% ppp.inc,]
prmset.inc.pnp = prmset[prmset$pkey %in% pnp.inc,]
prmset.z.inc.ppp = prmset.z[prmset.z$pkey %in% ppp.inc,]
prmset.z.inc.pnp = prmset.z[prmset.z$pkey %in% pnp.inc,]
prm_sobol.inc.ppp = prm_sobol[prmset.z$pkey %in% ppp.inc,]
prm_sobol.inc.pnp = prm_sobol[prmset.z$pkey %in% pnp.inc,]



prmset.z.zoom[c(4186:8438, 12776:14011),23] = -1*prmset.z.zoom[c(4186:8438, 12776:14011),23]
prmset.zoom[c(4186:8438, 12776:14011),23] = -1*prmset.zoom[c(4186:8438, 12776:14011),23]
##dec.ppp 1:4185
##dec.pnp 4186:8438
##inc.ppp 8439:12775
##inc.pnp 12776:14011

prmset.z.zoom[1:4185, -c(2,27:31)]

###haven't decided whether put three_gene_ff_all_init_sobol' or three_gene_ff_ppp_init_sobol' due to raw.smpl

#dec.ppp
temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward_pnp, name = "three_gene_ff_ppp_init_sobol'" ,prm.ranges.name = "three_gene_ff_all")
temp.addit.prm.combs   <- get.addit.prm.combs(object = three_gene_feedforward_pnp_1, name = "three_gene_ff_ppp_dec_addit_sobol'",prm.ranges.name = "three_gene_ff_all",init.prm.combs.name = "three_gene_ff_all_init_sobol'" )
temp.selected <- prmset.dec.ppp[,-c(2,27:31)]
names(temp.selected)[-1] <- temp.init.prm.combs$log.scale$names

temp.combs <- prmset.zoom[1:4185, -c(2,27:31)]
temp.combs.z <- prmset.z.zoom[1:4185, -c(2,27:31)]
names(temp.combs)[-1] <- temp.init.prm.combs$log.scale$names
names(temp.combs.z)[-1] <- temp.init.prm.combs$log.scale$names

add.additional.prm.combs(three_gene_feedforward_pnp) <- list(prm.ranges.name = "three_gene_ff_all",
                                                             init.prm.combs.name = "three_gene_ff_ppp_init_sobol'", 
                                                             name = "three_gene_ff_ppp_dec_addit_sobol'",
                                                             method = "sobol'", 
                                                             log.scale = temp.init.prm.combs$log.scale, 
                                                             frac.range= temp.addit.prm.combs$frac.range ,
                                                             num.grids = NULL, 
                                                             prm.combs.selected = temp.selected, 
                                                             prm.combs = temp.combs, 
                                                             prm.combs.z = temp.combs.z )
                                                             
#dec.pnp #nYZ -> -nYZ for both original and rescaled 
temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward_pnp, name = "three_gene_ff_ppp_init_sobol'" ,prm.ranges.name = "three_gene_ff_all")
temp.addit.prm.combs   <- get.addit.prm.combs(object = three_gene_feedforward_pnp_1, name = "three_gene_ff_ppp_dec_addit_sobol'",prm.ranges.name = "three_gene_ff_all",init.prm.combs.name = "three_gene_ff_all_init_sobol'" )
temp.selected <- prmset.dec.pnp[,-c(2,27:31)]
names(temp.selected)[-1] <- temp.init.prm.combs$log.scale$names

temp.combs <- prmset.zoom[4186:8438, -c(2,27:31)]
temp.combs.z <- prmset.z.zoom[4186:8438, -c(2,27:31)]
names(temp.combs)[-1] <- temp.init.prm.combs$log.scale$names
names(temp.combs.z)[-1] <- temp.init.prm.combs$log.scale$names

add.additional.prm.combs(three_gene_feedforward_pnp) <- list(prm.ranges.name = "three_gene_ff_all",
                                                             init.prm.combs.name = "three_gene_ff_pnp_init_sobol'", 
                                                             name = "three_gene_ff_pnp_dec_addit_sobol'",
                                                             method = "sobol'", 
                                                             log.scale = temp.init.prm.combs$log.scale, 
                                                             frac.range= temp.addit.prm.combs$frac.range ,
                                                             num.grids = NULL, 
                                                             prm.combs.selected = temp.selected, 
                                                             prm.combs = temp.combs, 
                                                             prm.combs.z = temp.combs.z )


#inc.ppp
temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward_pnp, name = "three_gene_ff_ppp_init_sobol'" ,prm.ranges.name = "three_gene_ff_all")
temp.addit.prm.combs   <- get.addit.prm.combs(object = three_gene_feedforward_pnp_1, name = "three_gene_ff_ppp_dec_addit_sobol'",prm.ranges.name = "three_gene_ff_all",init.prm.combs.name = "three_gene_ff_all_init_sobol'" )
temp.selected <- prmset.inc.ppp[,-c(2,27:31)]
names(temp.selected)[-1] <- temp.init.prm.combs$log.scale$names

temp.combs <- prmset.zoom[8439:12775, -c(2,27:31)]
temp.combs.z <- prmset.z.zoom[8439:12775, -c(2,27:31)]
names(temp.combs)[-1] <- temp.init.prm.combs$log.scale$names
names(temp.combs.z)[-1] <- temp.init.prm.combs$log.scale$names

add.additional.prm.combs(three_gene_feedforward_pnp) <- list(prm.ranges.name = "three_gene_ff_all",
                                                             init.prm.combs.name = "three_gene_ff_ppp_init_sobol'", 
                                                             name = "three_gene_ff_ppp_inc_addit_sobol'",
                                                             method = "sobol'", 
                                                             log.scale = temp.init.prm.combs$log.scale, 
                                                             frac.range= temp.addit.prm.combs$frac.range ,
                                                             num.grids = NULL, 
                                                             prm.combs.selected = temp.selected, 
                                                             prm.combs = temp.combs, 
                                                             prm.combs.z = temp.combs.z )

#inc.pnp
temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward_pnp, name = "three_gene_ff_ppp_init_sobol'" ,prm.ranges.name = "three_gene_ff_all")
temp.addit.prm.combs   <- get.addit.prm.combs(object = three_gene_feedforward_pnp_1, name = "three_gene_ff_ppp_dec_addit_sobol'",prm.ranges.name = "three_gene_ff_all",init.prm.combs.name = "three_gene_ff_all_init_sobol'" )
temp.selected <- prmset.inc.pnp[,-c(2,27:31)]
names(temp.selected)[-1] <- temp.init.prm.combs$log.scale$names

temp.combs <- prmset.zoom[12776:14011, -c(2,27:31)]
temp.combs.z <- prmset.z.zoom[12776:14011, -c(2,27:31)]
names(temp.combs)[-1] <- temp.init.prm.combs$log.scale$names
names(temp.combs.z)[-1] <- temp.init.prm.combs$log.scale$names

add.additional.prm.combs(three_gene_feedforward_pnp) <- list(prm.ranges.name = "three_gene_ff_all",
                                                             init.prm.combs.name = "three_gene_ff_pnp_init_sobol'", 
                                                             name = "three_gene_ff_pnp_inc_addit_sobol'",
                                                             method = "sobol'", 
                                                             log.scale = temp.init.prm.combs$log.scale, 
                                                             frac.range= temp.addit.prm.combs$frac.range ,
                                                             num.grids = NULL, 
                                                             prm.combs.selected = temp.selected, 
                                                             prm.combs = temp.combs, 
                                                             prm.combs.z = temp.combs.z )

three_gene_feedforward_pnp@prm.space$additional.prm.combs$three_gene_ff_all$"three_gene_ff_ppp_init_sobol'"
three_gene_feedforward_pnp@prm.space$additional.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_init_sobol'"
  
saveRDS(three_gene_feedforward_pnp, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")
three_gene_feedforward_pnp@phasespace.name
three_gene_feedforward_pnp@phasespace.name <- "Three-gene feedforward network"
saveRDS(three_gene_feedforward_pnp, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")
# now deal with three_gene_feedforward.Rds without subscript such as pnp...

three_gene_feedforward <- readRDS("three_gene_feedforward_PNP/three_gene_feedforward.Rds")
names(three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all) <- c("three_gene_ff_all_sobol'", "three_gene_ff_ppp_sobol'", "three_gene_ff_ppn_sobol'",
                                                                                 "three_gene_ff_pnp_sobol'", "three_gene_ff_pnn_sobol'", "three_gene_ff_npp_sobol'",
                                                                                  "three_gene_ff_npn_sobol'", "three_gene_ff_nnp_sobol'", "three_gene_ff_nnn_sobol'")
names(three_gene_feedforward@prm.space$additional.prm.combs$three_gene_ff_all) <-c("three_gene_ff_ppp_sobol'", "three_gene_ff_pnp_sobol'")
names(three_gene_feedforward@prm.space$additional.prm.combs$three_gene_ff_all$"three_gene_ff_ppp_sobol'") <-c("three_gene_ff_ppp_sobol'_add_dec", "three_gene_ff_ppp_sobol'_add_inc")
names(three_gene_feedforward@prm.space$additional.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'") <-c("three_gene_ff_pnp_sobol'_add_dec", "three_gene_ff_pnp_sobol'_add_inc")
saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")



#phenotypes
three_gene_feedforward <- readRDS("phasespace/three_gene_feedforward.Rds")
names(data.clust.ordered)[16:27]
data.clust.zoom1.phen <- read.csv("~/Dropbox/Codes/project_sim_ml/analysis/two_gene/run_Sep29_HPC/run_Dec23/corr_zoom.csv", stringsAsFactors = F)
all.equal(temp.to.compare.z.add$pkey , data.clust.zoom1.phen$pkey)

temp.init.names <- get.init.prm.combs.name(three_gene_feedforward)
temp.init.names <- temp.init.names[["three_gene_ff_all"]]
temp.init.names <- temp.init.names[-1]

temp.addit.names <- get.addit.prm.combs.name(three_gene_feedforward)
temp.addit.names <- temp.addit.names[["three_gene_ff_all"]]
temp.addit.names




corr.woy.ppp.not.na <- corr.woy.ppp[,!is.na(corr.woy.pnp[1,])]
corr.woy.pnp.not.na <- corr.woy.pnp[,!is.na(corr.woy.pnp[1,])]

names(corr.woy.ppp.not.na)[-1] = paste0(names(corr.woy.ppp.not.na)[-1],".woy")
names(corr.woy.pnp.not.na)[-1] = paste0(names(corr.woy.pnp.not.na)[-1],".woy")

corr.woy.not.na = rbind(corr.woy.ppp.not.na,corr.woy.pnp.not.na)



corr.ffd.zoom.wy
corr.ffd.zoom.wy.not.na <- corr.ffd.zoom.wy[,!is.na(corr.ffd.zoom.wy[1,])]

corr.ffd.zoom.woy.not.na <- corr.ffd.zoom.woy[,!is.na(corr.ffd.zoom.woy[1,])]
names(corr.ffd.zoom.woy.not.na)[-1] = paste0(names(corr.ffd.zoom.woy.not.na)[-1],".woy")



##initial parameter sets
for(i in 1:length(temp.init.names)){
  temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward, name =temp.init.names[i], prm.ranges.name = "three_gene_ff_all" )
  for(j in 1:(ncol(corr)-1)){
    add.phenotypes(three_gene_feedforward) <- list(name = names(corr)[j+1], 
                                          prm.combs.name = temp.init.names[i],
                                          phenotype = data.frame(pkey = corr$pkey[corr$pkey %in% temp.init.prm.combs$prm.combs$pkey   ],  corr[corr$pkey %in% temp.init.prm.combs$prm.combs$pkey,j+1], stringsAsFactors = F) )
    names(three_gene_feedforward@phenotypes[[names(corr)[j+1]]][[temp.init.names[i]]])[2] = names(corr)[j+1]
  }
}

##without Y
for(i in c(1,3)){
  temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward, name =temp.init.names[i], prm.ranges.name = "three_gene_ff_all" )
  for(j in 1:(ncol(corr.woy.not.na)-1)){
    add.phenotypes(three_gene_feedforward) <- list(name = names(corr.woy.not.na)[j+1], 
                                                   prm.combs.name = temp.init.names[i],
                                                   phenotype = data.frame(pkey = corr.woy.not.na$pkey[corr.woy.not.na$pkey %in% temp.init.prm.combs$prm.combs$pkey   ],  corr.woy.not.na[corr.woy.not.na$pkey %in% temp.init.prm.combs$prm.combs$pkey,j+1], stringsAsFactors = F) )
    names(three_gene_feedforward@phenotypes[[names(corr.woy.not.na)[j+1]]][[temp.init.names[i]]])[2] = names(corr.woy.not.na)[j+1]
  }
}



##additional parameter sets
for(i in 1:length(temp.addit.names)){
  if(!is.null(temp.addit.names[[i]])){
    for(k in 1:length(temp.addit.names[[i]])){
      temp.addit.prm.combs <- get.addit.prm.combs(object = three_gene_feedforward, name =temp.addit.names[[i]][k],init.prm.combs.name = names(temp.addit.names)[i] ,prm.ranges.name = "three_gene_ff_all" )
      for(j in 1:(ncol(corr.ffd.zoom.wy.not.na)-1)){
        add.phenotypes(three_gene_feedforward) <- list(name = names(corr.ffd.zoom.wy.not.na)[j+1], 
                                                       prm.combs.name = temp.addit.names[[i]][k],
                                                       phenotype = data.frame(pkey = corr.ffd.zoom.wy.not.na$pkey[corr.ffd.zoom.wy.not.na$pkey %in% temp.addit.prm.combs$prm.combs$pkey ],  corr.ffd.zoom.wy.not.na[corr.ffd.zoom.wy.not.na$pkey %in% temp.addit.prm.combs$prm.combs$pkey,j+1], stringsAsFactors = F) )
        names(three_gene_feedforward@phenotypes[[names(corr.ffd.zoom.wy.not.na)[j+1]]][[temp.addit.names[[i]][k]]])[2] = names(corr.ffd.zoom.wy.not.na)[j+1]
      }
    }
  }
}

#without Y
for(i in 1:length(temp.addit.names)){
  if(!is.null(temp.addit.names[[i]])){
    for(k in 1:length(temp.addit.names[[i]])){
      temp.addit.prm.combs <- get.addit.prm.combs(object = three_gene_feedforward, name =temp.addit.names[[i]][k],init.prm.combs.name = names(temp.addit.names)[i] ,prm.ranges.name = "three_gene_ff_all" )
      for(j in 1:(ncol(corr.ffd.zoom.woy.not.na)-1)){
        add.phenotypes(three_gene_feedforward) <- list(name = names(corr.ffd.zoom.woy.not.na)[j+1], 
                                                       prm.combs.name = temp.addit.names[[i]][k],
                                                       phenotype = data.frame(pkey = corr.ffd.zoom.woy.not.na$pkey[corr.ffd.zoom.woy.not.na$pkey %in% temp.addit.prm.combs$prm.combs$pkey ],  corr.ffd.zoom.woy.not.na[corr.ffd.zoom.woy.not.na$pkey %in% temp.addit.prm.combs$prm.combs$pkey,j+1], stringsAsFactors = F) )
        names(three_gene_feedforward@phenotypes[[names(corr.ffd.zoom.woy.not.na)[j+1]]][[temp.addit.names[[i]][k]]])[2] = names(corr.ffd.zoom.woy.not.na)[j+1]
      }
    }
  }
}

saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")


#fold.change
data.comp.ppp$cor.fold = data.comp.ppp$mxmz.max.neg / data.comp.ppp$mxmz.max.neg.woy 
data.comp.pnp$cor.fold = data.comp.pnp$mxmz.max.neg / data.comp.pnp$mxmz.max.neg.woy 

data.comp.ppp.pnp <- rbind(data.comp.pnp[,c(1,189)], data.comp.ppp[,c(1,188)])

for(i in c(1,3)){
  temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward, name =temp.init.names[i], prm.ranges.name = "three_gene_ff_all" )
  for(j in 1:1){
    add.phenotypes(three_gene_feedforward) <- list(name = "fold.mxmz.max.neg", 
                                                   prm.combs.name = temp.init.names[i],
                                                   phenotype = data.frame(pkey = data.comp.ppp.pnp$pkey[data.comp.ppp.pnp$pkey %in% temp.init.prm.combs$prm.combs$pkey   ],  data.comp.ppp.pnp[data.comp.ppp.pnp$pkey %in% temp.init.prm.combs$prm.combs$pkey,j+1], stringsAsFactors = F) )
    names(three_gene_feedforward@phenotypes[["fold.mxmz.max.neg"]][[temp.init.names[i]]])[2] = "fold.mxmz.max.neg"
  }
}

for(i in 1:length(temp.addit.names)){
  if(!is.null(temp.addit.names[[i]])){
    for(k in 1:length(temp.addit.names[[i]])){
      temp.addit.prm.combs <- get.addit.prm.combs(object = three_gene_feedforward, name =temp.addit.names[[i]][k],init.prm.combs.name = names(temp.addit.names)[i] ,prm.ranges.name = "three_gene_ff_all" )
      for(j in 1:1){
        add.phenotypes(three_gene_feedforward) <- list(name ="fold.mxmz.max.neg", 
                                                       prm.combs.name = temp.addit.names[[i]][k],
                                                       phenotype = data.frame(pkey = data.comp.ppp.pnp$pkey[data.comp.ppp.pnp$pkey %in% temp.addit.prm.combs$prm.combs$pkey ],  data.comp.ppp.pnp[data.comp.ppp.pnp$pkey %in% temp.addit.prm.combs$prm.combs$pkey,j+1], stringsAsFactors = F) )
        names(three_gene_feedforward@phenotypes[["fold.mxmz.max.neg"]][[temp.addit.names[[i]][k]]])[2] = "fold.mxmz.max.neg"
      }
    }
  }
}

saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")


##analysis
three_gene_feedforward <- readRDS("three_gene_feedforward_PNP/three_gene_feedforward.Rds")
temp.tsne.org.pnp <- data.frame(pkey = data.comp.pnp$pkey[data.comp.pnp$class2 =="original"], tsne.org.pnp)
temp.tsne.org.ppp <- data.frame(pkey = data.comp.ppp$pkey[data.comp.ppp$class2 =="original"], tsne.org.ppp)

temp.tsne.zoom.ppp = cbind(pkey = data.tsne.ext.ppp[,1], smpl.tsne.ext.ppp)
temp.tsne.zoom.pnp = cbind(pkey = data.tsne.ext.pnp[,1], smpl.tsne.ext.pnp)

temp.tsne.comb.ppp = rbind(temp.tsne.org.ppp, temp.tsne.zoom.ppp)
temp.tsne.comb.pnp = rbind(temp.tsne.org.pnp, temp.tsne.zoom.pnp)

temp.tsne.comb.ppp = temp.tsne.comb.ppp[,1:3] 
temp.tsne.comb.pnp = temp.tsne.comb.pnp[,1:3] 

names(temp.tsne.comb.ppp) <- c("pkey", "tSNE1", "tSNE2")
names(temp.tsne.comb.pnp ) <- c("pkey", "tSNE1", "tSNE2")

temp.tsne.comb.all <- rbind(temp.tsne.comb.ppp, temp.tsne.comb.pnp)

for(i in c(1,3)){
  temp.init.prm.combs <- get.init.prm.combs(object = three_gene_feedforward, name =temp.init.names[i], prm.ranges.name = "three_gene_ff_all" )
  for(j in 1:1){
    add.tsne.coord(three_gene_feedforward) <- list( prm.combs.name = temp.init.names[i], 
                                                    tsne.coord = temp.tsne.comb.all[temp.tsne.comb.all$pkey %in% temp.init.prm.combs$prm.combs$pkey,1:3])
  }
}

for(i in 1:length(temp.addit.names)){
  if(!is.null(temp.addit.names[[i]])){
    for(k in 1:length(temp.addit.names[[i]])){
      temp.addit.prm.combs <- get.addit.prm.combs(object = three_gene_feedforward, name =temp.addit.names[[i]][k],init.prm.combs.name = names(temp.addit.names)[i] ,prm.ranges.name = "three_gene_ff_all" )
      for(j in 1:1){
        add.tsne.coord(three_gene_feedforward) <-list( prm.combs.name = temp.addit.names[[i]][k], 
                                                       tsne.coord = temp.tsne.comb.all[temp.tsne.comb.all$pkey %in% temp.addit.prm.combs$prm.combs$pkey,1:3])
      }
    }
  }
}


##ML.models
source("classes.R")
rf.pnp.fold.mxmz.max.neg.combined.whole.reg <- rf.reg.comb.fold.pnp.all.bc
rf.pnp.fold.mxmz.max.neg.combined.whole.reg.res <- rf.reg.comb.fold.pnp.all.res.bc
data.comp.pnp[!is.na(data.comp.pnp$cor.fold) & data.comp.pnp$mxmz.max.neg.woy > 0.2,c(154:169, 172:177)]
data.comp.pnp[ !is.na(data.comp.pnp$cor.fold) & data.comp.pnp$mxmz.max.neg.woy > 0.2,189]
rf.pnp.fold.mxmz.max.neg.combined.whole.reg$pkey <- data.comp.pnp[!is.na(data.comp.pnp$cor.fold) & data.comp.pnp$mxmz.max.neg.woy > 0.2,1]
rf.pnp.fold.mxmz.max.neg.combined.whole.reg.res$pkey <- data.comp.pnp[!is.na(data.comp.pnp$cor.fold) & data.comp.pnp$mxmz.max.neg.woy > 0.2,1]

rf.ppp.fold.mxmz.max.neg.combined.whole.reg <- rf.reg.comb.fold.ppp.all.bc
rf.ppp.fold.mxmz.max.neg.combined.whole.reg.res <- rf.reg.comb.fold.ppp.all.res.bc
data.comp.ppp[!is.na(data.comp.ppp$cor.fold) & data.comp.ppp$mxmz.max.neg.woy > 0.2,c(154:169, 172:177)]
data.comp.ppp[!is.na(data.comp.ppp$cor.fold) & data.comp.ppp$mxmz.max.neg.woy > 0.2,188]
rf.ppp.fold.mxmz.max.neg.combined.whole.reg$pkey <- data.comp.ppp[!is.na(data.comp.ppp$cor.fold) & data.comp.ppp$mxmz.max.neg.woy > 0.2,1]
rf.ppp.fold.mxmz.max.neg.combined.whole.reg.res$pkey <- data.comp.ppp[!is.na(data.comp.ppp$cor.fold) & data.comp.ppp$mxmz.max.neg.woy > 0.2,1]

add.ml.model(three_gene_feedforward) <- list(phenotype.name = "fold.mxmz.max.neg",
                                    name = "rf.ppp.fold.mxmz.max.neg.combined.whole.reg", 
                                    ml.model = rf.ppp.fold.mxmz.max.neg.combined.whole.reg,
                                    ml.model.res = rf.ppp.fold.mxmz.max.neg.combined.whole.reg.res,
                                    mode = "regression",
                                    prm.sets.used = c(temp.init.names[1], temp.addit.names[[temp.init.names[1]]]), 
                                    train.data = data.comp.ppp[!is.na(data.comp.ppp$cor.fold) & data.comp.ppp$mxmz.max.neg.woy > 0.2,1], 
                                    test.data = NULL,
                                    class.def = NULL,
                                    note = "!is.na(fold.mxmz.max.neg) && mxmz.max.neg.woy > 0.2")

add.ml.model(three_gene_feedforward) <- list(phenotype.name = "fold.mxmz.max.neg",
                                             name = "rf.pnp.fold.mxmz.max.neg.combined.whole.reg", 
                                             ml.model = rf.pnp.fold.mxmz.max.neg.combined.whole.reg,
                                             ml.model.res = rf.pnp.fold.mxmz.max.neg.combined.whole.reg.res,
                                             mode = "regression",
                                             prm.sets.used = c(temp.init.names[3], temp.addit.names[[temp.init.names[3]]]), 
                                             train.data = data.comp.pnp[!is.na(data.comp.pnp$cor.fold) & data.comp.pnp$mxmz.max.neg.woy > 0.2,1], 
                                             test.data = NULL,
                                             class.def = NULL,
                                             note = "!is.na(fold.mxmz.max.neg) && mxmz.max.neg.woy > 0.2")

saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")

#change parameter labels
row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.ppp.fold.mxmz.max.neg.combined.whole.reg$ml.model$localImportance) <- names(temp.combs)[c(-1,-18,-19)]
row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.ppp.fold.mxmz.max.neg.combined.whole.reg$ml.model$importance) <- names(temp.combs)[c(-1,-18,-19)]

row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.ppp.fold.mxmz.max.neg.combined.whole.reg$ml.model.res$localImportance) <- names(temp.combs)[c(-1,-18,-19)]
row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.ppp.fold.mxmz.max.neg.combined.whole.reg$ml.model.res$importance) <- names(temp.combs)[c(-1,-18,-19)]

row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.pnp.fold.mxmz.max.neg.combined.whole.reg$ml.model$localImportance) <- names(temp.combs)[c(-1,-18,-19)]
row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.pnp.fold.mxmz.max.neg.combined.whole.reg$ml.model$importance) <- names(temp.combs)[c(-1,-18,-19)]

row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.pnp.fold.mxmz.max.neg.combined.whole.reg$ml.model.res$localImportance) <- names(temp.combs)[c(-1,-18,-19)]
row.names(three_gene_feedforward@ml.models$fold.mxmz.max.neg$rf.pnp.fold.mxmz.max.neg.combined.whole.reg$ml.model.res$importance) <- names(temp.combs)[c(-1,-18,-19)]
saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")


##raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_ppp_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_ppn_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_pnn_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_npp_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_npn_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_nnp_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_nnn_sobol'"$raw.smpl <-three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_all_sobol'"$raw.smpl
saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")

##remove factors
three_gene_feedforward@analysis$tsne$"three_gene_ff_ppp_sobol'"$pkey <- as.character(three_gene_feedforward@analysis$tsne$"three_gene_ff_ppp_sobol'"$pkey)
three_gene_feedforward@analysis$tsne$"three_gene_ff_ppp_sobol'_add_inc"$pkey <- as.character(three_gene_feedforward@analysis$tsne$"three_gene_ff_ppp_sobol'_add_inc"$pkey)
three_gene_feedforward@analysis$tsne$"three_gene_ff_ppp_sobol'_add_dec"$pkey <- as.character(three_gene_feedforward@analysis$tsne$"three_gene_ff_ppp_sobol'_add_dec"$pkey)

three_gene_feedforward@analysis$tsne$"three_gene_ff_pnp_sobol'"$pkey <- as.character(three_gene_feedforward@analysis$tsne$"three_gene_ff_pnp_sobol'"$pkey)
three_gene_feedforward@analysis$tsne$"three_gene_ff_pnp_sobol'_add_inc"$pkey <- as.character(three_gene_feedforward@analysis$tsne$"three_gene_ff_pnp_sobol'_add_inc"$pkey)
three_gene_feedforward@analysis$tsne$"three_gene_ff_pnp_sobol'_add_dec"$pkey <- as.character(three_gene_feedforward@analysis$tsne$"three_gene_ff_pnp_sobol'_add_dec"$pkey)
saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")



###fold.mxmz.max.neg -> fold.corr.ppp and fold.corr.pnp
three_gene <- readRDS("phasespace/three_gene_feedforward.Rds")
three_gene@phenotypes$fold.corr.ppp <- list()
three_gene@phenotypes$fold.corr.pnp <- list()

three_gene@phenotypes$fold.corr.ppp <- three_gene@phenotypes$fold.mxmz.max.neg[c(1,3,4)]
names(three_gene@phenotypes$fold.corr.ppp[[1]])[2] <- "fold.corr.ppp"
names(three_gene@phenotypes$fold.corr.ppp[[2]])[2] <- "fold.corr.ppp"
names(three_gene@phenotypes$fold.corr.ppp[[3]])[2] <- "fold.corr.ppp"

three_gene@phenotypes$fold.corr.pnp <- three_gene@phenotypes$fold.mxmz.max.neg[c(2,5,6)]
names(three_gene@phenotypes$fold.corr.pnp[[1]])[2] <- "fold.corr.pnp"
names(three_gene@phenotypes$fold.corr.pnp[[2]])[2] <- "fold.corr.pnp"
names(three_gene@phenotypes$fold.corr.pnp[[3]])[2] <- "fold.corr.pnp"

three_gene@ml.models$fold.corr.ppp <- list()
three_gene@ml.models$fold.corr.pnp <- list()
three_gene@ml.models$fold.corr.ppp <- three_gene@ml.models$fold.mxmz.max.neg[c(1,4,5)]
three_gene@ml.models$fold.corr.pnp <- three_gene@ml.models$fold.mxmz.max.neg[c(2,3,6)]

saveRDS(three_gene, file="phasespace/three_gene_feedforward.Rds")


###validation

#ppp "011416_AAAAFJWZ"

selected  <-  data.frame(c(prmset[prmset$pkey ==  "011416_AAAAFJWZ", c(1,3:26)] ,data.comp.ppp[data.comp.ppp$pkey ==  "011416_AAAAFJWZ", "cor.fold"]))
selected$pkey <- as.character(selected$pkey)
names(selected) <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")

# "KpxY" - 'kYm'
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm <- cbind(prmset.ppp.proj.tot[1:900,c(1,3:26)], prmset.z.ppp.proj.tot[1:900,27])
names(prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm)  <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")

prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm <- rbind(selected ,selected ,prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm)
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm[1, ] <- NA
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm[1,1 ] <- "perturbed_prms"
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm[1,"KXY" ] <-1
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm[1,"kYm" ] <-2
write.table(prm.comb.val.ppp.011416_AAAAFJWZ.KXY.kYm, file="three_gene_feedforward_PNP/011416_AAAAFJWZ_KXY_kYm_sim.txt", quote = F, row.names = F)

#  "KpxY" - KpyZ" 
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ <-  cbind(prmset.ppp.proj[1:900,c(1,3:26)], prmset.z.ppp.proj[1:900,27])
names(prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ) <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")

prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ <- rbind(selected ,selected ,prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ)
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ[1, ] <- NA
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ[1,1 ] <- "perturbed_prms"
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ[1,"KXY" ] <-1
prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ[1,"KYZ" ] <-2
write.table(prm.comb.val.ppp.011416_AAAAFJWZ.KXY.KYZ, file="three_gene_feedforward_PNP/011416_AAAAFJWZ_KXY_KYZ_sim.txt", quote = F, row.names = F)



# KpyZ-npyZ
prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ <-  cbind(prmset.ppp.proj[1801:2700,c(1,3:26)], prmset.z.ppp.proj[1801:2700,27])
names(prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ) <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")


prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ <- rbind(selected ,selected ,prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ)
prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ[1, ] <- NA
prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ[1,1 ] <- "perturbed_prms"
prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ[1,"KYZ" ] <-1
prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ[1,"nYZ" ] <-2
write.table(prm.comb.val.ppp.011416_AAAAFJWZ.KYZ.nYZ, file="three_gene_feedforward_PNP/011416_AAAAFJWZ_KYZ_nYZ_sim.txt", quote = F, row.names = F)



##pnp "011416_AAAAFYMP"


###sign problem for nYZ  for initial -> positive, additional -> negative => make it all negative
###in clustering.R, all analysis (data.comp.pnp) was done in terms of nYZ with negative sign multiplied for original and z-score
three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$prm.combs$nYZ <-
  -three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$prm.combs$nYZ

three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$prm.combs.z$nYZ <-
  -three_gene_feedforward@prm.space$initial.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$prm.combs.z$nYZ

three_gene_feedforward@prm.space$additional.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$"three_gene_ff_pnp_sobol'_add_dec"$prm.combs$nYZ

temp.pnp.combs <- three_gene_feedforward@prm.space$additional.prm.combs$three_gene_ff_all$"three_gene_ff_pnp_sobol'"$"three_gene_ff_pnp_sobol'_add_dec"

temp.pnp.combs$prm.combs.z[temp.pnp.combs$prm.combs.z$pkey ==  "011416_AAAAFYMP",]
prmset.z[prmset.z$pkey ==  "011416_AAAAFYMP",  ]
saveRDS(three_gene_feedforward, file ="three_gene_feedforward_PNP/three_gene_feedforward.Rds")


selected  <-  data.frame(c(prmset.zoom[prmset.zoom$pkey == "011416_AAAAFYMP", c(1,3:26)] ,data.comp.pnp[data.comp.pnp$pkey ==  "011416_AAAAFYMP", "cor.fold"]))
names(selected) <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")
selected$pkey <- as.character(selected$pkey)

## kYm-KpxY
prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY <- cbind(prmset.pnp.proj[1801:2700,c(1,3:26)], prmset.z.pnp.proj[1801:2700,27])
names(prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY)  <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")

prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY <- rbind(selected ,selected, prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY)
prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY[1, ] <- NA
prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY[1,1 ] <- "perturbed_prms"
prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY[1,"kYm" ] <-1
prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY[1,"KXY" ] <-2
write.table(prm.comb.val.pnp.011416_AAAAFYMP.kYm.KXY, file="three_gene_feedforward_PNP/011416_AAAAFYMP_kYm_KXY_sim.txt", quote = F, row.names = F)

## KpyZ-kYm

prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm <- cbind(prmset.pnp.proj[1:900,c(1,3:26)], prmset.z.pnp.proj[1:900,27])
names(prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm)  <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")

prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm <- rbind(selected ,selected, prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm)
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm[1, ] <- NA
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm[1,1 ] <- "perturbed_prms"
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm[1,"KYZ" ] <-1
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm[1,"kYm" ] <-2
write.table(prm.comb.val.pnp.011416_AAAAFYMP.KYZ.kYm, file="three_gene_feedforward_PNP/011416_AAAAFYMP_KYZ_kYm_sim.txt", quote = F, row.names = F)



## KpyZ-KpxY

prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY <- cbind(prmset.pnp.proj[901:1800,c(1,3:26)], prmset.z.pnp.proj[901:1800,27])
names(prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY)  <- c(names(temp.prmset.ppp), "fold.mxmz.max.neg")

prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY <- rbind(selected ,selected, prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY)
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY[1, ] <- NA
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY[1,1 ] <- "perturbed_prms"
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY[1,"KYZ" ] <-1
prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY[1,"KXY" ] <-2
write.table(prm.comb.val.pnp.011416_AAAAFYMP.KYZ.KXY, file="three_gene_feedforward_PNP/011416_AAAAFYMP_KYZ_KXY_sim.txt", quote = F, row.names = F)



##save ml models as seperate files



##mxmy corr for validation 


#################################
######two_gene_feedback_neg######
#################################

two_gene_neg_fb <- readRDS("phasespace/two_gene_neg_fb.Rds")

### parameter ranges
prm.ranges <- apply(t(prm.grid),1, range)
prm.ranges <- t(prm.ranges)

colnames(prm.ranges) <- c("min", "max")
prm.ranges <- data.frame(prm.ranges, stringsAsFactors = F)
prms <-c("kXon",  "kXoff", "kXm",   "dXm",   "kXp",   "dXp",   "kYon",  "kYoff", "kYm",   "dYm",   "kYp",   "dYp",   "nXY",  "KXY",  "nYX", "KYX" )
prm.ranges$names  <- prms 
prm.ranges <- prm.ranges[,c("names", "min", "max")]

#from app
prm.ranges <- data.frame( prm.ranges,
                         log.scale =two_gene_neg_fb@prm.space$initial.prm.combs$two_gene_neg_fb$two_gene_neg_fb_unifgrid$log.scale$log.scale,
                         num.grids = two_gene_neg_fb@prm.space$initial.prm.combs$two_gene_neg_fb$two_gene_neg_fb_unifgrid$num.grids$"number of grids")
names(prm.ranges)[5] <- "number of grids"


write.table(prm.ranges, file="two_gene_fb_prm_ranges.txt", row.names = F, quote= F)


two.gene.fb.grids <- data.frame(two.gene.fb.grids)
two.gene.fb.grids <- data.frame(names = prms, two.gene.fb.grids)
names(two.gene.fb.grids) <- c("min", paste0("V",2:9),"max")
two.gene.fb.grids[13,] <- c(1,NA,NA,NA,NA,NA,NA,NA,NA,5)
two.gene.fb.grids[15,] <- c(1,NA,NA,NA,NA,NA,NA,NA,NA,5)
two.gene.fb.grids[14,] <- c(30, 100, 300, 1000,NA,NA,NA,NA,NA,3000)
two.gene.fb.grids[16,] <- c(30, 100, 300, 1000,NA,NA,NA,NA,NA,3000)
row.names(two.gene.fb.grids) <- NULL


###initial parameter set
temp.prmset <- prmsets[,c(1,3:18)]
names(temp.prmset ) <- c("pkey", prms)
temp.prmset.z$pkey <- as.character(temp.prmset.z$pkey)
temp.prmset.z <- fun.scale.conv(sample_meth = "unif_grid",prm.ranges = prm.ranges, prm.combs = temp.prmset[,2:17], prm.grids = two.gene.fb.grids, z.to.org = FALSE)
names(temp.prmset.z) <- prms
temp
temp.prmset.z <- data.frame(pkey = temp.prmset[,1], temp.prmset.z)
temp.prmset.z.filt <- temp.prmset.z[temp.prmset.z$pkey %in% data.prms.z$pkey, ]
all.equal(temp.prmset.z.filt[order(temp.prmset.z.filt$pkey),] , data.prms.z[order(data.prms.z$pkey),], check.attributes = F)
all.equal(temp.prmset.z.filt , data.prms.z[order(data.prms.z$pkey),], check.attributes = F)

add.init.prm.combs(two_gene_neg_fb) <- list( prm.ranges.name = "two_gene_neg_fb", 
                                             name = "two_gene_neg_fb_unifgrid", 
                                             method = "unif_grid", 
                                             log.scale = two_gene_neg_fb@prm.space$initial.prm.combs$two_gene_neg_fb$two_gene_neg_fb_unifgrid$log.scale, 
                                             num.grids = two_gene_neg_fb@prm.space$initial.prm.combs$two_gene_neg_fb$two_gene_neg_fb_unifgrid$num.grids, 
                                             prm.grids = two.gene.fb.grids, 
                                             raw.smpl = NULL, 
                                             prm.combs = temp.prmset[order(temp.prmset$pkey),], 
                                             prm.combs.z = temp.prmset.z[order(temp.prmset.z$pkey),])

saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")


## phenotypes
## for initial parameter set with feedback on
corr.full1 <- corr.full1[order(corr.full1$pkey),]
all.equal(corr.full1$pkey, temp.prmset.z.filt$pkey)
ncol(corr.full1)

for(i in 2:66){
  add.phenotypes(two_gene_neg_fb) <- list(name = names(corr.full1)[i], 
                                          prm.combs.name ="two_gene_neg_fb_unifgrid",
                                          phenotype = data.frame(corr.full1[,c(1,i)], stringsAsFactors = F) 
                                          )
}

saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")

#phenotypes for fb-off
names(data.clust.z.on.off.fin)

for(i in 85:96){
  add.phenotypes(two_gene_neg_fb) <- list(name = names(data.clust.z.on.off.fin)[i], 
                                          prm.combs.name ="two_gene_neg_fb_unifgrid",
                                          phenotype = data.frame(data.clust.z.on.off.fin[,c(1,i)], stringsAsFactors = F) 
  )
}

for(i in 85:96){
  add.phenotypes(two_gene_neg_fb) <- list(name = names(data.clust.z.on.off.fin)[i], 
                                          prm.combs.name ="two_gene_neg_fb_unifgrid",
                                          phenotype = data.frame(data.clust.z.on.off.fin[,c(1,i)], stringsAsFactors = F) 
  )
}

for(i in 97:104){
  add.phenotypes(two_gene_neg_fb) <- list(name = names(data.clust.z.on.off.fin)[i], 
                                          prm.combs.name ="two_gene_neg_fb_unifgrid",
                                          phenotype = data.frame(data.clust.z.on.off.fin[,c(1,i)], stringsAsFactors = F) 
  )
}


#phenotypes calculated from ODEs
data.means = read.table("~/Dropbox/Codes/project_sim_ml/analysis/two_gene_feedback/run_Nov13/prmsets_111315.txt_elapsed.txt", stringsAsFactors = F)
names(data.means) = c("pkey", "rkey", "mean.mx.ode.fb", "mean.px.ode.fb", "mean.my.ode.fb", "mean.py.ode.fb",  "mean.mx.ode", "mean.px.ode", "mean.my.ode", "mean.py.ode")
data.means = data.means[,-2]
data.means <- data.means[order(data.means$pkey),]
for(i in 2:9){
  add.phenotypes(two_gene_neg_fb) <- list(name = names(data.means)[i], 
                                          prm.combs.name ="two_gene_neg_fb_unifgrid",
                                          phenotype = data.frame(data.means[,c(1,i)], stringsAsFactors = F) 
  )
}


#corr.max, where.max
data.corr = corr.full1[,c("mxmy.max.neg" ,  "mxmy.min.neg" ,  "mxmy.max.pos" ,  "mxmy.min.pos")]
max.idx = apply(abs(data.corr), 1, which.max)
max.idx = cbind(1:51406, max.idx)
corr.max = data.corr[max.idx]
corr.max = data.frame(pkey = corr.full1$pkey, corr.max, stringsAsFactors = F)
names(corr.max)[2] = "mxmy.abs.max" #name chagne
where.max = c("mxmy.max.neg" ,  "mxmy.min.neg" ,  "mxmy.max.pos" ,  "mxmy.min.pos")[max.idx[,2]]
where.max = data.frame(pkey = corr.full1$pkey, where.max)
where.max$pkey <- as.character(where.max$pkey)
names(where.max)
add.phenotypes(two_gene_neg_fb) <- list(name = "mxmy.abs.max", 
                                        prm.combs.name ="two_gene_neg_fb_unifgrid",
                                        phenotype = corr.max, stringsAsFactors = F) 

add.phenotypes(two_gene_neg_fb) <- list(name = "where.max", 
                                        prm.combs.name ="two_gene_neg_fb_unifgrid",
                                        phenotype = where.max, stringsAsFactors = F) 

saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")


#q.factor and peak.freq
#q.factor
detect.bw6$q.factor.1.mean.geom
temp.q.factor <- data.frame(detect.bw6[,c("pkey", "q.factor.1.mean.geom")])
names(temp.q.factor)[2] <- "q.factor"
#peak.freq
log(detect.bw6$pow.peak.freq.mean.geom.1,10)
temp.peak.freq = data.frame(pkey = detect.bw6$pkey, peak.freq = log(detect.bw6$pow.peak.freq.mean.geom.1,10))

add.phenotypes(two_gene_neg_fb) <- list(name = "q.factor", 
                                        prm.combs.name ="two_gene_neg_fb_unifgrid",
                                        phenotype = temp.q.factor, stringsAsFactors = F) 

add.phenotypes(two_gene_neg_fb) <- list(name = "peak.freq", 
                                        prm.combs.name ="two_gene_neg_fb_unifgrid",
                                        phenotype = temp.peak.freq, stringsAsFactors = F) 
saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")

##analysis tsne

rtsne.out.on.off.fin.lim.scale = Rtsne(as.matrix(data.frame(data.clust.z.on.off.fin.lim[,c(2:14,16)], KpxY.rel.2.scale =scale(data.clust.z.on.off.fin.lim[,115]),  KpyX.rel.2.scale =scale(data.clust.z.on.off.fin.lim[,116]) )) )
rtsne.out.on.off.fin.lim.scale.coord = rtsne.out.on.off.fin.lim.scale$Y$Y

temp.tsne <- data.frame(data.clust.z.on.off.fin.lim$pkey, rtsne.out.on.off.fin.lim.scale.coord, stringsAsFactors = F)
names(temp.tsne) <- c("pkey", "tSNE1", "tSNE2")
add.tsne.coord(two_gene_neg_fb) <- list( prm.combs.name = "two_gene_neg_fb_unifgrid", 
                                         tsne.coord = temp.tsne,
                                         custom.scale = list(name = "K.rel.z",
                                                             parameters = c(KXY.rel.z = "KXY", KYX.rel.z = "KYX")))

saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")

##ml models

#q.factor
load(file="~/Dropbox/Codes/project_sim_ml/analysis/two_gene_feedback/run_Nov13/rf.detect.bw6.qfactor.1.all.rda")

rf.q.factor.whole.reg <- rf.detect.bw6.qfactor.1.all
rf.q.factor.whole.reg.res <- rf.detect.bw6.qfactor.1.all.bc

rf.q.factor.whole.reg$pkey <- data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,1]
rf.q.factor.whole.reg.res$pkey <- data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,1]

saveRDS(rf.q.factor.whole.reg,file ="ml.models/rf.q.factor.whole.reg.Rds")
saveRDS(rf.q.factor.whole.reg.res,file ="ml.models/rf.q.factor.whole.reg.res.Rds")


row.names(rf.q.factor.whole.reg$importance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
row.names(rf.q.factor.whole.reg.res$importance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
row.names(rf.q.factor.whole.reg$localImportance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
row.names(rf.q.factor.whole.reg.res$localImportance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")

data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,1]

add.ml.model(two_gene_neg_fb) <- list(phenotype.name = "q.factor",
                                      name = "rf.q.factor.whole.reg", 
                                      ml.model.path = "ml.models/rf.q.factor.whole.reg.Rds",
                                      ml.model.res.path = "ml.models/rf.q.factor.whole.reg.res.Rds",
                                      mode = "regression",
                                      prm.sets.used = "two_gene_neg_fb_unifgrid", 
                                      train.data =  data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,1], 
                                      test.data = NULL,
                                      class.def = NULL,
                                      note = "(KXY.rel > -4 & KXY.rel < 4) & (KYX.rel > -4 & KYX.rel < 4) & (pow.mx.half.peak.freq.high != 0.5 & pow.my.half.peak.freq.high != 0.5)",
                                      custom.scale = list(name = "K.rel",
                                                          parameters = c(KXY.rel = "KXY", KYX.rel = "KYX"),
                                                          values = data.frame(pkey = data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,1],
                                                                              KXY.rel = data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,]$KpxY.rel.2,
                                                                              KYX.rel = data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$pow.mx.half.peak.freq.high != 0.5 & detect.bw6.on.off.fin.lim$pow.my.half.peak.freq.high != 0.5,]$KpyX.rel.2, 
                                                                              stringsAsFactors = F)
                                                          
                                                          )
                                      )


#peak.freq
load("~/Dropbox/Codes/project_sim_ml/analysis/two_gene_feedback/run_Nov13/rf.detect.bw6.peak.freq.1.all.rda")
rf.peak.freq.whole.reg <- rf.detect.bw6.peak.freq.1.log10.all
rf.peak.freq.whole.reg.res <- rf.detect.bw6.peak.freq.1.log10.all.bc

rf.peak.freq.whole.reg$pkey <- data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$class1 == "high" & detect.osc9.on.off.fin.lim$pow.mx.ratio != 1 &detect.osc9.on.off.fin.lim$pow.my.ratio != 1,1]
rf.peak.freq.whole.reg.res$pkey <- data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$class1 == "high" & detect.osc9.on.off.fin.lim$pow.mx.ratio != 1 &detect.osc9.on.off.fin.lim$pow.my.ratio != 1,1]

row.names(rf.peak.freq.whole.reg$importance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
row.names(rf.peak.freq.whole.reg.res$importance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
row.names(rf.peak.freq.whole.reg$localImportance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
row.names(rf.peak.freq.whole.reg.res$localImportance)[13:16] <- c("nXY", "nYX", "KXY.rel", "KYX.rel")
saveRDS(rf.peak.freq.whole.reg,file ="ml.models/rf.peak.freq.whole.reg.Rds")
saveRDS(rf.peak.freq.whole.reg.res,file ="ml.models/rf.peak.freq.whole.reg.res.Rds")

add.ml.model(two_gene_neg_fb) <- list(phenotype.name = "peak.freq",
                                      name = "rf.peak.freq.whole.reg", 
                                      ml.model.path = "ml.models/rf.peak.freq.whole.reg.Rds",
                                      ml.model.res.path = "ml.models/rf.peak.freq.whole.reg.res.Rds",
                                      mode = "regression",
                                      prm.sets.used = "two_gene_neg_fb_unifgrid", 
                                      train.data =  data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$class1 == "high" & detect.osc9.on.off.fin.lim$pow.mx.ratio != 1 &detect.osc9.on.off.fin.lim$pow.my.ratio != 1,1], 
                                      test.data = NULL,
                                      class.def = NULL,
                                      note = "(KXY.rel > -4 & KXY.rel < 4) & (KYX.rel > -4 & KYX.rel < 4) & q.factor.mean.geom > 0.1 & pow.mx.ratio != 1 & pow.my.ratio != 1",
                                      custom.scale = list(name = "K.rel",
                                                          parameters = c(KXY.rel = "KXY", KYX.rel = "KYX"),
                                                          values = data.frame(pkey = data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$class1 == "high" & detect.osc9.on.off.fin.lim$pow.mx.ratio != 1 &detect.osc9.on.off.fin.lim$pow.my.ratio != 1,1],
                                                                              KXY.rel = data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$class1 == "high" & detect.osc9.on.off.fin.lim$pow.mx.ratio != 1 &detect.osc9.on.off.fin.lim$pow.my.ratio != 1,]$KpxY.rel.2,
                                                                              KYX.rel = data.clust.z.on.off.fin.lim[detect.bw6.on.off.fin.lim$class1 == "high" & detect.osc9.on.off.fin.lim$pow.mx.ratio != 1 &detect.osc9.on.off.fin.lim$pow.my.ratio != 1,]$KpyX.rel.2, 
                                                                              stringsAsFactors = F)
                                                          )
                                      )




saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")

#rescaling scheme

#from c++ code for simulation
# double m_steady = Rconst[2]*Rconst[0]/(Rconst[3]*(Rconst[0]+Rconst[1]));
# double p_steady = m_steady*Rconst[4]/Rconst[5];
# double my_steady = Rconst[8]*Rconst[6]/(Rconst[9]*(Rconst[6]+Rconst[7]))*pow(p_steady,Rconst[Nreaction])/(pow(p_steady,Rconst[Nreaction])+pow(Rconst[Nreaction+1],Rconst[Nreaction]));
# double py_steady = my_steady*Rconst[10]/Rconst[11];


add.custom.scale(two_gene_neg_fb) <- list(name = "K.rel", 
                                            parameters =  c(KXY.rel = "KXY", KYX.rel = "KYX"), 
                                            func.obj = function(prm.combs, other.vals = NULL  ,cs.to.org = TRUE){
                                              if(cs.to.org == TRUE){
                                                temp.mx.steady = prm.combs[,"kXm"]*prm.combs[,"kXon"]/(prm.combs[,"dXm"]*(prm.combs[,"kXon"]+prm.combs[,"kXoff"]))
                                                temp.px.steady =  temp.mx.steady*prm.combs[,"kXp"]/prm.combs[,"dXp"]
                                                temp.my.steady = prm.combs[,"kYm"]*prm.combs[,"kYon"]/(prm.combs[,"dYm"]*(prm.combs[,"kYon"]+prm.combs[,"kYoff"]))*(temp.px.steady^prm.combs[,"nXY"])/(temp.px.steady^prm.combs[,"nXY"]+((10^prm.combs[,"KXY.rel"])*temp.px.steady)^prm.combs[,"nXY"])
                                                temp.py.steady = temp.my.steady*prm.combs[,"kYp"]/prm.combs[,"dYp"]
                                                
                                                temp.mx.steady = signif( temp.mx.steady , 6)
                                                temp.px.steady = signif( temp.px.steady , 6)
                                                temp.my.steady = signif( temp.my.steady , 6)
                                                temp.py.steady = signif( temp.py.steady , 6)
                                                temp.prm.combs.org = data.frame(pkey = prm.combs$pkey, KXY = (10^prm.combs$KXY.rel)*temp.px.steady , KYX = (10^prm.combs$KYX.rel)*temp.py.steady , stringsAsFactors = F)
                                                
                                                return(temp.prm.combs.org)
                                                
                                              }else if(cs.to.org == FALSE){
                                                
                                                temp.mx.steady = prm.combs[,"kXm"]*prm.combs[,"kXon"]/(prm.combs[,"dXm"]*(prm.combs[,"kXon"]+prm.combs[,"kXoff"]))
                                                temp.px.steady =  temp.mx.steady*prm.combs[,"kXp"]/prm.combs[,"dXp"]
                                                temp.my.steady = prm.combs[,"kYm"]*prm.combs[,"kYon"]/(prm.combs[,"dYm"]*(prm.combs[,"kYon"]+prm.combs[,"kYoff"]))*(temp.px.steady^prm.combs[,"nXY"])/(temp.px.steady^prm.combs[,"nXY"]+prm.combs[,"KXY"]^prm.combs[,"nXY"])
                                                temp.py.steady = temp.my.steady*prm.combs[,"kYp"]/prm.combs[,"dYp"]
                                                temp.mx.steady = signif( temp.mx.steady , 6)
                                                temp.px.steady = signif( temp.px.steady , 6)
                                                temp.my.steady = signif( temp.my.steady , 6)
                                                temp.py.steady = signif( temp.py.steady , 6)
                                                temp.prm.combs.cs = data.frame(pkey = prm.combs$pkey, KXY.rel = log(prm.combs$KXY/temp.px.steady,10) , KYX.rel = log(prm.combs$KYX/temp.py.steady,10) , stringsAsFactors = F)
                                                return( temp.prm.combs.cs)
                                              }
                                            } 
)


add.custom.scale(two_gene_neg_fb) <- list(name = "K.rel.z", 
                                          parameters =  c(KXY.rel.z = "KXY", KYX.rel.z = "KYX"), 
                                          func.obj = function(prm.combs, other.vals = NULL  ,cs.to.org = TRUE){
                                            temp.mean.KXY.rel = mean(other.vals$original$KXY.rel,na.rm = T)
                                            temp.mean.KYX.rel = mean(other.vals$original$KYX.rel, na.rm = T)
                                            
                                            temp.sd.KXY.rel = sd(other.vals$original$KXY.rel, na.rm = T)
                                            temp.sd.KYX.rel = sd(other.vals$original$KYX.rel,na.rm = T)
                                            
                                            if(cs.to.org == TRUE){
                                              temp.mx.steady = prm.combs[,"kXm"]*prm.combs[,"kXon"]/(prm.combs[,"dXm"]*(prm.combs[,"kXon"]+prm.combs[,"kXoff"]))
                                              temp.px.steady =  temp.mx.steady*prm.combs[,"kXp"]/prm.combs[,"dXp"]
                                              temp.my.steady = prm.combs[,"kYm"]*prm.combs[,"kYon"]/(prm.combs[,"dYm"]*(prm.combs[,"kYon"]+prm.combs[,"kYoff"]))*(temp.px.steady^prm.combs[,"nXY"])/(temp.px.steady^prm.combs[,"nXY"]+((10^prm.combs[,"KXY.rel"])*temp.px.steady)^prm.combs[,"nXY"])
                                              temp.py.steady = temp.my.steady*prm.combs[,"kYp"]/prm.combs[,"dYp"]
                                              
                                              temp.mx.steady = signif( temp.mx.steady , 6)
                                              temp.px.steady = signif( temp.px.steady , 6)
                                              temp.my.steady = signif( temp.my.steady , 6)
                                              temp.py.steady = signif( temp.py.steady , 6)
                                              temp.prm.combs.org = data.frame(pkey = prm.combs$pkey, KXY = (10^(prm.combs$KXY.rel.z*temp.sd.KXY.rel + temp.mean.KXY.rel ))*temp.px.steady , KYX = (10^(prm.combs$KYX.rel.z*temp.sd.KYX.rel + temp.mean.KYX.rel))*temp.py.steady , stringsAsFactors = F)
                                              
                                              return(temp.prm.combs.org)
                                              
                                            }else if(cs.to.org == FALSE){
                                              
                                              temp.mx.steady = prm.combs[,"kXm"]*prm.combs[,"kXon"]/(prm.combs[,"dXm"]*(prm.combs[,"kXon"]+prm.combs[,"kXoff"]))
                                              temp.px.steady =  temp.mx.steady*prm.combs[,"kXp"]/prm.combs[,"dXp"]
                                              temp.my.steady = prm.combs[,"kYm"]*prm.combs[,"kYon"]/(prm.combs[,"dYm"]*(prm.combs[,"kYon"]+prm.combs[,"kYoff"]))*(temp.px.steady^prm.combs[,"nXY"])/(temp.px.steady^prm.combs[,"nXY"]+prm.combs[,"KXY"]^prm.combs[,"nXY"])
                                              temp.py.steady = temp.my.steady*prm.combs[,"kYp"]/prm.combs[,"dYp"]
                                              temp.mx.steady = signif( temp.mx.steady , 6)
                                              temp.px.steady = signif( temp.px.steady , 6)
                                              temp.my.steady = signif( temp.my.steady , 6)
                                              temp.py.steady = signif( temp.py.steady , 6)
                                              temp.prm.combs.cs = data.frame(pkey = prm.combs$pkey, KXY.rel.z = (log(prm.combs$KXY/temp.px.steady,10)- temp.mean.KXY.rel)/temp.sd.KXY.rel , KYX.rel.z = (log(prm.combs$KYX/temp.py.steady,10)-temp.mean.KYX.rel)/temp.sd.KYX.rel , stringsAsFactors = F)
                                              return( temp.prm.combs.cs)
                                            }
                                          },
                                          other.vals = list(original = data.frame(KXY.rel = data.clust.z.on.off.fin.lim[,115], KYX.rel = data.clust.z.on.off.fin.lim[,116]))
)

temp.custom.scale <- data.clust.on.off.fin[,1:17]
names(temp.custom.scale)[14:17] <- c("nXY", "KXY", "nYX", "KYX")
temp.custom.scale.rel.z <- two_gene_neg_fb@analysis$custom.scale$K.rel.z$func.obj(prm.combs = temp.custom.scale, other.vals = two_gene_neg_fb@analysis$custom.scale$K.rel.z$other.vals, cs.to.org = FALSE )
all.equal(temp.custom.scale.rel.z$KYX.rel.z[temp.custom.scale.rel.z$pkey %in% data.clust.z.on.off.fin.lim$pkey]
          , as.numeric(scale(data.clust.z.on.off.fin.lim[,116])), check.attributes = F)

saveRDS(two_gene_neg_fb, "two_gene_neg_fb.Rds")

prm.ranges =apply(data.clust.z.on.off.fin.lim[,c(2:14,16,115,116)], 2, range)
prm.ranges =signif(prm.ranges,6)


##validation
###111315_AAAAENMF

prm.combs.val.111315_AAAAENMF <-
  read.table("~/Dropbox/Codes/project_sim_ml/analysis/two_gene_feedback/run_Nov13/prmsets_012617_prj.txt", stringsAsFactors = F)
prms

detect.bw6.prj.all.short$q.factor.1.mean.geom
detect.bw6.prj.all.short$pow.peak.freq.mean.log10.1
selected = data.clust.on.off.fin.lim[data.clust.on.off.fin.lim$pkey == "111315_AAAAENMF" ,]
selected = selected[, 1:17]
names(selected)[2:17] = prms
selected = data.frame(selected, q.factor = detect.bw6$q.factor.1.mean.geom[detect.bw6$pkey == "111315_AAAAENMF"],
                      peak.freq = log(detect.bw6$pow.peak.freq.mean.geom.1,10)[detect.bw6$pkey == "111315_AAAAENMF"],
                      stringsAsFactors = F)


  
prm.combs.val.111315_AAAAENMF <- prm.combs.val.111315_AAAAENMF[,c(1,3:18)]
names(prm.combs.val.111315_AAAAENMF) <- c("pkey", prms)

prm.combs.val.111315_AAAAENMF <- data.frame(prm.combs.val.111315_AAAAENMF, 
                                            q.factor = detect.bw6.prj.all.short$q.factor.1.mean.geom, 
                                            peak.freq = detect.bw6.prj.all.short$pow.peak.freq.mean.log10.1,
                                            stringsAsFactors = F)




#nYX-KYX
prm.combs.val.111315_AAAAENMF.nYX.KYX <- prm.combs.val.111315_AAAAENMF[1:900,]

prm.combs.val.111315_AAAAENMF.nYX.KYX <- rbind(selected ,selected ,prm.combs.val.111315_AAAAENMF.nYX.KYX)
prm.combs.val.111315_AAAAENMF.nYX.KYX[1, ] <- NA
prm.combs.val.111315_AAAAENMF.nYX.KYX[1,1 ] <- "perturbed_prms"
prm.combs.val.111315_AAAAENMF.nYX.KYX[1,"nYX" ] <-1
prm.combs.val.111315_AAAAENMF.nYX.KYX[1,"KYX" ] <-2
row.names(prm.combs.val.111315_AAAAENMF.nYX.KYX) <- NULL
write.table(prm.combs.val.111315_AAAAENMF.nYX.KYX, file="111315_AAAAENMF_nYX_KYX_sim.txt", quote = F, row.names = F)

#dXp-dYm 
prm.combs.val.111315_AAAAENMF.dXp.dYm <- prm.combs.val.111315_AAAAENMF[901:1800,]
prm.combs.val.111315_AAAAENMF.dXp.dYm <- rbind(selected ,selected ,prm.combs.val.111315_AAAAENMF.dXp.dYm)
prm.combs.val.111315_AAAAENMF.dXp.dYm[1, ] <- NA
prm.combs.val.111315_AAAAENMF.dXp.dYm[1,1 ] <- "perturbed_prms"
prm.combs.val.111315_AAAAENMF.dXp.dYm[1,"dXp" ] <-1
prm.combs.val.111315_AAAAENMF.dXp.dYm[1,"dYm" ] <-2
row.names(prm.combs.val.111315_AAAAENMF.dXp.dYm) <- NULL
write.table(prm.combs.val.111315_AAAAENMF.dXp.dYm, file="111315_AAAAENMF_dXp_dYm_sim.txt", quote = F, row.names = F)


#kYon-kYoff
prm.combs.val.111315_AAAAENMF.kYon.kYoff <- prm.combs.val.111315_AAAAENMF[1801:2700,]
prm.combs.val.111315_AAAAENMF.kYon.kYoff <- rbind(selected ,selected ,prm.combs.val.111315_AAAAENMF.kYon.kYoff)
prm.combs.val.111315_AAAAENMF.kYon.kYoff[1, ] <- NA
prm.combs.val.111315_AAAAENMF.kYon.kYoff[1,1 ] <- "perturbed_prms"
prm.combs.val.111315_AAAAENMF.kYon.kYoff[1,"kYon" ] <-1
prm.combs.val.111315_AAAAENMF.kYon.kYoff[1,"kYoff" ] <-2
row.names(prm.combs.val.111315_AAAAENMF.kYon.kYoff) <- NULL
write.table(prm.combs.val.111315_AAAAENMF.kYon.kYoff, file="111315_AAAAENMF_kYon_kYoff_sim.txt", quote = F, row.names = F)


#modify
