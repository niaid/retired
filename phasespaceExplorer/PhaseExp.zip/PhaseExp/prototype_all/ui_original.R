#####Proto web version for deploying to Monarch######
#####Contain all networks###########

###help message###
##explore phasespace
load_phasespace_help <- "Loading a phasespace object into the memory"
show_phasespace_vis_help <- "Select a phenotype, parameter sets and a ML model to launch tSNE visualization of phasespace."# Then, click the 'Launch Visualization' to launch visualization in the panel 'Phasespace visualization in tSNE."
prm_space_help <- "Manipulate the t-SNE plot by adjusting slide bars in the side panel."
within_ml_model_help <- "Parameter combinations to plot"#; \nAll: all points \nother options-points used for training and testing the selected ML model"
further_info_help <- "For global variable importance (GVI) and information of the selected point and ML model performance"

add_vis_help <- "Heatmaps, in-silico perturbation, and validation"
tab_hclust_help <- "Hierarchical clustering heatmaps of parameter combinations and LVIs of selected points in the dragged rectangular region."
tab_varImp_perturb_help <- "LVI of a single selected point and phase plot for in-silico parameter perturbation."
tab_val_help <- "Compare between prediction and validation simulation for in-silico parameter perturbation."

tagList(
  dashboardPage(
    title = "Phasespace Explorer",
    header = tags$header(class = "main-header", 
                tags$div(id="niaid_header_links",
                         tags$a(href="http://www.niaid.nih.gov", target="_blank", "National Institute of Allergy and Infectious Diseases (NIAID)"),
                         ",",
                         tags$a(href="http://www.nih.gov", target="_blank", "National Institutes of Health (NIH)")
                ),
               
                span(class = "logo", 
                     tags$img(src = "NIH_NIAID_logo.png",
                              alt = "NIH > NIAID logo",
                              class = "header__image", height = "40", style = "vertical-align: middle;"),
                     style = "background-color: rgb(1, 81, 154);line-height:75px;height: 70px;vertical-align: middle;"),
                tags$nav(class = "navbar navbar-static-top", role = "navigation", style = "background-color: rgb(1, 81, 154);margin-top:20px",
                         # Embed hidden icon so that we get the font-awesome dependency
                         span(shiny::icon("bars"), style = "display:none;height:20px;"),
                         # Sidebar toggle button
                         a(href="#", class="sidebar-toggle", `data-toggle`="offcanvas",
                           role="button",
                           span(class="sr-only", "Toggle navigation"),
                           style = "background-color: rgb(27, 80, 160);line-height: 10px; height: 10px;"
                         ),
                         tags$div(id = "header_title", "Phasespace Explorer", style = "position: absolute;left: 50px; line-height: 40px;height: 20px;font-size: 250%")
                )
              
    ),
    
    sidebar = dashboardSidebar(
      sidebarMenu(id = "side_menu_tab",
                  menuItem("Home", tabName = "home_tab"),
                           #menuSubItem("Overview", tabName = "overview_tab"),
                  menuItem("Tutorial", tabName = "how_to_use_tab"),
                  #menuItem("Dashboard", tabName = "workspace_tab"),
                  menuItem("Explore Phasespace", tabName = "exp_phase_tab"),
                  menuItem("About", tabName = "about_tab")
      )
    ),
    body = dashboardBody(
      ##niaid visual guidline
      tags$head(
        tags$link(rel = "stylesheet", type = "text/css", href = "niaidbranding.css"),
        tags$title("Phasespace Explorer"),
        tags$head(HTML(
          "<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src=\"https://www.googletagmanager.com/gtag/js?id=UA-87121203-27\"></script>
          <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          
          gtag('config', 'UA-87121203-27');
          </script>"
          
        ))
      ),
      
      ###Website description
      tabItems(
        tabItem("home_tab",
                h1("Welcome to Phasespace Explorer", align = "center"),
                br(),
                div(
                p(tags$b("PhaseX (Phasespace eXplorer)"), "is a Shiny-based interactive tool for exploring phasespaces of dynamical models. This is a website version of PhaseExp focusing on stochastic gene regulatory network models described in our paper <title> and serves as interactive figures of the main paper. Through this website, users can explore rich behaviors of phasespaces beyond the represented in the paper.
                   The full version of PhaseX will be distributed as a standalone R package. The following is Figure 1 of the main paper, which describe the basic framework of our work. For the detailed tutorial of this website, please go to the ", tags$b("Tutorial"),".", " To explore phasespaces we built in the paper, please go to the ", tags$b("Explore Phasespace"), "." ),
                style = "padding: 0px 25px; font-size: 20px"),
                tags$div(img(src = "Figure1.png", width = "800"), align = "center")
        ),
        tabItem("how_to_use_tab",
                h2("Key Concepts"),
                h4("Click items bellow to see the detail"),
                
                #tags$ul(
                bsCollapsePanel(tags$li(tags$b("Phasespace"),  style = "font-size: 20px"),
                                div(
                                  p("A phasespace consists of parameter space, phenotypic space, and Machine Learning (ML) models connecting parameter space and phenotypic space. ML models can be considered as phenomenological solutions of dynamical models, trained by a data-driven way."
                                  ),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                tags$div(img(src = "web_tutorial_1.png", width = "600"), align = "center"),
                                style = "info"
                ),
                bsCollapsePanel(tags$li(tags$b("Parameter space"),  style = "font-size: 20px"),
                                div(
                                  p("A parameter space consists of kinetic parameters of dynamical models and their feasible ranges. As dynamical models become realistic, the dimensionality of the parameter space also increases. Practically we randomly sample parameter combinations to cover the entire parameter space. To intuitively visualize high-dimensional space, we apply t-distributed Stochastic Neighbor Embedding (t-SNE) for the sampled parameter combinations to plot in 2D."
                                  ),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                bsCollapsePanel(tags$li(tags$b("Phenotypic space"),  style = "font-size: 20px"),
                                div(
                                  p("A phenotypic space consists of a single or multiple phenotype(s). Each phenotype is quantitative or categorical values defining a certain aspect of simulation outcomes throughout the parameter space of a dynamical model, such as single cell gene-gene expression correlations or q-factor as in the main paper."
                                  ),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                bsCollapsePanel(tags$li(tags$b("Machine Learning (ML) model"),  style = "font-size: 20px"),
                                div(
                                  p("A ML model is a random forest regression/classification model. Parameter combinations and phenotypes are input data and output data, respectively for training ML models. In realistic dynamical models with high-dimensional parameter spaces, nonlinearity, and stochasticity, analytical solutions to describe quantitative relationships between parameter and phenotypic spaces are often intractable. Here, ML models can be considered as phenomenological solutions of dynamical models, trained by a data-driven way. Not only ML model can predict phenotypes for given parameter combinations, ML models can also output variable importance in global and local levels, which leads us to better understand behaviors of dynamical models."
                                  ),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                bsCollapsePanel(tags$li(tags$b("Variable Importance"),  style = "font-size: 20px"),
                                div(
                                  p("The random forest algorithm implemented as the randomForest package in R generates variable importance both in the global level averaged for all data points in training sets and in the local level for each individual data points in training sets with the ‘importance’ and  ‘localImp’ options turned on, respectively. Variable importance is the most crucial information to understand the systems’ behaviors in terms of the controllability of each of kinetic parameters. Although the global variable importance (GVI) gives a general overview, the behaviors in the neighborhood of each region of the parameter space can differ each other, and the local variable importance (LVI) does capture this aspect. We can cluster the patterns of LVIs with the hierarchical clustering method and visualize them along with t-SNE plots."
                                  ),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                bsCollapsePanel(tags$li(tags$b("Parameter Key"),  style = "font-size: 20px"),
                                div(
                                  p("Each parameter combinations is assigned its own parameter key to make it easily distinguishable and accessible. A general scheme of parameter keys in this paper is to assign the date when parameter combinations are generated and capital letter digits such as 'AACBEGFD'. An example is 042015_AAACEZGP." 
                                  ),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                #  style = " font-size: 20px"
                #),
                #tags$div(img(src = "web_tutorial_1.png", width = "600"), align = "center"),
                br(),
                h2("How to Explore Phasespace"),
                h4("Click items bellow to see the detail"),
                #tags$ul(
                bsCollapsePanel(tags$li(tags$b("Loading a phasespace"),  style = "font-size: 20px"), style = "info", 
                                div(
                                  p("In the panel 'Load Phasespace', select a phasespace object of interest and click 'Load Selected Phasespace' button. Then the selected phasespace object will be loaded into the memory. There are three phasespace objects, which are related to Figure2, Figure3, and Figure4 in the main paper, respectively. The describing figure will be shown for the selected phasespace."
                                  ),
                                  tags$div(img(src = "tutorial_1_load_phasespace.png", width = "600", class = "border"), align = "center"),
                                  # p("In the Explore Phasespace, select a phasespace of interest and click 'Load Selected Phasespace' button. Then the selected phasespace will be loaded into the memory. You will see the information about parameter ranges, sampled parameter sets, defined phenotypes, and trained ML models in the windows below. There are three phasespaces, which correspond to Figure2, Figure3, and Figure4 in the main paper, respectively."
                                  # ),
                                  
                                  style = "padding: 0px 25px; font-size: 20px")
                ),
                bsCollapsePanel(tags$li(tags$b("Launching phasespace visualization"),  style = "font-size: 20px"), style = "info",
                                div(
                                  p("In the panel 'Launch Phasespace Visualization', select a phenotype of interest, parameter sets in t-SNE, and a ML model, and then click the ‘Launch Visualization!’ button. Then a t-SNE plot for selected parameter sets will come up in the panel 'Phasespace Visualization in tSNE'."
                                  ),
                                  tags$div(img(src = "tutorial_2_launch_phasespace_visualization.png", width = "600", class = "border"), align = "center"),
                                  
                                  #Each point corresponds to each parameter combinations, colored by phenotypic values.
                                  #The Global Variable Importance (GVI) of the selected ML model will come up next to the t-SNE plot."
                                  style = "padding: 0px 25px; font-size: 20px")
                                
                ),
                
                bsCollapsePanel(tags$li(tags$b("Manipulating t-SNE plot"),  style = "font-size: 20px"),
                                div(
                                  p("In the side panel in the panel 'Phasespace Visualization in tSNE', you can adjust various aspect of the t-SNE plot, such as the color scale, the size of points, and transparency of points. You can select a point by a single click, through which original and scaled parameter values of the selected point along with the corresponding parameter key will be shown in the 'Further Information' popup. You can select multiple points by dragging the mouse pointer on the plot. By double clicking the dragged region, you can zoom in further."
                                  ),
                                  tags$div(img(src = "tutorial_3_Phasespace_vis_tSNE.png", width = "600", class = "border"), align = "center"),
                                  
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                
                bsCollapsePanel(tags$li(tags$b("Further information on phasespace visualization"),  style = "font-size: 20px"),
                                div(
                                  p("You can see the further information by clicking the ‘Further Information' button in the panel 'Phasespace Visualization in tSNE'. This will show you various information in a seperate popup panel, including global variable importance (GVI), original and scaled parameter values of the selected point, and the training results and prediction accuracies for out-of-bag (OOB) and test dataset of the ML model. You can also manually select by inputting a parameter key in the 'Input parameter key for manual selection' window."
                                  ),
                                  tags$div(img(src = "tutorial_4_Further Info_1.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_4_Further Info_2.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_4_Further Info_3.png", width = "600", class = "border"), align = "center"),
                                  
                                 
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                
                bsCollapsePanel(tags$li(tags$b("Heatmaps of parameter combinations and LVIs for dragged points"),  style = "font-size: 20px"),
                                div(
                                  p("In the ‘Heatmap for selected points’ tab of the panel 'Additional Visualization', you can further visualize individual parameter combinations and local variable importances (LVIs) for dragged points by hierarchical clustering heatmaps. You can further define clusters for the LVI heatmap and inspect them through the t-SNE plot."
                                  ),
                                  tags$div(img(src = "tutorial_5_additional_heatmap_1.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_5_additional_heatmap_2.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_5_additional_heatmap_3.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_5_additional_heatmap_4.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                
                bsCollapsePanel(tags$li(tags$b("LVI and in-silico perturbation"),  style = "font-size: 20px"),
                                div(
                                  p("In the ‘LVI and parameter perturbation’ tab of the panel 'Additional Visualization', you will see the LVI of the selected parameter combination, once you select a point by clicking in the t-SNE plot or manually inputting a parameter key. Under the guidance of the LVI, which tells you the phenotype’s local sensitivity to each parameter, you can perturb two parameters and see the prediction of the phenotype in a 2D heatmap or 3D surface plot. Moreover, you can generate and save the perturbed parameter combinations for further validation simulation."
                                  ),
                                  tags$div(img(src = "tutorial_6_additional_perturb_1.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_6_additional_perturb_2.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                ),
                
                bsCollapsePanel(tags$li(tags$b("Validation"),  style = "font-size: 20px"),
                                div(
                                  p("In the ‘Validation’ tab of the panel 'Additional Visualization', you can further visualize the results of validation simulations in comparison with predictions of in-silico parameter perturbations shown in the main paper. The scatter plot in the rightmost enables you to examine validity of the prediction of the in-silico parameter perturbation."
                                  ),
                                  tags$div(img(src = "tutorial_7_additional_validation_1.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  tags$div(img(src = "tutorial_7_additional_validation_2.png", width = "600", class = "border"), align = "center"),
                                  br(),
                                  
                                  style = "padding: 0px 25px; font-size: 20px"),
                                style = "info"
                )
                
                # style = "font-size: 20px")
                
        ),
          
        tabItem("workspace_tab",
                
                # fluidRow(
                #   column(4,uiOutput("current_phasespace_name")),
                #   column(4,actionButton("phasespace_load", label = h5("Load a selected phasespace") )),
                #   column(4)
                # ),
                fluidRow(
                  column(4, uiOutput("list_prm_ranges")),
                  column(4, uiOutput("list_init_prm_combs"))#,
                  #column(4, uiOutput("list_addit_prm_combs"))
                ),
                
                fluidRow(
                  column(4, uiOutput("list_phenotypes")),
                  column(4, uiOutput("list_ML.models"))
                )
                
        ),
        tabItem("exp_phase_tab",
                fluidRow(
                  column(12,
                         bsCollapsePanel(h4("Load PPM", icon(id = "load_phasespace_help", "question-circle")),
                                         style = "primary",
                                         bsTooltip(id = "load_phasespace_help" ,title = load_phasespace_help, placement = "top", options = list(container = "body")),
                                         fluidRow(
                                           column(4,uiOutput("current_phasespace_name")),
                                           column(5,h4("Description"),
                                                  uiOutput("show_phasespace_descript_ui")),
                                           column(3,actionButton("phasespace_load", label = "Load Selected Phasespace" ))
                                         ),
                                         fluidRow(
                                           column(6,
                                           
                                             HTML("<div class='myHeader' style='color:blue'><span>Current Status (click here to view)</span></div>"),
                                             HTML("<div class='myContent' style='display:none;padding:5px;'>"),
                                             uiOutput("load_phasespace_info_ui"),
                                             HTML("</div>"),
                                             #toggle text
                                             HTML('<script>
                                                  $(".myHeader").click(function () {
                                                  
                                                  $header = $(this);
                                                  //getting the next element
                                                  $content = $header.next();
                                                  //open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
                                                  $content.slideToggle(200, function () {
                                                  //execute this after slideToggle is done
                                                  //change text of header based on visibility of content div
                                                  $header.text(function () {
                                                  //change text based on condition
                                                  return $content.is(":visible") ? "Current Status (click here to collapse)" : "Current Status (click here to view)";
                                                  });
                                                  });
                                                  
                                                  }); </script>')
                                           )
                                         )
                                        
                         )
                  )
                ),
                fluidRow(
                  column(12,
                         bsCollapsePanel(h4("Launch Phasespace Visualization", icon(id = "show_phasespace_vis_help", "question-circle")),
                                         bsTooltip(id = "show_phasespace_vis_help" ,title = show_phasespace_vis_help, placement = "top", options = list(container = "body")),
                                         fluidRow(
                                           column(3, uiOutput("list_phenotypes_tab_ui")
                                                  #   checkboxInput("with_ml.models", label = h5("With ML models"))
                                           ),
                                           column(4, uiOutput("list_prm_sets_tab_ui")
                                                  #    checkboxInput("with_tsne", label = h5("With tSNE coordinates"))
                                           ),
                                           column(5, uiOutput("list_ml.models_tab_ui"))
                                         )
                                         ,
                                         fluidRow(
                                           column(3, actionButton("launch_exp_phase",label = "Launch Visualization!")
                                                  #br(),
                                                  #h4("Selected ML model"),
                                                  #verbatimTextOutput("test_exp_phase_tab")
                                                  ),
                                           column(9,
                                                  HTML("<div class='myHeader1' style='color:blue'><span>Current Status (click here to view)</span></div>"),
                                                  HTML("<div class='myContent1' style='display:none;padding:5px;'>"),
                                                  uiOutput("launch_phasespace_vis_ui"),
                                                  HTML("</div>"),
                                                  #toggle text
                                                  HTML('<script>
                                                       $(".myHeader1").click(function () {
                                                       
                                                       $header = $(this);
                                                       //getting the next element
                                                       $content = $header.next();
                                                       //open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
                                                       $content.slideToggle(200, function () {
                                                       //execute this after slideToggle is done
                                                       //change text of header based on visibility of content div
                                                       $header.text(function () {
                                                       //change text based on condition
                                                       return $content.is(":visible") ? "Current Status (click here to collapse)" : "Current Status (click here to view)";
                                                       });
                                                       });
                                                       
                                                       }); </script>'))
                                         ),
                                         
                                         style = "primary"
                                         
                         )
                  )
                ),
                fluidRow(
                  column(12, bsCollapsePanel(h4("Phasespace Visualization in tSNE", icon(id = "prm_space_help", "question-circle")), style = "primary",
                                             bsTooltip(id = "prm_space_help" ,title = prm_space_help, placement = "top", options = list(container = "body")),
                                             sidebarLayout(
                                               sidebarPanel(
                                                 uiOutput("exp_phase_side_ui"),
                                                 actionButton("modal_button", h5("Further Information",  icon(id = "further_info_help", "question-circle"))),
                                                 bsTooltip(id = "further_info_help" ,title = further_info_help, placement = "top", options = list(container = "body")),
                                                 
                                                 bsModal("further_info", h4("Further Information"), "modal_button", size = "large",
                                                        
                                                         fluidRow(
                                                           column(5,h4("Global Variable Importance (GVI)"),
                                                                  plotOutput("global_varImp",height = "300px")
                                                                  
                                                           ),
                                                           column(7,uiOutput("selected_point_ui"),
                                                                  column(9,style = "padding:0px",textInput("tsne_manual_pt_select", h4("Input parameter key for manual selection", width = 4)))
                                                           )
                                                         ),
                                                         fluidRow(
                                                           #uiOutput("further_info_ml_model_button_ui"),
                                                           column(12,uiOutput("further_info_ml_model_ui"))
                                                         )
                                                 ),
                                                 width = 3
                                               ),
                                               
                                               mainPanel(
                                                 fluidRow(
                                                   HTML("<div class='myHeader3' style='color:blue'><span><h5>Scope of plot (click here to view)</h5></span></div>"),
                                                   HTML("<div class='myContent3' style='display:none;padding:5px;'>"),
                                                   p(tags$b("All"),": all parameter combinations regardless of whether used for building the ML model or not", br(),
                                                     tags$b("Training and Test sets"),": parameter combinations used as a training or test dataset for building the ML model", br(),
                                                     tags$b("Traing set"),": parameter combinations used as a training dataset for building the ML model", br()
                                                   ),
                                                   HTML("</div>"),
                                                   #toggle text
                                                   HTML('<script>
                                                        $(".myHeader3").click(function () {
                                                        
                                                        $header = $(this);
                                                        //getting the next element
                                                        $content = $header.next();
                                                        //open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
                                                        $content.slideToggle(200, function () {
                                                        //execute this after slideToggle is done
                                                        //change text of header based on visibility of content div
                                                        $header.text(function () {
                                                        //change text based on condition
                                                        return $content.is(":visible") ? "Scope of plot (click here to collapse)" : "Scope of plot (click here to view)";
                                                        });
                                                        });
                                                        
                                                        }); </script>')
 
                                                   #h5("Scope of plot", icon(id = "within_ml_model_help", "question-circle")),
                                                   #bsTooltip(id = "within_ml_model_help" ,title = within_ml_model_help, placement = "top", options = list(container = "body"))
                                                 ),
                                                 fluidRow(
                                                   column(7,style='padding:0px;',radioButtons(inputId = "within_ml.model", label = NULL, choices = c("All", "Training and test sets", "Training set" ),inline = TRUE)),
                                                   uiOutput("tsne_ml_ui")
                                                 ),
                                                 # fluidRow(column(6,checkboxInput("within_ml.model", label = h5("Training and test sets"))),
                                                 #          column(6,checkboxInput("within_ml.model", label = h5("Training and test sets")))
                                                 plotOutput("t_SNE", 
                                                            dblclick = "tsne_dblclick",
                                                            click = "tsne_click",
                                                            brush = brushOpts(
                                                              id = "tsne_brush",
                                                              resetOnNew = TRUE
                                                            ),
                                                            height = "600px"),
                                                 width = 9)
                                               
                                             )
                                            
                  )
                  
                  
                  
                  )
                ),
  
                fluidRow(
                  column(12,
                         bsCollapsePanel(h4("Additional Visualizatione", icon(id = "add_vis_help", "question-circle")), style = "primary",
                                         bsTooltip(id = "add_vis_help" ,title = add_vis_help, placement = "top", options = list(container = "body")),
                                         tabBox(id = "selection", selected = NULL, width = 12, #type = "pills",
                                                tabPanel( style = "padding:0px",h4("Heatmaps for selected points", icon(id = "tab_hclust_help", "question-circle")), value = "tab_hclust",
                                                         bsTooltip(id = "tab_hclust_help" ,title = tab_hclust_help, placement = "top", options = list(container = "body")),
                                                         fluidRow(
                                                           uiOutput("gen_hclust_ui")
                                                         ),
                                                         br(),
                                                         fluidRow(
                                                           column(6, style = "padding:0px",
                                                                  h4("Parameter combination"),
                                                                  checkboxInput("hclust_prms_col_dendr", h5("Column dendrogram")),
                                                                  plotOutput("hclust_prms",height = "600px"),
                                                                  uiOutput("hclust_prms_selected_ui")),
                                                           
                                                           column(6,style = "padding:0px",
                                                                  h4("Local variable importance"),
                                                                  checkboxInput("hclust_locImp_col_dendr", h5("Column dendrogram")),
                                                                  plotOutput("hclust_local_varimp",height = "600px"),
                                                                  uiOutput("hclust_locImp_spec_ui")
                                                           )
                                                         )
                                                ),
                                                
                                                tabPanel(h4("LVI and in-silico perturbation", icon(id="tab_varImp_perturb_help", "question-circle")), value = "tab_varImp_perturb",
                                                         bsTooltip(id = "tab_varImp_perturb_help" ,title = tab_varImp_perturb_help, placement = "top", options = list(container = "body")),
                                                         
                                                         fluidRow(
                                                           column(4,
                                                                  h4("Local Variable Importance (LVI)"),
                                                                  #plotOutput("global_varImp",height = "300px"),
                                                                  plotOutput("local_varImp", height = "300px")
                                                           ),
                                                           column(8,
                                                                  div(h4("in-silico perturbation"), align = "center"),
                                                                  #choice of parameters to perturb and the type. actionbutton for generation
                                                                  fluidRow(
                                                                    column(3,
                                                                           uiOutput("parameter_choice1"),
                                                                           uiOutput("parameter_choice2"),
                                                                           selectInput(inputId = "plot_type",
                                                                                       label = h5("Plot type:"),
                                                                                       choices = c("2D", "3D")),
                                                                           numericInput("num_grids_val", label = h5("Number of grids"),value = 30, min = 2, max = 100),
                                                                           uiOutput("plot_range_ui"),
                                                                           actionButton(inputId = "plot_gen",
                                                                                        label = "Generate phase plot!")
                                                                    ),
                                                                    column(9,
                                                                           uiOutput("perturb_plot")
                                                                    )
                                                                  )
                                                                  
                                                           )
                                                         ),
                                                         fluidRow(
                                                           uiOutput("gen_prm_combs_val_ui")
                                                         )
                                                         
                                                ),
                                                tabPanel(h4("Validation",icon(id="tab_val_help", "question-circle")), value = "tab_val",
                                                         bsTooltip(id = "tab_val_help" ,title = tab_val_help, placement = "top", options = list(container = "body")),
                                                         #fileInput("file_validation", "Load a validation simulation result (.txt, .csv)."),
                                                         fluidRow(#uiOutput("select_validation_ui")
                                                           column(4,uiOutput("val_parameter_key_ui")),
                                                           column(4,uiOutput("val_perturb_prms_ui")),
                                                           column(4,uiOutput("val_phenotype_ui"))),
                                                         fluidRow(uiOutput("gen_validation_ui")),
                                                         fluidRow(uiOutput("validation_plots"))
                                                         
                                                )
                                               
                                         )
                         )
                  )
                  
                  
                )
                
        ),
        tabItem("about_tab",
                h2("About this website"),
                p("This website is developed by Kyemyung Park, ", 
                  a(href = "https://www.niaid.nih.gov/lab-sections/3174", 
                    target="_blank",
                    "Systems Genomics and Bioinformatics Unit"), ", Laboratory of Systems Biology, NIAID, NIH.",
                  style = "padding: 0px 25px; font-size: 20px"),
                # p(a(href = "https://www.niaid.nih.gov/about/cyber-infrastructure-computational-biology-contacts", 
                #     target="_blank",
                #     "OCICB/NIAID"), 
                #   "supports for hosting this website.",
                #   style = "padding: 0px 25px; font-size: 20px"),
                br(),
                h2("Contact Us"),
                # p("Please contact Kyemyung Park ", tags$b(tags$i("Email:"),tags$span(id="demo")), "or John Tsang (john.tsang_at_nih.gov) if you have any inquiry.",
                #   style = "padding: 0px 25px; font-size: 20px")
                
                p("Please contact Drs. Kyemyung Park ", 
                  a(href = "http://www.google.com/recaptcha/mailhide/d?k=01coJzKVKp9xOUb8yiqLQlfA==&amp;c=YdpHIOCdSNf1YG6SC-uAzfBt-toaJWQOi4f1UdMPMGs=",
                    onclick = "window.open('http://www.google.com/recaptcha/mailhide/d?k\x3d01coJzKVKp9xOUb8yiqLQlfA\x3d\x3d\x26c\x3dYdpHIOCdSNf1YG6SC-uAzfBt-toaJWQOi4f1UdMPMGs\x3d', '', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=500,height=300'); return false;",
                    title="Reveal this e-mail address",
                    icon("envelope-square")),
                  "or John Tsang ",
                  a(href = "http://www.google.com/recaptcha/mailhide/d?k=01R5rs6DRX1mQ0Zc06uJyo_A==&amp;c=wnlDX0wdD0JK-uc9qH2VAiDAI_7_4ceiiox4Usjd1VA=",
                    onclick = "window.open('http://www.google.com/recaptcha/mailhide/d?k\x3d01R5rs6DRX1mQ0Zc06uJyo_A\x3d\x3d\x26c\x3dwnlDX0wdD0JK-uc9qH2VAiDAI_7_4ceiiox4Usjd1VA\x3d', '', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=500,height=300'); return false;",
                    title="Reveal this e-mail address",
                    icon("envelope-square")),
                  " if you have any inquiry.",
                  style = "padding: 0px 25px; font-size: 20px")
                
                )
      )
    )
    
    
    
  ),
  
  tags$footer(tags$p(align = "center",
                     actionLink("actionlink_home", "Home"),
                     #a(href = "/", "Home"), 
                     "|",
                     actionLink("actionlink_sitemap", "Site Map"),
                     #a(href = "/", "Site Map"),
                     "|",
                     a(href = "http://inside.niaid.nih.gov/policies/Pages/accessibility.aspx", target="_blank", "Accessibility"),
                     "|",
                     a(href = "http://inside.niaid.nih.gov/policies/Pages/privacyPolicy.aspx", target="_blank", "Privacy Policy"),
                     "|",
                     a(href = "https://www.niaid.nih.gov/global/website-disclaimer", target="_blank", "Disclaimer"),
                     "|",
                     a(href = "http://inside.niaid.nih.gov/policies/Pages/default.aspx", target="_blank", "Website Links & Policies"),
                     "|",
                     a(href = "http://inside.niaid.nih.gov/topic/records/FOIA/Pages/default.aspx", target="_blank", "FOIA"),
                     "|",
                     actionLink("actionlink_about_us", "About Us"),
                     "|",
                     actionLink("actionlink_contact", "Contact")
                     ),
              
              tags$div(class = "footer__images", align = "center",
                       tags$a(href="http://www.hhs.gov",
                              target="_blank",
                              img(src="HHS_Logo.gif",
                                  alt="United States Department of Health and Human Services Logo",
                                  class="footer__image",
                                  style="padding-left:5px;")
                              ),
                       tags$a(href="https://www.nih.gov",
                              target="_blank",
                              img(src="NIH_Logo.png",
                                  alt="National Institutes of Health Logo",
                                  class="footer__image", 
                                  style="padding-left:35px;")
                              ),
                       tags$a(href="https://www.usa.gov/",
                              target="_blank",
                              img(src="USA.gov_Logo.png",
                                  alt="USA.gov Logo",
                                  class="footer__image",
                                  style="padding-left:20px;")
                       )
              )
  )
  

  
)

