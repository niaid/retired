#####Proto web version for deploying to Monarch######
#####Contain all networks###########



options(shiny.maxRequestSize=10000*1024^2)
ggdata = data.frame() ## how to make this local? to be able to load data by user input

source("classes.R")

server <- function(input, output,session) {
  #####################################
  ##############Help messages #########
  #####################################
  
  
  ##workspace
  show_phasespace_help <- "These are PPM objects of stochastic gene regulatory networks in the main paper. Once selecting one of these, click the button in the right to load into the memory."
  show_prm_ranges_list_help <- "A list of defined parameter ranges in the loaded PPM."
  show_prm_combinations_list_help <- "Initially and additionally sampled parameter sets; initial-evenly sampled, additional-focused around regions of interest of the parameter space"
  #show_addit_prm_combs_list_help <- "Additionally sampled parameter sets, focused around regions of interest of the parameter space."
  show_phenotypes_help <- "A list of defined phenotypes, being either quantitative values or categorical values."
  show_ml_model_ml_help <- "A list of ML models, conneting parameter space and phenotypic space."
  
  ##explore phasespace
  load_phenotype_help <- "The selected phenotype will be shown using a color scale in the t-SNE plot."
  load_parameter_sets_help <- "The selected parameter sets will be shown in the t-SNE plot."
  # Only ones upon which the selected phenotype is computed are shown. 
  load_ml_model_help <- "Random forest classification/regression models."
  
  
  
  
  
  #####################################
  ############## Overview #############
  #####################################
 
  
  #####################################
  ######### Workspace##################
  #####################################
  # phasespace <- reactiveValues()
  # 
  # output$current_phasespace_name <- renderUI({
  #   
  #   phasespace.name <- c(`Two-gene simple network (Figure2)` = "Two-gene simple network",`Three-gene feedforward network (Figure3)` =  "Three-gene feedforward network", `Two-gene negative feedback network (Figure4)` = "Two-gene negative feedback network")
  #   isolate({
  #     list(
  #       selectInput("show_phasespace",label = h4("Select a phasespace.", icon(id = "show_phasespace_help", "question-circle")),choices = phasespace.name, size = 3, multiple = TRUE, selectize = FALSE),
  #       bsTooltip(id = "show_phasespace_help" ,title = show_phasespace_help, placement = "top", options = list(container = "body"))
  #       
  #     )
  #   })
  # })
  # 
  # observeEvent(input$phasespace_load,{
  #   if(!is.null(input$show_phasespace)){
  #     if(input$show_phasespace == "Two-gene simple network"){
  #       phasespace$object <- NULL
  #       phasespace$object <- readRDS("phasespace/two_gene_simple.Rds")
  #     }else if(input$show_phasespace == "Two-gene negative feedback network"){
  #       phasespace$object <- NULL
  #       phasespace$object <- readRDS("phasespace/two_gene_neg_fb.Rds")
  #     }else if(input$show_phasespace == "Three-gene feedforward network"){
  #       phasespace$object <- NULL
  #       phasespace$object <- readRDS("phasespace/three_gene_feedforward.Rds")
  #     }
  #   }
  #  
  #   
  # })
  # 
  # 
  
  output$show_phasespace_descript_ui <- renderUI({ if(!is.null(input$show_phasespace)){
        if(input$show_phasespace == "Two-gene simple network"){
          tags$div(img(src = "Figure2A.png", width = "400"), align = "left")
        }else if(input$show_phasespace == "Two-gene negative feedback network"){
          tags$div(img(src = "Figure4A.png", width = "400"), align = "left")
        }else if(input$show_phasespace == "Three-gene feedforward network"){
          tags$div(img(src = "Figure3A.png", width = "400"), align = "left")
        }
      }
    
   
  })
  
  
  
  
  output$list_prm_ranges <- renderUI({
    prm.ranges.names <- NULL
    if(!is.null(phasespace$object)){
      prm.ranges.names <- get.prm.ranges.name(phasespace$object)
    }
    
    #labeling
    isolate({
      if(!is.null(phasespace$object)){
        if(!is.null(input$show_phasespace)){
          if( get.phasespace.name(phasespace$object) == "Two-gene simple network"){
            names(prm.ranges.names) <- c("Two-gene parameter ranges", "Two-gene parameter ranges")
            prm.ranges.names <- prm.ranges.names[2]
          }else if( get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
            names(prm.ranges.names) <- "Two-gene feedback parameter ranges"
          }else if( get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
            names(prm.ranges.names) <- "Three-gene parameter ranges"
          }
        }
      }
    })
    
    
    
    isolate({
      list(
           selectInput("show_prm_ranges_list",label = h4("Parameter ranges", icon(id ="show_prm_ranges_list_help", "question-circle")),choices =  prm.ranges.names,size = 3,multiple = TRUE, selectize = FALSE),
           bsTooltip(id = "show_prm_ranges_list_help" ,title = show_prm_ranges_list_help, placement = "top", trigger = "hover", options = list(container = "body"))  
      )
    })
  })
  
  output$list_init_prm_combs <- renderUI({
    prm.combs.names <- NULL
    init.prm.combs.names <- NULL
    if(!is.null(phasespace$object) && !is.null(get.init.prm.combs.name(phasespace$object))){
      init.prm.combs.names <- get.init.prm.combs.name(phasespace$object)
      init.prm.combs.names <- unlist(init.prm.combs.names )
      names(init.prm.combs.names) <- NULL
    }
    addit.prm.combs.names <- NULL
    if(!is.null(phasespace$object) && !is.null(get.addit.prm.combs.name(phasespace$object))){
      addit.prm.combs.names <- get.addit.prm.combs.name(phasespace$object)
      addit.prm.combs.names <- unlist(addit.prm.combs.names)
      names(addit.prm.combs.names) <- NULL
    }
    
    
    #labeling
    isolate({
      if(!is.null(phasespace$object)){
        if(!is.null(input$show_phasespace)){
          if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
            names(init.prm.combs.names) <- "Initial parameter set (uniform grid)"
            names(addit.prm.combs.names) <- "Additional parameter set (uniform grid)"
            prm.combs.names <- c(init.prm.combs.names, addit.prm.combs.names)
          }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
            prm.combs.names <- c(init.prm.combs.names, addit.prm.combs.names)
            prm.combs.names <- "Initial parameter set (uniform grid)"
          }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
            prm.combs.names <- c(init.prm.combs.names, addit.prm.combs.names)
            prm.combs.names <- prm.combs.names[c(2,10,11,4,12,13)]
            names(prm.combs.names) <-  c("Initial parameter set (ppp, Sobol')", 
                                         "Additional parameter set (ppp, Sobol', dec)",
                                         "Additional parameter set (ppp, Sobol', inc)",
                                         "Initial parameter set (pnp, Sobol')", 
                                         "Additional parameter set (pnp, Sobol', dec)",
                                         "Additional parameter set (pnp, Sobol', inc)")
          }
        }
      }
    })
  
    
    isolate({
      list(
        selectInput("show_prm_combinations_list",label = h4("Parameter sets", icon(id="show_prm_combinations_list_help", "question-circle")),choices =   prm.combs.names, size = 3,multiple = TRUE, selectize = FALSE),
        bsTooltip(id = "show_prm_combinations_list_help" ,title = show_prm_combinations_list_help, placement = "top", trigger = "hover", options = list(container = "body"))  
        )
    })
    
  })
    
  
  # output$list_addit_prm_combs <- renderUI({
  #   addit.prm.combs.names <- NULL
  #   if(!is.null(phasespace$object) && !is.null(get.addit.prm.combs.name(phasespace$object))){
  #     addit.prm.combs.names <- get.addit.prm.combs.name(phasespace$object)
  #     addit.prm.combs.names <- unlist(addit.prm.combs.names)
  #     names(addit.prm.combs.names) <- NULL
  #   }
  #   isolate({
  #     list(
  #       selectInput("show_addit_prm_combs_list",label = h4("Additional parameter sets", icon(id="", "question-circle")),choices =   addit.prm.combs.names, size = 3,multiple = TRUE, selectize = FALSE),
  #       bsTooltip(id = "show_addit_prm_combs_list_help" ,title = show_addit_prm_combs_list_help, placement = "top", trigger = "hover", options = list(container = "body"))  
  #     )
  #   })
  # })
  
  output$list_phenotypes <- renderUI({
    phenotypes.names <- NULL
    if(!is.null(phasespace$object)){
      
      phenotypes.names <-  get.phenotypes.name(phasespace$object)
      phenotypes.names <- append("None", phenotypes.names)
    }
    
    if(!is.null(phasespace$object) ){ #&& input$with_ml.models_ml == T){
      phenotypes.names <- phenotypes.names[phenotypes.names%in% get.phenotypes.with.ml.models(phasespace$object)]
    }
    
    #labeling
    isolate({
      if(!is.null(phasespace$object)){
        if(!is.null(input$show_phasespace)){
          if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
            names(phenotypes.names) <- "Corr(mx,my)"
            
          }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
            
          }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
            phenotypes.names <- phenotypes.names[c(2,3)]
          }
        }
      }
    })
    
    isolate({
      list(
        selectInput("show_phenotypes",label = h4("Phenotypes",icon(id="show_phenotypes_help", "question-circle")),choices =   phenotypes.names, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "show_phenotypes_help" ,title = show_phenotypes_help, placement = "top", trigger = "hover", options = list(container = "body"))  
        
      )
    })
    
    
  })
  
  
  output$list_ML.models <- renderUI({
    ml.models.names <- NULL
    # if(!is.null(phasespace$object)){
    #   ml.models.names <- get.ml.models.name(phasespace$object)
    #   ml.models.names <- unlist(ml.models.names)
    #   names(ml.models.names) <- NULL
    # }else{}
    
    if(!is.null(phasespace$object)){
      if(!is.null(input$show_phenotypes)){
      #   if(!is.null(get.ml.models.name(phasespace$object))){
        ml.models.name <- list()
        ml.models.names <- get.ml.models.name(phasespace$object)
        names(ml.models.names) <- get.phenotypes.name(phasespace$object)
       
        if(isolate(input$show_phasespace) == "Three-gene feedforward network"){
          ml.models.names <- ml.models.names[["fold.mxmz.max.neg"]]
          names(ml.models.names) <- NULL
        }else{
          ml.models.names <- ml.models.names[[input$show_phenotypes]]
          names(ml.models.names) <- NULL
        }
        
        
        #   }else{}
      #   
      }
    }else{}
    
    #labeling
    isolate({
      if(!is.null(phasespace$object) & !is.null(input$show_phenotypes)){
        if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
          names(ml.models.names) <- c("Combined regression ML model (whole)",
                                      "Initial classification ML model (training)",
                                      "Combined classification ML model (training)",
                                      "Combined regression ML model (training)",
                                      "Initial regression ML model (training) ")
          ml.models.names <- ml.models.names[c(1,5,4,2,3)]
        }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
          names(ml.models.names) <- c("Initial regression ML model (whole)",
                                      "Initial regression ML model (training)")
        }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
          ml.models.names <- ml.models.names[order( ml.models.names)]
          names(ml.models.names) <- c("Combined regression ML model (training)",
                                      "Combined regression ML model (whole)",
                                      "Initial regression ML model (training)",
                                      "Combined regression ML model (training)",
                                      "Combined regression ML model (whole)",
                                      "Initial regression ML model (training)")
          if(input$show_phenotypes == "fold.mxmz.max.neg.ppp"){
            ml.models.names <- ml.models.names[c(5,6,4)]
          }else{
            ml.models.names <- ml.models.names[c(2,3,1)]
          }
        }
      }
    })
    
    
    isolate({
      list(
        selectInput("show_ml.model_ml",label = h4("ML models", icon(id="show_ml_model_ml_help", "question-circle")),choices =   ml.models.names, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "show_ml_model_ml_help" ,title = show_ml_model_ml_help, placement = "top", trigger = "hover", options = list(container = "body"))  
        
      )
    })
    
  })
  
  

  #####################################
  ######## Explore Phase space ########
  #####################################
  #load phasespace
  phasespace <- reactiveValues()
  
  output$current_phasespace_name <- renderUI({
    
    phasespace.name <- c(`Two-gene simple network (Figure1&2)` = "Two-gene simple network",`Three-gene feedforward network (Figure3)` =  "Three-gene feedforward network", `Two-gene negative feedback network (Figure4)` = "Two-gene negative feedback network")
    isolate({
      list(
        selectInput("show_phasespace",label = h4("Select a PPM.", icon(id = "show_phasespace_help", "question-circle")),choices = phasespace.name, size = 3, multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "show_phasespace_help" ,title = show_phasespace_help, placement = "top", options = list(container = "body"))
        
      )
    })
  })
  
  observeEvent(input$phasespace_load,{
    withProgress(message = 'Loading PPM object', value = NULL, {
    if(!is.null(input$show_phasespace)){
      if(input$show_phasespace == "Two-gene simple network"){
        phasespace$object <- NULL
        phasespace$object <- readRDS("phasespace/two_gene_simple.Rds")
      }else if(input$show_phasespace == "Two-gene negative feedback network"){
        phasespace$object <- NULL
        phasespace$object <- readRDS("phasespace/two_gene_neg_fb.Rds")
      }else if(input$show_phasespace == "Three-gene feedforward network"){
        phasespace$object <- NULL
        phasespace$object <- readRDS("phasespace/three_gene_feedforward.Rds")
      }
    }
    })
    
    
  })
  
  output$load_phasespace_info_ui <- renderUI({
    input$phasespace_load
    if(is.null(phasespace$object)){
      list(div(span("Loaded PPM: None"), style = "font-size: 15px" ))
    }else(
      list(div(span("Loaded PPM: "),span(phasespace$object@phasespace.name), style = "font-size: 15px"))
    )
    
  })
  
  
  
  
  #launch visualization
  
  
  loaded.phase.components <- reactiveValues()
  
  
  phenotype.loaded <- reactiveValues()
  output$list_phenotypes_tab_ui <- renderUI({
    phenotypes.names <- NULL
    if(!is.null(phasespace$object)){
      
      phenotypes.names <-  get.phenotypes.name(phasespace$object)
     
    }
    
    
    
    if(!is.null(phasespace$object)){ #&& input$with_ml.models == T){
      phenotypes.names <- phenotypes.names[phenotypes.names%in% get.phenotypes.with.ml.models(phasespace$object)]
    }
   
    
    #labeling
    isolate({
      if(!is.null(phasespace$object) & !is.null(phenotypes.names)){
        phenotypes.names <- append("None", phenotypes.names)
        if( get.phasespace.name(phasespace$object) == "Two-gene simple network"){
          names(phenotypes.names) <-c("None", "Corr(mx,my)")
          
        }else if( get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
          names( phenotypes.names) <- c("None", "QF (quality factor)", "PF (peak frequency" )
        }else if( get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
          phenotypes.names <- phenotypes.names[c(1,3,4)]
          names(phenotypes.names) <- c("None", "FC (fold increase of Corr(mx,my); PPP)", "FC (fold increase of Corr(mx,my); PNP)")
        }
      }
     
    })
    
    loaded.phase.components$phenotypes.names <- phenotypes.names
    
    isolate({
      list(
        selectInput("load_phenotype",label = h4("Select a phenotype" ,icon(id ="load_phenotype_help", "question-circle")),choices =   phenotypes.names, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "load_phenotype_help" ,title = load_phenotype_help, placement = "top", options = list(container = "body"))
        
      )
    })
  })
  
  observe({
    if(!is.null(phasespace$object) & !is.null(input$load_phenotype)){
      if(input$load_phenotype != "None"){
        phenotype.loaded$list <- get.phenotypes(phasespace$object,input$load_phenotype)
        
      }else{
        phenotype.loaded$list <- NULL
      }
    }else{
      phenotype.loaded$list <- NULL
    }
  })
  
  output$list_prm_sets_tab_ui <- renderUI({
    prm.sets.names <- NULL
    if(!is.null(input$load_phenotype)&& input$load_phenotype != "None"){
      prm.sets.names <- names(phenotype.loaded$list)
    }else if(!is.null(input$load_phenotype) && input$load_phenotype == "None"){
      prm.sets.names <- append(unlist(get.init.prm.combs.name(phasespace$object)), 
                               unlist(get.addit.prm.combs.name(phasespace$object)))
      names(prm.sets.names) <- NULL
    }
    
    if(!is.null(phasespace$object)){ #&& input$with_tsne == T){#show only ones with tsne
      prm.sets.names <- prm.sets.names[prm.sets.names%in% get.tsne.coord.name(phasespace$object)]
      
    }
    
    #labeling
    isolate({
      if(!is.null(phasespace$object) & !is.null(prm.sets.names)){
        if( get.phasespace.name(phasespace$object) == "Two-gene simple network"){
          names(prm.sets.names)<- c("Initial parameter set (uniform grid)","Additional parameter set (uniform grid)")
         
        }else if( get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
          names(prm.sets.names) <- "Initial parameter set (uniform grid)"
        }else if( get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
          if(input$load_phenotype == "None"){
            prm.sets.names <- prm.sets.names[c(1,3,4,2,5,6)]
            names(prm.sets.names) <-  c("Initial parameter set (PPP, Sobol')", 
                                        "Additional parameter set (PPP, Sobol', dec)",
                                        "Additional parameter set (PPP, Sobol', inc)",
                                        "Initial parameter set (PNP, Sobol')", 
                                        "Additional parameter set (PNP, Sobol', dec)",
                                        "Additional parameter set (PNP, Sobol', inc)")
          }else if(input$load_phenotype == "fold.corr.ppp"){
            names(prm.sets.names) <- c("Initial parameter set (PPP, Sobol')", 
                                       "Additional parameter set (PPP, Sobol', dec)",
                                       "Additional parameter set (PPP, Sobol', inc)")
          }else if(input$load_phenotype == "fold.corr.pnp"){
              names(prm.sets.names) <- c("Initial parameter set (PNP, Sobol')", 
                                       "Additional parameter set (PNP, Sobol', dec)",
                                       "Additional parameter set (PNP, Sobol', inc)")
          }
        }
      }
    })
    
    loaded.phase.components$prmsets.names <- prm.sets.names
    
    # if(!is.null(prm.sets.names)){
    #   prm.sets.names <- prm.sets.names[order(prm.sets.names)]
    # }
    isolate({
      list(
        selectInput("load_parameter_sets",label = h4("Select parameter sets",icon(id ="load_parameter_sets_help", "question-circle") ),choices =   prm.sets.names, size = 3,multiple = TRUE, selectize = FALSE),
        bsTooltip(id = "load_parameter_sets_help" ,title = load_parameter_sets_help, placement = "top", options = list(container = "body"))
        
      )
    })
  })
  
  output$list_ml.models_tab_ui <- renderUI({
    ml.models.names <- NULL
    if(!is.null(phasespace$object)){
      if(!is.null(input$load_phenotype) && input$load_phenotype != "None"){
        if(!is.null(get.ml.models.name(phasespace$object))){
          ml.models.names <- get.ml.models.name(phasespace$object)
          names(ml.models.names) <- get.phenotypes.name(phasespace$object)
          ml.models.names <- ml.models.names[[input$load_phenotype]]
          
          
          names(ml.models.names) <- NULL
        }else{}
        
      }
    }else{}
    
    #labeling
    isolate({
      if(!is.null(phasespace$object) & !is.null(ml.models.names)){
        if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
          names(ml.models.names) <- c("Combined regression ML model (whole)",
                                      "Initial classification ML model (training)",
                                      "Combined classification ML model (training)",
                                      "Combined regression ML model (training)",
                                      "Initial regression ML model (training) ")
          #ml.models.names <- ml.models.names[c(1,5,4,2,3)]
          ml.models.names <- ml.models.names[1]
        }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
          names(ml.models.names) <- c("Initial regression ML model (whole)",
                                      "Initial regression ML model (training)")
          ml.models.names <- ml.models.names[1]
        }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
          if(input$load_phenotype == "fold.corr.ppp"){
             names(ml.models.names) <- c("Combined regression ML model (whole)",
                                         "Initial classification ML model (training)",
                                         "Combined classification ML model (training)")
             ml.models.names <- ml.models.names[1]
          }else if(input$load_phenotype == "fold.corr.pnp"){
            names(ml.models.names) <- c("Combined regression ML model (whole)",
                                        "Initial classification ML model (training)",
                                        "Combined classification ML model (training)")
            ml.models.names <- ml.models.names[1]
           
            
          }
        }
      }
    })
    
    loaded.phase.components$ml.models.names <- ml.models.names
    isolate({
      list(
        selectInput("load_ml.model",label = h4("Select a ML model", icon(id ="load_ml_model_help", "question-circle")),choices =   ml.models.names, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "load_ml_model_help" ,title = load_ml_model_help, placement = "top", trigger = "hover", options = list(container = "body"))
        
      )
    })
  })
  
  
  # output$test_exp_phase_tab <- renderText({
  #   #input$launch_exp_phase
  #   if(!is.null(ml.model.selected$name)){
  #     ml.model.selected$name
  #   }
  # })
  
  output$launch_phasespace_vis_ui <- renderUI({
    input$launch_exp_phase
    
    if(is.null(loaded.phase.components$prmsets)){
      temp.prmsets <- "None"
    }else{
      temp.prmsets <- NULL
      for(prmset.idx in loaded.phase.components$prmsets){
        temp.prmsets <- paste0(temp.prmsets, prmset.idx, ", ")
      }
      temp.prmsets <- substr( temp.prmsets, 1,nchar(temp.prmsets)-2)
    }    
    
    if(is.null(loaded.phase.components$phenotype)){
      temp.phenotype <- "None"
    }else{
      temp.phenotype <- loaded.phase.components$phenotype
    }
    
    if(is.null(loaded.phase.components$ml.model)){
      temp.ml.model <- "None"
    }else{
      temp.ml.model <- loaded.phase.components$ml.model
    }
    
    

    list(div(span("Loaded Phenotype: "),span(temp.phenotype), style = "font-size: 15px"),
         div(span("Loaded Parameter Set(s): "),span(temp.prmsets), style = "font-size: 15px"),
         div(span("Loaded ML model: ",span(temp.ml.model), style = "font-size: 15px")))
    
    
    
  })
  
  
  
  #phase space   
  tsne_range = reactiveValues(x=c(-30,30), y = c(-30,30))
  prm.sets.selected <- reactiveValues()
  phenotype.values.selected <- reactiveValues()
  prm.ranges.selected <- reactiveValues()
  prm.ranges.z.selected <- reactiveValues() # The ranges of perturbation. If ML models use custom scale for some parameter, then replace with custum ranges
  
  prm.grids.selected <- reactiveValues()
  prm.set.method <- reactiveValues()
  ml.model.selected <- reactiveValues()
  local.importance <- reactiveValues()
 
  
  #parameters
  ##number of parameters
  numPrm <- reactiveValues() # = 10 ## later to be detected automatically
  parameters <- reactiveValues()  #names(data.clust.z.combined)[2:(numPrm+1)]
  
  
  
  ##loading parameter sets with accordance with the selection above
  observeEvent(input$launch_exp_phase,{
    withProgress(message = 'This may take a while....', value = NULL, {
    prm.sets.selected$tsne <- data.frame(stringsAsFactors = F)
    prm.sets.selected$original <- data.frame(stringsAsFactors = F)
    prm.sets.selected$rescaled <- data.frame(stringsAsFactors = F)
    phenotype.values.selected$DF <- data.frame(stringsAsFactors = F)
    
    ##store information for loaded phasespace components
    loaded.phase.components$prmsets <- names(loaded.phase.components$prmsets.names)[loaded.phase.components$prmsets.names %in% input$load_parameter_sets]
    loaded.phase.components$phenotype <- names(loaded.phase.components$phenotypes.names)[loaded.phase.components$phenotypes.names %in% input$load_phenotype]
    loaded.phase.components$ml.model <- names(loaded.phase.components$ml.models.names)[loaded.phase.components$ml.models.names %in% input$load_ml.model]
    
    
    ##launch parameter space
    if(!is.null(input$load_parameter_sets)){
      for(i in 1:length(input$load_parameter_sets)){
        prm.sets.selected$tsne <- rbind(prm.sets.selected$tsne, get.tsne.coord(phasespace$object,input$load_parameter_sets[i] ) )
        temp.prm.ranges.names <- get.prm.ranges.name(object = phasespace$object)
        temp.prm.names.init <- get.init.prm.combs.name(object = phasespace$object)
        temp.prm.names.addit <- get.addit.prm.combs.name(object = phasespace$object)
        
        
        ##to obtain corresponding parameter ranges for selected initial parameter space
        if(any(unlist( temp.prm.names.init) == input$load_parameter_sets[i]) ){
          temp.idx <- unlist(
            apply(matrix(temp.prm.ranges.names), 1,
                  function(name, prm.names, input.name){
                    any(prm.names[[name]] == input.name) }, 
                  prm.names = temp.prm.names.init, input.name = input$load_parameter_sets[i])
          )
          temp.range.name <- temp.prm.ranges.names[temp.idx]
          temp.prm.combs <- get.init.prm.combs(phasespace$object,input$load_parameter_sets[i], temp.range.name )
          
          
          
          prm.ranges.z.selected$DF <- apply( temp.prm.combs$prm.combs.z[-1], 2, range)
          prm.ranges.selected$DF <- get.prm.ranges(object = phasespace$object,name = temp.range.name )
          prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, log.scale = temp.prm.combs$log.scale$log.scale, stringsAsFactors = F)
          
          prm.set.method$method <- temp.prm.combs$method 
          if(temp.prm.combs$method == "unif_grid"){
            prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, temp.prm.combs$num.grids$`number of grids`, stringsAsFactors = F)
            names(prm.ranges.selected$DF)[5] = "number of grids"
            prm.grids.selected$DF <- temp.prm.combs$prm.grids
          }else{
            prm.sets.selected$raw.smpl <-  temp.prm.combs$raw.smpl
          }
          
          
          
          
          
          prm.sets.selected$original <-rbind(prm.sets.selected$original, temp.prm.combs$prm.combs )
          prm.sets.selected$rescaled <-rbind(prm.sets.selected$rescaled, temp.prm.combs$prm.combs.z )
          temp.prm.combs <- NULL
          
        }else{
          ##to obtain corresponding parameter ranges and inital parameter set for selected additional parameter space
          temp.idx <- unlist(
            apply(matrix(temp.prm.ranges.names), 1,
                  function(name, prm.names, input.name){
                    any(unlist(prm.names[[name]]) == input.name) }, 
                  prm.names = temp.prm.names.addit, input.name = input$load_parameter_sets[i])
          )
          temp.range.name <- temp.prm.ranges.names[temp.idx]
          temp.idx <- unlist(
            apply(matrix(unlist(temp.prm.names.init)), 1,
                  function(name, prm.range.name, prm.names, input.name){
                    any(prm.names[[ prm.range.name]][[name]] == input.name) }, 
                  prm.range.name = temp.range.name, prm.names = temp.prm.names.addit, input.name = input$load_parameter_sets[i])
          )
          temp.prm.name.init <- unlist(temp.prm.names.init)[temp.idx]
          
          temp.prm.combs <- get.addit.prm.combs(phasespace$object,input$load_parameter_sets[i], temp.range.name,temp.prm.name.init )
          temp.prm.combs.init <- get.init.prm.combs(phasespace$object, temp.prm.name.init, temp.range.name )
          
          if(is.null(prm.ranges.z.selected$DF)){
            prm.ranges.z.selected$DF <- apply( temp.prm.combs.init$prm.combs.z[,-1],2, range)
          }
          if(is.null( prm.ranges.selected$DF)){
            prm.ranges.selected$DF <- get.prm.ranges(object = phasespace$object,name = temp.range.name)
            prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, log.scale = temp.prm.combs.init$log.scale$log.scale, stringsAsFactors = F)
            prm.set.method$method <- temp.prm.combs.init$method 
            
            if(temp.prm.combs.init$method == "unif_grid"){
              prm.ranges.selected$DF <- data.frame(prm.ranges.selected$DF, temp.prm.combs.init$num.grids$`number of grids`, stringsAsFactors = F)
              names(prm.ranges.selected$DF)[5] = "number of grids"
              prm.grids.selected$DF <- temp.prm.combs.init$prm.grids
            }else{
              prm.sets.selected$raw.smpl <-  temp.prm.combs.init$raw.smpl
            }         
          }
          
          
          prm.sets.selected$original <-rbind(prm.sets.selected$original, temp.prm.combs$prm.combs )
          prm.sets.selected$rescaled <-rbind(prm.sets.selected$rescaled, temp.prm.combs$prm.combs.z )
          temp.prm.combs <- NULL
          temp.prm.combs.init <- NULL
          
        }
        if(input$load_phenotype != "None"){
          phenotype.values.selected$DF <- rbind( phenotype.values.selected$DF, phenotype.loaded$list[[input$load_parameter_sets[i]]] )
        }else{
          phenotype.values.selected$DF <- NULL
        }
      }
    }else{
      prm.sets.selected$tsne <- NULL
      prm.sets.selected$original <- NULL
      prm.sets.selected$rescaled <- NULL
      phenotype.values.selected$DF <- NULL
      prm.ranges.selected$DF <- NULL
      prm.ranges.z.selected$DF <- NULL
      prm.grids.selected$DF <- NULL
      prm.set.method$method <- NULL
      
    }
    
    ##launch ml.model
    if(!is.null(input$load_ml.model)){
      temp.ml.model <- get.ml.model(object = phasespace$object, phenotype.name = input$load_phenotype, ml.model.name = input$load_ml.model  )
      if(!is.null(temp.ml.model$custom.scale)){
        ml.model.selected$custom.scale <- temp.ml.model$custom.scale
      }
      
      if(!is.null( temp.ml.model$ml.model.path )){
        ml.model.selected$ml.model <- readRDS(temp.ml.model$ml.model.path)
        if(!is.null(temp.ml.model$ml.model.res.path)){
          ml.model.selected$ml.model.res <- readRDS(temp.ml.model$ml.model.res.path)
        }
      }else{
        
        ml.model.selected$ml.model <- temp.ml.model[["ml.model"]]
        if(!is.null(temp.ml.model[[2]])){
          ml.model.selected$ml.model.res <- temp.ml.model[["ml.model.res"]]
        }
      }
      ml.model.selected$train.data <- temp.ml.model$train.data
      ml.model.selected$test.data <- temp.ml.model$test.data
      ml.model.selected$mode <- temp.ml.model$mode
      ml.model.selected$prm.sets.used <- temp.ml.model$prm.sets.used
      ml.model.selected$class.def <- temp.ml.model$class.def
      ml.model.selected$note <- temp.ml.model$note
      ml.model.selected$phenotype <-  input$load_phenotype
      ml.model.selected$name <- input$load_ml.model
      
      ##ml.model specific tsne
      if(get.tsne.coord.ml.exist(object = phasespace$object, ml.model.name = input$load_ml.model  )){
        if(!is.null(input$load_parameter_sets)){
          ml.model.selected$tsne <- data.frame(stringsAsFactors = F)
          for(i in 1:length(input$load_parameter_sets)){
            ml.model.selected$tsne <- rbind(ml.model.selected$tsne, get.tsne.coord.ml(phasespace$object, ml.model.name = input$load_ml.model, name = input$load_parameter_sets[i]))
          }
          ml.model.selected$tsne <-  ml.model.selected$tsne[order( ml.model.selected$tsne$pkey),]
        }
      }
      
      rm(temp.ml.model)
      local.importance$DF <- data.frame(pkey =  ml.model.selected$ml.model$pkey, t( ml.model.selected$ml.model$localImportance), stringsAsFactors = F)
      
    }else{
      ml.model.selected$name <- NULL
      ml.model.selected$ml.model <-NULL
      ml.model.selected$ml.model.res <-NULL
      ml.model.selected$train.data <- NULL
      ml.model.selected$test.data <- NULL
      ml.model.selected$custom.scale <- NULL
      ml.model.selected$mode <- NULL
      ml.model.selected$prm.sets.used <- NULL
      ml.model.selected$class.def <- NULL
      ml.model.selected$note <- NULL
      ml.model.selected$phenotype <-  NULL
      ml.model.selected$tsne <- NULL
      local.importance$DF <- NULL
      
    }
    
    
    if(!is.null(prm.sets.selected$original)){
      numPrm$prmset <- nrow(prm.ranges.selected$DF)
      parameters$prmset <- prm.ranges.selected$DF$names
    }else{
      numPrm$prmset <- NULL
      parameters$prmset <- NULL
    }
    
    if(!is.null(ml.model.selected$ml.model)){
      numPrm$ml.model <- nrow(ml.model.selected$ml.model$localImportance)
      parameters$ml.model <- row.names(ml.model.selected$ml.model$localImportance)
    }else{
      numPrm$ml.model <- NULL
      parameters$ml.model <- NULL
    }
    
    if(!is.null( ml.model.selected$custom.scale )){
      prm.ranges.z.selected$DF <- prm.ranges.z.selected$DF[,intersect(parameters$ml.model, parameters$prmset)]
      prm.ranges.z.selected$DF <- cbind(prm.ranges.z.selected$DF, apply(  ml.model.selected$custom.scale$values[,-1], 2, range))
    }else{}
    })
    
  })
  
  #####side bar
  phen.range <- reactiveValues()
  
  observeEvent(input$launch_exp_phase,{
    if(!is.null(phenotype.values.selected$DF)){
      phen.range$DF <- signif(range(phenotype.values.selected$DF[,2], na.rm = T),1)
      temp.range <- range(phenotype.values.selected$DF[,2],na.rm = T)
      
      if(phen.range$DF[1]>temp.range[1]){
        
      }
      
      if(phen.range$DF[2] < temp.range[2]){
        
      }
      
    }else{
      phen.range$DF <- NULL
    }
  })
  
  
  
  output$exp_phase_side_ui <- renderUI({
    if(!is.null(phen.range$DF) ){
      list(sliderInput("phen.range", label = h5("Range of phenotype"),
                       min = phen.range$DF[1] - (phen.range$DF[2]-phen.range$DF[1])*0.1, 
                       max = phen.range$DF[2] + (phen.range$DF[2]-phen.range$DF[1])*0.1, 
                       step = (phen.range$DF[2]-phen.range$DF[1])/500, 
                       value = c(phen.range$DF[1],phen.range$DF[2])),# min = -0.5, max = 1, step = 0.01, value = c(0.5, 1)),
           sliderInput("phen.mid.color", label = h5("Value of mid color"),
                       min = phen.range$DF[1], max = phen.range$DF[2], step = (phen.range$DF[2]-phen.range$DF[1])/500, value = (phen.range$DF[1] + phen.range$DF[2])/2),
           sliderInput("point.size", label = h5("Point Size"),
                       min = 0, max = 3, step = 0.1, value = 1),
           sliderInput("point.alpha", label = h5("Point Transparency"), 
                       min = 0, max = 1, step = 0.1, value = 0.5),
           uiOutput("cluster_phase_exp"),
           radioButtons(inputId = "point_sel", label = h5("Point Selection and Zoom-in"), choices = c("Single point selection", "Multiple points selection or zoom-in" ),inline = F)
           # verbatimTextOutput("info")
      )
    }else{
      list(
        sliderInput("point.size", label = h5("Point Size"),
                    min = 0, max = 2, step = 0.1, value = 1),
        sliderInput("point.alpha", label = h5("Point Transparency"), 
                    min = 0, max = 1, step = 0.1, value = 0.5)#,
        # verbatimTextOutput("info"))
      )
      
    }
    
  })
  
  output$tsne_ml_ui <- renderUI({
    if(!is.null(ml.model.selected$tsne)){
      checkboxInput("tsne_ml", h5("ML model-specific tSNE"))
    }
    
  })
  
  
  output$cluster_phase_exp <- renderUI({
    if(!is.null(hclust$locImp.row.cut)){
      list(checkboxInput("show_clusters_phase_exp", h5("LVI clusters")),
           uiOutput("cluster_select_input_ui")
      )
    }
  })
  
  output$cluster_select_input_ui<- renderUI({
    #if(input$show_clusters_phase_exp){
    list(
      selectInput("cluster_select_input", h5("Choose cluster(s)"),choices = c(1:input$num_clust),selected = c(1:input$num_clust)   ,multiple = TRUE)
      #actionButton("cluster_apply_tsne", h5("Apply!"))
    )
    #}
    
  })
  
  
  
  output$t_SNE <- renderPlot({
    ##progress indicator
    withProgress(message = 'This may take a while....', value = NULL, {
    #updating global variable
    
    if(!is.null(prm.sets.selected$tsne) ){
      
      if(isolate(input$load_phenotype) == "None"){
        ggdata <<- data.frame(prm.sets.selected$tsne, stringsAsFactors = F)
        names(ggdata) <<- c("pkey", "tSNE1","tSNE2")
        p1 = ggplot(ggdata, aes_string(x = "tSNE1", y = "tSNE2"))#, color = input$load_phenotype))
        p1 = p1+geom_point(size = input$point.size, alpha = input$point.alpha, color = "black") +# +scale_colour_gradient2(low="blue", high="red", midpoint = 0.4) + #labs(title =paste0( "tsne for original data"))  +
          #xlim(-30,30) +ylim(-30,30) +
          coord_cartesian(xlim = tsne_range$x, ylim = tsne_range$y, expand = FALSE) +
          theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
        p1
        
      } else {
        
        if(!is.null(ml.model.selected$tsne)){
          
          #model specific 
          if(input$tsne_ml){
            temp.pkey <- intersect(ml.model.selected$tsne$pkey, phenotype.values.selected$DF$pkey)
            #all.equal(as.character(prm.sets.selected$tsne$pkey[prm.sets.selected$tsne$pkey%in%temp.pkey]), phenotype.values.selected$DF$pkey[phenotype.values.selected$DF$pkey%in%temp.pkey],check.attributes = F) 
            temp.tsne <-ml.model.selected$tsne
            temp.phen.values <- phenotype.values.selected$DF
            
            temp.tsne <- temp.tsne[temp.tsne$pkey %in%temp.pkey,  ]
            temp.tsne <- temp.tsne[order(temp.tsne$pkey),  ]
            temp.phen.values <- temp.phen.values[temp.phen.values$pkey %in% temp.pkey, ]
            temp.phen.values <- temp.phen.values[order(temp.phen.values$pkey), ]
          }else{
            temp.pkey <- intersect(prm.sets.selected$tsne$pkey, phenotype.values.selected$DF$pkey)
            all.equal(as.character(prm.sets.selected$tsne$pkey[prm.sets.selected$tsne$pkey%in%temp.pkey]), phenotype.values.selected$DF$pkey[phenotype.values.selected$DF$pkey%in%temp.pkey],check.attributes = F) 
            temp.tsne <-prm.sets.selected$tsne
            temp.phen.values <- phenotype.values.selected$DF
            
            temp.tsne <- temp.tsne[temp.tsne$pkey %in%temp.pkey,  ]
            temp.tsne <- temp.tsne[order(temp.tsne$pkey),  ]
            temp.phen.values <- temp.phen.values[temp.phen.values$pkey %in% temp.pkey, ]
            temp.phen.values <- temp.phen.values[order(temp.phen.values$pkey), ]
          }
        }else{
          temp.pkey <- intersect(prm.sets.selected$tsne$pkey, phenotype.values.selected$DF$pkey)
          all.equal(as.character(prm.sets.selected$tsne$pkey[prm.sets.selected$tsne$pkey%in%temp.pkey]), phenotype.values.selected$DF$pkey[phenotype.values.selected$DF$pkey%in%temp.pkey],check.attributes = F) 
          temp.tsne <-prm.sets.selected$tsne
          temp.phen.values <- phenotype.values.selected$DF
          
          temp.tsne <- temp.tsne[temp.tsne$pkey %in%temp.pkey,  ]
          temp.tsne <- temp.tsne[order(temp.tsne$pkey),  ]
          temp.phen.values <- temp.phen.values[temp.phen.values$pkey %in% temp.pkey, ]
          temp.phen.values <- temp.phen.values[order(temp.phen.values$pkey), ]
          
        }
        
        
        ##show data only used in ML model trainig and test
        if(!is.null(ml.model.selected$ml.model) & input$within_ml.model == "All" ){
          phen.range$DF <- signif(range(temp.phen.values[,2], na.rm = T),1)
        }else if(!is.null(ml.model.selected$ml.model) & input$within_ml.model == "Training and test sets" ){
          if(ml.model.selected$train.data == "whole"){
          }else{
            temp.tsne <- temp.tsne[temp.tsne$pkey %in% c(ml.model.selected$train.data,ml.model.selected$test.data),  ]
            temp.tsne <- temp.tsne[order(temp.tsne$pkey),  ]
            temp.phen.values <- temp.phen.values[temp.phen.values$pkey %in% c(ml.model.selected$train.data,ml.model.selected$test.data), ]
            temp.phen.values <- temp.phen.values[order(temp.phen.values$pkey), ]
          }
          phen.range$DF <- signif(range(temp.phen.values[,2], na.rm = T),1)
        }else if(!is.null(ml.model.selected$ml.model) & input$within_ml.model == "Training set" ){
          if(ml.model.selected$train.data[1] == "whole"){
          }else{
            temp.tsne <- temp.tsne[temp.tsne$pkey %in% ml.model.selected$train.data,  ]
            temp.tsne <- temp.tsne[order(temp.tsne$pkey),  ]
            temp.phen.values <- temp.phen.values[temp.phen.values$pkey %in% ml.model.selected$train.data, ]
            temp.phen.values <- temp.phen.values[order(temp.phen.values$pkey), ]
          }
          phen.range$DF <- signif(range(temp.phen.values[,2], na.rm = T),1)
        }
        
        ggdata <<- data.frame(temp.tsne, temp.phen.values[,isolate(input$load_phenotype)], stringsAsFactors = F)
        
        temp.phenotype.name <- isolate(input$load_phenotype)
        
      

        names(ggdata) <<- c("pkey", "tSNE1","tSNE2", isolate(input$load_phenotype))
        ggdata <<- ggdata[ggdata[[isolate(input$load_phenotype)]] >= input$phen.range[1] & ggdata[[isolate(input$load_phenotype)]] < input$phen.range[2] , ]
        
        input$show_clusters_phase_exp
        if(isolate(is.null(hclust$locImp.row.cut))){
          p1 = ggplot(ggdata, aes_string(x = "tSNE1", y = "tSNE2", color = isolate(input$load_phenotype)))
          p1 = p1+geom_point(size = input$point.size, alpha = input$point.alpha) +scale_colour_gradient2(low="blue", high="red", midpoint = input$phen.mid.color) + #labs(title =paste0( "tsne for original data"))  +
            #xlim(-30,30) +ylim(-30,30) +
            coord_cartesian(xlim = tsne_range$x, ylim = tsne_range$y, expand = FALSE) +
            theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
          #label
          if(isolate(input$load_phenotype) == "mxmy.max"){
            p1 <- p1 + labs(color = "Corr(mx,my)")
          }else if(isolate(input$load_phenotype) == "fold.corr.ppp"){
            p1 <- p1 + labs(color = "FC")
          }else if(isolate(input$load_phenotype) == "fold.corr.pnp"){
            p1 <- p1 + labs(color = "FC")
          }else if(isolate(input$load_phenotype) == "q.factor"){
            p1 <- p1 + labs(color = "QF")
          }else if(isolate(input$load_phenotype) == "peak.freq"){
            p1 <- p1 + labs(color = "PF")
          }
          #selected point
          if(!is.null(selected$pkey)){
            p1 <- p1 + geom_point(data = ggdata[ggdata$pkey == selected$pkey,], aes_string(x = "tSNE1", y = "tSNE2"), color = 'black', size = 2)
          }
          p1
        }else{
          if(!input$show_clusters_phase_exp){
            p1 = ggplot(ggdata, aes_string(x = "tSNE1", y = "tSNE2", color = isolate(input$load_phenotype)))
            p1 = p1+geom_point(size = input$point.size, alpha = input$point.alpha) +scale_colour_gradient2(low="blue", high="red", midpoint = input$phen.mid.color) + #labs(title =paste0( "tsne for original data"))  +
              #xlim(-30,30) +ylim(-30,30) +
              coord_cartesian(xlim = tsne_range$x, ylim = tsne_range$y, expand = FALSE) +
              theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
            #label
            if(isolate(input$load_phenotype) == "mxmy.max"){
              p1 <- p1 + labs(color = "Corr(mx,my)")
            }else if(isolate(input$load_phenotype) == "fold.corr.ppp"){
              p1 <- p1 + labs(color = "FC")
            }else if(isolate(input$load_phenotype) == "fold.corr.pnp"){
              p1 <- p1 + labs(color = "FC")
            }else if(isolate(input$load_phenotype) == "q.factor"){
              p1 <- p1 + labs(color = "QF")
            }else if(isolate(input$load_phenotype) == "peak.freq"){
              p1 <- p1 + labs(color = "PF")
            }
            #selected point
            if(!is.null(selected$pkey)){
              p1 <- p1 + geom_point(data = ggdata[ggdata$pkey == selected$pkey,], aes_string(x = "tSNE1", y = "tSNE2"), color = 'black', size = 2)
            }
            p1
          }else{
            
            
            ggdata <<- ggdata[ggdata$pkey %in% intersect(ggdata$pkey, row.names(brush.points$loc.imp)),]
            ggdata <<- ggdata[order(ggdata$pkey),]
            temp.clust <- isolate(hclust$locImp.row.cut[row.names(brush.points$loc.imp) %in% intersect(ggdata$pkey, row.names(brush.points$loc.imp))])
            ggdata$cluster <<- as.factor(temp.clust)
            rm(temp.clust)
            ggdata <<- ggdata[ggdata$cluster %in% input$cluster_select_input ,]
            color.gradient = colorRampPalette(c("blue", "green","yellow","red"))
            
            p1 = ggplot(ggdata, aes_string(x = "tSNE1", y = "tSNE2", color = "cluster"))
            p1 = p1+geom_point(size = input$point.size, alpha = input$point.alpha) + scale_colour_manual(values =color.gradient(isolate(input$num_clust))[as.numeric(input$cluster_select_input)[order(as.numeric(input$cluster_select_input))]] )+ #labs(title =paste0( "PNP t_SNE plot with var imp clusters")) + #labs(title =paste0( "tsne for original data"))  +
              #xlim(-30,30) +ylim(-30,30) +
              coord_cartesian(xlim = tsne_range$x, ylim = tsne_range$y, expand = FALSE) +
              theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
            p1
            
          }
        }
        
        
      } 
    }
    })
  })
  
  
  
  ##zoom-in
  ##brush and double click
  observeEvent(input$tsne_dblclick,{
    brush <- input$tsne_brush
    if(!is.null(brush)){
      tsne_range$x = c(brush$xmin,brush$xmax)
      tsne_range$y = c(brush$ymin,brush$ymax)
    }else{
      tsne_range$x = c(-30,30)
      tsne_range$y = c(-30,30)
    }
  })
  
  
  ##specifying parameter ranges
  # prm.z.ranges = matrix(NA, nrow = 2, ncol = numPrm$ml.model )
  # colnames(prm.z.ranges) = parameters$ml.model
  # for(i in 2:(numPrm$ml.model+1)){
  #   prm.z.ranges[1,i-1] = signif(min(data.clust.z.combined[,i]), 4)
  #   prm.z.ranges[2,i-1] = signif(max(data.clust.z.combined[,i]), 4)
  # }
  # 
  # 
  
  ##point-select
  selected = reactiveValues()
  
  
  
  observeEvent(input$tsne_click,{
    
    if(input$point_sel == "Single point selection"){
    
      selected_temp = nearPoints(ggdata, input$tsne_click,  maxpoints = 1, xvar = "tSNE1", yvar = "tSNE2")
      selected_pkey = selected_temp$pkey
      
      
      if(nrow(selected_temp) !=0){
        selected$pkey = selected_pkey
        selected$point <- data.frame(Parameter = parameters$prmset,
                                     Rescaled = t(prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey == selected_pkey, -1]),
                                     Original = t(prm.sets.selected$original[prm.sets.selected$original$pkey == selected_pkey, -1]), stringsAsFactors = F)
        names(selected$point) <- c("parameter", "rescaled", "original")
        
        if(!is.null(ml.model.selected$custom.scale)){
          temp.prms <- c(intersect(parameters$ml.model, parameters$prmset), setdiff(parameters$ml.model, parameters$prmset))
          selected$point.custom.scale <- t(prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey == selected_pkey, -1])[intersect(parameters$ml.model, parameters$prmset),]
          if(any(ml.model.selected$custom.scale$values$pkey == selected_pkey)){
            selected$point.custom.scale <- as.numeric(append(selected$point.custom.scale, t(ml.model.selected$custom.scale$values[ml.model.selected$custom.scale$values$pkey == selected_pkey,])[ setdiff(parameters$ml.model, parameters$prmset),]  ))
            names(selected$point.custom.scale) <- temp.prms
          }else{
            temp.cs.func <- get.custom.scale.func.obj(phasespace$object, ml.model.selected$custom.scale$name)
            selected$point.custom.scale  <- as.numeric(append(selected$point.custom.scale, 
                                                              t(temp.cs.func(prm.combs = prm.sets.selected$original[prm.sets.selected$original$pkey == selected_pkey,],
                                                                             other.vals = ml.model.selected$custom.scale$other.vals,
                                                                             cs.to.org = F))[ setdiff(parameters$ml.model, parameters$prmset),]
            ))
            names(selected$point.custom.scale) <- temp.prms
            
          }
          
          
        }else{
          selected$point.custom.scale <- NULL
        }
        
      }else {
        selected$pkey <- NULL
        selected$point <- NULL
        selected$point.custom.scale <- NULL
      }
    }
  })
  
  observeEvent(input$tsne_manual_pt_select,{
    #selected_temp = nearPoints(ggdata, input$tsne_click,  maxpoints = 1)
    selected_pkey = input$tsne_manual_pt_select
    
    
    if(selected_pkey %in% prm.sets.selected$original$pkey){
      selected$pkey = selected_pkey
      selected$point <- data.frame(Parameter = parameters$prmset,
                                   Rescaled = t(prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey == selected_pkey, -1]),
                                   Original = t(prm.sets.selected$original[prm.sets.selected$original$pkey == selected_pkey, -1]), stringsAsFactors = F)
      names(selected$point) <- c("parameter", "rescaled", "original")
      
      if(!is.null(ml.model.selected$custom.scale)){
        temp.prms <- c(intersect(parameters$ml.model, parameters$prmset), setdiff(parameters$ml.model, parameters$prmset))
        selected$point.custom.scale <- t(prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey == selected_pkey, -1])[intersect(parameters$ml.model, parameters$prmset),]
        if(any(ml.model.selected$custom.scale$values$pkey == selected_pkey)){
          selected$point.custom.scale <- as.numeric(append(selected$point.custom.scale, t(ml.model.selected$custom.scale$values[ml.model.selected$custom.scale$values$pkey == selected_pkey,])[ setdiff(parameters$ml.model, parameters$prmset),]  ))
          names(selected$point.custom.scale) <- temp.prms
        }else{
          temp.cs.func <- get.custom.scale.func.obj(phasespace$object, ml.model.selected$custom.scale$name)
          selected$point.custom.scale  <- as.numeric(append(selected$point.custom.scale, 
                                                            t(temp.cs.func(prm.combs = prm.sets.selected$original[prm.sets.selected$original$pkey == selected_pkey,],
                                                                           other.vals = ml.model.selected$custom.scale$other.vals,
                                                                           cs.to.org = F))[ setdiff(parameters$ml.model, parameters$prmset),]
          ))
          names(selected$point.custom.scale) <- temp.prms
          
        }
        
        
      }else{
        selected$point.custom.scale <- NULL
      }
      
    }else {
      selected$pkey <- NULL
      selected$point <- NULL
      selected$point.custom.scale <- NULL
    }
  })
  # output$info <- renderPrint({
  #   #nearPoints(ggdata, input$tsne_click,  maxpoints = 1)$pkey
  #   cat(selected$pkey)
  # })
  
  ## output of selected point
  
  output$selected_point_ui <- renderUI({
    if(!is.null(selected$point)){
      list(h4("Selected point"),
           verbatimTextOutput("selected_pkey_exp_phase_tab"),
           wellPanel(id = "tPanel",
                     style = "overflow-x:scroll",
                     tableOutput("parmeter_values"))
      )
    }
  })
  
  
  ##Further Info for selected ML model
  # output$further_info_ml_model_button_ui <- renderUI({
  #   if(!is.null(ml.model.selected$ml.model)){
  #     actionButton("further_info_ml_model_button",h5("Further info for selected ML model"))
  #   }
  # })
  
  output$further_info_ml_model_ui <- renderUI({
    # if(!is.null(input$further_info_ml_model_button)){
      # if(input$further_info_ml_model_button[[1]]%%2 == 0  ){
      #   return()
      # }else{
    if(!is.null(ml.model.selected$ml.model)){
      if((ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression") ){
        bsCollapsePanel(h4("Further Info for ML model"), style = "primary",
                        tabBox(id = "selection_ml_phase_exp", selected = NULL, width = 12, #type = "pills",
                               tabPanel("Info of trained ML model", value = "tab_info_ml",
                                        fluidRow(
                                          column(6,
                                               plotOutput("performance_phase_exp")
                                        
                                               )
                                        )
                                        # column(6,
                                        #        plotOutput("varImp_phase_exp")
                                        # )
                                        
                               ),
                               
                               tabPanel("Prediction performance", value = "tab_pred_perform",
                                        fluidRow(
                                          column(3,
                                                 uiOutput("options_bias_pred_phase_exp_ui")
                                          ),
                                          column(9,
                                                 uiOutput("OOB_test_pred_phase_exp_ui")
                                          )
                                        )
                               )
                                        
                        )
        )
      }else if(ml.model.selected$mode == "class" | ml.model.selected$mode == "classification"){
        bsCollapsePanel(h4("Further Info for ML model"), style = "primary",
                        tabBox(id = "selection_ml_phase_exp", selected = NULL, width = 12, #type = "pills",
                               tabPanel("Info of trained ML model", value = "tab_info_ml",
                                        fluidRow(
                                          column(6,
                                                 plotOutput("performance_phase_exp")
                                          )
                                          # column(6,
                                          #        plotOutput("varImp_phase_exp")
                                          # )
                                        )
                                        
                               ),
                               
                               tabPanel("Prediction performance", value = "tab_pred_perform",
                                        fluidRow(
                                          column(6,
                                                 uiOutput("options_bias_pred_phase_exp_ui")
                                          ),
                                          column(6,
                                                 uiOutput("OOB_test_pred_phase_exp_ui")
                                          )
                                        )
                               )
                        )
        )
      }
    }
      # }
    # }else{return()}
  })
  
  output$selected_pkey_exp_phase_tab <- renderText({
    selected$pkey
  })
  output$parmeter_values <- renderTable({
    if(!is.null(selected$point)){
      temp.point <- data.frame(Parameter = c("Original", "Scaled"),
                               stringsAsFactors = F)
      temp.point <- cbind(temp.point,t(selected$point[,c(3,2)]))
      return( temp.point)
      
    }
    
  },
  align = "c", spacing = "xs", digits = 3
  )
  
  ##Further Info for ML model detailed codes
  output$performance_phase_exp <- renderPlot({
    if(!is.null(ml.model.selected$ml.model)){
      if(ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression"){
        temp.main <- "Error rates for regression ML model"
      }else{
        temp.main <- "Error rates for classification ML model"
      }
      plot(ml.model.selected$ml.model, main = temp.main)
    }
  })
  
  output$varImp_phase_exp <- renderPlot({
    if(!is.null(ml.model.selected$ml.model)){
      varImpPlot(ml.model.selected$ml.model,  main = paste0(ml.model.selected$name,": Global Variable Importance"), scale = F)
    }
  })
  
  
  output$options_bias_pred_phase_exp_ui <- renderUI({
    if(!is.null(ml.model.selected$ml.model)){
      if((ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression") & !is.null(ml.model.selected$ml.model.res)){
        list(checkboxInput("plot_bias_corr_phase_exp","Bias correction"),
            radioButtons("oob_test_phase_exp", label= NULL ,choices = c("OOB", "Test set"), inline = T ) ## for test sets
        )
      }else if((ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression") & is.null(ml.model.selected$ml.model.res)){
        radioButtons("oob_test_phase_exp", label= NULL ,choices = c("OOB", "Test set"), inline = T ) ## for test sets
      }else if(ml.model.selected$mode == "class" | ml.model.selected$mode == "classification"){
        list(
          fluidRow(
            column(6, radioButtons("oob_test_phase_exp", label= h5("Prediction for") ,choices = c(OOB = "OOB", 'Test set' = "test.set"), inline = FALSE )),## for test sets
            # column(6, selectInput("confusion_roc", label = h5("Choose display mode"), choices = c("Text", "Plot") ))
            column(6, selectInput("positive_class_phase_exp", label = h5("Positive class"), choices = ml.model.selected$class.def$info$Class))
          ),
          fluidRow(
            column(6, sliderInput("pred_cut_off_phase_exp", h5("Cut-off"), min = 0, max = 1, step = 0.01, value = 0.5))
          ),
          fluidRow(
            column(6,style='padding-left:0px;',
                   h5("Confusion matrix"),
                   tableOutput("conf_mat_phase_exp")),
            column(5,offset = 1,
                   tableOutput("conf_stats_phase_exp"))
          )
        )
      }
    }
  })  
  
  
  output$conf_mat_phase_exp<- renderTable({
    
    temp.table  <-  ml.model.selected$class.def$pred.perform[[input$oob_test_phase_exp]][[input$positive_class_phase_exp]]$conf.mat[[(input$pred_cut_off_phase_exp*100+1)]]$table 
    temp.df <- data.frame(pred_ref = row.names( temp.table),  temp.table[,1],  temp.table[,2])
    row.names(temp.df) <- NULL
    colnames(temp.df)[2:3] <- row.names( temp.table)
    return(temp.df)
  },rownames = F,align = "c")
  
  output$conf_stats_phase_exp<- renderTable({
    temp.conf.mat <- ml.model.selected$class.def$pred.perform[[input$oob_test_phase_exp]][[input$positive_class_phase_exp]]$conf.mat[[(input$pred_cut_off_phase_exp*100+1)]]
    temp.df <- temp.conf.mat$byClass[1:4]
    temp.df <- append( temp.df, c(temp.conf.mat$overall[1], temp.conf.mat$byClass[11]))
    temp.df <- data.frame(temp.df)
    return(temp.df)
  },align = "c", colnames = F, rownames = T)
  
  
  
  output$OOB_test_pred_phase_exp_ui <-renderUI({
    if(!is.null(ml.model.selected$ml.model)){
      if(ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression"){
        if(input$oob_test_phase_exp == "OOB"){
          column(8,plotOutput("OOB_prediction_phase_exp"))
        }else if(input$oob_test_phase_exp != "OOB" & (!is.null(ml.model.selected$test.data) & length(ml.model.selected$test.data) != 0)){
          column(8,plotOutput("test_set_prediction_phase_exp"))
        }
      }else if (ml.model.selected$mode == "class" | ml.model.selected$mode == "classification"){
        list(
          plotOutput("prediction_roc_plot_class_phase_exp"),
          plotOutput("prediction_pr_plot_class_phase_exp")#, style = "padding:0px; margin:0px")
        )
      }
    }
  })
  
  
  output$prediction_roc_plot_class_phase_exp <- renderPlot({
    plot(ml.model.selected$class.def$pred.perform[[input$oob_test_phase_exp]][[input$positive_class_phase_exp]]$roc,  type= "b", main = "ROC", xlab = "False Positive", ylab = "True Positive", col= colfunc(101), pch = 19, xlim = c(0,1), ylim=c(0,1))
    points(t(ml.model.selected$class.def$pred.perform[[input$oob_test_phase_exp]][[input$positive_class_phase_exp]]$roc[(input$pred_cut_off_phase_exp*100+1),1:2]))
  })
  
  output$prediction_pr_plot_class_phase_exp <- renderPlot({
    plot(ml.model.selected$class.def$pred.perform[[input$oob_test_phase_exp]][[input$positive_class_phase_exp]]$prec.recall, type= "b", main = "Precision-Recall", xlab = "Recall", ylab = "Precision", col= colfunc(101), pch = 19, xlim = c(0,1), ylim=c(0,1))
    points(t(ml.model.selected$class.def$pred.perform[[input$oob_test_phase_exp]][[input$positive_class_phase_exp]]$prec.recall[(input$pred_cut_off_phase_exp*100+1),1:2]))
  })
  
  
  
  
  
  
  
  
  ##regression
  output$OOB_prediction_phase_exp <- renderPlot({
    if(is.null( ml.model.selected$ml.model) & is.null( ml.model.selected$ml.model.res) ){
      return()
    }else if(!is.null( ml.model.selected$ml.model) & is.null( ml.model.selected$ml.model.res) ){
      df <- data.frame(x = ml.model.selected$ml.model$y, y = ml.model.selected$ml.model$predicted )
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) +ylim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) + ggtitle(paste0("OOB Pred VS Sim: corr = ", signif(cor( ml.model.selected$ml.model$y, ml.model.selected$ml.model$predicted ,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("OOB Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }else if(!is.null( ml.model.selected$ml.model) & !is.null( ml.model.selected$ml.model.res) & input$plot_bias_corr_phase_exp == FALSE){
      df <- data.frame(x = ml.model.selected$ml.model$y, y = ml.model.selected$ml.model$predicted )
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) +ylim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) + ggtitle(paste0("OOB Pred VS Sim: corr = ", signif(cor( ml.model.selected$ml.model$y, ml.model.selected$ml.model$predicted ,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("OOB Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }else if(!is.null( ml.model.selected$ml.model) & input$plot_bias_corr_phase_exp == TRUE){
      df <- data.frame(x = ml.model.selected$ml.model$y, y = ml.model.selected$ml.model$predicted -ml.model.selected$ml.model.res$predicted)
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) +ylim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) + ggtitle(paste0("OOB Pred VS Sim: corr = ", signif(cor( ml.model.selected$ml.model$y, ml.model.selected$ml.model$predicted -ml.model.selected$ml.model.res$predicted ,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("OOB Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }
  })
  
  output$test_set_prediction_phase_exp <- renderPlot({
    input$oob_test_phase_exp
    isolate({
      ##load selected parameter sets
      temp.prm.ranges.names <- get.prm.ranges.name(object = phasespace$object)
      temp.prm.names.init <- get.init.prm.combs.name(object = phasespace$object)
      temp.prm.names.addit <- get.addit.prm.combs.name(object = phasespace$object)
      prm.sets.test.original <- data.frame(stringsAsFactors = F)
      prm.sets.test.rescaled <- data.frame(stringsAsFactors = F)
      
      for(i in 1:length(ml.model.selected$prm.sets.used)){
        ##to obtain corresponding parameter ranges for selected initial parameter space
        if(any(unlist( temp.prm.names.init) ==ml.model.selected$prm.sets.used[i]) ){
          temp.idx <- unlist(
            apply(matrix(temp.prm.ranges.names), 1,
                  function(name, prm.names, input.name){
                    any(prm.names[[name]] == input.name) }, 
                  prm.names = temp.prm.names.init, input.name = ml.model.selected$prm.sets.used[i])
          )
          temp.range.name <- temp.prm.ranges.names[temp.idx]
          temp.prm.combs <- get.init.prm.combs(phasespace$object,ml.model.selected$prm.sets.used[i], temp.range.name )
          
          
          prm.sets.test.original  <-rbind( prm.sets.test.original , temp.prm.combs$prm.combs )
          prm.sets.test.rescaled <-rbind(prm.sets.test.rescaled, temp.prm.combs$prm.combs.z )
          temp.prm.combs <- NULL
          
        }else{
          ##to obtain corresponding parameter ranges and inital parameter set for selected additional parameter space
          temp.idx <- unlist(
            apply(matrix(temp.prm.ranges.names), 1,
                  function(name, prm.names, input.name){
                    any(unlist(prm.names[[name]]) == input.name) }, 
                  prm.names = temp.prm.names.addit, input.name = ml.model.selected$prm.sets.used[i])
          )
          temp.range.name <- temp.prm.ranges.names[temp.idx]
          temp.idx <- unlist(
            apply(matrix(unlist(temp.prm.names.init)), 1,
                  function(name, prm.range.name, prm.names, input.name){
                    any(prm.names[[ prm.range.name]][[name]] == input.name) }, 
                  prm.range.name = temp.range.name, prm.names = temp.prm.names.addit, input.name = ml.model.selected$prm.sets.used[i])
          )
          temp.prm.name.init <- unlist(temp.prm.names.init)[temp.idx]
          
          temp.prm.combs <- get.addit.prm.combs(phasespace$object,ml.model.selected$prm.sets.used[i], temp.range.name,temp.prm.name.init )
          temp.prm.combs.init <- get.init.prm.combs(phasespace$object, temp.prm.name.init, temp.range.name )
          
          prm.sets.test.original  <-rbind( prm.sets.test.original , temp.prm.combs$prm.combs )
          prm.sets.test.rescaled <-rbind( prm.sets.test.rescaled, temp.prm.combs$prm.combs.z )
          temp.prm.combs <- NULL
          temp.prm.combs.init <- NULL
          
        }
      }
      prm.sets.test.original<- prm.sets.test.original[order(prm.sets.test.original$pkey),] 
      prm.sets.test.rescaled <- prm.sets.test.rescaled[order(prm.sets.test.rescaled$pkey),]
      
      prm.sets.test.original<- prm.sets.test.original[prm.sets.test.original$pkey %in% ml.model.selected$test.data,] 
      prm.sets.test.rescaled <- prm.sets.test.rescaled[prm.sets.test.rescaled$pkey  %in% ml.model.selected$test.data ,]
      
      ##load phenotype values
      phenotype.values.test <-data.frame(stringsAsFactors = F)
      phenotype.loaded.ml.list <- get.phenotypes(phasespace$object, ml.model.selected$phenotype)
      for(temp.name in ml.model.selected$prm.sets.used){
        phenotype.values.test <- rbind(phenotype.values.test, phenotype.loaded.ml.list[[temp.name]])
      }
      phenotype.values.test <- phenotype.values.test[order(phenotype.values.test$pkey),]
      phenotype.values.test <- phenotype.values.test[phenotype.values.test$pkey %in% ml.model.selected$test.data,]
      
      if(!is.null(ml.model.selected$custom.scale)){
        prm.sets.test.rescaled <- cbind(prm.sets.test.rescaled, ml.model.selected$custom.scale$values[ ml.model.selected$custom.scale$values$pkey %in%  ml.model.selected$test.data,names(ml.model.selected$custom.scale$parameters)])
      }
      
    })
    
    if(is.null( ml.model.selected$ml.model) & is.null( ml.model.selected$ml.model.res) ){
      return()
    }else if(!is.null( ml.model.selected$ml.model) & is.null( ml.model.selected$ml.model.res) ){
      df <- data.frame(x = phenotype.values.test[,-1], y = predict(ml.model.selected$ml.model,prm.sets.test.rescaled[,-1]))
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) +ylim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) + ggtitle(paste0("Test set Pred VS Sim: corr = ", signif(cor( df$x, df$y,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("OOB Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }else if(!is.null( ml.model.selected$ml.model) & !is.null( ml.model.selected$ml.model.res) & input$plot_bias_corr_phase_exp == FALSE){
      df <- data.frame(x = phenotype.values.test[,-1], y = predict(ml.model.selected$ml.model,prm.sets.test.rescaled[,-1]) )
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) +ylim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) + ggtitle(paste0("Test set VS Sim: corr = ", signif(cor( df$x, df$y ,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("OOB Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }else if(!is.null( ml.model.selected$ml.model) & input$plot_bias_corr_phase_exp == TRUE){
      df <- data.frame(x = phenotype.values.test[,-1], y = predict(ml.model.selected$ml.model,prm.sets.test.rescaled[,-1]) -  predict(ml.model.selected$ml.model.res,prm.sets.test.rescaled[,-1]) )
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) +ylim(min(ml.model.selected$ml.model$y),max(ml.model.selected$ml.model$y)) + ggtitle(paste0("Test set VS Sim: corr = ", signif(cor(df$x, df$y,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulated      ") + ylab("OOB Predicted     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }
  })
  
  
  ######
  
  
  
  ##automatic generation of sliders
  output$parameters <- renderUI({
    if(!is.null(numPrm$ml.model)){
      prmInput = vector("list", numPrm$ml.model)
      for(i in 1:numPrm$ml.model){
        prmInput[[i]] <- list(sliderInput(paste0("prm",i),
                                          parameters$ml.model[i],
                                          min = signif(min(prm.sets.selected$rescaled[,2:(numPrm$ml.model+1)]),3),
                                          max = signif(max(prm.sets.selected$rescaled[,2:(numPrm$ml.model+1)]),3),
                                          value = 0, step =.01))
      }
      return(prmInput)
    }
  })
  
  
  #Variable importance
  library(gridExtra)
  output$global_varImp <- renderPlot({
    if(!is.null( ml.model.selected$ml.model)){
      imp = importance( ml.model.selected$ml.model, scale = F)
      ggdata.imp = data.frame( imp)
      
      if(ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression"){
        ggdata.imp$names = factor(row.names(imp), levels=row.names(ggdata.imp)[order(ggdata.imp$X.IncMSE)])
        p1 = ggplot(data=ggdata.imp[order(ggdata.imp$X.IncMSE, decreasing = T),], aes(x =names , y =  X.IncMSE))
        p1 = p1+geom_point(size = 2, color= "black", stat = "identity") + xlab("") + ylab("")+ labs(title =paste0( "Permutation importance")) +
          theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
      }else{
        ggdata.imp$names = factor(row.names(imp), levels=row.names(ggdata.imp)[order(ggdata.imp$MeanDecreaseAccuracy)])
        p1 = ggplot(data=ggdata.imp[order(ggdata.imp$MeanDecreaseAccuracy, decreasing = T),], aes(x =names , y =  MeanDecreaseAccuracy))
        p1 = p1+geom_point(size = 2, color= "black", stat = "identity") + xlab("") + ylab("")+ labs(title =paste0( "Permutation importance")) +
          theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
      }
      
      ggdata.imp = data.frame( imp)
      if(ml.model.selected$mode == "reg" | ml.model.selected$mode == "regression"){
        ggdata.imp$names = factor(row.names(imp), levels=row.names(ggdata.imp)[order(ggdata.imp$IncNodePurity)])
        p2 = ggplot(data=ggdata.imp[order(ggdata.imp$IncNodePurity, decreasing = T),], aes(x =names , y =IncNodePurity ))
        p2 = p2+geom_point(size = 2, color= "black", stat = "identity")+ xlab("") + ylab("") + labs(title =paste0( "Impurity Importance")) +
          theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
      }else{
        ggdata.imp$names = factor(row.names(imp), levels=row.names(ggdata.imp)[order(ggdata.imp$MeanDecreaseGini)])
        p2 = ggplot(data=ggdata.imp[order(ggdata.imp$MeanDecreaseGini, decreasing = T),], aes(x =names , y = MeanDecreaseGini ))
        p2 = p2+geom_point(size = 2, color= "black", stat = "identity")+ xlab("") + ylab("") + labs(title =paste0( "Impurity Importance")) +
          theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
      }
      grid.arrange(p1,p2, ncol = 2, nrow =1)
    }
    
  })
  
  #local.imp.combined = data.frame(pkey = data.clust.z.combined$pkey, t(rf.two.gene.combined.bc$localImportance))
  
  output$local_varImp <- renderPlot({
    if(!is.null(selected$pkey) && !is.null(ml.model.selected$ml.model)){
      #rf.two.gene.combined$localImportance[order(rf.two.gene.combined$localImportance[,1027], decreasing = TRUE),1027]
      idx.pt = which(local.importance$DF$pkey == selected$pkey)
      if(length(idx.pt) != 0){
        ggdata.imp = data.frame( imp = as.numeric(t(local.importance$DF[idx.pt ,-1])))
        ggdata.imp$names = colnames(local.importance$DF)[-1]
        ggdata.imp = ggdata.imp[order(ggdata.imp$imp),]
        ggdata.imp$names = factor(ggdata.imp$names, levels=ggdata.imp$names)
        p1 = ggplot(data=ggdata.imp, aes(x =names , y =  imp))
        p1 = p1+geom_point(size = 2, color= "black", stat = "identity") + xlab("Parameters") + ylab("Avg. increase in squared OOB residuals")+ labs(title = selected$pkey) +
          theme_bw() + theme(axis.text=element_text(size=10, face = "bold"), axis.title=element_text(size=10,face="bold")) +coord_flip()
        p1
      }else{
        return(0)
      }
    }
  })
  
  
  
  #perturbation
  
  #validation parameter combinations
  prm.combs.val.z <- reactiveValues()
  prm.combs.val <- reactiveValues()
  
  
  
  output$parameter_choice1 <- renderUI({
    selectInput(inputId = "parameter_choice1",
                label = h5("First parameter:"),
                choices = parameters$ml.model, selected = parameters$ml.model[1])
  })
  
  output$parameter_choice2 <- renderUI({
    selectInput(inputId = "parameter_choice2",
                label = h5("Second parameter:"),
                choices = parameters$ml.model, selected = parameters$ml.model[1])
  })
  
  output$plot_range_ui <- renderUI({
    if(!is.null(ml.model.selected$ml.model)){
      if(ml.model.selected$ml.model$type == "regression"){
        list(
          sliderInput("plot_range", label = h5("Range of phenotype"),
                      min = phen.range$DF[1] - (phen.range$DF[2]-phen.range$DF[1])*0.1, 
                      max = phen.range$DF[2] + (phen.range$DF[2]-phen.range$DF[1])*0.1, 
                      step = (phen.range$DF[2]-phen.range$DF[1])/500, 
                      value = c(phen.range$DF[1],phen.range$DF[2]))
        )
      }else{
        list(
          selectInput("pred_type_exp", label = h5("Prediction type"), choices = c("Probability", "Binary")),
          uiOutput("cut_off_exp_ui"),
          selectInput("posit_class_exp", label = h5("Positive class"), choices = ml.model.selected$class.def$info$Class)
        )
      }
    }
    
    
  })
  
  output$cut_off_exp_ui <- renderUI({
    if(!is.null(input$pred_type_exp) & input$pred_type_exp == "Binary"){
      sliderInput("cut_off_exp", label = h5("Cut-off"),
                  min =0, max = 1, step = 0.01, value = 0.5)
    }
    
  })
  
  
  
  ##generate a plot only when a point is selected and two selected parameters are different.
  observeEvent(input$plot_gen,{
    if(!is.null(selected$pkey)){
      if(!is.null(ml.model.selected$ml.model) & is.null(ml.model.selected$custom.scale)){
        selected$point.perturbed <- t(selected$point[parameters$ml.model,"rescaled"])
        colnames( selected$point.perturbed) <- parameters$ml.model
      }else if(!is.null(ml.model.selected$ml.model) & !is.null(ml.model.selected$custom.scale)){
        selected$point.perturbed <- t(selected$point.custom.scale[parameters$ml.model])
        colnames( selected$point.perturbed) <- parameters$ml.model
      }else if(is.null(ml.model.selected$ml.model)){
        selected$point.perturbed <- NULL
      }
      
      if(input$parameter_choice1 == input$parameter_choice2  ){
        showModal(modalDialog(
          title = "Alert!",
          paste0("Please select different paramters."),
          easyClose = TRUE
        ))
      }
      
    }else{
      showModal(modalDialog(
        title = "Alert!",
        paste0("No point selected! Please select a point."),
        easyClose = TRUE
      ))
    }
    
  })
  
  #plot_counter <- reactiveValues()
  
  output$perturb_plot <- renderUI({
    
    input$plot_gen
    ##check if a point selected
    if(!is.null(selected$pkey)){
      ##progress indicator
      
      withProgress(message = 'This may take a while...', value = NULL, {
      isolate(if( !is.null(ml.model.selected$ml.model)){
        #plot_counter$count <- 1
        if(input$plot_type == "2D"){
          return(plotOutput("perturb_plot_2d",height = "450px", width = "450px"))
        } else if(input$plot_type == "3D"){
          return(rglwidgetOutput("perturb_plot_3d",height = "450px", width = "450px"))
        }
      })
      })
    }else{
     
    }
  })
  
  output$perturb_plot_2d <- renderPlot({
    input$plot_gen
    
    isolate(if( !is.null(ml.model.selected$ml.model) && input$plot_type == "2D"){
      if(is.null(input$parameter_choice1) | is.null(input$parameter_choice2)  ){
       
        return()
      }else if((input$parameter_choice1 != input$parameter_choice2) & ((nrow(nearPoints(ggdata, input$tsne_click,  maxpoints = 1, xvar = "tSNE1", yvar = "tSNE2")) != 0) | !is.null(selected$pkey))){
        ##progress indicator
        withProgress(message = 'This may take a while...', value = NULL, {
        
        
        prm.combs.val.z$DF <- vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res, selected$point.perturbed,
                                               c(input$parameter_choice1, input$parameter_choice2),prm.ranges.z.selected$DF[,parameters$ml.model], grid.lines = input$num_grids_val, zoom = 1, zlim = c(input$plot_range[1],input$plot_range[2]), gap = 0 , three.dim = F, posit.class = input$posit_class_exp,
                                               pred.type = input$pred_type_exp, cut.off = input$cut_off_exp)
        prm.combs.val.z$pkey = selected$pkey
        prm.combs.val.z$prm.comb.selected.rescaled = selected$point$rescaled
        prm.combs.val.z$prm.comb.selected.original = selected$point$original
        names(prm.combs.val.z$prm.comb.selected.rescaled) <-  selected$point$parameter
        names(prm.combs.val.z$prm.comb.selected.original) <-  selected$point$parameter
        #print( selected$point$original )
        })
        
      }
      
      
    })
    
    
  })
  
  output$perturb_plot_3d <- renderRglwidget({
    
    input$plot_gen
    isolate({if( !is.null(ml.model.selected$ml.model) && input$plot_type == "3D"){
      if(is.null(input$parameter_choice1) |is.null(input$parameter_choice2)  ){
       
        return()
      }else if((input$parameter_choice1 != input$parameter_choice2) & ((nrow(nearPoints(ggdata, input$tsne_click,  maxpoints = 1, xvar = "tSNE1", yvar = "tSNE2")) != 0) | !is.null(selected$pkey))){
        ##progress indicator
        withProgress(message = 'This may take a while...', value = NULL, {
        try(rgl.close(), silent = TRUE)
        prm.combs.val.z$DF <-  vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,selected$point.perturbed,
                                                c(input$parameter_choice1, input$parameter_choice2),prm.ranges.z.selected$DF[,parameters$ml.model], grid.lines =input$num_grids_val, zoom = 1, zlim =  c(input$plot_range[1],input$plot_range[2]), gap = 0 , three.dim = T, posit.class = input$posit_class_exp,
                                                pred.type = input$pred_type_exp, cut.off = input$cut_off_exp)
        prm.combs.val.z$pkey = selected$pkey
        
        prm.combs.val.z$prm.comb.selected.rescaled = selected$point$rescaled
        prm.combs.val.z$prm.comb.selected.original = selected$point$original
        names(prm.combs.val.z$prm.comb.selected.rescaled) <-  selected$point$parameter
        names(prm.combs.val.z$prm.comb.selected.original) <-  selected$point$parameter
        
        scene1<- scene3d()
        rglwidget(scene1)
        })
        
      }
    }})
  })
  
  
  output$gen_prm_combs_val_ui <- renderUI(
    if(!is.null(prm.combs.val.z$DF)){
      list(br(),
           h4("Generate validation parameter combinations"),
           
           
           HTML("<div class='myHeader2' style='color:blue'><span><h5>Assign parameter keys (click here to view)</h5></span></div>"),
           HTML("<div class='myContent2' style='display:none;padding:5px;'>"),
           p("Parameter keys have a form of (Current date)_(digits of capital letters). Ex) 042015_AAACEZGP. A recommandation for digits is to start with AAAAAAAA."),
           HTML("</div>"),
           #toggle text
           HTML('<script>
                $(".myHeader2").click(function () {

                $header = $(this);
                //getting the next element
                $content = $header.next();
                //open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
                $content.slideToggle(200, function () {
                //execute this after slideToggle is done
                //change text of header based on visibility of content div
                $header.text(function () {
                //change text based on condition
                return $content.is(":visible") ? "Assign parameter keys (click here to collapse)" : "Assign parameter keys (click here to view)";
                });
                });

                }); </script>'),
           fluidRow(
             column(4,dateInput("pkey_date_val", label = h5("Current date"), format = "mmddyyyy")),
             column(4,textInput("pkey_digits_val", label = h5("Starting digit")))
           ),
           
           uiOutput("gen_prm_combs_val_action_ui"),
           br(),
           DT::dataTableOutput("prm_combs_val"),
           br(),
           uiOutput("save_prm_combs_val_ui")
           )
      
    }
  )
  
  output$gen_prm_combs_val_action_ui <-renderUI({
    if(!is.null(input$pkey_digits_val) & input$pkey_digits_val != ""){
      actionButton("gen_prm_combs_val", "Generate!")
    }
  })
  
  observeEvent(input$gen_prm_combs_val,{
    
    
    ##1.generate parameter keys (convention: date + "_" + 8 digit LETTER barcodes)
    let.to.num = c(0:25)
    names(let.to.num) = LETTERS
    p.index = as.numeric(let.to.num[strsplit(input$pkey_digits_val,"")[[1]]])
    temp.date = input$pkey_date_val
    temp.date = format(temp.date, "%m%d%Y")
    temp.date = as.character(temp.date)
    temp.pkey = gen_prm_keys(input$num_grids_val^2,  temp.date, p.index, nchar(input$pkey_digits_val))
    
    temp.pkey$pkey = append(prm.combs.val.z$pkey ,temp.pkey$pkey) ## adding the pkey of the selcted parameter combination
    temp.chosen.prms = c(input$parameter_choice1, input$parameter_choice2)
    temp.prms.perturb <- setdiff(c(input$parameter_choice1, input$parameter_choice2), names(ml.model.selected$custom.scale$parameters)) 
    
    ##2.generate validation parameter combinations
    #adding the selected parameter combination
    #temp.prm.combs.val.z = rbind( t(selected$point[,-1])["rescaled",parameters$ml.model], prm.combs.val.z$DF)
    
    temp.prm.combs.val.z = rbind( selected$point.perturbed , prm.combs.val.z$DF)
    
    ##whether the values of parameters are negative
    temp.neg <- t(selected$point[,-1])["original",] < 0 
    
    ##negative prms -> multiply by -1 
    for(prm.choice  in temp.prms.perturb){
      if(temp.neg[prm.choice]){
        temp.prm.combs.val.z[,prm.choice] <- -1*temp.prm.combs.val.z[,prm.choice]
      }else{}
    }
    
    # if(temp.neg[input$parameter_choice2]){
    #   temp.prm.combs.val.z[,input$parameter_choice2] <- -1*temp.prm.combs.val.z[,input$parameter_choice2]
    # }else{}
    
    temp.prm.combs.val<- data.frame(t(replicate(input$num_grids_val^2, t(selected$point[,-1])["original",])))
    
    if(prm.set.method$method =="unif_grid"){
      row.names(prm.ranges.selected$DF) <- prm.ranges.selected$DF$names
      row.names(prm.grids.selected$DF) <- prm.grids.selected$DF$names
      
      if(length(temp.prms.perturb) != 0){
        temp.prm.combs.val[,temp.prms.perturb] <- 
          fun.scale.conv(sample_meth = prm.set.method$method,
                         prm.ranges = prm.ranges.selected$DF[temp.prms.perturb,], 
                         prm.grids =  prm.grids.selected$DF[temp.prms.perturb,], 
                         prm.combs = temp.prm.combs.val.z[-1,temp.prms.perturb], 
                         z.to.org = TRUE)
      }
      
    }else{
      row.names(prm.ranges.selected$DF) <- prm.ranges.selected$DF$names
      if(length(temp.prms.perturb) != 0){
        temp.prm.combs.val[,temp.prms.perturb] <-
          fun.scale.conv(sample_meth = prm.set.method$method,
                         prm.ranges = prm.ranges.selected$DF[temp.prms.perturb,], 
                         raw.smpl = prm.sets.selected$raw.smpl[,c("pkey",temp.prms.perturb)],
                         prm.combs = temp.prm.combs.val.z[-1,temp.prms.perturb], 
                         z.to.org = TRUE)
      }
    }
    
    
    #custom to original
    if(!is.null(ml.model.selected$custom.scale)){
      temp.prm.combs.val <- cbind(temp.prm.combs.val,prm.combs.val.z$DF[, names(ml.model.selected$custom.scale$parameters)])
      temp.prm.combs.val$pkey <- NA
      temp.cs.func <- get.custom.scale.func.obj(phasespace$object, ml.model.selected$custom.scale$name)
      temp.prm.combs.val[,ml.model.selected$custom.scale$parameters] <-  temp.cs.func(temp.prm.combs.val, other.vals = ml.model.selected$custom.scale$other.vals, cs.to.org = TRUE )[, ml.model.selected$custom.scale$parameters]
      temp.prm.combs.val <- temp.prm.combs.val[,parameters$prmset]
    }
    
    
    
    ##negative prms -> multiply by -1 again to turn back to negative sign.
    for(prm.choice  in temp.prms.perturb){
      if(temp.neg[prm.choice]){
        temp.prm.combs.val.z[,prm.choice] <- -1*temp.prm.combs.val.z[,prm.choice]
        temp.prm.combs.val[,prm.choice] <- -1* temp.prm.combs.val[,prm.choice]
      }else{}
    }
    # if(temp.neg[input$parameter_choice1]){
    #   temp.prm.combs.val.z[,input$parameter_choice1] <- -1*temp.prm.combs.val.z[,input$parameter_choice1]
    #   temp.prm.combs.val[,input$parameter_choice1] <- -1* temp.prm.combs.val[,input$parameter_choice1]
    # }else{}
    # 
    # if(temp.neg[input$parameter_choice2]){
    #   temp.prm.combs.val.z[,input$parameter_choice2] <- -1*temp.prm.combs.val.z[,input$parameter_choice2]
    #   temp.prm.combs.val[,input$parameter_choice2] <- -1* temp.prm.combs.val[,input$parameter_choice2]
    # }else{}
    
    temp.prm.combs.val  = rbind( t(selected$point[,-1])["original",],  temp.prm.combs.val )
    prm.combs.val$DF  <- data.frame(pkey = temp.pkey$pkey, temp.prm.combs.val, stringsAsFactors = F)
    prm.combs.val$DF[,-1] <- signif(prm.combs.val$DF[,-1], digits = 6) ## as in "~/Dropbox/Codes/project_sim_ml/analysis/visualization/vec.plot.R"
    
    prm.combs.val$DF <-  rbind( prm.combs.val$DF[1,],prm.combs.val$DF)
    prm.combs.val$DF[1,] = NA
    prm.combs.val$DF[1,1] = "perturbed_prms"
    
    #for custom.scaled parameters, not yet resolved
    
    
    if(any(temp.prms.perturb == input$parameter_choice1)){
      prm.combs.val$DF[1,input$parameter_choice1] = 1
    }else{
      prm.combs.val$DF[1,ml.model.selected$custom.scale$parameters[input$parameter_choice1]] =1
    }
    
    if(any(temp.prms.perturb == input$parameter_choice2)){
      prm.combs.val$DF[1,input$parameter_choice2] = 2
    }else{
      prm.combs.val$DF[1,ml.model.selected$custom.scale$parameters[input$parameter_choice2]] =2
    }
    
    
    # prm.combs.val$DF[1,input$parameter_choice1] = 1
    # prm.combs.val$DF[1,input$parameter_choice2] = 2
    
  })
  
  
  # shinyFileSave(input, "save_prm_combs", roots = c("roots"= "~/"))
  # observe({
  #   # if(!is.null(prm.combinations$DF)){
  #   #
  #   # }
  #   print(input$save_prm_combs)
  #   file.info = parseSavePath(c("roots"= "~/"), input$save_prm_combs)
  #   print(file.info)
  #   if(nrow(file.info) > 0){
  #     if(file.info$type == "text"){
  #       isolate({
  #         write.table( prm.combinations$DF,file = as.character(file.info$datapath) ,quote = FALSE, col.names = TRUE, row.names = FALSE)})
  #     }else if (file.info$type == "csv"){
  #       isolate({
  #         write.csv(prm.combinations$DF,file = as.character(file.info$datapath) ,quote = FALSE, row.names = FALSE)})
  #     }
  #   }
  # })
  #
  output$prm_combs_val <- renderDataTable({
    input$gen_prm_combs_val
    if(!is.null(prm.combs.val$DF )){
      isolate({
        prm.combs.val$DF[3:nrow(prm.combs.val$DF),]
      })
    }
    
    
  },options = list(scrollX = TRUE))
  
  output$save_prm_combs_val_ui <- renderUI({
    input$gen_prm_combs_val
    if(!is.null(prm.combs.val$DF )){
      downloadButton("save_prm_combs_val", "Save validation parameter combinations")
    }
  })
  
  
  output$save_prm_combs_val <- downloadHandler(
    filename = function() {
      paste0(selected$pkey, "_",input$parameter_choice1, "_", input$parameter_choice2,  ".txt")
    },
    content = function(file) {
      write.table(prm.combs.val$DF, file, row.names = FALSE,quote =FALSE)
    }
    
  )
  
  
  ##Generate validation plots
  prms.combs.val.sim <-reactiveValues()
  
  
  ####only for website version
  output$val_parameter_key_ui <- renderUI({
    if(!is.null(ml.model.selected$ml.model) & !is.null(ml.model.selected$phenotype)){
      
      if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
        temp.prm.key = "042015_AAACEZGP"
       
      }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
        if(ml.model.selected$phenotype == "fold.corr.ppp"){
          temp.prm.key = "011416_AAAAFJWZ"
        }else if(ml.model.selected$phenotype == "fold.corr.pnp"){
          temp.prm.key = "011416_AAAAFYMP"
        }
      }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
        temp.prm.key = "111315_AAAAENMF"
      }
      
      
      
      list(
        selectInput("val_parameter_key",label = h4("Parameter Key", icon(id="val_parameter_key_help", "question-circle")),choices =   temp.prm.key, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "val_parameter_key_help" ,title = "val_parameter_key_help", placement = "top", trigger = "hover", options = list(container = "body"))
      )
      
      
    }
    
  })
  
  output$val_perturb_prms_ui <- renderUI({
    if(!is.null(ml.model.selected$ml.model) & !is.null(ml.model.selected$phenotype)){
      
      if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
        temp.pert.prms = c("dXp_kXm", "kYon_kXon")
      }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
        if(ml.model.selected$phenotype == "fold.corr.ppp"){
          temp.pert.prms = c("KXY_kYm", "KXY_KYZ", "KYZ_nYZ")
        }else if(ml.model.selected$phenotype == "fold.corr.pnp"){
          temp.pert.prms = c("kYm_KXY", "KYZ_kYm", "KYZ_KXY")
        }
      }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
        temp.pert.prms = c("nYX_KYX", "dXp_dYm", "kYon_kYoff")
      }
      
      
      
      list(
        selectInput("val_perturb_prms",label = h4("Perturbed parameters", icon(id="val_perturb_prms_help", "question-circle")),choices =   temp.pert.prms, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "val_perturb_prms_help" ,title = "val_perturb_prms_help", placement = "top", trigger = "hover", options = list(container = "body"))
      )
      
      
    }
    
  })
  
  
  output$val_phenotype_ui <- renderUI({
    if(!is.null(ml.model.selected$ml.model) & !is.null(ml.model.selected$phenotype) ){
      
      if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
        temp.val.phen = c(`Corr(mx,my)` = "mxmy.max")
        
      }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
        if(ml.model.selected$phenotype == "fold.corr.ppp"){
          temp.val.phen = c("fold.corr.ppp")
        }else if(ml.model.selected$phenotype == "fold.corr.pnp"){
          temp.val.phen = c("fold.corr.pnp")
        }
      }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
        if(ml.model.selected$phenotype == "q.factor"){
          temp.val.phen = "q.factor"
        }else if(ml.model.selected$phenotype == "peak.freq"){
          temp.val.phen = "peak.freq"
        }
      }
      
      
      
      list(
        selectInput("val_phenotype",label = h4("Phenotype", icon(id="val_phenotype_help", "question-circle")),choices =   temp.val.phen, size = 3,multiple = FALSE, selectize = FALSE),
        bsTooltip(id = "val_phenotype_help" ,title = "val_phenotype_help", placement = "top", trigger = "hover", options = list(container = "body"))
      )
      
      
    }
    
  })
  ####only for website version
  
  
  
  output$gen_validation_ui <- renderUI({
    if(!is.null(phen.range$DF)){
      list(
        column(
          selectInput(inputId = "plot_type_val",
                      label = h5("Plot type:"),
                      choices = c("2D", "3D")),
          actionButton("gen_val_plots", "Generate validation plots."),
          width = 3),
        column(
          sliderInput("plot_range_val", label = h5("Range of phenotype"),
                      min = phen.range$DF[1] - (phen.range$DF[2]-phen.range$DF[1])*0.1, 
                      max = phen.range$DF[2] + (phen.range$DF[2]-phen.range$DF[1])*0.1, 
                      step = (phen.range$DF[2]-phen.range$DF[1])/500, 
                      value = c(phen.range$DF[1],phen.range$DF[2])
          ),
          width = 3)
      )
    }
  })
  
  
  ## implement for retaining prm.val.z from generation.
  observeEvent(input$gen_val_plots,{
    # if(!is.null(input$file_validation)){
    #   prms.combs.val.sim$DF <- read.table(input$file_validation$datapath, header = T, stringsAsFactors = F)
    # }
    
    
    if(get.phasespace.name(phasespace$object) == "Two-gene simple network"){
      prms.combs.val.sim$DF <- read.table(paste0("two_gene_smpl/", input$val_parameter_key, "_", input$val_perturb_prms,"_sim.txt"),
                                          header = T, 
                                          stringsAsFactors = F)
      
    }else if(get.phasespace.name(phasespace$object) == "Three-gene feedforward network"){
      prms.combs.val.sim$DF <- read.table(paste0("three_gene_feedforward/", input$val_parameter_key, "_", input$val_perturb_prms,"_sim.txt"),
                                          header = T, 
                                          stringsAsFactors = F)
    }else if(get.phasespace.name(phasespace$object) == "Two-gene negative feedback network"){
      prms.combs.val.sim$DF <- read.table(paste0("two_gene_neg_fb/", input$val_parameter_key, "_", input$val_perturb_prms,"_sim.txt"),
                                          header = T, 
                                          stringsAsFactors = F)
    }
    
    
    
    
    
    
    if(!is.null( ml.model.selected$ml.model) && !is.null(prms.combs.val.sim$DF) ){
      prms.combs.val.sim$selected_pkey = prms.combs.val.sim$DF[2,1]
      
      idx.not.custom <- !(prm.ranges.selected$DF$names %in% ml.model.selected$custom.scale$parameters)
      prms.not.custom <- prm.ranges.selected$DF$names[idx.not.custom]
      
      
      ##whether the values of parameters are negative
      temp.neg <-prms.combs.val.sim$DF[2,prms.not.custom] < 0 
      
      ##negative prms -> multiply by -1 
      prms.combs.val.sim$DF[-1,prms.not.custom] <-
        apply( matrix((colnames(temp.neg)),nrow =1),2,
               function(prm, temp.neg, DF) {
                 if(temp.neg[,prm]){
                   DF[,prm] <- -1* DF[,prm]
                 }else{
                   DF[,prm]
                 }}, 
               temp.neg = temp.neg,
               DF = prms.combs.val.sim$DF[-1,prms.not.custom])
      
      if(prm.set.method$method == "unif_grid" && is.null(ml.model.selected$custom.scale)){
        prms.combs.val.sim$DF_z = fun.scale.conv(sample_meth = prm.set.method$method, 
                                                 prm.ranges = prm.ranges.selected$DF, 
                                                 prm.grids = prm.grids.selected$DF, 
                                                 prm.combs = prms.combs.val.sim$DF[-1,c(2:(numPrm$prmset+1))], 
                                                 z.to.org = FALSE)
        
      }else if(prm.set.method$method == "unif_grid" && !is.null(ml.model.selected$custom.scale)){
        
        prms.combs.val.sim$DF_z = fun.scale.conv(sample_meth = prm.set.method$method, 
                                                 prm.ranges = prm.ranges.selected$DF[idx.not.custom,], 
                                                 prm.grids = prm.grids.selected$DF[idx.not.custom,], 
                                                 prm.combs = prms.combs.val.sim$DF[-1,prms.not.custom], 
                                                 z.to.org = FALSE)
        temp.custom.scale.func <- get.custom.scale.func.obj(object = phasespace$object,name = ml.model.selected$custom.scale$name)
        prms.combs.val.sim$DF_z <- cbind(prms.combs.val.sim$DF_z,
                                         temp.custom.scale.func(prm.combs = prms.combs.val.sim$DF[-1,], other.vals = ml.model.selected$custom.scale$other.vals,cs.to.org = F)[,names(ml.model.selected$custom.scale$parameters)] 
        )
        
        
      }else if(prm.set.method$method != "unif_grid" && is.null(ml.model.selected$custom.scale)) {
        prms.combs.val.sim$DF_z = fun.scale.conv(sample_meth = prm.set.method$method, 
                                                 prm.ranges = prm.ranges.selected$DF, 
                                                 raw.smpl = prm.sets.selected$raw.smpl, 
                                                 prm.combs = prms.combs.val.sim$DF[-1,c(2:(numPrm$prmset+1))], 
                                                 z.to.org = FALSE)
        
      }else if(prm.set.method$method != "unif_grid" && !is.null(ml.model.selected$custom.scale)) {
        
        prms.combs.val.sim$DF_z = fun.scale.conv(sample_meth = prm.set.method$method, 
                                                 prm.ranges = prm.ranges.selected$DF[idx.not.custom,], 
                                                 raw.smpl = prm.sets.selected$raw.smpl[,idx.not.custom], 
                                                 prm.combs = prms.combs.val.sim$DF[-1,prms.not.custom], 
                                                 z.to.org = FALSE)
        temp.custom.scale.func <- get.custom.scale.func.obj(object = phasespace$object,name = ml.model.selected$custom.scale$name)
        prms.combs.val.sim$DF_z <- cbind(prms.combs.val.sim$DF_z,
                                         temp.custom.scale.func(prm.combs = prms.combs.val.sim$DF[-1,], other.vals = ml.model.selected$custom.scale$other.vals,cs.to.org = F)[,names(ml.model.selected$custom.scale$parameters)] 
        )
        
      }
      
      ##negative prms -> multiply by -1 again
      ##original
      prms.combs.val.sim$DF[-1,prms.not.custom] <-
        apply( matrix((colnames(temp.neg)),nrow =1),2,
               function(prm, temp.neg, DF) {
                 if(temp.neg[,prm]){
                   DF[,prm] <- -1* DF[,prm]
                 }else{
                   DF[,prm]
                 }}, 
               temp.neg = temp.neg,
               DF = prms.combs.val.sim$DF[-1,prms.not.custom])
      
      ##rescaled
      prms.combs.val.sim$DF_z[,prms.not.custom] <-
        apply( matrix((colnames(temp.neg)),nrow =1),2,
               function(prm, temp.neg, DF) {
                 if(temp.neg[,prm]){
                   DF[,prm] <- -1* DF[,prm]
                 }else{
                   DF[,prm]
                 }}, 
               temp.neg = temp.neg,
               DF =  prms.combs.val.sim$DF_z[,prms.not.custom] )
      prms.combs.val.sim$DF_z <- data.frame( prms.combs.val.sim$DF_z )
      names(prms.combs.val.sim$DF_z)   <- c( prms.not.custom, names(ml.model.selected$custom.scale$parameters))
      
      
      
      
      #print(prms.combs.val.sim$DF[2,2:(nrow(prm.ranges.phase)+1)])
      prms.combs.val.sim$selected_prm_comb_z = prms.combs.val.sim$DF_z[1,]
      
      #print( prms.combs.val.sim$DF_z[1,])
      prms.combs.val.sim$DF_z = prms.combs.val.sim$DF_z[-1,]
      
      prms.combs.val.sim$perturbed_prm1 = colnames(prms.combs.val.sim$DF)[which(prms.combs.val.sim$DF[1,] == 1)]
      prms.combs.val.sim$perturbed_prm2 = colnames(prms.combs.val.sim$DF)[which(prms.combs.val.sim$DF[1,] == 2)]
      if(!is.null(ml.model.selected$custom.scale)){
        if(any(ml.model.selected$custom.scale$parameters == prms.combs.val.sim$perturbed_prm1)){
          prms.combs.val.sim$perturbed_prm1 = names(ml.model.selected$custom.scale$parameters)[ml.model.selected$custom.scale$parameters == prms.combs.val.sim$perturbed_prm1]
        }else{}
        
        if(any(ml.model.selected$custom.scale$parameters == prms.combs.val.sim$perturbed_prm2)){
          prms.combs.val.sim$perturbed_prm2 = names(ml.model.selected$custom.scale$parameters)[ml.model.selected$custom.scale$parameters == prms.combs.val.sim$perturbed_prm2]
        }
      }
      
      
      
      prms.combs.val.sim$num_grids = sqrt(nrow(prms.combs.val.sim$DF)-2)
      
      prms.combs.val.sim$phenotype = input$load_phenotype
      #colnames(prms.combs.val.sim$DF)[ncol(prms.combs.val.sim$DF)]
      
      prms.combs.val.sim$selected_prm_comb_z_pred = predict( ml.model.selected$ml.model,  prms.combs.val.sim$selected_prm_comb_z[,parameters$ml.model]) - predict( ml.model.selected$ml.model.res,  prms.combs.val.sim$selected_prm_comb_z[,parameters$ml.model])
      prms.combs.val.sim$selected_prm_comb_z_simulated = prms.combs.val.sim$DF[2, prms.combs.val.sim$phenotype]
      prms.combs.val.sim$pred = predict( ml.model.selected$ml.model,  prms.combs.val.sim$DF_z[,parameters$ml.model]) - predict( ml.model.selected$ml.model.res,  prms.combs.val.sim$DF_z[, parameters$ml.model])
      prms.combs.val.sim$simulated = prms.combs.val.sim$DF[-c(1,2), prms.combs.val.sim$phenotype]
      
      print( prms.combs.val.sim$perturbed_prm1 )
      print(prms.combs.val.sim$perturbed_prm2)
    }
  })
  
  
  
  
  
  output$validation_plots <- renderUI({
    # if(input$gen_val_plots[[1]] == 0){
    #   return(0)
    # }else{
    input$gen_val_plots
    ##progress indicator
     withProgress(message = 'This may take a while....', value = NULL, {
    if(!is.null(prms.combs.val.sim$DF)){
      isolate({
        if(input$plot_type_val == "2D"){
          list(
            column(4,h4("Prediction"),plotOutput("val_plot_pred_2d",height = "330px")),
            column(4,h4("Simuation"),plotOutput("val_plot_sim_2d", height = "330px")),
            column(4,br(),br(),plotOutput("val_plot_corr",  height = "300px"))
          )
        }else if(input$plot_type_val == "3D"){
          list(
            column(4,h4("Prediction"),rglwidgetOutput("val_plot_pred_3d", height = "330px")),
            column(4,h4("Simuation"), rglwidgetOutput("val_plot_sim_3d", height = "330px")),
            column(4,br(),br(), plotOutput("val_plot_corr",  height = "300px"))
          )
        }
      })
    }
    })
  })
  
  
  
  
  
  output$val_plot_pred_2d <- renderPlot({
    input$gen_val_plots
    #print(prms.combs.val.sim$selected_prm_comb_z)
    #since rf models were trained without kYp, dYp, n, K
    ##progress indicator
    # withProgress(message = 'This may take a while....', value = NULL, {
    isolate({if(!is.null( ml.model.selected$ml.model)){
      if(0){
        vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,prms.combs.val.sim$selected_prm_comb_z[1:numPrm$ml.model],
                         c(prms.combs.val.sim$perturbed_prm1, prms.combs.val.sim$perturbed_prm2),prm.ranges.z.selected$DF[,1:numPrm$ml.model], grid.lines =  prms.combs.val.sim$num_grids, zoom = 1, zlim = c(input$plot_range_val[1],input$plot_range_val[2]), gap = 0 , three.dim = F)
      }
      
      if(1){
        ##progress indicator
        withProgress(message = 'This may take a while....', value = NULL, {
        image2D(matrix( prms.combs.val.sim$pred, nrow = prms.combs.val.sim$num_grids), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]), contour = T, zlim = c(input$plot_range_val[1],input$plot_range_val[2]),xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2)
        points(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], pch =  19 )
        })
        }
    }})
    # })
    
    
  })
  
  output$val_plot_sim_2d <- renderPlot({
    input$gen_val_plots
    ##progress indicator
    # withProgress(message = 'This may take a while....', value = NULL, {
    isolate({if(!is.null( ml.model.selected$ml.model)){
      image2D(matrix(prms.combs.val.sim$simulated, nrow =prms.combs.val.sim$num_grids), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]), contour = T, zlim = c(input$plot_range_val[1],input$plot_range_val[2]),xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2, NAcol = "grey50")
      points(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], pch =  19 )
    }})
    # })
  })
  
  
  output$val_plot_pred_3d <- renderRglwidget({
    input$gen_val_plots
    #since rf models were trained without kYp, dYp, n, K
    ##progress indicator
    # withProgress(message = 'This may take a while....', value = NULL, {
    isolate({if(!is.null( ml.model.selected$ml.model)){
      try(rgl.close(), silent = TRUE)
      
      if(0){
        vec.plot.bc.mod( ml.model.selected$ml.model, ml.model.selected$ml.model.res,prms.combs.val.sim$selected_prm_comb_z[1:numPrm$ml.model],
                         c(prms.combs.val.sim$perturbed_prm1, prms.combs.val.sim$perturbed_prm2),prm.ranges.z.selected$DF[,1:numPrm$ml.model], grid.lines =  prms.combs.val.sim$num_grids, zoom = 1, zlim = c(input$plot_range_val[1],input$plot_range_val[2]), gap = 0 , three.dim = T)
      }
      
      if(1){
        color.gradient <- function(x, colors=c("blue", "green","yellow","red"), colsteps=100) {
          return( colorRampPalette(colors) (colsteps) [ findInterval(x, seq(input$plot_range_val[1],input$plot_range_val[2], length.out=colsteps)) ] )
        }
        plot3d(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2],
               z = prms.combs.val.sim$pred, zlim = c(input$plot_range_val[1],input$plot_range_val[2]), xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2, zlab = prms.combs.val.sim$phenotype)
        plot3d(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], z =   prms.combs.val.sim$selected_prm_comb_z_pred, xlab = prms.combs.val.sim$perturbed_prm1, ylab = prms.combs.val.sim$perturbed_prm2,
               main = "Prediction", col = "red", size = 7, add = TRUE, zlim = c(input$plot_range_val[1],input$plot_range_val[2]))
        surface3d(unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]),
                  z = prms.combs.val.sim$pred, col = color.gradient( prms.combs.val.sim$pred), size = 4, alpha = 0.4, zlim = c(input$plot_range_val[1],input$plot_range_val[2]))
        
      }
      scene2<- scene3d()
      rglwidget(scene2)
      
    }})
    # })
    
  })
  
  output$val_plot_sim_3d <- renderRglwidget({
    input$gen_val_plots
    ##progress indicator
    # withProgress(message = 'This may take a while....', value = NULL, {
    isolate({if(!is.null( ml.model.selected$ml.model)){
      try(rgl.close(), silent = TRUE)
      color.gradient <- function(x, colors=c("blue", "green","yellow","red"), colsteps=100) {
        return( colorRampPalette(colors) (colsteps) [ findInterval(x, seq(input$plot_range_val[1],input$plot_range_val[2], length.out=colsteps)) ] )
      }
      plot3d(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2],
             z = prms.combs.val.sim$simulated, zlim =c(input$plot_range_val[1],input$plot_range_val[2]), xlab = prms.combs.val.sim$perturbed_prm1, ylab =prms.combs.val.sim$perturbed_prm2, zlab = prms.combs.val.sim$phenotype)
      plot3d(prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm1], prms.combs.val.sim$selected_prm_comb_z[prms.combs.val.sim$perturbed_prm2], z = prms.combs.val.sim$selected_prm_comb_z_simulated, xlab = prms.combs.val.sim$perturbed_prm1, ylab = prms.combs.val.sim$perturbed_prm2,
             main = "Simulation", col = "red", size = 7, add = TRUE, zlim = c(input$plot_range_val[1],input$plot_range_val[2]))
      surface3d(unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm1]), unique(prms.combs.val.sim$DF_z[,prms.combs.val.sim$perturbed_prm2]),
                z = prms.combs.val.sim$simulated, col = color.gradient(prms.combs.val.sim$simulated), size = 4, alpha = 0.4,  zlim = c(input$plot_range_val[1],input$plot_range_val[2]))
      
      scene3<- scene3d()
      rglwidget(scene3)
    }})
    # })
    
  })
  
  
  output$val_plot_corr <- renderPlot({
    input$gen_val_plots
    ##progress indicator
    # withProgress(message = 'This may take a while....', value = NULL, {
    isolate({if(!is.null( ml.model.selected$ml.model)){
      df <- data.frame(x = prms.combs.val.sim$simulated, y = prms.combs.val.sim$pred )
      g = ggplot(df,aes(x=x, y=y)) + geom_point(alpha=1, size = 1, color = "black") +# stat_density2d(aes( alpha = ..level..),geom='polygon',colour='yellow', size = 0.05)+
        geom_abline(slope = 1,intercept = 0) + xlim(input$plot_range_val[1],input$plot_range_val[2]) +ylim(input$plot_range_val[1],input$plot_range_val[2]) + ggtitle(paste0("Pred VS Sim for ", prms.combs.val.sim$perturbed_prm1," and ", prms.combs.val.sim$perturbed_prm2, ": corr = ", signif(cor( prms.combs.val.sim$simulated, prms.combs.val.sim$pred,use = "complete.obs"), 3)))+ theme_bw() + xlab("Simulation      ") + ylab("Prediction     ") + #+ geom_smooth(method=lm,linetype=2,colour="red",se=F)
        theme(axis.text=element_text(size=10), axis.title=element_text(size=10))
      g
    }})
    # })
  })
  
  
  
  #h-clustering for prm.z and localVarImp
  output$gen_hclust_ui <- renderUI({
    list(
     actionButton("gen_hclust","Generate hierarchical clustering plots!")
    )
  })
  
  
  brush.points <- reactiveValues()
  hclust <- reactiveValues()
  
  myfun <- function(x) hclust(x, method = "ward.D")
  
  observeEvent(input$gen_hclust,{
    
    
    
    ##progress indicator
    withProgress(message = 'This may take a while...', value = NULL, {
    if(!is.null(input$tsne_brush)){
      brush.points$rtsne = brushedPoints(ggdata, input$tsne_brush, xvar = "tSNE1", yvar = "tSNE2")
      #check the number of selected points. If this is greater than 5000, pop up a warning.
      if(nrow( brush.points$rtsne) > 10000){
        showModal(modalDialog(
          title = "Alert!",
          paste0("You have selected too many points (", nrow( brush.points$rtsne),"), exceeding the capacity of the server to generate heatmaps. Please select less than 10000 points."),
          easyClose = TRUE
        ))
        
      }else{
        if(!is.null(ml.model.selected$ml.model)){
          brush.points$loc.imp = local.importance$DF[local.importance$DF$pkey %in% brush.points$rtsne$pkey,c("pkey", parameters$ml.model)]
          brush.points$loc.imp <- brush.points$loc.imp[order(brush.points$loc.imp$pkey),]
          row.names(brush.points$loc.imp) = brush.points$loc.imp$pkey
          brush.points$loc.imp = brush.points$loc.imp[,-1]
        }else{
          numPrm$ml.model <- numPrm$prmset
        }
        
        temp.prms.custom <- setdiff( parameters$ml.model, parameters$prmset)
        if(length(temp.prms.custom) != 0){
          brush.points$prm.z <- prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey %in% brush.points$rtsne$pkey,c("pkey", setdiff(parameters$ml.model,temp.prms.custom ))]
          temp.prms.custom.z <- get.custom.scale(phasespace$object, paste0(ml.model.selected$custom.scale$name,".z"))
          temp.prm.values <- temp.prms.custom.z$func.obj(prm.sets.selected$original[prm.sets.selected$original$pkey %in% brush.points$rtsne$pkey,c("pkey", parameters$prmset)],
                                                         temp.prms.custom.z$other.vals, 
                                                         F)
          brush.points$prm.z <- cbind(brush.points$prm.z, temp.prm.values[,-1])
          temp.prm.values <- NULL
        }else{
          brush.points$prm.z = prm.sets.selected$rescaled[prm.sets.selected$rescaled$pkey %in% brush.points$rtsne$pkey,c("pkey", parameters$ml.model)]
        }
        row.names( brush.points$prm.z) = brush.points$prm.z$pkey
        brush.points$prm.z = brush.points$prm.z[,-1]
        
        hclust$prms.row <- as.dendrogram(myfun(dist(as.matrix(brush.points$prm.z))))
        hclust$prms.col <- as.dendrogram(myfun(dist(t(as.matrix(brush.points$prm.z)))))
        hclust$locImp.row <- as.dendrogram(myfun(dist(as.matrix(brush.points$loc.imp))))
        hclust$locImp.col <- as.dendrogram(myfun(dist(t(as.matrix(brush.points$loc.imp)))))
        hclust$locImp.row.cut <- NULL
        hclust$locImp.row.cut.color <- NULL
      }
      
      
      
    }else{
      showModal(modalDialog(
        title = "Alert!",
        paste0("No point selected. Please select points (> 2 points) by dragging the region of your interest and try again."),
        easyClose = TRUE
      ))
      brush.points$rtsne <- NULL
      brush.points$prm.z <- NULL
      brush.points$loc.imp <- NULL
      hclust$prms.row <- NULL
      hclust$prms.col <- NULL
      hclust$locImp.row <- NULL
      hclust$locImp.col <- NULL
      hclust$locImp.row.cut <- NULL
      hclust$locImp.row.cut.color <- NULL
    }
    })
    
  })
  
  
  
  output$hclust_prms <- renderPlot({
    if(!is.null(brush.points$prm.z)){
      ##progress indicator
      withProgress(message = 'This may take a while...', value = NULL, {
      temp.range = signif(range(as.numeric(as.matrix(brush.points$prm.z))),2 )
      colors <- c(seq(temp.range[1],temp.range[2],length=100))
      if(!is.null(input$hclust_prms_selected_pt)){
        if(input$hclust_prms_selected_pt){
          ##denote selected point
          
          temp.hclust.prms.row.col <- rep(NA, nrow(brush.points$prm.z) )
          temp.hclust.prms.row.col[row.names(brush.points$prm.z) == selected$pkey] <- "black"
          
          if(!input$hclust_prms_col_dendr){
            isolate({
              #heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun, Rowv = TRUE, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
              heatmap.2(as.matrix(brush.points$prm.z),  Rowv = hclust$prms.row, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations"),  RowSideColors=temp.hclust.prms.row.col, labRow = FALSE)
            })
          }else{
            isolate({
              #heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun,  trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
              heatmap.2(as.matrix(brush.points$prm.z),  Rowv = hclust$prms.row, Colv = hclust$prms.col, trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations"), RowSideColors=temp.hclust.prms.row.col, labRow = FALSE)
            })
          }
          
          
        }else{
          if(!input$hclust_prms_col_dendr){
            isolate({
              #heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun, Rowv = TRUE, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
              heatmap.2(as.matrix(brush.points$prm.z),  Rowv = hclust$prms.row, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") , labRow = FALSE)
            })
          }else{
            isolate({
              #heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun,  trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
              heatmap.2(as.matrix(brush.points$prm.z),  Rowv = hclust$prms.row, Colv = hclust$prms.col, trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations"), labRow = FALSE )
            })
          }
        }
      }else{
        if(!input$hclust_prms_col_dendr){
          isolate({
            #heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun, Rowv = TRUE, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
            heatmap.2(as.matrix(brush.points$prm.z),  Rowv = hclust$prms.row, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations"), labRow = FALSE )
          })
        }else{
          isolate({
            #heatmap.2(as.matrix(brush.points$prm.z), hclustfun = myfun,  trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations") )
            heatmap.2(as.matrix(brush.points$prm.z),  Rowv = hclust$prms.row, Colv = hclust$prms.col, trace = "none",breaks = colors, col = colorRampPalette(c("blue", "white", "red"))(n = 99), main = paste0("Parameter combinations"), labRow = FALSE )
          })
        }
      }
      
      
      })
    }
  })
  
  output$hclust_prms_selected_ui <- renderUI({
    if(!is.null(brush.points$prm.z) & !is.null(selected$pkey)){
      if(selected$pkey %in% row.names(brush.points$prm.z)){
        checkboxInput("hclust_prms_selected_pt", h5("Denote the selected point"))
      }
    }
  })
  
  
  output$hclust_locImp_spec_ui <- renderUI({
    if(!is.null(brush.points$loc.imp)){
      isolate({
        temp.range = signif(range(as.numeric(as.matrix(local.importance$DF[,-1]))),1 )
        list(
          column(4,sliderInput(inputId = "hclust_locImp_color_scale",
                               label = h5("Color scale"), 
                               min = 0,
                               max = temp.range[2]/2,
                               step = (temp.range[2])/500, 
                               round = -1,
                               dragRange = TRUE,
                               value =  temp.range[2])),
          column(4,selectInput(inputId = "num_clust",label = h5("Number of cluster"), choices = c(1:20))),
          column(3,actionButton("hclust_local_varimp_refresh", h5("Refresh")))
        )
      })
    }
  })
  
  
  observeEvent(input$hclust_local_varimp_refresh,{
    if(!is.null(input$num_clust)){
      if(input$num_clust > 1){
        hclust$locImp.row.cut = cutree(as.hclust(hclust$locImp.row), input$num_clust)
        color.gradient = colorRampPalette(c("blue", "green","yellow","red"))
        temp.clust.color <- color.gradient( input$num_clust)
        hclust$locImp.row.cut.color <-  temp.clust.color[ hclust$locImp.row.cut ]
      }else{
        hclust$locImp.row.cut <- NULL
        hclust$locImp.row.cut.color <- NULL
      }
    }
  })
  
  output$hclust_local_varimp <- renderPlot({
    ##progress indicator
    withProgress(message = 'This may take a while...', value = NULL, {
    if(!is.null(brush.points$loc.imp)){
      input$hclust_local_varimp_refresh
      input$hclust_locImp_col_dendr
      isolate({
        if(nrow(brush.points$loc.imp) != 0  & !is.null(input$hclust_locImp_color_scale)){
          
          colors <- c(seq(-input$hclust_locImp_color_scale,input$hclust_locImp_color_scale,length=100))
          if(!is.null(hclust$locImp.row.cut)){##with clusters
            if(!input$hclust_locImp_col_dendr){
              #heatmap.2(as.matrix(brush.points$loc.imp), hclustfun = myfun, Rowv = TRUE, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance") )
              heatmap.2(as.matrix(brush.points$loc.imp),  Rowv = hclust$locImp.row, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance") ,  RowSideColors=hclust$locImp.row.cut.color, labRow = FALSE)
            }else{
              #heatmap.2(as.matrix(brush.points$loc.imp), hclustfun = myfun, trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance") )
              heatmap.2(as.matrix(brush.points$loc.imp),  Rowv = hclust$locImp.row, Colv = hclust$locImp.col, trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance"), RowSideColors=hclust$locImp.row.cut.color, labRow = FALSE )
            }
          }else{
            if(!input$hclust_locImp_col_dendr){
              #heatmap.2(as.matrix(brush.points$loc.imp), hclustfun = myfun, Rowv = TRUE, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance") )
              heatmap.2(as.matrix(brush.points$loc.imp),  Rowv = hclust$locImp.row, Colv = FALSE,  dendrogram = "row", trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance"), labRow = FALSE )
            }else{
              #heatmap.2(as.matrix(brush.points$loc.imp), hclustfun = myfun, trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance") )
              heatmap.2(as.matrix(brush.points$loc.imp),  Rowv = hclust$locImp.row, Colv = hclust$locImp.col, trace = "none",breaks = colors, col = colorRampPalette(c("green", "black", "red"))(n = 99), main = paste0("Local variable importance"), labRow = FALSE )
            }
            
          }
          
          
        }
      })
    }
    })
  })
  
  ##action link
  
  observeEvent(input$actionlink_home,{
    
    
    updateTabItems(session, "side_menu_tab", "home_tab")
  })
  
  observeEvent(input$actionlink_sitemap,{
    
    
    updateTabItems(session, "side_menu_tab", "overview_tab")
  })
  
  
  observeEvent(input$actionlink_about_us,{
    
  
    updateTabItems(session, "side_menu_tab", "about_tab")
  })
  
  observeEvent(input$actionlink_contact,{
    
    
    updateTabItems(session, "side_menu_tab", "about_tab")
  })
  
  
  
}




