# PhasespaceExplorer

This is an R shiny application for the paper "Exploring information transmission in gene networks using stochastic simulation and machine learning". Now it contains a prototype version only with the two-gene simple network for now. Along with Monarch deployment, we will develop into a complete version.
