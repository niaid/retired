SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

DROP SCHEMA IF EXISTS `wren` ;
CREATE SCHEMA IF NOT EXISTS `wren` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
USE `wren` ;

-- -----------------------------------------------------
-- Table `wren`.`User`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wren`.`User` ;

CREATE  TABLE IF NOT EXISTS `wren`.`User` (
  `id` INT NOT NULL  AUTO_INCREMENT ,
  `login_name` VARCHAR(45) NOT NULL ,
  `firstName` VARCHAR(45) NULL ,
  `lastName` VARCHAR(45) NULL ,
  `password` VARCHAR(45) NULL ,
  `created_date` TIMESTAMP NOT NULL DEFAULT now() ,
  `role` VARCHAR(45) NULL ,
  `email` VARCHAR(45),
  PRIMARY KEY (`id`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wren`.`Experiment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wren`.`Experiment` ;

CREATE  TABLE IF NOT EXISTS `wren`.`Experiment` (
  `id` INT NOT NULL   AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `template_json` LONGTEXT NULL ,
  `created_date` TIMESTAMP NOT NULL DEFAULT now() ,
  `last_modified_date` TIMESTAMP NULL ,
  `hasLayout` INT DEFAULT 1,
  `User_id` INT NOT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_Experiment_User1` (`User_id` ASC) ,
  CONSTRAINT `fk_Experiment_User1`
    FOREIGN KEY (`User_id` )
    REFERENCES `wren`.`User` (`id` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wren`.`Layout`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wren`.`Layout` ;

CREATE  TABLE IF NOT EXISTS `wren`.`Layout` (
  `id` INT NOT NULL   AUTO_INCREMENT ,
  `inputfile` LONGTEXT,
  `Experiment_id` INT NOT NULL ,
  `layout_json` LONGTEXT NULL ,
  `worksheet_name` VARCHAR(45),
  `created_date` TIMESTAMP NOT NULL DEFAULT now() ,
  `last_modified_date` TIMESTAMP NULL ,
  `refgenenames` TEXT NULL ,
  `targetgenenames` TEXT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_Layout_Experiment1` (`Experiment_id` ASC) ,
  CONSTRAINT `fk_Layout_Experiment1`
    FOREIGN KEY (`Experiment_id` )
    REFERENCES `wren`.`Experiment` (`id` )
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `wren`.`Reference_Gene`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `wren`.`Reference_Gene` ;

CREATE  TABLE IF NOT EXISTS `wren`.`Reference_Gene` (
  `id` INT NOT NULL   AUTO_INCREMENT ,
  `gene_name` VARCHAR(45) NOT NULL ,  
  `Experiment_id` INT NOT NULL ,
  `Layout_id` INT NOT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_Reference_Gene_Experiment1` (`Experiment_id` ASC) ,
  INDEX `fk_Reference_Gene_Layout1` (`Layout_id` ASC) ,
  CONSTRAINT `fk_Reference_Gene_Experiment1`
    FOREIGN KEY (`Experiment_id` )
    REFERENCES `wren`.`Experiment` (`id` )
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Reference_Gene_Layout1`
    FOREIGN KEY (`Layout_id` )
    REFERENCES `wren`.`Layout` (`id` )
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

insert into User (login_name, password, role) values ('LOGIN-NAME', 'PASSWROD', 'USER');
