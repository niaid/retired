# What's this project
	A browser-based software for rapidly analyzing and archiving qPCR data

# How to check out source code
	svn co "YOUR SOURCE CODE LOCATION" SAGE
# How to connect database
	- Development database
	mysql -u 'YOUR USER' -h 'YOUR SERVER NAME' -p
	Enter password>'YOUR SERVER PASSWORD'
	mysql> use wren
	- Production database
	mysql -u 'YOUR USER' -h 'YOUR SERVER NAME' -p
	Enter password>'YOUR SERVER PASSWORD'
	mysql> use wren


# How to checkout the project from the repository and set up the project in eclipse? 
	1. Project source code is located at SVN Repositrory > 'YOUR SERVER'
	2. Please checkout the application code to Eclipse (default is Eclipse IDE, 
	   however if you are using any other IDE, please change the settings based on the .classpath file).
	3. You will have to set the Default Output folder ( of Project > Properties > Java Build Path > Source) 
	   to "SAGE/target/pave/WEB-INF/classes"
	4. Set up the Tomcat ( of Project > Properties > Tomcat > General) properties. To make this a tomcat project, 
	   - check all boxes
	   - set the context as "/SAGE", and 
	   - set web application root as "/target/SAGE"
	5. In MyEclipse: right click pave project > MyEclipse > add web capabilities > web-root folder: target/sage, web context-root: /sage
	6. in sage directory > mvn eclipse:eclipse



# How to package/deploy the application on local machine?
	 1. In sage > mvn clean package
	 2. Upon successful build, sage.war file will be created under the target folder.
	 3. Set the Tomcat project settings in Eclipse for the project.
	 4. On successful tomcat start, the application can be viewed at http://localhost:8080/sage/
	 
	 
# How to package/deploy the application on the servers?
	 1. In pave >  mvn clean package
	 2. Upon successful build, pave.war file will be created under the target folder.
	 3. On 'YOUR DEV SERVER NAME', go to 'YOUR DEV SERVER NAME'/probe/, deploy sage.war, check 'YOUR SERVER NAME'/sage
		- check the 'Update the application if it is already deployed'
		- check the 'Discard "work" directory if exists'	
	 4. Email the Development Lead, request deployment to 'YOUR PROD SERVER NAME' as ROOT.war, check http://sage.niaid.nih.gov

# Database ER diagram
	SAGE/doc/WREN-DB.mwb (MySQL WorkBench file)

# Database schema 
	SAGE/doc/wren.sql

# How to create a new user
   	1. Ask user to fill the form in http://sage.niaid.nih.gov/createNewAccount
	2. SAGE_SUPPORT receive the email about this request and generated a sql for creating new account
	3. mysql -u 'YOUR USER' -h ai- 'YOUR SERVER NAME' -p'YOUR PASSWORD'
	   copy the generated sql statement to mysql prompt
	   i.e. mysql> insert into ...

# How to reset user password
   	1. Ask user to fill the form in http://sage.niaid.nih.gov/forgetPassword
	2. SAGE_SUPPORT receive the email about this request and generated a sql for resetting password
	3. mysql -u 'YOUR USER' -h ai- 'YOUR SERVER NAME' -p'YOUR PASSWORD'
	   copy the generated sql statement to mysql prompt
	   i.e. mysql> update user ...

# How to update the demo video file
	1. save file to <SAGE>/src/main/webapps/download/
	2. change url in loginpage.jsp and downloadDemoFiles.jsp


# Troubleshooting
	1. if the image is not loaded in google chart, check if tmp folder exist in ~/webapps/ROOT/  (or ~/webapps/SAGE/) with read/write permission.  
	2. if the image is not loaded in google chart, remove the tmp folder in ~/webapps/
	
## TODO
	1. backup database regularly