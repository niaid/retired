/*
 * SAGE Web Application
 * 
 */
var project; // you can access this as Project.IN
var DEBUG = false;
var main = "#wren_main";
var main_view = "#wren_table";
var main_sidebar = "#wren_sidebar";
var downloadType = -1;
var lastPrint = ""; // for debugging only-- use print() function to print/debug
var isShowOutput = false;
function setup() {
	project = new Project();
	$("#mainpane").css('min-height', '500px');
	// $("#mainpane").css('background-color', '#efe');
	
	$("#mainpane").append($.create('div', {
		'id' : removeHash(main),
		'style' : 'width:880px'
	}));
	$("#mainpane").append($.create('div', {
		'id' : 'exclusionTable',
		'style' : 'display:none; width: 880px'
	}));
	$("#mainpane").append($.create('div', {
		'id' : 'webOutput',
		'style' : 'display:none; width: 880px'
	}));
//	$("#webOutput").jScrollPane( {
//		showArrows: true,
//		autoReinitialise : true,
//		enableKeyboardNavigation : false,
//		hideFocus : true
//	});
	// $("#mainpane").append('<div id="test"
	// style="position:relative;float:left"></div>');
	// $(main).disableTextSelect();
	$(main).append($.create('fieldset', {
		'id' : 'intro',
		'title' : 'Home'
	}));

	$(main).append($.create('fieldset', {
		'id' : 'template',
		'title' : 'Create an Experiment'
	}));
	$(main).append($.create('fieldset', {
		'id' : 'layout',
		'title' : 'Edit layout'
	}));
	$(main).append($.create('fieldset', {
		'id' : 'calculate',
		'title' : 'Calculate Data'
	}));
	$(main).append($.create('fieldset', {
		'id' : 'result',
		'title' : 'Show Output'
	}));
	// $("#intro").append("<legend></legend>");
	// $("#template").append("<legend></legend>");
	// $("#layout").append("<legend></legend>");
	// $("#calculate").append("<legend></legend>");
	// $("#result").append("<legend></legend>");
	// $("#calculate").append("<div id='calculations'></div>");
	$("#calculate").append($.create('div', {
		'id' : 'calculate_dialog',
		'style' : ';width:880px;height:450px'
	}));

	$("#calculate_dialog").append($.create('div', {
		'id' : 'calculate_overlay',
		'style' : 'position:relative;width:100%;height:450px'
	}));
	$("#calculate").append($.create('div', {
		'id' : 'calculate_buttons',
		'style' : 'display:none;'
	}));

	var dataBox = '';
	
	dataBox += '<div style="width:300px;margin:0 auto;">';
	
	dataBox += '<form id="uploadDataForm" name="uploadDataForm" method="POST"  enctype="multipart/form-data">';
	dataBox += '<h1 style="color:white; float:left;" class="hidden" id="reCalculateButton">Use existing file: <input type="submit" value="ReCalculate"/></h1>';
	dataBox += '<h1 style="color:white; float:left;">Upload Data File:</h1>';
	dataBox += '<br>';
	dataBox += '<input style="display:none;float:right;" name="type" value="file" />';
	dataBox += '<textarea style="display:none;float:right;" name="projectObject">placeHolder</textarea>';
	dataBox += '<textarea style="display:none;float:right;" name="experimentID">' + Project.IN.experimentID + '</textarea>';
	dataBox += '<textarea style="display:none;float:right;" name="layoutID">' + Project.IN.layoutID + '</textarea>';
	dataBox += '<input style="width:300px;float:left;text-align:center" type="file" name="uploadTemplateForm" style="" />';
	dataBox += '<input style="display:none;float:right;" type="text" name="worksheetName" value="myworksheet" />';
	dataBox += '<br><br><br>';
	dataBox += '<input style="float:right;" type="submit" value="Upload" />';
	//dataBox += '<input id='usePrevInputFile' style="float:right;" type="submit" value="Use Previous Input File" />';
	
	dataBox += '</form>';
	dataBox += '</div>';
	dataBox += '';
	$("#downloadButton").removeClass('hidden');
	$("#calculate_buttons").append(dataBox);
	$('#uploadDataForm')
			.ajaxForm(
					{
						dataType : null,
						url : 'service/uploadDataFile',
						beforeSubmit : function() {
							document.uploadDataForm.projectObject.value = processJSON(project);
							document.uploadDataForm.experimentID.value = Project.IN.experimentID;
							document.uploadDataForm.layoutID.value = Project.IN.layoutID;
						},
						success : function(data) {
							isShowOutput = true;
							$("#downloadButton").removeClass('hidden');
							$('#webOutput').html(data);
							$("#wren_main").slideUp('fast', function() {
								$("#webOutput").slideDown();
							});
							//alert('excel');
							$("#returnType").val('calculate');
							$('a').filter(function() {
								return this.id.match(/wren_main-next-3/);
								}).click();
							
						}
					});

}

function createNewExperiment(){
	setDownloadButton(2);
	$.fn.stepy.step(2, '#wren_main');
	$('#settings').slideDown();
	$('#currProj').css('display', 'inherit');
	cont = true;

	$('button').filter(function() {
		return this.id.match(/_template_module_plus/);
	}).click();
	cont = true;
	$("#projectName").click();
}

function intro(thisID, thisSelectedJson, optionType) {
	Project.IN.mainOptionType = optionType;
	$("#intro").append($.create('div', {
		'id' : 'intro_overlay',
		'style' : 'width:100%;height:450px'
	}));
	$("#intro").append($.create('div', {
		'id' : 'intro_buttons',
		'style' : 'display:none;'
	}));
	
	var items = '';
	items += '<h1 style="color:black">Choose an Option:</h1>';
	items += '<br>';
	items += '<div id="optB">';
	items += '<button class="button black" id="createTemplate">Create an Expreriment</button>';
	items += '<br><br>';
	items += '<button class="button black" id="newLayoutExistingExperiment">Create a layout for existing experiment</button>';
	items += '<br><br>';
	items += '<button class="button black" id="editTemplate">Edit Template</button>';
	items += '<br><br>';
	items += '<button class="button black" id="editLayout">Edit a layout</button>';
	items += '<br><br>';
	items += '</div>';
	
	$('#intro_buttons').append(items);
	$('#intro_buttons button')
			.live('click', function() {
				
				var id = $(this).attr('id');
				if (id == 'createTemplate') {
					// project = new Project();
					// $("#webOutput").slideUp();
					setDownloadButton(2);
					$.fn.stepy.step(2, '#wren_main');
					$('#settings').slideDown();
					$('#currProj').css('display', 'inherit');
					cont = true;

					$('button').filter(function() {
						return this.id.match(/_template_module_plus/);
					}).click();
					cont = true;
				
				}else if (id == 'editLayout' || id == 'newLayoutExistingExperiment' || id == 'editTemplate'){
					Project.IN.experimentUpdateTypeID = id;
					project.setProjectData(thisSelectedJson);
					
					//Project.IN.tableType = 1; // 384 well
					var canModifyTemplate = false;
					if (thisID==-1){//new experiment, Reuse a previously used gene layout
						canModifyTemplate = true;
						Project.IN.experimentID = -1;
						Project.IN.layoutID = -1;
						Project.IN.projectName = thisSelectedJson.projectName+" NEW";
						$("#projectName").html(Project.IN.projectName);
					}else{
						Project.IN.experimentID = thisSelectedJson.experimentID;
						Project.IN.layoutID = thisID;
						Project.IN.projectName = thisSelectedJson.projectName;
					}
					if (id == 'editTemplate' || (id == 'editLayout' && thisID == -1)){//editLayoutNewExperiment
						canModifyTemplate = true;
					}
					//alert('ccc id=='+id+' thisID='+thisID+" canModifyTemplate="+Project.IN.canModifyTemplate);
					// alert("experimentID=="+Project.IN.experimentID);
					$("#projectName").html(Project.IN.projectName);
					$('div')
							.filter(
									function() {
										return this.id
												.match(/template_module_accordion_header/);
									})
							.unblock();
		
					$('button')
							.filter(
									function() {
										return this.id
												.match(/template_module_edit/);
									})
							.toggleEnabled();
		
					setDownloadButton(2);
					$.fn.stepy
							.step(
									2,
									'#wren_main');
					$('#settings')
							.slideDown();
					$('#currProj')
							.css(
									'display',
									'inherit');
					cont = true;
					project.template.replaceGroups(thisSelectedJson);
					if (id == 'newLayoutExistingExperiment'){
						project.layout.addRefGene(thisSelectedJson);
					}
					if (canModifyTemplate){
						project.template
						.addTableDragToSelect();
					}
					
					if (id == 'editLayout'){
						Project.IN.showSetting = false;
						$('a').filter(function() {
							return this.id.match(/wren_main-next-1/);
							}).click();
						if (thisID==-1){//reuse previous layout for new experiment, copy groups only
							$('a').filter(function() {
								return this.id.match(/wren_main-back-2/);
								}).click();
						}
						
					}
					if (!canModifyTemplate){ //disable these buttons
						$('button')
						.filter(
								function() {
									return this.id
											.match(/template_module_edit/);
								})
						.toggleEnabled();
						$('button')
						.filter(
								function() {
									return this.id
											.match(/template_module_plus/);
								})
						.toggleEnabled();
					}
					Project.IN.canModifyTemplate = canModifyTemplate;
					if (id != 'newLayoutExistingExperiment'){
						if (thisID >0){
							project.layout.replaceGenes(thisSelectedJson); //need this otherwise edit template not editable
						}else{
							project.layout.replaceGenes2(thisSelectedJson);//create empty structure,no genes added
							Project.IN.showSetting = true;
						}
						if (id = 'editTemplate'){
							Project.IN.colorIndex = project.template.data.length - 1;
						}
					}
					if (Project.IN.layout.data.length - Project.IN.refGeneCount > 0){
						$('div')
						.filter(
								function() {
									return this.id
											.match(/layout_module_accordion_header/);
								})
						.unblock();
						$('button')
						.filter(
								function() {
									return this.id
											.match(/layout_module_edit/);
								})
						.toggleEnabled();
					}
					
					if (thisID==-1){
						$("#projectName").click();
					}
				}
			});

	$('#back').live('click', function() {
		//$('#intro_overlay').styleBlock($("#intro_buttons"), 300);
	});

	$("#downloadButton").live('click', function() {
		$("#downloadName").val(project.projectName);
		$("#downloadData").val(processJSON(project));
		$("#downloadForm").submit();
	});

	// $('#optB input:radio').button();
	$('#optB button').width(200);

	//$('#intro_overlay').styleBlock($("#intro_buttons"), 300);
	

}

function wren_load() {
	jQuery.fx.off = true; // #setting slide down when template loaded; so the
							// table dragToSelect calculation was off without
							// this;
	Project.IN.template.loadModule("#template");
	Project.IN.layout.loadModule("#layout");
	Project.IN.exclusion.loadModule("#exclusionTable");
}

function configurePreferences() {
	$('#wren_main').stepy( {
		finishButton : false,
		titleClick : true,
		backLabel : 'Back',
		nextLabel : 'Next',
		
		back : function(index) {
			if (Project.IN.editing){
				alert('Please click on done to complete the edit');
				return false;
			}
			Project.IN.layout.refreshTable();
			if (index == 1) {
				$('#wren_main-next-0').hide();
				cont = false;
			}
			setDownloadButton(index);
		},
		next : function(index) {
			if (Project.IN.editing){
				alert('Please click on done to complete the edit');
				return false;
			}
			// alert(index);
			Project.IN.layout.refreshTable();
			if (!cont) {
				return false;
			} else {
				if (index > 2 && Project.IN.template.data.length == 0) {
					alert("You must have at least one group to continue!");
					return false;
				} else if (index > 3 && Project.IN.layout.data.length == 0) {
					alert("You must have at least one gene to continue!");
					return false;
				}
				setDownloadButton(index);
			}
			if (index == 3 && Project.IN.tableType == 1) {// TODO:: change UI selection
				Project.IN.setTableType(1);
			}
			return true;
		}
	});
	$('#wren_main-back-1').text('Home');
	$('#wren_main-next-3').hide();//remove the next button on upload file
	$('#wren_main-next-0').toggle();
	$("#wren_main-titles")
			.wrap('<div id="arrows" class="breadCrumb module" />');
	$("#arrows").wrap('<div id="breadCrumb" class="module" />');
	$("#breadCrumb").wrap('<div id="header" style="overflow:hidden" />');
	// $("#arrows").jBreadCrumb({
	// easing:'swing'
	// });
	$("#breadCrumb")
			.append(
					$
							.create(
									'div',
									{
										'id' : 'downloadContainer',
										'style' : 'float: right; margin-top: -26px; margin-right: 40px; width:auto'
									}));
	// $("#header").append('<div
	// id="settings"style="margin-top:5px;margin-bottom:5px;display:none;"
	// class="breadCrumb"><div style="overflow:hidden; position:relative; width:
	// 868px;"><div>Stuff here</div></div></div>')
	$("#header").append($.create('div', {
		'id' : 'settings',
		'class' : 'breadCrumb',
		'style' : 'margin-top:5px;margin-bottom:5px;display:none;height:auto'
	}));
	$("#settings").append($.create('div', {
		'style' : 'position:relative; width: 868px;'
	}));
	$("#settings div").append($.create('div', {
		'id' : 'settingsContent'
	}));
	
	$("#downloadContainer").append($.create('button', {
		'id' : 'printButton',
		'style' : 'float:right;position:relative;',
		'class' : 'gearButton'
	}));
	$("#printButton").append('&nbsp;<img title="click to print" alt="click to print" border="0" src="images/print.jpg" />&nbsp; ');
	
	$("#downloadContainer").append($.create('button', {
		'id' : 'settingsButton',
		'style' : 'float:right;position:relative;',
		'class' : 'hidden gearButton'
	}));
	$("#settingsButton").append('<img src="images/gear.png" title="click to change configuration" alt="click to change configuration" />');
	
	$("#downloadContainer").append($.create('button', {
		'id' : 'saveButton',
		'style' : 'float:right;position:relative;',
		'class' : 'gearButton'
	}));

	
	$("#saveButton").append('&nbsp;<img title="click to save to database" alt="click to view gene information" border="0" src="images/save.png" />&nbsp; ');
	
	$("#downloadContainer").append($.create('button', {
		'id' : 'viewButton',
		'style' : 'float:right;position:relative;',
		'class' : 'gearButton'
	}));

	
	$("#viewButton").append('<img title="click to view gene information" alt="click to view gene information" src="images/view.png" />');
	
	$("#downloadContainer").append($.create('div', {
		'id' : 'saveLabel',
		'style' : 'float:right;position:relative;',
		'class' : 'hidden'
	}));
	$("#saveLabel").append('saved&nbsp;&nbsp;');
//	$("#downloadContainer").append($.create('button', {
//		'id' : 'logoutButton',
//		'style' : 'float:right;position:relative;',
//		'value':'logout'
//	}));
	
	$("#downloadContainer").append($.create('form', {
		'id' : 'downloadForm',
		'action' : 'service/downloadFile',
		'method' : 'POST',
		'style' : 'display:inline'
	}));
	$("#downloadForm").append($.create('input', {
		'id' : 'downloadName',
		'name' : 'downloadName',
		'type' : 'hidden'
	}));
	$("#downloadForm").append($.create('input', {
		'id' : 'returnType',
		'name' : 'returnType',
		'type' : 'hidden'
	}));
	$("#downloadForm").append($.create('input', {
		'id' : 'downloadData',
		'name' : 'data',
		'type' : 'hidden'
	}));
	$("#downloadForm").append($.create('div', {
		'id' : 'downloadButton',
		'class' : 'button green small hidden',
		'style' : 'position:relative'
	}));
	$("#settingsContent")
			.append(
					$
							.create(
									'div',
									{
										'id' : 'projectNameWrapper',
										'style' : 'position:relative;display:inline-block; height:32px; float:left; padding-right:10px; min-width: 200px; max-width: 200px;'
									}));
	$("#projectNameWrapper").append($.create('div', {
		'id' : 'projectNameContainer',
		'style' : 'display:table; height:32px; margin-top: -1.5px;'
	}));
	$("#projectNameContainer").append($.create('div', {
		'id' : 'projectName',
		'class' : 'inactiveField editField settingsField'
	}));
	
	$("#settingsContent").append($.create('div', {
		'id' : 'tableTypeDiv',
		'class' : 'hidden'
	}));
	
	$("#tableTypeDiv")
			.append(
					$
							.create(
									'select',
									{
										'id' : 'tableType',
										'style' : 'width:200px;height:30px;'
									}));


	var configItems = '';

	configItems += '<div style="display:none" id="configDialog" title="Configuration">';
	configItems += '<h3>Default setting for the experiment</h3>';
	configItems += '<form id="configForm">';
	configItems += '<p>Please specify the mode of handling for samples that did not generate a Ct value:</p>';
	// if (Project.IN.missingValue==-1){
	// configItems += '<input type="radio" id="missingValueMode1"
	// name="missingValueMode" value="-1" checked/>Exclude from analysis<br />';
	// configItems += '<input type="radio" id="missingValueMode2"
	// name="missingValueMode" value="1"/>Replace with the following value:';
	// configItems += ' <input id="missingValueNumber" name="missingValueNumber"
	// size=5 value="'+Project.IN.defaultMissingValue+'"><br>';
	// }else{
	// configItems += '<input type="radio" id="missingValueMode1"
	// name="missingValueMode" value="-1" />Exclude from analysis<br />';
	// configItems += '<input type="radio" id="missingValueMode2"
	// name="missingValueMode" value="1" checked/>Replace with the following
	// value:';
	// configItems += ' <input id="missingValueNumber" name="missingValueNumber"
	// size=5 value="'+Project.IN.missingValue+'"><br>';
	// }
	configItems += '<input type="radio" id="missingValueMode1" name="missingValueMode" value="-1" />Exclude from analysis<br />';
	configItems += '<input type="radio" id="missingValueMode2" name="missingValueMode" value="1" checked/>Replace with the following value:';
	configItems += ' <input id="missingValueNumber" name="missingValueNumber" size=5 value="' + Project.IN.missingValue + '"><br>';
	configItems += '<br>Flag CT value where CV is &gt; <input id="covarianceConfig" name="covarianceConfig" size=5 value="' + Project.IN.coVarianceValue + '">%<br>';
	configItems += '<br>No. of replicates for each sample, per gene = <select id="noOfReplicates" name="noOfReplicates"><option value="0">1</option>'+ 
		'<option value="1" selected>2</option><option value="2">3</option></select><br>';
	//configItems += '<br>Gene batch creation size: <input id="batchCreationValueConfig" name="covarianceConfig" size=5 value="' + Project.IN.batchCreationValue + '"><br>';
	configItems += '</form>';
	configItems += '</br></div>';

	$('#settingsButton')
			.live(
					'click',
					function() {
						$('#configDialog')
								.dialog(
										{
											bgiframe : true,
											resizable : true,
											modal : true,
											width : 450,
											height : 370,

											overlay : {
												backgroundColor : '#000',
												opacity : 0.5
											},

											buttons : {
												'save' : function() {

													if ($(
															'#missingValueMode1:checked')
															.val() == -1) {// checked
														Project.IN.missingValue = -1;
														// this.setMissingValue(-1);
													} else {
														Project.IN.missingValue = $(
																'#missingValueNumber')
																.val();
														// this.setMissingValue($('#missingValueNumber').val());
													}
													// this.setCoVarianceValue($('#covarianceConfig').val());
													Project.IN.coVarianceValue = $(
															'#covarianceConfig')
															.val();
													Project.IN.batchCreationValue = $(
															'#batchCreationValueConfig')
															.val();
													Project.IN.noOfReplicates = $('#noOfReplicates').val();
													$(this).dialog('close');
												},
												'close' : function() {
													$(this).dialog('close');
												}
											}

										});
					});
	
	$('#saveButton').live(
			'click',
			function() {
				if (downloadType == 0){
					$.post("saveTemplateJson", {
						templateJson: processJSON(project),
						experimentID: project.experimentID,
						experimentName: project.projectName
					}, function(data) {
						Project.IN.experimentID = data;
						$("#saveLabel").removeClass('hidden');
						setTimeout('$("#saveLabel").addClass("hidden")',1500);
						//alert('saved type: '+downloadType +" Project.IN.experimentID="+Project.IN.experimentID);
					});
				}else{
					$.post("service/saveWholeExperiment", {
						experimentID: project.experimentID,
						layoutID: project.layoutID,
						experimentName: project.projectName,
						layoutJson: processJSON(project)
					}, function(data) {
						//alert('save layout ID: '+data);
						Project.IN.layoutID = data;
						$("#saveLabel").removeClass('hidden');
						setTimeout('$("#saveLabel").addClass("hidden")',1500);
						//alert('saved type: '+downloadType +" Project.IN.layoutID="+Project.IN.layoutID);
					});
				}
			}
	);
	
	$('#printButton').live(
			'click',
			function() {
//				if (downloadType == 3){
//					$("#mainpane").jqprint({ operaSupport: true }); 
//				}else{	
//					$("#wren_main").jqprint({ operaSupport: true }); 
//				}
				$("#mainBody").jqprint({ operaSupport: true }); //print other div cause lost of some css
			}
	);
	
	$('#viewButton').live(
			'click',
			function() {
				if (project.experimentID>0){
					$.post("listExperimentGenes", {
						experimentID: project.experimentID
					}, function(data) {
						var myLayouts = $.fromJsonRef(data);
						var allDetailStr = '';
						$(myLayouts).each(
							function() {
								var layout = this;
								allDetailStr +=layout.name+"&nbsp;&nbsp;&nbsp;"+layout.modifiedDate;
								var referenceGenes = layout.referenceGenes;
								$(referenceGenes).each(
										function() {
											var gene = this;
											allDetailStr +='<ul>ReferenceGene: '+gene+"</ul>";
										}
								);
								var targetGenes = layout.targetGenes;
								$(targetGenes).each(
										function() {
											var gene = this;
											allDetailStr +='<ul>TargetGene: '+gene+"</ul>";
										}
								);
								allDetailStr +='<br><br>\n';
						});
						
						document.getElementById('experimentDetainDialog').innerHTML = allDetailStr;
						$('#experimentDetainDialog').dialog( {
							bgiframe : false,
							resizable : true,
							modal : true,
							width : 600,
							height : 600,
							overlay : {
								backgroundColor : '#000',
								opacity : 0.5
							}
								});
					});
				}else{
					document.getElementById('experimentDetainDialog').innerHTML = 'New Experiment. No Gene information.';
					$('#experimentDetainDialog').dialog( {
						bgiframe : false,
						resizable : false,
						modal : true,
						width : 250,
						height : 100,
						overlay : {
							backgroundColor : '#000',
							opacity : 0.5
						}
							});
				}
				
			});


	// $("#settingsContent").append($.create('div', {
	// 'id': 'loading',
	// 'style':'position:relative;height:32px; display:none; float:left;
	// padding-right:40px; min-width: 200px; max-width: 200px;'
	// }));
	// var items = '<img src="images/loading.gif" /> Please Wait';
	// $('#loading').append(items);

	$("#tableTypeDiv")
			.append(
					$
							.create(
									'div',
									{
										'id' : 'exclusions',
										'style' : 'float:right;position:relative;display:inline;width:100px;height:30px;'
									}));
	$("#exclusions").append($.create('div', {
		'id' : 'exclusionHidden',
		'class' : 'hidden'
	}, [ "Title here" ]));

	$("#exclusionHidden").append($.create('div', {
		'id' : 'exclusionHeader'
	}, [ "Title here" ]));

	$("#exclusionHidden").append($.create('p', {
		'id' : 'exclusionContent',
		'style' : 'width:500px'
	}));

	$("#exclusions")
			.append($.create(
									'button',
									{
										'id' : 'exclusionButton',
										'style' : 'float:right;position:relative;width:100px;height:30px;',
										'class' : 'button red hidden'
									}, [ 'Exclusions' ]));

	$("#exclusions").append($.create('div', {
		'id' : 'exclusionHidden',
		'class' : 'hidden'
	}, [ "Title here" ]));

	$("#exclusionHidden").append($.create('div', {
		'id' : 'exclusionHeader'
	}, [ "Title here" ]));

	$("#exclusionHidden").append($.create('p', {
		'id' : 'exclusionContent',
		'style' : 'width:500px'
	}));

	$('#exclusionButton').live('click', function() {
		if ($("#exclusionTable").is(":hidden")) {
			$('#exclusionButton').addClass('activeButton');
			// $('#exclusionButton').html('close exclusion');
			// $("#exclusionTable").addClass('activeButton');
			$("#wren_main").slideUp(
					'fast',
					function() {
						$("#exclusionTable").slideDown();
						$("#webOutput").slideUp();
						if (Project.IN.exclusion.firstRun
								|| Project.IN.exclusion.refresh) {
							$("#exclusionTable td").removeClass('greenShadow');
							$("#exclusionTable td").addClass('redShadow');
							Project.IN.exclusion.addTableDragToSelect();
							Project.IN.exclusion.firstRun = false;
							Project.IN.exclusion.refresh = false;
						}
						// $('#exclusionButton').addClass('active');
					});
		} else {
			$('#exclusionButton').removeClass('activeButton');
			$("#exclusionTable").slideUp('fast', function() {
				if (isShowOutput) {
					$("#webOutput").slideDown();
				} else {
					$("#wren_main").slideDown();
				}

			});
		}
	});

	$('#settingsContent').append(configItems);

//	var excludeDialog = '';
//	excludeDialog += '<div style="display:none;" id="exclusiveDialog">Excluded</div>';
//
//	$('#settingsContent').append(excludeDialog);
	
	var experimentDetainDialog = '';
	experimentDetainDialog += '<div style="display:none" title="Experiment Gene Information" id="experimentDetainDialog">experimentDetainDialog</div>';

	$('#settingsContent').append(experimentDetainDialog);

	$("#projectName").append(Project.IN.projectName);
	$("#projectName").editInPlace( {
		bg_over : '',
		bg_out : 'inactiveField',
		preinit : function() {
			$(this).removeClass('inactiveField');
		},
		callback : function() {
			var text = $("#projectName").text();
			Project.IN.setProjectName(text);
			return text;
		},
		postclose : function() {
			$(this).addClass('inactiveField');
		}
	});

	$('#tableType')
			.append('<option value="0" >cDNA or PCR (96 Wells)</option>');
	$('#tableType').append('<option value="1" >PCR (384 Wells)</option>');
	$('#tableType').selectBox( {
		'menuTransition' : 'fade'
	}).change(function(e) {
		e.stopPropagation();
		e.preventDefault();
		Project.IN.setTableType($(this).val());
	});
	if (this.tableType==0){
    	$('#tableType').selectBox('value', "0");
    }else{
    	$('#tableType').selectBox('value', "1");
    }
	// TODO; remove by Qina

	// $("#settingsButton").live('click', function(){
	// $('#settings').slideToggle();
	// //$('#wren_main').slideToggle();
	// });
	$("#header").after("<br />");

	$(".button-back").button( {
		icons : {
			primary : "ui-icon-triangle-1-w"
		}
	});

	$(".button-next").button( {
		icons : {
			secondary : "ui-icon-triangle-1-e"
		}
	});

}

// sets the download button on the top and knows when to show/hide the settings
function setDownloadButton(id) {
	$('#exclusionButton').removeClass('activeButton');
	$("#exclusionTable").slideUp('fast', function() {
		$("#wren_main").slideDown();
	});
	isShowOutput = false;
	//alert('xxsetDownloadButton='+id);
	switch (id) {
	case 1: //not used, redirect to home page
		downloadType = -1;
		window.location = 'index';
		break;
	case 2:
		downloadType = 0;
		$("#returnType").val('template');
		$("#tableTypeDiv").addClass('hidden');
		//$("#exclusionButton").addClass('hidden');
		if (DEBUG){
			$("#downloadButton").html('Download Template');
			$("#downloadButton").removeClass('hidden');
		}
		$("#settingsButton").removeClass('hidden');
		$("#saveButton").removeClass('hidden');
		$("#webOutput").slideUp();
		break;
	case 3:
		//alert('xxlayout UI case 3:  '+(Project.IN.layout.data.length - Project.IN.refGeneCount)+" Project.IN.experimentUpdateTypeID="+Project.IN.experimentUpdateTypeID);
		//alert('case 3');
		if ((Project.IN.layout.data.length - Project.IN.refGeneCount)==0 && 
				(Project.IN.experimentUpdateTypeID!='editLayout' || (Project.IN.showSetting))){
			$('#settingsButton').click();
		}
		if (DEBUG){
			$("#downloadButton").html('Download Template');
			$("#downloadButton").removeClass('hidden');
		}
		$("#exclusionButton").removeClass('hidden');
		$("#tableTypeDiv").removeClass('hidden');
		downloadType = 1;
		$("#returnType").val('layout');
		$("#saveButton").removeClass('hidden');
		$.post("saveTemplateJson", {
			templateJson: processJSON(project),
			experimentID: project.experimentID,
			experimentName: project.projectName
		}, function(data) {
			project.experimentID = data;
		});
			
		$("#settingsButton").removeClass('hidden');
		$("#webOutput").slideUp();
		//Project.IN.layout.table.reloadPaintedExclusionElements(Project.IN);
		
		break;
	case 4:
		//alert('case 4 save whole experiment');
		if (Project.IN.experimentUpdateTypeID=='newLayoutExistingExperiment' || Project.IN.experimentUpdateTypeID=='editTemplate'){
			Project.IN.layoutID = -1;
		}
		
		if (Project.IN.layoutID>0){
			$("#reCalculateButton").removeClass('hidden');
		}
			downloadType = 2;
			
			$.post("service/saveWholeExperiment", {
				experimentID: project.experimentID,
				layoutID: project.layoutID,
				experimentName: project.projectName,
				layoutJson: processJSON(project)
			}, function(data) {
				Project.IN.layoutID = data;
			});
			$("#returnType").val('calculate');
			$("#downloadButton").html('Download Calculations');
			$("#saveButton").addClass('hidden');
			$("#downloadButton").addClass('hidden');
			//$("#exclusionButton").addClass('hidden');
			$("#tableTypeDiv").addClass('hidden');
			// $("#downloadButton").removeClass('hidden');
			$("#settingsButton").removeClass('hidden');
			$("#webOutput").slideUp();
			calculate();
			
		break;
	case 5:
		downloadType = 3;
		$("#returnType").val('calculate');
		//$("#returnType").val('result');
		$("#downloadButton").html('Download Calculations');
		// $("#downloadButton").addClass('hidden');
		$("#downloadButton").removeClass('hidden');
		$("#saveButton").addClass('hidden');
		//$("#exclusionButton").addClass('hidden');
		$("#tableTypeDiv").addClass('hidden');
		$("#settingsButton").removeClass('hidden');
		$("#webOutput").slideDown();
		$("#wren_main").slideUp();
		isShowOutput = true;
		break;
	}
}

function calculate() {
	$('#calculate_overlay').styleBlock($("#calculate_buttons"), 300);
	$('#calculate_overlay .blockMsg').css("top", 140).css("left", 275);
	$('#back2').live('click', function() {
		('#calculate_overlay').styleBlock($("#calculate_buttons"), 300);
	});
}

function removeHash(name) {
	return name.substring(1);
}

function addExclusion(ele, data, msg) {
	if (ele.innerHTML=='(excluded)'){
		ele.innerHTML=msg;
		project.exclusionsTable.dragTileGroupExclusion(data, false);
	}else{
		ele.innerHTML='(excluded)';
		project.exclusionsTable.dragTileGroupExclusion(data, true);
	}
	
}

function reCalculate(savedLayoutID) {
	document.uploadDataForm.projectObject.value = processJSON(project);
	document.uploadDataForm.experimentID.value = Project.IN.experimentID;
	Project.IN.layoutID = savedLayoutID;
	document.uploadDataForm.layoutID.value = Project.IN.layoutID;
	$("#uploadDataForm").submit();
}

