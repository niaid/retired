(function($)
{
    $.fn.blink = function(options)
    {
        var defaults = {
            delay:500, 
            data:null
        };
        var options = $.extend(defaults, options);
		
        return this.each(function()
        {
            var obj = $(this);
            setInterval(function()
            {

                if($(obj).hasClass('blink') & options.data.length == 0){
                    $(obj).switchClass( "blink", "activeGreenButton");
                } else {
                    $(obj).switchClass( "activeGreenButton", "blink");
                }
                        
                        
                        
            }, options.delay);
        });
    }
}(jQuery))