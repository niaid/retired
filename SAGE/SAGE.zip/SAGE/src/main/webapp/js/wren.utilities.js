//<![CDATA[
            
function cloneObject(source) {
    for (i in source) {
        if (typeof source[i] == 'source') {
            this[i] = new cloneObject(source[i]);
        }
        else{
            this[i] = source[i];
        }
    }
}

function processJSON(projectData){
    var out = {};
    if(downloadType == 0){
        out.groups = projectData.groups;
        out.templateTable = projectData.templateTable;
    }
    
    //modify the information here!

    return $.toJsonRef(projectData);
    
}

jQuery.fn.reloadAccoridon = function (accordion) {
    var selector = this;
    var module = accordion.module;
    $(selector).data('stop', false);
    $(selector).accordion('destroy').accordion({
        header: "> div > h3",
        active: accordion.module.active,
        clearStyle: true,
        collapsible: true,
        event: 'click',
        change: function(){
	    	
            var active = $(selector).accordion( "option", "active" );
            module.active = active;
            var myActive = ''+active;//add this to distinct false and 0
            if(myActive!='false'){
                $("#" + module.dataIndex[active] + "_radio").prop({
                checked: true
                });
                module.setActiveElement(module.data[active]);
            }
            if (!Project.IN.canModifyTemplate && module.element.shortName == 'Group'){
	    		alert('Warning: Template is not editable');
	    	}
        }
    }).sortable({
        axis: "y",
        handle: "h3",
        stop: function() {
            $(selector).data('stop', true);
        },
        update: function(){
            var result = $(this).sortable('toArray');
            var newStructure = {};
            for(var i = 0; i < result.length; i++){
                var id = result[i].split('_')[0];
                newStructure[id + ""] = i;
            }
            function sortID(a, b){
                var aI = newStructure[a.id];
                var bI = newStructure[b.id];
                if(aI < bI){
                    return -1;
                }
                if(aI > bI){
                    return 1;
                }
                return 0;
            }
            
            var oldID = module.dataIndex[module.active];
            module.data.sort(sortID);
            module.rebuildDataStructure();
            module.active = newStructure[oldID];
            $(selector).reloadAccoridon(accordion);
            module.reloadPattern();
        }
    });
    
    $(selector).find('h3').click(function(event) {
        if ($(selector).data('stop')) {
            event.stopImmediatePropagation();
            event.preventDefault();
            $(selector).data('stop', false);
        }
    });
    
    $(selector).find('h3').each(function(){
        var id = $(this).attr('id');
        if(module.element.showIndexInName()){
            if (module.getElementWithID(id)!=null){
                $("#" +  id + "_name").text((parseInt(module.dataID[id]) + 1) + ": " + module.getElementWithID(id).name);
            }else{
                $("#" +  id + "_name").text('XXXShowIndexInName'+id);
            }
            
        } else {
            if (module.getElementWithID(id)!=null){
                $("#" +  id + "_name").text(module.getElementWithID(id).name);
            }else{
                $("#" +  id + "_name").text('XXX'+id);
            }
            
        }
                            
        $("#" +  id + "_name").text($("#" +  id + "_name").text().replace(/(\S{19})/g, '$1 '));

    });
    
    $(selector).disableTextSelect();
    
}


jQuery.fn.toggleEnabled = function () {
    this.toggleClass('ui-state-disabled');
    this.toggleClass('ui-button-disabled');
    this.toggleAttr('disabled');
    
}

jQuery.fn.toggleAttr = function (attr) {
    if(this.attr(attr)){
        this.attr(attr, false);
    } else {
        this.attr(attr, true);
    }
    
}


jQuery.fn.styleBlock = function (mess, width) {
    if(width == null){
        this.block({
            message: mess,
            css: {
                border: 'none', 
                padding: '15px', 
                backgroundColor: '#000', 
                '-webkit-border-radius': '10px', 
                '-moz-border-radius': '10px', 
                opacity: .5, 
                color: '#fff'
            }
        });
    } else {
        this.block({
            message: mess,
            css: {
                border: 'none', 
                padding: '15px', 
                backgroundColor: '#000', 
                '-webkit-border-radius': '10px', 
                '-moz-border-radius': '10px', 
                opacity: .5, 
                color: '#fff',
                width: width + 'px'
            }
        });
    }
 
    
}

$.styleBlockScreen = function (mess) {
    this.blockUI({
        message: mess,
        css: {
            border: 'none', 
            padding: '15px', 
            backgroundColor: '#000', 
            '-webkit-border-radius': '10px', 
            '-moz-border-radius': '10px', 
            opacity: .5, 
            color: '#fff'
        }
    });
 
    
}

function integerToLetter(index) {
    var letter = ' ';
    switch (index) {
        case 0:
            letter = 'A';
            break;
        case 1:
            letter = 'B';
            break;
        case 2:
            letter = 'C';
            break;
        case 3:
            letter = 'D';
            break;
        case 4:
            letter = 'E';
            break;
        case 5:
            letter = 'F';
            break;
        case 6:
            letter = 'G';
            break;
        case 7:
            letter = 'H';
            break;
        case 8:
            letter = 'I';
            break;
        case 9:
            letter = 'J';
            break;
        case 10:
            letter = 'K';
            break;
        case 11:
            letter = 'L';
            break;
        case 12:
            letter = 'M';
            break;
        case 13:
            letter = 'N';
            break;
        case 14:
            letter = 'O';
            break;
        case 15:
            letter = 'P';
            break;
        case 16:
            letter = 'Q';
            break;
        case 17:
            letter = 'R';
            break;
        case 18:
            letter = 'S';
            break;
        case 19:
            letter = 'T';
            break;
        case 20:
            letter = 'U';
            break;
        case 21:
            letter = 'V';
            break;
        case 22:
            letter = 'W';
            break;
        case 23:
            letter = 'X';
            break;
        case 24:
            letter = 'Y';
            break;
        case 25:
            letter = 'Z';
            break;

    }
    return letter;
}

function letterToInteger(c) {
    var num = -1;
    switch (c) {
        case 'A':
            num = 0;
            break;
        case 'B':
            num = 1;
            break;
        case 'C':
            num = 2;
            break;
        case 'D':
            num = 3;
            break;
        case 'E':
            num = 4;
            break;
        case 'F':
            num = 5;
            break;
        case 'G':
            num = 6;
            break;
        case 'H':
            num = 7;
            break;
        case 'I':
            num = 8;
            break;
        case 'J':
            num = 9;
            break;
        case 'K':
            num = 10;
            break;
        case 'L':
            num = 11;
            break;
        case 'M':
            num = 12;
            break;
        case 'N':
            num = 13;
            break;
        case 'O':
            num = 14;
            break;
        case 'P':
            num = 15;
            break;
        case 'Q':
            num = 16;
            break;
        case 'R':
            num = 17;
            break;
        case 'S':
            num = 18;
            break;
        case 'T':
            num = 19;
            break;
        case 'U':
            num = 20;
            break;
        case 'V':
            num = 21;
            break;
        case 'W':
            num = 22;
            break;
        case 'X':
            num = 23;
            break;
        case 'Y':
            num = 24;
            break;
        case 'Z':
            num = 25;
            break;

    }
    return num;
}

function changeColor() {
    var g = '#' + Math.floor(Math.random() * 16777215).toString(16);
    return g;
}
function randomColor() {
    return 'rgb(' + Math.round(Math.random() * 255) + ', ' + Math.round(Math.random() * 255) + ', ' + Math.round(Math.random() * 255) + ')'
}

function HSBToRGB(hsb) {
    var rgb = {};
    var h = Math.round(hsb.h);
    var s = Math.round(hsb.s*255/100);
    var v = Math.round(hsb.b*255/100);
    if(s == 0) {
        rgb.r = rgb.g = rgb.b = v;
    } else {
        var t1 = v;
        var t2 = (255-s)*v/255;
        var t3 = (t1-t2)*(h%60)/60;
        if(h==360) h = 0;
        if(h<60) {
            rgb.r=t1;
            rgb.b=t2;
            rgb.g=t2+t3
        }
        else if(h<120) {
            rgb.g=t1;
            rgb.b=t2;
            rgb.r=t1-t3
        }
        else if(h<180) {
            rgb.g=t1;
            rgb.r=t2;
            rgb.b=t2+t3
        }
        else if(h<240) {
            rgb.b=t1;
            rgb.r=t2;
            rgb.g=t1-t3
        }
        else if(h<300) {
            rgb.b=t1;
            rgb.g=t2;
            rgb.r=t2+t3
        }
        else if(h<360) {
            rgb.r=t1;
            rgb.g=t2;
            rgb.b=t1-t3
        }
        else {
            rgb.r=0;
            rgb.g=0;
            rgb.b=0
        }
    }
    return {
        r:Math.round(rgb.r), 
        g:Math.round(rgb.g), 
        b:Math.round(rgb.b)
    };
}
function RGBToHex(rgb) {
    var hex = [
    rgb.r.toString(16),
    rgb.g.toString(16),
    rgb.b.toString(16)
    ];
    $.each(hex, function (nr, val) {
        if (val.length == 1) {
            hex[nr] = '0' + val;
        }
    });
    return hex.join('');
}
function HSBToHex(hsb) {
    return RGBToHex(HSBToRGB(hsb));
}


function hsb2hex(h, s, b){
    var hsb = {};
    hsb.h = h;
    hsb.s = s;
    hsb.b = b;
    return HSBToHex(hsb);
}

function rgbToHex(rgb) {
    return "#" + ((1 << 24) + (rgb[0] << 16) + (rgb[1] << 8) + rgb[2]).toString(16).slice(1);
}

function rgb2hex(rgb) {
    rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    function hex(x) {
        return ("0" + parseInt(x).toString(16)).slice(-2);
    }
    return "#" + hex(rgb[0]) + hex(rgb[1]) + hex(rgb[2]);
}

//make sure the text contrasts the color of the header
function getBrightness(hex) {
    var hex = hex.replace('#','');
    var c_r = hexDec(hex.substr(0, 2));
    var c_g = hexDec(hex.substr(2, 2));
    var c_b = hexDec(hex.substr(4, 2));
    var num = ((c_r * 299) + (c_g * 587) + (c_b * 114)) / 1000;
    return num;
}
 
function hexDec(hex_string){
    hex_string = (hex_string+'').replace(/[^a-f0-9]/gi, '');
    return parseInt(hex_string, 16);
}


function print(stuff){
    if(!((lastPrint=="" || lastPrint=="<br>") && stuff=="<br>")){
        $("#test").append(stuff + " ");
        lastPrint = stuff;
    }
}

function printC(stuff){
    $("#test").html(stuff);
}

function printObject(o) {
    var out = '';
    for (var p in o) {
        out += p + ': ' + o[p] + '\n';
    }
    print(out);
}

$.extend($.fn.disableTextSelect = function() {
    return this.each(function(){
        if($.browser.mozilla){//Firefox
            $(this).css('MozUserSelect','none');
        }else if($.browser.msie){//IE
            $(this).bind('selectstart',function(){
                return false;
            });
        }else{//Opera, etc.
            $(this).mousedown(function(){
                return false;
            });
        }
    });
});
           
//]]>
