$.Class.extend("Project",{
    firstRun: true,
    IN: null,
    defaultColor:'DDEEFF',
    defaultHighlightColor:'A8EB92',
    defaultMissingValue: 40,
    defaultCoVarianceValue: 2,
    defaultBatchCreationValue: 8,
    defaultNoOfReplicates: 1, //default double
    defaultProjectName: 'Untitled Experiment',
    defaultWorksheetName: 'Untitled Worksheet'
    
},{
    init: function(){
        Project.IN = this;
        this.experimentID = -1;
        this.layoutID = -1;
        this.workSheetName = Project.defaultWorksheetName;
        this.projectName = Project.defaultProjectName;
        this.missingValue = Project.defaultMissingValue;
        this.coVarianceValue = Project.defaultCoVarianceValue;
        this.batchCreationValue = Project.defaultBatchCreationValue;
        this.noOfReplicates = Project.defaultNoOfReplicates;
        this.groups = new Array();
        this.genes = new Array();

        this.templateTable = new Table(0);
        this.layoutTable = new Table(0);
        this.exclusionsTable = new Table(0);
        this.calculationsTable = new Table(0);

        this.template = new Module(Group);
        this.layout = new Module(Gene);
        this.exclusion = new Module(Exclusion);

        this.tableType = 1;//TODO:: default 384 wells, done
        
        this.data = {};
        
        this.colorArray = [ "ff9999", "9a94eb", "ffff33", "66ccff" , "cc6600" , "669900", "6633ff",
        "e01b4c", "1be07e", "e0bc1b", "1b30bc" , "a41bbc" , "bcb91b", "8c551b",
        "4ce01b", "7e1be0", "1be0bc", "bc1b30" , "bca41b" , "1bbcb9", "9fc83f",
        "99ff99", "eb9a94", "33ffff", "ff66cc" , "00cc66" , "026699", "ff6633"];
    
        this.colorIndex = 0;
        this.groupIndex = 1;
        this.geneIndex = 0;
        this.refGeneCount = 0;
        this.experimentUpdateTypeID = '';
        this.mainOptionType = -1;
        this.firstSetTableType = true;
        this.canModifyTemplate = true;
        this.prePatternType = 0;
        this.editing = false;
        this.showSetting = false;
    },
    setProjectName: function(projectName){
        this.projectName = projectName;
    },
    setMissingValue: function(missingValue){
        this.missingValue = missingValue;
    },
    setCoVarianceValue: function(coVarianceValue){
        this.coVarianceValue = coVarianceValue;
    },
    setBatchCreationValue: function(batchCreationValue){
        this.batchCreationValue = batchCreationValue;
    },
    setTableType: function(val){
        val = parseInt(val);
        //var originalTableType = this.tableType;
        this.tableType = val;
        this.changeTableSizes(val);
        this.layout.changeTable();
        //the following keeps the exclusion in back/next, but the underlying json object is outdated
//        if (val!=originalTableType || Project.IN.firstSetTableType){
//        	this.exclusion.changeTable();
//        }
//        Project.IN.firstSetTableType = false;
        this.exclusion.changeTable();
        if($("#wren_main").is(":hidden")){
            this.exclusion.addTableDragToSelect();
            $("#exclusionTable td").removeClass('greenShadow');
            $("#exclusionTable td").addClass('redShadow');
        } else {
            this.exclusion.refresh = true;
        }
        this.layout.reloadPattern();

    },
    getTableType: function(){
        return this.tableType;
    },
    changeTableSizes: function(i){
        this.layoutTable = new Table(i);
        this.exclusionsTable = new Table(i);
        this.calculationsTable = new Table(i);
    },
    setProjectData: function(data){
        //this method makes template UI shows colored table
        //makes layout UI NOT showing colored table
        this.projectName = data.projectName;
        this.missingValue = data.missingValue;
        this.coVarianceValue = data.coVarianceValue;
        this.batchCreationValue = data.batchCreationValue;
        if (this.batchCreationValue == undefined){
        	this.batchCreationValue = Project.defaultBatchCreationValue;
        }
        this.tableType = data.tableType;
        if (this.tableType==0){
        	$('#tableType').selectBox('value', "0");
        }
    }
    
});

$.Class.extend("Element",{
    isAccordionEnabled: function(){
        return true;
    },
    isSelectionEnabled: function(){
        return true;
    },
    isColorEnabled: function(){
        return false;
    },
    isPatternEnabled: function(){
        return false;
    },
    showIndexInName: function(){
        return false;
    },
    getStepType: function(){
        return "element"
    },
    getRadioArray: function(){
        return this.getData();
    },
    getRadioOptions: function(){
        return null;
    },
    loadExtra: function(){
        return null;
    }
},{
    init: function(id, name, type, number){
        //TODO:: replace random number
        this.id = (id != null) ? id:parseInt(Math.random()*100000);
        if (this.Class.shortName == 'Group'){
            number = Project.IN.groupIndex++;
        }else{
            number = Project.IN.geneIndex++;
        }
        
        this.name = (name != null) ? name:this.Class.shortName+' '+number;
        this.type = (type != null) ? type:1; //TODO:: set default as test
        this.controlID = -1;
    }
});

Element.extend("Group",{
    isColorEnabled: function(){
        return true;
    },
    getTable: function(){
        return Project.IN.templateTable;
    },
    getData: function(){
        //TODO:: should has a better way to do it
        var controlID = null;
//        for(var i = 0; i < Project.IN.groups.length; i++){
//            if (Project.IN.groups[i].type == 0 || Project.IN.groups[i].type == "0"){
//                controlID = Project.IN.groups[i].id;
//                Project.IN.groups[i].controlID = -1;
//            }else if (Project.IN.groups[i].type == 1){
//            	if (Project.IN.groups[i].o!=undefined){//did not use default reference group
//                    Project.IN.groups[i].controlID = Project.IN.groups[i].o;//do not know why it's o
//                }else if (Project.IN.groups[i].controlID==-1 && controlID!=-1){
//                    Project.IN.groups[i].controlID = controlID;
//                }
//            } 
//        //alertstr+="\n"+Project.IN.groups[i].name+": type: "+Project.IN.groups[i].type+" id: "+Project.IN.groups[i].controlID;
//        }
        
        for(var i = 0; i < Project.IN.groups.length; i++){
            if (controlID==null && Project.IN.groups[i].type == 0 || Project.IN.groups[i].type == "0"){
                controlID = Project.IN.groups[i].id;
                Project.IN.groups[i].controlID = -1;
            }else if (Project.IN.groups[i].type == 1 && controlID!=-1){
                if (Project.IN.groups[i].o!=undefined){//did not use default reference group
                    Project.IN.groups[i].controlID = Project.IN.groups[i].o;//do not know why it's o
                }else if (Project.IN.groups[i].controlID==-1){
                    Project.IN.groups[i].controlID = controlID;
                }
            } 
        //alertstr+="\n"+Project.IN.groups[i].name+": type: "+Project.IN.groups[i].type+" id: "+Project.IN.groups[i].controlID;
        }
        
        
        
        
        return Project.IN.groups;
    },
    getStepType: function(){
        return "template"
    },
    getRadioButtons: function(){
        return new Array(
            new Array("Control","Test","Water")
            );
    },
    getRadioActions: function(){
        return new Array(
            new Array(0,"controlID",0)
            );
    },
    getRadioLocations: function(){
        return new Array(
            "type"
            );
    },
    getRadioOptions: function(){
        return new Array(
            new Array(true, false, false)
            );
    }
},{
    init: function(id, name, type, color){
        this._super(id, name, type);
        this.color = (color != null) ? color:Project.defaultHighlightColor;
        this.claimedTiles = new Array();
    }
});

Element.extend("Gene",{
    isSelectionEnabled: function(){
        return false;
    },
    isPatternEnabled: function(){
        return true;
    },
    showIndexInName: function(){
        return true;
    },
    getTable: function(){
        return Project.IN.layoutTable;
    },
    getData: function(){
        //TODO:: should has a better way to do it
        if (Project.IN.genes!=null){
            var controlID = null;
            for(var i = 0; i < Project.IN.genes.length; i++){
                if (Project.IN.genes[i].type == 0){
                    controlID = Project.IN.genes[i].id;
                }else if (Project.IN.genes[i].type == 1 && Project.IN.genes[i].controlID == -1 && controlID!=-1){
                    Project.IN.genes[i].controlID = controlID;
                }                
            }
        }
        return Project.IN.genes;
    },
    getStepType: function(){
        return "layout"
    },
    getRadioButtons: function(){
        return new Array(
            new Array("1","2","3"),//singles, doubles, triples
            new Array("Reference","Target")
            );
    },
    getRadioActions: function(){
        return new Array(
            new Array(0,0,0),
            new Array(0,"controlID")
            );
    },
    getRadioLocations: function(){
        return new Array(
            "replicates",
            "type"
            );
    },
    getRadioOptions: function(){
        return new Array(
            new Array(true, true, true),
            new Array(true, false)
            );
    }
},{
    init: function(id, name, type){
        this._super(id, name, type);
        this.replicates = Project.IN.noOfReplicates; //default is double == 1
        if (this.replicates != 1){//if not double
        	/*
        	 * 
        	 *  = new Array(
                    "By template horizontally",
                    "By template vertically (odd columns)",
                    "By template vertically (even columns)",
                    "By row of the template vertically (odd columns)",
                    "By row of the template vertically (even columns)",
                    "Compact"
                    
        	 */
        	if (Project.IN.prePatternType == 1){//By template vertically (odd columns)",
        		this.patternType = 2;//By template vertically (even columns)
        	}else if (Project.IN.prePatternType == 2){//By template vertically (even columns)
        		this.patternType = 1;//By template vertically (odd columns)",
        	}else if (Project.IN.prePatternType == 3){//By row of the template vertically (odd columns)",
        		this.patternType = 4;//By row of the template vertically (even columns)",
        	}else if (Project.IN.prePatternType == 4){//By row of the template vertically (even columns)",
        		this.patternType = 3;//By row of the template vertically (odd columns)",
        	}else{
        		this.patternType = 1;//By template vertically (odd columns)",
        	}
        	Project.IN.prePatternType = this.patternType;
        }else{
        	this.patternType = 0;
        }
        
        this.hidden = false;
    }
});

Element.extend("Calculation",{
    isAccordionEnabled: function(){
        return false;
    },
    getTable: function(){
        return Project.IN.calculationsTable;
    },
    getData: function(){
        return new Array();
    },
    getStepType: function(){
        return "calculations"
    }
},{
    init: function(id, name, type){
        this._super(id, name, type);
    }
});

Element.extend("Exclusion",{
    isAccordionEnabled: function(){
        return false;
    },
    isSelectionEnabled: function(){
        return true;
    },
    getTable: function(){
        return Project.IN.exclusionsTable;
    },
    getData: function(){
        return new Array();
    },
    getStepType: function(){
        return "exclusions"
    }
},{
    init: function(id, name, type){
        this._super(id, name, type);
        this.color = "eb6767";//red
    }
});


        
        
$.Class.extend("Module",{},{
    init: function(element){
        this.element = element;
        this.selector = parseInt(Math.random()*100) + "_" + element.getStepType() + "_module";
        if(element.isAccordionEnabled()){
            this.accordion = new Accordion(this);
        }
        this.table = element.getTable();
        this.data = element.getData();
        this.dataID = {};
        this.dataIndex = {};
        this.claimedTiles = new Array();
        this.layoutTiles = new Array();
        this.active = -1;
        this.activeID = -1;
        this.firstRun = true;
        this.activePatternID = -1;
        this.stop = false;
    },
    loadModule: function(selector){
        var module = this;
        var element = this.element;
        var table = this.table;
        var main_view = "#" + this.selector;
        var main_sidebar = "#" + this.selector + "_sidebar";
        var accordion_view = "#" + this.selector + "_accordion";
        var plusMultiGenes = "#" + this.selector + "_MultiGroupsPlus";//it is multiple genes
        var plus = "#" + this.selector + "_plus";
        var edit = "#" + this.selector + "_edit";
        var isGroup = false;
        if (element.shortName  == 'Group'){
            isGroup = true;
        } 
                
        //DEBUG, blank page
        //element.setSelectionEnabled(true);
        // module.addTableDragToSelect();
          
        if(element.isAccordionEnabled()){
            this.accordion.setSelector(accordion_view);
        }

        this.table.setModule(this);
        $(selector).append($.create('div', {
            'id':removeHash(main_view),
            'class':'main',
            'style':'position:relative;overflow:auto; min-height: 400px'
        }));

        if(!element.isAccordionEnabled()){
            $(main_view).css("width", 880);
        }

        if(element.isAccordionEnabled()){
            $(selector).append($.create('div', {
                'id':removeHash(main_sidebar),
                'class':'sidebar'
            }));
        }


        $(selector).append('<div id="spacer"></div>');
        $(main_view).append(table.getCode());
        this.refreshTable();
        
        //append part to table (layout controls)
        if(element.isPatternEnabled()){
            $("#" + this.selector).append($.create('div', {
                'id':this.selector + '_switcher',
                'class':'breadCrumb',
                'style': 'float:right;margin-top:5px;margin-bottom:5px;display:inline-block;height:auto;width: 605px;'
            }));
            $("#" + this.selector + "_switcher").append($.create('div', {
                'style': 'position:relative; width: 605px;'
            }));
            $("#" + this.selector + "_switcher div").append($.create('div', {
                'id': this.selector + '_switcherContent'
            }));

            $("#" + this.selector + "_switcherContent").append($.create('select', {
                'id': this.selector + '_data',
                'style':'float:left;position:relative;display:inline-block;width:169px;height:30px;line-height: 1.8;'
            }));
            $("#" + this.selector + "_switcherContent").append($.create('select', {
                'id': this.selector + '_pattern',
                'style':'float:right;position:relative;display:inline-block;width:349px;height:30px;line-height: 1.8;'
            }));
            $('#' + this.selector + '_data').selectBox({
                'menuTransition': 'fade'
            }).change(function(e){
                e.stopPropagation();
                e.preventDefault();
                var temp = module.getElementWithID(parseInt($(this).val()));
                module.activePatternID = temp.id;
                module.reloadPattern();
            });
            $('#' + this.selector + '_pattern').selectBox({
                'menuTransition': 'fade'
            }).change(function(e){
                e.stopPropagation();
                e.preventDefault();
                module.getElementWithID(module.activePatternID).patternType = parseInt($(this).val());
                module.reloadPattern();
            });
        }

        if(element.isAccordionEnabled()){
            $(main_sidebar).append($.create('div',{
                'id':removeHash(accordion_view + "_header"),
                'style':"height:" + $(main_view).height() + "px"
            }));
        }

        //only for accordion
        if(element.isAccordionEnabled()){
            $(accordion_view + "_header").append($.create('div',{
                'id':removeHash(accordion_view)
            }));
            
            //make elements scroll if overflow
            $(accordion_view + "_header").jScrollPane({
                autoReinitialise: true,
                enableKeyboardNavigation: false,
                hideFocus: true
            });

            $(main_sidebar).append($.create('div', {
                'id': this.selector + '_buttons',
                'style':'position:relative;margin-left:-2px;margin-top:2px;padding-bottom:10px;'
            }));
            
            if (element.shortName  == 'Gene'){
            	 $('#' + this.selector + '_buttons').append($.create('button', {
                     'id':removeHash(plusMultiGenes),
                     'class':'button green small'
                 } ,['fill']));
            }
           
            
            $('#' + this.selector + '_buttons').append($.create('button', {
                'id':removeHash(plus),
                'class':'button green small blink'
            } ,['+']));
            $('#' + this.selector + '_buttons').append($.create('button', {
                'id':removeHash(edit),
                'class':'button green small'
            } ,['edit']));
           
            
            //batchCreation button
            $(plusMultiGenes + '[disabled!=true]').livequery(function(){
                $(this).click(function(){
                    //TODO:: not work, if nothing in between $("#loading").show() and hide, then works
                    //$("#loading").fadeIn();
                	Project.IN.batchCreationValue = module.getMaxTemplateRow();
                    for(var i = 0; i < Project.IN.batchCreationValue; i++){
                        module.addElement();
                        module.accordion.addElementToAccordion(module.getLastElement(), false, false, true);
                        $("." + module.selector + "_depOption").removeAttr('disabled');
                        
                        //this step should be very fast
                        //this step cannot move out of loop
                        //moving out cause the accordion target option not selected
                        if(module.data.length == 1 || Project.firstRun){
                            $(edit).toggleEnabled();
                            $(accordion_view + "_header").unblock();
                            $(module.table.id).unblock();
                            $("#" + module.getLastElement().id + "_radio").prop({
                                checked: true
                            });
                                                
                            $("." + module.selector + "_depOption").attr('disabled', 'disabled');
                            if(Project.firstRun){
                                if(element.isSelectionEnabled()){
                                    module.addTableDragToSelect();
                                }
                                Project.firstRun = false;
                            }
                            module.setActiveElement(module.getLastElement());
                        } else {
                            $("." + module.selector + "_depOption").removeAttr('disabled');
                        }
                    } 
                           
                    //move some of the this function out of addElementToAccordion to improve performance
                    $(module.accordion.selector).reloadAccoridon(module.accordion);
                //module.accordion.updateColors();
                //module.recreateSelectBoxes();
                //TODO:: PERFORMANCE
                // module.reloadPattern();
                //$("#loading").fadeOut();

                });

            }, function(){
                $(this).unbind();
            }); ///stop plus
            //
            //
            
            //add button
            $(plus + '[disabled!=true]').livequery(function(){
                $(this).click(function(){
                    module.addElement();
                    module.accordion.addElementToAccordion(module.getLastElement(), true, true, true);
                    //TODO:: Project.firstRun???, for manuallhy adding refGene
                   // alert('!!!!add ');
                    if(module.data.length == 1 || Project.firstRun){
                    	
                    	//alert('module.data.length='+module.data.length+" Project.firstRun="+Project.firstRun);
                        $(edit).toggleEnabled();
                        $(accordion_view + "_header").unblock();
                        $(module.table.id).unblock();
                        $("#" + module.getLastElement().id + "_radio").prop({
                            checked: true
                        });
                        module
                        $("." + module.selector + "_depOption").attr('disabled', 'disabled');
                        if(Project.firstRun){
                            if(element.isSelectionEnabled()){
                                module.addTableDragToSelect();
                            }

                            Project.firstRun = false;
                        }
                    } else {
                    	//alert('add '+module.getLastElement());
                        $("." + module.selector + "_depOption").removeAttr('disabled');
                    }
                    module.setActiveElement(module.getLastElement());
                    var thisID = module.getLastElement().id;
                    $('input:radio[name=rdio][value='+thisID+']').click();
                });

            }, function(){
                $(this).unbind();
            }); ///stop plus


            
            $(edit + '[disabled!=true]').livequery(function(){
                $(this).click(function(e){
                	
//                	if (element.shortName  == 'Gene'){
//                		$('#'+Project.IN.layout.selector+'_data')[0].selectedIndex = 0;
//                		$('#'+Project.IN.layout.selector+'_data').selectBox('refresh');
//                	}
                    $(accordion_view).reloadAccoridon(module.accordion);
                    $(accordion_view + ' h3 a div').toggleClass('hidden');
                    //$('#accordion h3 button').toggleClass('hidden');
                    //$(accordion_view + ' h3 a form').toggleClass('hidden');
                    $(accordion_view + ' h3 span').toggle();
                    $(accordion_view + ' h3 span span').toggle();
                    $(accordion_view + '.ui-icon-triangle-1-e').toggle();
                    $(accordion_view + ' h3 a input').toggle();
                    //$(accordion_view + ' h3 a form input').toggleClass('hidden');
                    $(plus).toggleEnabled();
                    //$(accordion_view).jScrollPane('reinitialise');
                    var notEdit = ($(edit).text() == 'done');
                    var editing = !notEdit;
                    Project.IN.editing = editing;
                    if(editing){ //what we're about to do..
                        this.active = $(accordion_view).accordion( "option", "active" );
                        $(accordion_view).accordion( "option", "active", false );
                        $(edit).html('done');
                        $(accordion_view + ' h3').unbind('click');
                        $(accordion_view + ' h3').unbind('focus');
                        $(accordion_view + ' h3').unbind('blur');
                        $(accordion_view + ' h3').unbind('mouseout');
                        $(accordion_view + ' h3').unbind('mouseover');
                        $(accordion_view + ' h3').unbind('keydown');
                        $(accordion_view).unbind('remove');
                        $(accordion_view + ' h3 a').css('cursor','default');

                    }
                    else {
                        $(accordion_view + ' h3').each(function(){
                            var id = $(this).attr('id');
                            if(element.showIndexInName()){
                                $("#" +  id + "_name").text((parseInt(module.dataID[id]) + 1) + ": " + module.getElementWithID(id).name);
                            } else {
                                $("#" +  id + "_name").text(module.getElementWithID(id).name);
                            }
                            
                            $("#" +  id + "_name").text($("#" +  id + "_name").text().replace(/(\S{19})/g, '$1 '));


                        });
                        
                        $(edit).html('edit');
                        $(accordion_view).reloadAccoridon(module.accordion);
                        $(accordion_view).accordion( "option", "active", this.active);
                    // module.recreateSelectBoxes();
                    }
                    module.reloadPattern();
                });

            }, function(){
                $(this).unbind();
            });

            if(element.isSelectionEnabled() && element.isAccordionEnabled()){
                $(this.table.id +" td").live('mousedown', function() {
                    if(module.data.length == 0){
                        $(module.table.id).styleBlock("You have not selected a " + element.shortName + " yet!");
                    }
                });
            }
        } else {
            if(element.isSelectionEnabled()){
                module.addElement();
                module.setActiveElement(module.getLastElement());
            }
        }

        $('#colorSelector div').css('backgroundColor', Project.IN.defaultHighlightColor);
        //$(plusMultiGenes).addClass('hidden');
        if(module.data.length == 0){
            if(element.isAccordionEnabled()){
            	if (this.element.shortName == 'Gene'){//Group always create one by default
            		$(accordion_view + "_header").styleBlock("Add a new " + this.element.shortName + " below!", null);
            	}
                $(edit).toggleEnabled();
                $(plusMultiGenes).toggleEnabled();
                if (element.shortName  == 'Gene'){
                   $(plusMultiGenes).toggleEnabled();
                   // $(plusMultiGenes).removeClass('hidden');
                }
            }
        }
        module.element.loadExtra();
        module.reloadPattern();
    },
   
    rebuildDataStructure: function(){
        //creates a JSON object for easy access to index/id and vice versa 
        this.dataID = {};
        this.dataIndex = {};
        for(var i = 0; i < this.data.length; i++){
            this.dataID[this.data[i].id] = i;
            this.dataIndex[i] = this.data[i].id;
        }
    },
    changeTable: function(){
        $(this.table.id).replaceWith(this.element.getTable().getCode());
        this.table = this.element.getTable();
        this.table.setModule(this);

        this.refreshTable();
    },
    refreshTable: function(){
        var table = this.table;
        var tempWidth;
        if(this.element.isAccordionEnabled()){
            if(this.table.type == 0){
                tempWidth = 52.3333; //411
                $("#" + this.selector + "_accordion_header").css('height', 437);
            } else if(this.table.type == 1){
                tempWidth = 26.08;
                $("#" + this.selector + "_accordion_header").css('height', 389);
            }
        } else {
            if(this.table.type == 0){
                tempWidth = 60.1666
            } else if(this.table.type == 1){
                tempWidth = 32.5833
            }
        }


        $(this.table.id + ' td.tile').each(function(i){
            $(this).width(tempWidth);
            $(this).height(tempWidth * table.getWidthPercentage());

        });

    },
    
    getMaxTemplateRow :function(){
    	var maxTemplateRow = -1;//no of rows in the template
    	var maxLayoutRow = -1;
    	var canFillTimes = 0;
        var tableTils = Project.IN.templateTable.tiles;
        var exclusionTable = Project.IN.exclusion.table.tiles;
        if(typeof tableTils != "undefined"){
	        for(var i = 0; i < tableTils.length; i++){
	            for(var j = 0; j < tableTils[i].length; j++){
	                if(typeof tableTils[i][j]!='undefined' && tableTils[i][j] != 0 && exclusionTable[i][j] == 0){
	                	if (i > maxTemplateRow){
	                		maxTemplateRow = i;
	                	}
	                }
	            }
	        }
        }
        maxTemplateRow++;
        var layoutTils = Project.IN.layoutTable.tiles;
        if(typeof layoutTils != "undefined"){
	        for(var i = 0; i < layoutTils.length; i++){
	            for(var j = 0; j < layoutTils[i].length; j++){
	                if(typeof layoutTils[i][j]!='undefined' && layoutTils[i][j] != 0 && exclusionTable[i][j] == 0){
	                	if (i > maxLayoutRow){
	                		maxLayoutRow = i;
	                	}
	                }
	            }
	        }
        }
        maxLayoutRow++;//already filled rows
        var totalLayoutRow = Project.IN.layoutTable.row;//total table rows
	        if (maxTemplateRow!=0){
	        //TODO:: for best result, should take the layout type and replicate into calculation
	        if (Project.IN.tableType == 0){//if it's 96 cell, default by template and duplicate
	        	var myNoOfReplicates = 2;
	        	if (Project.IN.noOfReplicates == "1"){//double, default
	        		myNoOfReplicates = 2;
	        	}else if (Project.IN.noOfReplicates == "0"){//single
	        		myNoOfReplicates = 1;
	        	}else{//triple
	        		myNoOfReplicates = 3;
	        	}
	        	canFillTimes = (totalLayoutRow - maxLayoutRow) / (maxTemplateRow * myNoOfReplicates);
	      	    canFillTimes = Math.floor( canFillTimes ); //use the odd and even by cross
	        }else{//384 wells
	        	var myNoOfReplicates = 2;
	        	if (Project.IN.noOfReplicates == "1"){//double, default
	        		myNoOfReplicates = 2;
	        		canFillTimes = Math.floor((totalLayoutRow - maxLayoutRow) / (maxTemplateRow * myNoOfReplicates) * 2);
	        	}else if (Project.IN.noOfReplicates == "0"){//single
	        		myNoOfReplicates = 1;
	        		canFillTimes = Math.floor((totalLayoutRow - maxLayoutRow) / (maxTemplateRow * myNoOfReplicates)) * 2;
	        	}else{//triple
	        		myNoOfReplicates = 3;
	        		canFillTimes = Math.floor((totalLayoutRow - maxLayoutRow) / (maxTemplateRow * myNoOfReplicates)) * 2;
	        	}
	      	    //canFillTimes = Math.floor( canFillTimes ); //use the odd and even by cross
	        }
       }
       return canFillTimes;
    },
    recreateSelectBoxes: function(){ //make sure everything is selected by value and things are hidden if needed.
        //TODO:: do not know when need this
        var module = this;
        var moduleElement = module.element;
        var moduleLocations = moduleElement.getRadioLocations();
        var moduleActions = moduleElement.getRadioActions();
        var data = module.data;
        for(var i = 0; i < moduleElement.getRadioButtons().length; i++){
            for(var j = 0; j < moduleElement.getRadioButtons()[i].length; j++){
                for(var o = 0; o < data.length; o++){
                    var selectBox = '#' + i + '_' + data[o].id + '_selectBox';
                    var selectBoxHidden = '#' + i + '_' + j + '_' + data[o].id + '_selectBox_hidden';
                   
                    if(moduleActions[i][j] != 0){//moduleActions[i][j] == controlID
                        // alert('1BBB moduleActions['+i+']['+j+']='+moduleActions[i][j]+' data.length='+data.length+' data[o][moduleLocations[i]]='+data[o][moduleLocations[i]]);
                         
                        if(data.length == 1 && data[o][moduleLocations[i]] == j){//data[o][moduleLocations[i]] == j==>test
                            $(selectBoxHidden).addClass('hidden');
                            $(selectBoxHidden).next().css('display', 'none');
                            data[o][moduleLocations[i]] = 0;
                            data[o][moduleActions[i][j]] = -1;
                        // alert('1BBB -1');
                        } else if(data[o][moduleLocations[i]] == j){//data[o][moduleLocations[i]] == j==>test
                            //TODO:: set the selected option in selectBox
                            $(selectBoxHidden).removeClass('hidden');
                            $(selectBoxHidden).next().css('display', 'inline-block');
                            // alert('before '+$(selectBoxHidden).next().filter(':checked').val());
                            // $(selectBoxHidden).selectBox('setValue','Group 2');
                            $(selectBoxHidden).next().selectedIndex = 1;
                            


                           
                        // var selectedIndex = $(hiddenBox)[0].selectedIndex;
                        //$(selectBoxHidden).0.options.selectedIndex = 1;
                        // $('#' + i + '_' + j + '_' + data[o].id + '_selectBox_hidden option[text=Group2]').attr("selected", true);
                        // $("select[name=foo] option[text=bar]").attr("selected", true);
                            
                        }
                        $(selectBoxHidden).selectBox('refresh');
                    // $(selectBoxHidden).selectBox('value', data[o][moduleActions[i][j]]);/
                    //  alert('BBB #' + i + '_' + j + '_' + data[o].id + '_selectBox_hidden'+data[o][moduleActions[i][j]]);
                    }
                    $(selectBox).selectBox('refresh');
                // alert('selectBox'+$(selectBox).selectedIndex);
                //TODO::
                //
                // $(selectBox).selectBox('value', data[o][moduleLocations[i]]);//TODO:: setCOntrolID here?? why type is automatically assigned, but not controlID??
                // alert('BBB #' + i + '_' + data[o].id + '_selectBox value='+data[o][moduleLocations[i]]);
                }
            }
        }
      
        
    },
    addTableDragToSelect: function(){
        //add the dragToSelect plugin to the table
        var table = this.table;
        //alert('table='+table.valueOf());
        $(table.id).livequery(function(){
            $(this).dragToSelect({
                selectables: 'td',
                percentCovered:	.01,
                onHide: function () {
                    if($(table.id + ' td.selected').length != 0){
                        var first = table.getToggleResult($(table.id + ' td.selected:first').attr('id').split('_'));
                        var last = table.getToggleResult($(table.id + ' td.selected:last').attr('id').split('_'));
                        var highlight = first || last;
                        if(!highlight){
                            $(table.id + ' td.selected').each(function(){
                                if(table.getToggleResult($(this).attr('id').split('_'))){
                                    highlight = true;
                                }
                            });
                        }

                        $(table.id + ' td.selected').each(function(){
                            table.dragTileGroup($(this).attr('id').split('_'), highlight);
                            $(this).removeClass('selected');
                        });
                    }
                    //TODO:: need to load genes when groups are created??
                   // alert('addTableDragToSelect call layoutTable.reload');
                    Project.IN.layout.table.reloadPattern();

                }
            });
        }, function(){
            $(this).unbind();
        });
    },

    setActiveElement: function(element){
        
        this.activeElement = element;
        var module = this;
        var targetLabel = "Control: ";
        if(module.element.isAccordionEnabled() && element != null){
        	this.outlineGroupTable(module, element, this.table.idNum);
            var moduleElement = module.element;
            var moduleLocations = moduleElement.getRadioLocations();//replicates, type
            var moduleActions = moduleElement.getRadioActions();//{0,0,0},{0,"controlID",0}
            var moduleArray = moduleElement.getRadioArray();//data
            var moduleOptions = moduleElement.getRadioOptions();//{true,true,true},{true,false}
            var data = module.data;
            this.activePatternID = element.id;
            //reload selectBoxes for this element ONLY
            for(var i = 0; i < moduleElement.getRadioButtons().length; i++){
                // alert(' moduleLocations value='+element[moduleLocations[i]]);
                for(var j = 0; j < moduleElement.getRadioButtons()[i].length; j++){
                    var selectBox = '#' + i + '_' + element.id + '_selectBox';
                    var selectBoxHidden = '#' + i + '_' + j + '_' + element.id + '_selectBox_hidden';
                    
                    if(moduleActions[i][j] != 0){//controlID
                       
                        if(data.length == 1 && element[moduleLocations[i]] == j){
                            //alert('NONE 2BBBmoduleActions['+i+']['+j+']='+moduleActions[i][j]+" value="+element[moduleLocations[i]]);
                            $(selectBoxHidden).addClass('hidden');
                            $(selectBoxHidden).next().css('display', 'none');
                            element[moduleLocations[i]] = 0;
                            element[moduleActions[i][j]] = -1;//if only one==>reference==>controlID=-1
                        } else if(element[moduleLocations[i]] == j){
                            //  alert('SHOW 2BBBmoduleActions['+i+']['+j+']='+moduleActions[i][j]+" value="+element[moduleLocations[i]]);
                            $(selectBoxHidden).removeClass('hidden');
                            $(selectBoxHidden).next().css('display', 'inline-block');
                          //  alert("SHOW controlID element["+moduleActions[i][j]+"] ="+element[moduleActions[i][j]] );
                        }
                        //the following cause the pre-selected group/gene lost
                        //eliminating the following will lead to options outdated and group not selected
                        
                        //                        var optold = $(selectBoxHidden).selectBox.options;
                        //                        for(var kk = 0; kk < optold.length; kk++){
                        //                            
                        //                                    alert('opt['+kk+']'+optold[kk]);
                        //                                    //which one selected??/
                        //                               
                        //                            
                        //
                        //                        }
                        
                        var selectedIndex = $(selectBoxHidden)[0].selectedIndex;
                         
                       
                       //  alert('selectedIndex '+selectedIndex);//SHOUDL DEBUG and DO THEREXXXXXXXXXXX

                        // alert('selectedIndex '+selectedIndex+" "+Project.IN.groups[selectedIndex]);
                         //                         if (selectedIndex>=0){
//                        	 element.controlID = Project.IN.groups[selectedIndex].id;
//                         }
                     
                        
                        if (selectedIndex>=1){//not choose the first reference gene==>UI OK. but xls file still taking the first assigned reference gene
                            //TODO:: need to reset the selectedIndex and do the same as 'else'
                            var opt = {};
                            for(var k = 0; k < moduleArray.length; k++){
                                if(element.id != moduleArray[k].id){
                                    if(moduleOptions[i][moduleArray[k].type]){
                                        opt[moduleArray[k].id] =  targetLabel+moduleArray[k].name;
                                        if (k==selectedIndex){
                                            opt[moduleArray[k].id].selectedIndex = selectedIndex;
                                            opt[moduleArray[k].id].selected = 'true';
                                           // alert(moduleArray[k].name +'selcted');
                                        }
                                   // alert('new opt['+moduleArray[k].id+']'+moduleArray[k].name);
                                    //which one selected??
                                    }
                                }

                            }
                           // $(selectBoxHidden).selectBox('options', opt);
                          //  $(selectBoxHidden).selectBox('refresh');
                          //  $(selectBoxHidden).selectBox('value', element[moduleActions[i][j]]);
     
         
                      // $(selectBoxHidden)[0].selectBox('selectedIndex', selectedIndex);
                        }else{
                            // alert('add selectBox');
                            var opt = {};
                            for(var k = 0; k < moduleArray.length; k++){
                                if(element.id != moduleArray[k].id){
                                    if(moduleOptions[i][moduleArray[k].type]){
                                        opt[moduleArray[k].id] = targetLabel + moduleArray[k].name;
                                    // alert('new opt['+moduleArray[k].id+']'+moduleArray[k].name);
                                    //which one selected??/
                                    }
                                }
                            }
                           
                            $(selectBoxHidden).selectBox('options', opt);
                           // alert('hidden setActiveElement '+element.name +" id="+element.id +" type:"+element.type+" value: "+element[moduleActions[i][j]]);
                            $(selectBoxHidden).selectBox('refresh');
                            $(selectBoxHidden).selectBox('value', element[moduleActions[i][j]]);
                            
                            
                            if (selectedIndex==0){//if selectedIndex == 0, and only one control group, then set this as controlID
                            	// alert('selectedIndex controlID = '+$(selectBoxHidden).selectBox('value'));
                            	element.controlID = $(selectBoxHidden).selectBox('value');
                            }
                            
                        }
                        
                       
                    //$(selectBoxHidden).selectBox('value', 'Group 2');
                    }
                    $(selectBox).selectBox('refresh');
                   // alert('show setActiveElement value: '+element.name +" id="+element.id +" type:"+element.type+" value: "+element[moduleLocations[i]]);
                    $(selectBox).selectBox('value', element[moduleLocations[i]]);

                }
            }
        }
    },
    
    outlineGroupTable: function(module,element, tableID){
    	var groupID = element.id;
     	var tableTiles = module.table.tiles;
     	var needOutline = false;
     	if(typeof tableTiles != "undefined"){
     		this.resetTableTiles(tableTiles, tableID);
     		for(var r = 0; r < tableTiles.length; r++){ //row
        		for(var c = 0; c < tableTiles[r].length; c++){ //column
        			if (tableTiles[r][c] == groupID){
        				needOutline = true;
        				var cellID = "#"+r+"_"+c+"_"+tableID;
        				$(cellID).addClass('outlineShadow');
        			}
        		}
        	}
     	}
    },
    resetTableTiles: function(tableTiles, tableID){
    	if(typeof tableTiles != "undefined"){
    		for(var r = 0; r < tableTiles.length; r++){ //row
        		for(var c = 0; c < tableTiles[r].length; c++){ //column
        			var cellID = "#"+r+"_"+c+"_"+tableID;
    				$(cellID).removeClass('outlineShadow');
        		}
    		}
    	}
    },
    setActiveElementWithID: function(id){
        this.setActiveElement(this.getElementWithID(id));
    },
    addElement: function(myData){
        var element;
        //element = this.element.newInstance();
        if(myData == null){
            this.claimedTiles.push(new Array());
            this.layoutTiles.push(new Array());
            element = this.element.newInstance();
            if(this.data.length > 0){
                //Change to fixed color  
                if (Project.IN.colorIndex >= Project.IN.colorArray.length){
                    Project.IN.colorIndex = 0
                }
                element.color = Project.IN.colorArray[Project.IN.colorIndex];
                Project.IN.colorIndex++;
            } else {
                this.hue = 105;
            }
        }else{
            project.templateTable.layoutTiles.push(new Array());
            this.claimedTiles.push(new Array());
            this.layoutTiles.push(new Array());
            element = myData;
        //alert('new id'+element.id+' group.id='+myData.id);
        }
        this.data.push(element);
        this.rebuildDataStructure();
    },
    replaceGroups: function(data){
        
        project.templateTable.tiles = data.templateTable.tiles;
        project.templateTable.layoutTiles = data.templateTable.layoutTiles;
        project.templateTable.claimedTiles = data.templateTable.claimedTiles;
        var thisTemplate = this;
        var groupData = data.groups;
        var count = 0;
        $(groupData).each(function(){
            count++;
            var group = this;
            var g = new Group(group.id, group.name, group.type,group.color);
            g.controlID = group.controlID;
            if(typeof group.o != "undefined" && group.o!=0){//use o to override controlID
            	g.controlID = group.o;
            }
            thisTemplate.addElement(g);
            if (count == groupData.length){//only the last one reload
            	thisTemplate.accordion.addElementToAccordion(thisTemplate.getLastElement(), true, true, true);
            }else{
            	thisTemplate.accordion.addElementToAccordion(thisTemplate.getLastElement(), false, true, false);
            }
            
        });
        
       // this.recreateSelectBoxes();
       // this.reloadPattern();
        //this.rebuildDataStructure();
        //paint table
        this.table.reloadPaintedGroupElements();
        
    },
    
    addRefGene: function(data){
        var thisLayout = this;
        var refGeneData = data.referenceGenes;
        var count = 0;
        $(refGeneData).each(function(){
            count++;
            var refGene = this;
            var g = new Element(refGene.id, refGene.geneName, 0);
            g.hidden = true;
            //g.isPatternEnabled = false;
            thisLayout.addElement(g);
            thisLayout.accordion.addHiddenElementToAccordion(thisLayout.getLastElement(), false, false, false);
            //Project.IN.geneIndex--;
            Project.IN.refGeneCount++;
        });
        
    },
    getAllHiddenRefGeneIDs: function(data, layoutID){
    	var allIDs = '';
        var thisLayout = this;
        var refGeneData = data.referenceGenes;
        $(refGeneData).each(function(){
            var refGene = this;
            if (layoutID != refGene.layoutID){//from other worksheet
            	allIDs = allIDs+","+refGene.id;
            }
        });
        return allIDs;
    },
  
    isRefGene: function (myGene, allRefGeneIDs, layoutID){
    	var isRef = false;
    	if (allRefGeneIDs.indexOf(myGene.id) != -1){
    		isRef = true;
    	}
    	return isRef;
    },

   
    replaceGenes: function(data) {
						var thisLayout = this;
						var gendId;
						var count = 0;
						thisLayout.claimedTiles = new Array();
						thisLayout.layoutTiles = new Array();
						//refGene from other worksheet
						var allRefGeneIDs = thisLayout.getAllHiddenRefGeneIDs(data, data.layoutID);
						var genes = data.genes;
						Project.firstRun = false;
						var totalCount = 0;
						$(genes).each(
								function() {
									totalCount++;
									var gene = this;
									gendId = gene.id;
									if (thisLayout.isRefGene(gene, allRefGeneIDs, data.layoutID)){//refGene
										count++;
							            var g = new Element(gene.id, gene.name, 0);
							            g.hidden = true;
							            //g.isPatternEnabled = false;
							            thisLayout.addElement(g);
							            thisLayout.accordion.addHiddenElementToAccordion(thisLayout.getLastElement(), false, false, false);
							            //Project.IN.geneIndex--;
							            Project.IN.refGeneCount++;
									}else{
										thisLayout.claimedTiles.push(new Array());
										thisLayout.layoutTiles.push(new Array());
										thisLayout.addElement(gene);
										Project.IN.geneIndex++;

										var i = thisLayout.data.length; 
										thisLayout.dataID[gene.id] = i;
										thisLayout.dataIndex[i] = gene.id;

									    
									    if (totalCount == genes.length){//only the last one reload
									    	thisLayout.rebuildDataStructure();
									    	thisLayout.accordion.addElementToAccordion(
													thisLayout.getLastElement(), true, false,
													false);
									    }else{
									    	thisLayout.accordion.addElementToAccordion(
													thisLayout.getLastElement(), false, false,
													false);
									    }
										
									}
									
								});
						//thisLayout.rebuildDataStructure();
						thisLayout.activePatternID = gendId;
						//thisLayout.reloadPattern();
						//this.table.reloadPaintedExclusionElements(data);
	},
	
	replaceGenes2: function(data) {
		var thisLayout = this;
		thisLayout.claimedTiles = new Array();
		thisLayout.layoutTiles = new Array();
		Project.firstRun = false;
	},

   
    getElementWithID: function(id){
        return this.data[this.dataID[id]];
    },
    getLastElement: function(){
        if(this.data.length > 0){
            return this.data[this.data.length - 1];
        } else {
            return -1;
        }

    },
    getFirstElement: function(){
        if(this.data.length > 0){
            return this.data[0];
        } else {
            return -1;
        }

    },
    claimTile: function(id, selector){
        this.claimedTiles[this.dataID[id]].push(selector);
    },
    unclaimTile: function(id, selector){
        var clmTiles =  this.claimedTiles[this.dataID[id]];
        for(var i = 0; i < clmTiles.length; i++){
            if(clmTiles[i] == selector){
                clmTiles.splice(i,1);
            }
        }
    },
    updateLayoutColors: function(){
        var module = this;
        if(module.element.isColorEnabled()){
            for(var i = 0; i < module.data.length; i++){
                var element = module.data[i];
                var color = "#" + element.color;
                for(var k = 0; k < module.layoutTiles[i].length; k++){
                    $(module.layoutTiles[i][k] + '').css("background-color", color);
                }
            }
        }
    },
    updateTemplateColors: function(){
        var module = this;
        if(module.element.isColorEnabled()){
            for(var i = 0; i < module.data.length; i++){
                var element = module.data[i];
                var color = "#" + element.color;
            //alert(module.data[i].id+'  color='+color);
            }
        }
    },
    reloadPattern: function(){//module reload
        var module = this;
        var moduleData = module.data;
        if(module.element.isPatternEnabled()){//gene
            //alert('length= '+module.data.length+" this.geneIndex="+Project.IN.geneIndex);
            if(module.data.length <= Project.IN.refGeneCount){
                $('#' + this.selector + '_switcher').slideUp();
                module.table.reloadPattern();
            } else {
                $('#' + this.selector + '_switcher').slideDown();

                var dataBox = '#' + this.selector + '_data';
                var patternBox = '#' + this.selector + '_pattern';

                if(module.activePatternID == -1 || module.getElementWithID(parseInt(module.activePatternID)) == -1){
                    module.activePatternID = module.data[0].id;
                }

                var opt = '';
                for(var i = 0; i < moduleData.length; i++){
                    if (i<Project.IN.refGeneCount){ //cannot remove, safari shows the right side disabled is removed; firefox is OK
                        opt += '<option class="hidden" disabled="disabled" value="' + moduleData[i].id + '"></option>';
                    }else{
                        opt += '<option value="' + moduleData[i].id + '">' + moduleData[i].name + '</option>';
                    }

                  //  opt += '<option value="' + moduleData[i].id + '">xxx' + moduleData[i].name + '</option>';
                //alert('BBB option: '+moduleData[i].name);  
                }
                //var selectedIndex = $(dataBox)[0].selectedIndex;
                // alert('BBB realodpattern selectedIndex= '+selectedIndex);
                       
                $(dataBox).selectBox('options', opt);
                $(dataBox).selectBox('refresh');
                
                //exception handling when activePatternID is deleted
                var ele = module.getElementWithID(parseInt(module.activePatternID));
                if(typeof ele == "undefined"){
                	ele = module.getLastElement();
                	if(typeof ele != "undefined"){
                		module.activePatternID = ele.id;
                	}else{
                		module.activePatternID = -1;
                	}
                }
                if(typeof ele != "undefined"){
                	$(dataBox).selectBox('value', parseInt(module.activePatternID));
	                var patternTypes = module.table.getPatternTypes(parseInt(module.activePatternID));
	                var types = patternTypes[0];
	                var disabled = patternTypes[1];
	                opt = {};
	                for(var j = 0; j < types.length; j++){
	                    if (i<Project.IN.refGeneCount){
	                       opt[j] = types[j];
	                    }else{
	                       opt[j] = types[j];
	                    }
	                }
	                $(patternBox).selectBox('options', opt);
	
	                for(var k = 0; k < disabled.length; k++){
	                    if(disabled[k] != 0 && k>=Project.IN.refGeneCount){
	                        $(patternBox).find('option').eq(k).attr('disabled', 'disabled');
	                    }
	                }
                }
                $(patternBox).selectBox('refresh');
                
                if(typeof ele != "undefined"){
                	
                	if(Project.IN.tableType == 0){//96 wells
                		//if replicates is 1, By row of the template is disabled
                		if (ele.replicates=="0" && ele.patternType==1){//"0","1","2" represents replicates 1,2,3 
                			ele.patternType = 0;//choose by template 
                		}
                	}else{	
	                	if (ele.replicates!="1" && ele.patternType==0){//"0","1","2" represents replicates 1,2,3 
	                    	ele.patternType = 1;//choose by template odd vertically
	                    }else if (ele.replicates=="1" && ele.patternType==5){
	                    	ele.patternType = 0;//choose by template horizontally
	                    }
                	}
                	
                    $(patternBox).selectBox('value', parseInt(ele.patternType));
                } 
                module.table.reloadPattern();
            }

        }else{//GROUP
            //do nothing
        }
    }
});


$.Class.extend("Accordion",{},
{
    init : function(module){
        this.module = module;
        this.type = module.element.type;
    },
    setSelector: function(selector){
        this.selector = selector;
    },
    addElementToAccordion: function(element, reload, isGroup, isSetActive){
        var accordion = this;
        var module = accordion.module;
        var moduleElement = module.element;
        var id = element.id;
        var content = "#" + id + '_content';
        var colorpicker = id + '_colorpicker';
        var selectBox = id + '_selectBox';
        var selectBoxHidden = id + '_selectBox_hidden';
        var group = '<div id="' + id + '_sortable">'
        group += '<h3 id="' + id + '">';
        group += '<a style="">';
        //show index in the name
        if(moduleElement.showIndexInName()){
            group += '<span id="' + id + '_name" style="width:180px;display:block">' + (parseInt(module.dataID[id]) + 1) + ": " + element.name + '</span>'; 
        } else {
            group += '<span id="' + id + '_name" style="width:180px;display:block">' + element.name + '</span>';
        }
        group += '<input id="' + id + '_text" type="text" name="text" class="hidden" style="margin-left: -20px;display:none;font-size:10px;z-index:10;font-family:verdana;width:68%" value="' + element.name + '" />';
        group += '</a>';
        if(moduleElement.isSelectionEnabled()){
            group += '<span style="right:0.5em;z-index:10;margin-top:-9px;top:50%;position:absolute"><input id="' + id + '_radio" style="" type="radio" name="rdio" value="' + id +'" /></span>';
        }

        group += '<span style="right:0.5em;z-index:10;margin-top:-10px;top:50%;position:absolute" class="hidden"><button id="' + id + '_del" class="button red small db" style="font-size:11px;">-</button></span>';
        group += '</h3>';
        group += '<div id="' + id + '_content" style="overflow:none;">';
        group += '</div>';
        group += '</div>';
        $(this.selector).append(group);

        if(moduleElement.isColorEnabled()){
            $(content).append($.create('div', {
                'id': colorpicker,
                'class':'colorSelector',
                'style':'margin-left:-20px;display:inline;float:left'
            }));
        }
        var typeLabel = "Type: ";
        if(moduleElement.isColorEnabled()){
        	typeLabel = "Type: ";
        }
        //load the arrays about selectboxes and create them
        var selectBoxWidth = (moduleElement.isColorEnabled()) ? 100:132;
        for(var i = 0; i < moduleElement.getRadioButtons().length; i++){
            $(content).append($.create('select', {
                'id': i + "_" + selectBox,
                'style':'position:relative;float:right;display:inline-block;height:30px;width:' + selectBoxWidth + 'px',
                'class': element.id + '_box'
            }));

            var space = 0;
            for(var j = 0; j < moduleElement.getRadioButtons()[i].length; j++){
                
                if(moduleElement.getRadioActions()[i][j] != 0){//==controlID, test
                    //TODO: add label HERE
                	//$(content).append('<br><br>Ref:');
                	$(content).append('<br><br>');
                    $(content).append($.create('select', {
                        'id': i + '_' + j + '_' + selectBoxHidden,
                        'style':'position:relative;float:right;width:140px;height:30px', //group: target
                        'class': element.id + '_box hidden hiddenSelectBox'
                    }));
                    space++;
                    $('#' + i + "_" + selectBox).append('<option class="' + accordion.module.selector + '_depOption" value="' + j + '" >'+typeLabel+ accordion.module.element.getRadioButtons()[i][j] + '</option>');
                } else {
                	if(!moduleElement.isColorEnabled() && 
                    		(accordion.module.element.getRadioButtons()[i][j]=='1' || accordion.module.element.getRadioButtons()[i][j]=='2' || accordion.module.element.getRadioButtons()[i][j]=='3')){
                    	$('#' + i + "_" + selectBox).append('<option value="' + j + '" >Replicates: '+ accordion.module.element.getRadioButtons()[i][j] + '</option>');
                        
                    }else{
                    	$('#' + i + "_" + selectBox).append('<option value="' + j + '" >'+typeLabel+ accordion.module.element.getRadioButtons()[i][j] + '</option>');
                    }
                    
                }
            }
            if(space == 0){
                $(content).append('<br><br>');
            }
        }
        
        //only if the color can be changed
        if(moduleElement.isColorEnabled()){ 
            $('#' + colorpicker).append($.create('div', {
                'style':'background-color: ' + this.color
            }));
        }
        if(isSetActive && this.module.data.length == 1){
            this.module.active = this.module.dataID[element.id];
        }
        this.addElementListeners(element);
        //adding this for batch creation improve performance (create 7 genes, from 16 seconds to 9 seconds);
        if (reload){
            $(this.selector).reloadAccoridon(this);
            if (isGroup){
                this.updateColors();
                this.reloadCheckboxStyles();
                this.module.reloadPattern(); 
            }
            
        }
    },
    
    addHiddenElementToAccordion: function(element, reload, isGroup, isSetActive){
        var accordion = this;
        var module = accordion.module;
        var moduleElement = module.element;
        var id = element.id;
        var content = "#" + id + '_content';
        var selectBox = id + '_selectBox';
        var selectBoxHidden = id + '_selectBox_hidden';
        var group = '<div id="' + id + '_sortable" style="display:hidden"  class="hidden" >'
        group += '<h3 id="' + id + '"  class="hidden" >';
        group += '<a style="display:hidden"  class="hidden" >';
        //show index in the name
        if(moduleElement.showIndexInName()){
            group += '<span id="' + id + '_name" class="hidden" >' + (parseInt(module.dataID[id]) + 1) + ": " + element.name + '</span>'; 
        } else {
            group += '<span id="' + id + '_name" class="hidden" >' + element.name + '</span>';
        }
        //group += '<input id="' + id + '_text" type="text" name="text" class="hidden" style="margin-left: -20px;display:none;font-size:10px;z-index:10;font-family:verdana;width:68%" value="' + element.name + '" />';
        group += '</a>';
        if(moduleElement.isSelectionEnabled()){
            group += '<span  class="hidden" ><input id="' + id + '_radio" style="" type="radio" name="rdio" value="' + id +'" /></span>';
        }

        // group += '<span style="hidden" class="hidden"><button id="' + id + '_del" class="button red small db" style="font-size:11px;">-</button></span>';
        group += '</h3>';
        // group += '<div id="' + id + '_content" style="hidden">';
        //group += '</div>';
        group += '</div>';
        $(this.selector).append(group);


        for(var i = 0; i < moduleElement.getRadioButtons().length; i++){
            $(content).append($.create('select', {
                'id': i + "_" + selectBox,
                'class': element.id + '_box'
            }));

            var space = 0;
            for(var j = 0; j < moduleElement.getRadioButtons()[i].length; j++){
                
                if(moduleElement.getRadioActions()[i][j] != 0){//==controlID, test
                    //alert('3BBBB moduleActions['+i+']['+j+']='+moduleElement.getRadioActions()[i][j]+" j="+j+" accordion.module.element.getRadioButtons()[i][j]="+accordion.module.element.getRadioButtons()[i][j]+' class='+accordion.module.selector);
                    $(content).append('<br><br>');
                    $(content).append($.create('select', {
                        'id': i + '_' + j + '_' + selectBoxHidden,
                        'class': element.id + '_box hidden hiddenSelectBox'
                    }));
                    space++;
                    $('#' + i + "_" + selectBox).append('<option style="display:hidden" class="' + accordion.module.selector + '_depOption hidden" value="' + j + '" >' + accordion.module.element.getRadioButtons()[i][j] + '</option>');
                } else {
                    $('#' + i + "_" + selectBox).append('<option style="display:hidden"  class="hidden"  value="' + j + '" >' + accordion.module.element.getRadioButtons()[i][j] + '</option>');
                }
            }
            
        }
    },
    
  
    addElementListeners: function(element){//once teh element is added, add this function
    	
        var accordion = this;
        var moduleElement = accordion.module.element;
        var moduleArray = moduleElement.getRadioArray();
        var moduleButtons = moduleElement.getRadioButtons();
        var moduleActions = moduleElement.getRadioActions();
        var moduleLocations = moduleElement.getRadioLocations();
        var moduleOptions = moduleElement.getRadioOptions();
        
        //colorpicker
        if(accordion.module.element.isColorEnabled() && element.color != null){
            $('#' + element.id + '_colorpicker').livequery(function(){
                $(this).ColorPicker({
                    color: element.color,
                    onShow: function (colpkr) {
                        $(colpkr).fadeIn(500);
                        return false;
                    },
                    onHide: function (colpkr) {
                        $(colpkr).fadeOut(500);
                        return false;
                    },
                    onChange: function(hsb, hex, rgb, el) {
                        if(hex == 'ddeeff'){
                            hex = "d0e5fa";
                        }
                        this.color = hex;
                        element.color = hex;
                        accordion.updateColors();
                        accordion.module.updateLayoutColors();
                        return false;
                    }
                });
                
            }, function(){
                $(this).unbind();
            });
            
        }

        //selectBox action bindings
        for(var i = 0; i < moduleButtons.length; i++){
            var index = i;
            var type = element[moduleLocations[index]];
            $('#' + index + '_' + element.id + '_selectBox').livequery(function(){
                var q = this;
                $(this).selectBox({
                    'menuTransition': 'slide'
                }).change(function(e){
                	//alert('change setting of type control/test/water');
                	//bug here, if control changes, target group's control id is -1
                    e.stopPropagation();
                    e.preventDefault();
                    var ind = $(q).data('index');
                    var oldType = element[moduleLocations[ind]];
                    var hiddenBox;
                    element[moduleLocations[ind]] = $(this).val();
                    type = element[moduleLocations[ind]];                    
                    var action = moduleActions[ind];
                    if(action[type] != 0){//group type: test
                        hiddenBox = '#' + ind + '_' + type + '_' + element.id + '_selectBox_hidden';
                        var opt = {};
                       
                        for(var h = 0; h < moduleArray.length; h++){
                            if(element.id != moduleArray[h].id){
                                if(moduleOptions[ind][moduleArray[h].type]){
                                    opt[moduleArray[h].id] =  moduleArray[h].name;
                                // alert('AAABBBqelement.id='+element.id+' moduleArray[h].id='+moduleArray[h].id+" moduleArray[h].name="+moduleArray[h].name);
                                }

                            }
                        }
                        var selectedIndex = $(hiddenBox)[0].selectedIndex;
                        // alert('BBB addElementListeners selectedIndex= '+selectedIndex);
                        //TODO:: removing the following fix the problem for multi-ref
                        //DO NOT KNOW what's the side effect yet
                        //$(hiddenBox).selectBox('options', opt);
                        $(hiddenBox).removeClass('hidden');
                        $(hiddenBox).next().css('display', 'inline-block');
                        element[action[type]] = $(hiddenBox).selectBox('value');
                        element.controlID = $(hiddenBox).selectBox('value');
                        //alert('set controlID = '+ $(hiddenBox).selectBox('value'));
                    } else {//group type: control and water
                        hiddenBox = '#' + ind + '_' + oldType + '_' + element.id + '_selectBox_hidden';
                        $(hiddenBox).addClass('hidden');
                        $(hiddenBox).next().css('display', 'none');
                        element[action[type]] = -1;
                        element.controlID = -1;
                    }
                    $(accordion.selector).reloadAccoridon(accordion);
                accordion.module.reloadPattern(); //need this when change replicates, layout table changes
                });
                $(this).data('index', i);
            }, function(){
                $(this).unbind();
            });

            $('#' + index + '_' + element.id + '_selectBox').selectBox('value', type);

         
            
            for(var j = 0; j < moduleButtons[index].length; j++){
                if(moduleActions[index][j] != 0){
                    var action = moduleActions[index][j];
                    $('#' + index + '_' + j + '_' + element.id + '_selectBox_hidden').livequery(function(){
                        var q = this;
                        $(this).selectBox({
                            'menuTransition': 'slide'
                        }).change(function(e){
                        	//alert('xxchange associated control group');
                        	//alert('element.controlID='+element.controlID+"element[moduleActions[i][j]]= "+element[moduleActions[i][j]]); 
                            
                            e.stopPropagation();
                            e.preventDefault();
                            
                            element.controlID = $(this).val();
                            element[action[type]] = $(this).val();
                            ///AAAAAAAAAAAA
                           //ment.controlID
                           
                        }).focus(function(e){
                            e.stopPropagation();
                            e.preventDefault();
                            var ind = $(q).data('index');
                            var opt = {};
                            var k;
                            // alert('xxxyyyelement.id='+element.id+' moduleArray[k].id='+moduleArray[k].id);
                            for(k = 0; k < moduleArray.length; k++){
                                if(element.id != moduleArray[k].id){
                                    if(moduleOptions[ind][moduleArray[k].type]){
                                        opt[moduleArray[k].id] =  moduleArray[k].name;
                                    //alert('BBB moduleArray[k].name= '+moduleArray[k].name);
                                    // alert('AAABBBNOT HIDDEN qelement.id='+element.id+' moduleArray[k].id='+moduleArray[k].id+" moduleArray[h].name="+moduleArray[k].name);
                                    }

                                }

                            } 
                            var selectedIndex = $(this)[0].selectedIndex;
                            // alert('BBB addElementListeners 222 selectedIndex= '+selectedIndex);
                            //TODO:: removing the following fix the problem for multi-ref
                            //DO NOT KNOW what's the side effect yet
                            //$(this).selectBox('options', opt);
                            // $(this).selectBox('refresh');
                            //$(this).selectBox('value', element[action[type]]);

                            $(this).selectBox('showMenu');
                        });
                        $(this).data('index', i);
                    }, function(){
                        //$(this).selectBox('destroy');
                        $(this).unbind();
                    });

                    //alert('elementListener: '+element[action]);
                    $('#' + index + '_' + j + '_' + element.id + '_selectBox_hidden').selectBox('value', element[action]);

                    if(element[action] == -1){//control and water
                        $('#' + index + '_' + j + '_' + element.id + '_selectBox_hidden').next().css('display', 'none');
                    }

                }



            }
        }

        //delete button
        $('#' + element.id + '_del').livequery(function(){
            $(this).click(function(e){
                e.stopPropagation();
                accordion.removeElementFromAccordion(element);
            });

        }, function(){
            $(this).unbind();
        });

        //text field
        $('#' + element.id + '_text').livequery(function(){
            $(this).click(function(e) {
                e.stopPropagation();
                this.focus();
            }).bind('keyup keypress keydown', function(e) {
                if (e.which == 32 || e.which == 13) {
                    e.stopPropagation();
                }
                element.name = $(this).val().trim();
            });
        }, function(){
            $(this).unbind();
        });


        this.reloadCheckboxStyles();
        this.module.reloadPattern();
        $(this.selector + "_header").jScrollPane('reinitialise');
    },
    removeElementFromAccordion: function(e){
    	var element = e;
        var oldIndex = this.module.dataID[element.id];
        var newCheckmarkNeeded = ($("span.ui-radio-checked").prev().val() == element.id);
        this.module.table.resetTilesWithID(element.id);
        var colorpickerID = "#" + $('#' + element.id + '_colorpicker').data('colorpickerId');

        $("." + element.id + "_box").selectBox('destroy');

        $(colorpickerID).remove();
        $("#" + element.id).remove();
        $("#" + element.id + "_content").remove();
        $(this.selector).reloadAccoridon(this);
        $(this.selector + " h3 span.ui-icon-triangle-1-e").toggle();
        this.module.data.splice(oldIndex, 1);
        this.module.rebuildDataStructure();
        this.module.claimedTiles.splice(oldIndex, 1);
        this.module.layoutTiles.splice(oldIndex, 1);
        if(newCheckmarkNeeded){
            if(this.module.data.length != 0){
                var newInd;
                if(oldIndex == 0){
                    newInd = 0;
                } else {
                    newInd = Math.abs(oldIndex - 1);
                }
                var newGroup = this.module.data[newInd];
                $("#" + newGroup.id + "_radio").prop({
                    checked: true
                });
                this.module.setActiveElement(newGroup);
            } else {
                this.module.setActiveElement(null);
            }


        }
        $(this.selector + "_header").jScrollPane('reinitialise');
        if(this.module.data.length == 0){
            this.reloadAccordion();
            $("#" + this.module.selector + "_edit").trigger('click');
            $("#" + this.module.selector + "_edit").toggleEnabled();
            $(this.selector + "_header").styleBlock("Add a new " + this.module.element.shortName + " below!!!");
        } else if(this.module.data.length == 1){
            $("." + this.module.selector + "_depOption").attr('disabled', 'disabled');
        } else{
            $(this.selector + ' h3').unbind('click');
            $(this.selector + ' h3').unbind('focus');
            $(this.selector + ' h3').unbind('blur');
            $(this.selector + ' h3').unbind('mouseout');
            $(this.selector + ' h3').unbind('mouseover');
            $(this.selector + ' h3').unbind('keydown');
            $(this.selector).unbind('remove');
        }

        this.module.recreateSelectBoxes();
        this.module.reloadPattern();
    //TODO:: REMOVE, module.reloadPattern(); includes module.table.reloadPattern();
    // TODO:: remove the following to avoid removing everything from table; do not know the side effect yet;
   //this.module.table.reloadPattern();

    },
    updateColors: function(){
        var accordion = this;
        if(this.module.element.isColorEnabled()){
            for(var i = 0; i < accordion.module.data.length; i++){
                var element = accordion.module.data[i];
                var color = "#" + element.color;
                for(var j = 0; j < accordion.module.claimedTiles[i].length; j++){
                    $(accordion.module.claimedTiles[i][j] + '').css("background-color", color);
                }
                $('#' + element.id).css('background-color', color);
                $('#' + element.id + '_colorpicker div').css('background-color', color);
                $('#' + element.id).addClass('glass');
                if(getBrightness(color) < 120){
                    $('#' + element.id + "_name").css('color','#FFFFFF');
                } else {
                    $('#' + element.id + "_name").css('color','#000000');
                }
            }
        }


    },
    reloadCheckboxStyles: function(){
    	//alert('XXXXXX reloadCheckboxStyles ');
        var accordion = this;
        $(this.selector + " input:radio").filter(":checkbox,:radio").checkBox({
            addLabel: false,
            'change': function(e, ui){
                e.stopPropagation();
                if($(this).is(':checked')){
                    var id = $(this).parent().parent().attr('id');
                    accordion.module.setActiveElementWithID(id);
                }
            }
        });
    },
    reloadAccordion: function(){
        $(this.selector).html('');
        //TODO:: gene or group, use false/true for addElementToAccordion
        for(i = 0; i < this.module.data.length; i++){
            this.addElementToAccordion(this.module.data[i], false, true, true); //TODO:: to test, false if added without testing
        }
        $(this.selector).reloadAccoridon(this);
        this.updateColors();
        this.reloadCheckboxStyles();
        this.module.reloadPattern();
            
            
        // this.reloadCheckboxStyles();
        if(this.activeGroup != null){
            $("#" + this.activeGroup.id + "_radio").prop({
                checked: true
            });
        }

    }
});

$.Class.extend("Table",{},
{
    // constructor function
    init : function(type){
        this.type = type;
        switch(this.type){
            case 0:
                this.row = 8;
                this.col = 12;
                break;
            case 1:
                this.row = 16;
                this.col = 24;
                break;
        }

        this.idNum = parseInt(Math.random()*100000);
        this.id = "#" + this.idNum + "_table";
        this.tiles = new Array(this.row); //contains GROUP ID
        this.layoutTiles = new Array(this.row); //contains GENE ID
        this.replicateTiles = new Array(this.row); //contrains REPLICATE NUMBER
        this.geneID = -1; //current GENE ID
        this.nextLine = 0; //used by pattern to specify which line to print on
        for(i = 0; i < this.tiles.length; i++){
            this.tiles[i] = new Array(this.col);
            for(j = 0; j < this.tiles[i].length; j++){
                this.tiles[i][j] = 0;
            }
        }
        for(i = 0; i < this.layoutTiles.length; i++){
            this.layoutTiles[i] = new Array(this.col);
            for(j = 0; j < this.layoutTiles[i].length; j++){
                this.layoutTiles[i][j] = 0;
            }
        }
        for(i = 0; i < this.replicateTiles.length; i++){
            this.replicateTiles[i] = new Array(this.col);
            for(j = 0; j < this.replicateTiles[i].length; j++){
                this.replicateTiles[i][j] = 0;
            }
        }
    },
    getSizeString: function(){
        return "[" + this.row + "," + this.col + "]";
    },
    getWidthPercentage: function(){
        switch(this.type){
            case 0:
                return 1;
            case 1:
                return .90;
        }
    },
    getCode: function(){
        var table = "";
        table += "<table style='padding-right:1px; padding-bottom:1px; position:relative; overflow:hidden' width='100%' cellpadding='0' cellspacing='0' id='" + removeHash(this.id) +"'>";
        table += "<tr>";
        for(var i = 0; i < this.col + 1; i++){
            if(i != 0){
                table += "<th style='padding-bottom:3px' >" + (i) + "</th>";
            } else {
                table += "<th> </th>";
            }

        }
        table += "</tr>";
        for(i = 0; i < this.row; i++){
            table += "<tr>";
            for(var j = 0; j < this.col; j++){
                if(j == 0){
                    table += "<th style='padding-right:3px' width='2' rowspan='1'>" + integerToLetter(i) + "</th>";
                }
                table += "<td class='tile greenShadow' id='" + i + "_" + j + "_" + this.idNum + "'>";
                table += " ";
                table += "</td>";
            }
            table += "</tr>";
        }
        table += "</table>";
        return table;
    },
    setModule: function(module){
        this.module = module;
    },
    getTileGroup: function(i,j){
        return this.tiles[i][j];
    },
    getToggleResult: function(ar){
        return (this.module.activeElement != null && this.tiles[ar[0]][ar[1]] != this.module.activeElement.id);
    },
    dragTileGroup: function(ar, highlight){
        //depending if something is highlighted, it processes and then allows certain tiles to be painted
        //alert("#" + ar[0] + "_" + ar[1] + "_" + ar[2]+"==>"+highlight);
        if(highlight){
            this.processClaimedTile(ar, this.module.activeElement.id);
            $("#" + ar[0] + "_" + ar[1] + "_" + ar[2]).css("background-color", "#" + this.module.activeElement.color);
        } else {
            this.processClaimedTile(ar, null);
            $("#" + ar[0] + "_" + ar[1] + "_" + ar[2]).css("background-color", "#" + Project.defaultColor);
        }
    },
    dragTileGroupExclusion: function(data, show){
        //depending if something is highlighted, it processes and then allows certain tiles to be painted
        var numbers = data.split(":");
        var ar=[numbers[0],numbers[1],this.idNum];
        // alert("added to exclusion:   row:" +ar[0]+ " column:"+ar[1]);
        this.dragTileGroup(ar,show);
        Project.IN.layout.table.reloadPattern();
        
    },
    dragTileAllExclusion: function(data){//only call by replaceGene
        //depending if something is highlighted, it processes and then allows certain tiles to be painted
        var numbers = data.split(":");
        var ar=[numbers[0],numbers[1],this.idNum];
        // alert("added to exclusion:   row:" +ar[0]+ " column:"+ar[1]);
        this.dragTileGroup(ar,true);
        //Project.IN.layout.table.reloadPattern();
        
    },
    
    resetAllTiles: function(){
    	//alert('resetAllTiltes');
        for(var i = 0; i < this.tiles.length; i++){
            for(var j = 0; j < this.tiles[i].length; j++){
                this.tiles[i][j] = 0;
            }
        }
        for(i = 0; i < this.layoutTiles.length; i++){
            for(j = 0; j < this.layoutTiles[i].length; j++){
                this.layoutTiles[i][j] = 0;
            }
        }
        for(i = 0; i < this.replicateTiles.length; i++){
            for(j = 0; j < this.replicateTiles[i].length; j++){
                this.replicateTiles[i][j] = 0;
            }
        }
        $(this.id + ' td').html(" ");
        $(this.id + ' td').css("background-color", "#" + Project.defaultColor);
        this.nextLine = 0;
        this.geneID = -1;
    },
    resetTilesWithID: function(id){
        var table = this;
        for(var i = 0; i < this.tiles.length; i++){
            for(var j = 0; j < this.tiles[i].length; j++){
                if(this.tiles[i][j] == id){
                    this.tiles[i][j] = 0;
                    $("#" + i + "_" + j + "_" + table.idNum).css("background-color", "#" + Project.defaultColor);
                }
            }
        }
    },
    processClaimedTile: function(ar, newID){
        //makes sure the element has a record of the tiles it should update (colors)
        var oldID = this.tiles[ar[0]][ar[1]];
        if(newID != null){
            if(oldID != newID){
                if(oldID != 0){
                    this.module.unclaimTile(oldID, "#" + ar[0] + "_" + ar[1] + "_" + ar[2]);
                    this.module.claimTile(newID, "#" + ar[0] + "_" + ar[1] + "_" + ar[2]);
                } else {
                    this.module.claimTile(newID, "#" + ar[0] + "_" + ar[1] + "_" + ar[2]);
                }
                this.tiles[ar[0]][ar[1]] = newID;
            }

        } else {
            if(this.tiles[ar[0]][ar[1]] != 0){
                this.tiles[ar[0]][ar[1]] = 0;
                this.module.unclaimTile(oldID, "#" + ar[0] + "_" + ar[1] + "_" + ar[2]);
            }

        }


    },
    reloadPaintedElements: function(){//table: layout on gene
    	//alert('reloadPaintedElementsxxxxxxx');
        var template = Project.IN.template;
        var layout = Project.IN.layout;
        var exclusionTable = Project.IN.exclusion.table.tiles;
        for(var i = 0; i < this.tiles.length; i++){
            for(var j = 0; j < this.tiles[i].length; j++){
                if(this.tiles[i][j] != 0 && exclusionTable[i][j] == 0){
                    var id = this.tiles[i][j];
                    var index = template.dataID[id];
                    var geneIndex = parseInt(layout.dataID[this.layoutTiles[i][j]]);
                    template.layoutTiles[index].push("#" + i + "_" + j + "_" + this.idNum);
                    
                    $("#" + i + "_" + j + "_" + this.idNum).html(parseInt(geneIndex + 1));
                } else {
                	if (this.tiles[i][j] != 0 && exclusionTable[i][j] > 0 ){//excluded
                    	this.tiles[i][j] = -this.tiles[i][j];//need to know the group ID even thought it's excluded
                    }else{
                    	this.tiles[i][j] = 0;
                    }
                	$("#" + i + "_" + j + "_" + this.idNum).html(" ");
                    
                    
                }
            }
        }
        template.updateLayoutColors();
    },
    
    reloadPaintedGroupElements: function(){//table, group
        var template = Project.IN.template;
        var layout = Project.IN.layout;
        var exclusionTable = Project.IN.exclusion.table.tiles;
        //var tableTils = Project.IN.templateTable.tiles;
       
        var idColorMap = new Object();
        if(template.element.isColorEnabled()){
            for(var i = 0; i < template.data.length; i++){
                var element = template.data[i];
                var color = "#" + element.color;
                //alert(template.data[i].id+'  color='+color);
                idColorMap[template.data[i].id] = color;
            }
        }
        var tableTils = Project.IN.templateTable.tiles;
        for(var i = 0; i < tableTils.length; i++){
            for(var j = 0; j < tableTils[i].length; j++){
                if(tableTils[i][j] != 0 && exclusionTable[i][j] == 0){
                    var id = tableTils[i][j];
                    var index = template.dataID[id];
                    //template.table.layoutTiles[index].push("#" + i + "_" + j + "_" + this.idNum); //cause teh templateTable.layoutTiles has wrong extra info, but UI works
                    template.claimedTiles[index].push("#" + i + "_" + j + "_" + this.idNum); 
                    $("#" + i + "_" + j + "_" + this.idNum).css("background-color", idColorMap[id]);
                    this.tiles[i][j] = id;
                //Project.IN.template.table.tiles[i][j] = id;
                } else {
                    this.tiles[i][j] = 0;
                    $("#" + i + "_" + j + "_" + this.idNum).html(" ");
                }
            }
        }
    //template.updateTemplateColors();
    },
    reloadPaintedExclusionElements: function(data){//table, exclusion
    	//alert('reloadPaintedExclusionElementsxxxxxxxx'); //only call by replaceGenes
        var tableTils = data.exclusionsTable.tiles;
        var idNum = data.exclusionsTable.idNum;
        
        for(var i = 0; i < tableTils.length; i++){
            for(var j = 0; j < tableTils[i].length; j++){
                if(tableTils[i][j] != 0){
                	Project.IN.exclusionsTable.dragTileAllExclusion(i+":"+j);
                }
            }
        }
        if (tableTils.length>0){
        	Project.IN.layout.table.reloadPattern();
        }
    },
    paintTile: function(id, x, y, color){
        this.tiles[x][y] = id;
    },
    rowIsFull: function(row, alternate){
        var table = this;
        var start = 0;
        var increment = 1;
        if(row < table.row){
            if(alternate != null){
                if(alternate == "odd"){
                    increment = 2;
                } else if(alternate == "even"){
                    increment = 2;
                    start = 1;
                }
            }
            for(var j = start; j < table.tiles[row].length; j += increment){
                if(table.tiles[row][j] != 0){
                    return true;
                }
            }
        }
        
        return false;
    },
    paintByTemplate: function(replicates, alternate){
        var table = this;
        var templateTable = Project.IN.template.table;
        this.nextLine = 0;
        for(var i = 0; i < replicates; i++){
            for(var k = 0; k < templateTable.tiles.length; k++){
                table.paintRow(k, i, alternate);

            }
        }
        this.reloadPaintedElements();
    },
    paintByRowOfTemplate: function(replicates, alternate){
        var table = this;
        var templateTable = Project.IN.template.table;
        this.nextLine = 0;
        for(var k = 0; k < templateTable.tiles.length; k++){
            for(var i = 0; i < replicates; i++){
                table.paintRow(k, i, alternate);

            }
        }

        this.reloadPaintedElements();
    },
    paintByTemplateHorizontally: function(){
    	//alert('xxpaintByTemplateHorizontally');
        var table = this;
        var templateTable = Project.IN.template.table;
        this.nextLine = 0;
        for(var k = 0; k < templateTable.tiles.length; k++){
            table.paintRow(k, 1, "even");
            table.paintRow(k, 2, "odd");
        }

        this.reloadPaintedElements();
    },
    paintRow: function(row, replicates, alternate){
        var table = this;
        var multi = 1;
        var alt = 0;
        if(alternate == "odd"){
            multi = 2;
        } else if(alternate == "even"){
            multi = 2;
            alt = 1;
        }
        while(table.rowIsFull(this.nextLine,  alternate)){
            this.nextLine++;
        }
        if(this.nextLine < table.row){
            var templateTable = Project.IN.template.table;
            for(var j = 0; j < templateTable.tiles[row].length; j++){
                if(templateTable.tiles[row][j] != 0){
                    var rowOffset = (this.nextLine);
                    var colOffset = (j * multi) + alt;
                    table.tiles[rowOffset][colOffset] = templateTable.tiles[row][j];
                    table.layoutTiles[rowOffset][colOffset] = table.geneID;
                    table.replicateTiles[rowOffset][colOffset] = replicates;
                }
            } 
        
        }
    },
    paintCompact: function(replicates){
        var table = this;
        var templateTable = Project.IN.template.table;
        var offset = 0;
        if(this.nextLine != 0){
            if(!table.rowIsFull(this.nextLine - 1, 'even')){
                offset = 1;
                this.nextLine--;
            }
        }
        
        for(var k = 0; k < templateTable.tiles.length; k++){
            for(var i = 0 + offset; i < replicates + offset; i++){
                if(((k + i) % 2) == 0){
                    table.paintRow(k, i-offset, "odd");
                } else {
                    table.paintRow(k, i-offset, "even");
                }
            }
        }

        this.reloadPaintedElements();
    },
    getLocationsOfID: function(id){
        var loc = new Array();
        for(var i = 0; i < this.tiles.length; i++){
            for(var j = 0; j < this.tiles[i].length; j++){
                if(this.tiles[i][j] == id){
                    loc.push(new Array(i, j));
                }
            }
        }
        return loc;
    },
    setLocationsForID: function(it, data, loc){
        for(var i = 0; i < loc.length; i++){
            this.paintTile(it, data.id, loc[i], data.color);
        }
    },
    getPatternTypes: function(id){
        //selectBox options
        var element = this.module.getElementWithID(id);
        if(typeof element != "undefined"){
            var replicates = parseInt(element.replicates) + 1;
            var opt;
            var dis = new Array();
            var i;
            if(Project.IN.tableType == 0){//96 wells
                opt = new Array(
                    "By Template",
                    "By row of the template"
                    );

                for(i = 0; i < opt.length; i++){
                    dis.push(0);
                }

                if(replicates == 1){//if replicates is 1, By row of the template is disabled
                    dis[1] = 1;
                }
                return new Array(opt, dis);
            } else {//384 wells
                opt = new Array(
                    "By template horizontally",
                    "By template vertically (odd columns)",
                    "By template vertically (even columns)",
                    "By row of the template vertically (odd columns)",
                    "By row of the template vertically (even columns)",
                    "Compact"
                    );

                for(i = 0; i < opt.length; i++){
                    dis.push(0);
                }

                if(replicates != 2){
                    dis[0] = 1;//if replicates is not 2, By template horizontally disabled
                }
                if(replicates == 2){
                    dis[5] = 1;//if replicates is 2, Compact disabled
                }

                return new Array(opt, dis);
            }
        } else {
            return new Array({},{});
        }
        
    },
    reloadPattern: function(){//table reload
    	//alert('reloadtablepattern');
        var table = this;
        var geneData = this.module.data;
        var replicates;
        this.resetAllTiles();
        for(var j = 0; j < Project.IN.template.layoutTiles.length; j++){
            Project.IN.template.layoutTiles[j] = new Array();
        }
        
        //96 wells
        if(Project.IN.tableType == 0){
            for(var i = 0; i < geneData.length; i++){
                this.geneID = geneData[i].id;
                replicates = parseInt(geneData[i].replicates) + 1;
                //if replicates is 1, By row of the template is disabled
                if (replicates==1 && geneData[i].patternType==1){
                	geneData[i].patternType = 0;
                }
                switch(geneData[i].patternType){
                    case 0:
                        table.paintByTemplate(replicates, null);
                        break;
                    case 1:
                        table.paintByRowOfTemplate(replicates, null);
                        break;
                }
            }
        //384 wells
        } else {//TODO:: change to improve performance: adding a single gene with need to repaint 
            for(var k = 0; k < geneData.length; k++){
                this.geneID = geneData[k].id;
                replicates = parseInt(geneData[k].replicates) + 1;
                if (replicates!=2 && geneData[k].patternType==0){
                	geneData[k].patternType = 1;
                }else if (replicates==2 && geneData[k].patternType==5){
                	geneData[k].patternType = 0;
                }
                switch(geneData[k].patternType){
                    case 0:
                        // alert('reloadPattern paintByTemplateHorizontally');
                        table.paintByTemplateHorizontally();//default one
                        break;
                    case 1:
                        table.paintByTemplate(replicates, "odd");
                        break;
                    case 2:
                        table.paintByTemplate(replicates, "even");
                        break;
                    case 3:
                        table.paintByRowOfTemplate(replicates, "odd");
                        break;
                    case 4:
                        table.paintByRowOfTemplate(replicates, "even");
                        break;
                    case 5:
                        table.paintCompact(replicates);
                        break;
                }
            }
        }
    }
});


