import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import wren.domain.jsonObject.ProjectObject;


public class TestParseJson {

	  public static void main(String[] args) {
		  TestParseJson testParseJson = new TestParseJson();
		  //String jsonInputFile = "tmp/work2-layout.json";
		  String jsonInputFile = "tmp/notwork-layout.json";
		  testParseJson.parseJsonObject(jsonInputFile);
	   }

	   public void parseJsonObject(String jsonInputFile) {
	       Gson gson = new Gson();
	       try {

	           BufferedReader br = new BufferedReader(
	                   new FileReader(jsonInputFile));
	           //convert the json string back to object
	           ProjectObject projectObj = gson.fromJson(br, ProjectObject.class);
	           System.out.println("DONE");
	       } catch (IOException e) {
	           //e.printStackTrace();
	       }

	   }

}
