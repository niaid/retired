package wren.util;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/*
 * reference: http://code.google.com/p/trillian-goodies/source/browse/trunk/src/main/java/se/trillian/goodies/spring/HostNameBasedPropertyPlaceHolderConfigurer.java?r=116
 *
 */
public class HostNameBasedPropertyPlaceHolderConfigurer extends PropertyPlaceholderConfigurer {

    private static final Log log = LogFactory.getLog(HostNameBasedPropertyPlaceHolderConfigurer.class);
    private Resource[] locations;
    private final static String prodJDBC = "jdbc.properties";
    private final static String devJDBC = "jdbcdev.properties";
    private final static String localJDBC = "jdbclocal.properties";
    private final static String devServer = "dev";
    private final static String localServer = "m-bcbb-10108";//Qina's desktop
    private final static String localServer2 = "L01787085";//Qina's laptop

    public HostNameBasedPropertyPlaceHolderConfigurer() {
        setLocation(new ClassPathResource("/" + prodJDBC));
        setIgnoreResourceNotFound(true);
    }

    @Override
    public void setLocation(Resource location) {
        this.setLocations(new Resource[]{location});
    }

    @Override
    public void postProcessBeanFactory(
            ConfigurableListableBeanFactory beanFactory) throws BeansException {


        String hostName = "localhost";
        try {
            hostName = getHostName();
        } catch (UnknownHostException uhe) {
            log.warn("Could not determine the name for the current host. Using '"
                    + hostName + "'.");
        }

        try {
            List<Resource> newLocations = new ArrayList<Resource>();
            for (Resource res : locations) {
                if (hostName.contains(devServer)) {
                    newLocations.add(res.createRelative(devJDBC));
                } else if (hostName.contains(localServer) || hostName.contains(localServer2)) {
                    newLocations.add(res.createRelative(localJDBC));
                } else {
                    newLocations.add(res.createRelative(prodJDBC));
                }
            }
            super.setLocations(newLocations.toArray(new Resource[0]));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        super.postProcessBeanFactory(beanFactory);
    }

    @Override
    public void setLocations(Resource[] locations) {
        this.locations = locations;
    }

    protected String getHostName() throws UnknownHostException {
        return InetAddress.getLocalHost().getHostName();
    }
}
