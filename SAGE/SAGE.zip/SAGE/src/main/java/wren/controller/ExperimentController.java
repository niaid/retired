package wren.controller;

import com.google.gson.Gson;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import wren.domain.CustomizedUser;
import wren.domain.Experiment;
import wren.domain.Layout;
import wren.domain.ResultObj;
import wren.domain.User;
import wren.dto.ExperimentDTO;
import wren.dto.LayoutDTO;
import wren.dto.WorkBookSerializable;
import wren.service.ExperimentService;
import wren.service.WorkBookGenerator;
import wren.service.WorkSheetGenerator;

/**
 * @author ningj 2/28/2013, removed warnings
 */
@Controller
@RequestMapping("/")
public class ExperimentController {

    @Autowired
    private ExperimentService experimentService;
    protected static final Logger logger = Logger.getLogger("ExperimentController");

    @RequestMapping(value = "/createNewExperiment", method = RequestMethod.GET)
    public String createNewExperiment(ModelMap model) {
        model.addAttribute("optionType", "1");//experiment
        model.addAttribute("id", "0");
        model.addAttribute("selectedJson", "0");
        return "wren";
    }

    /**
     * listExperimentsForUser
     */
    @RequestMapping(value = "/listExperiments", method = RequestMethod.GET)
    String listExperiments(HttpServletRequest request,
            HttpServletResponse response, ModelMap model) {
        response.setContentType("text/html");
        String myAction = request.getParameter("myAction");
        List<ExperimentDTO> experimentDTOList = getExperimentList(myAction);
        model.addAttribute("experimentList", experimentDTOList);
        if (myAction != null && !myAction.equals("null")) {
            model.addAttribute("myAction", myAction);
        }
        return "listExperiments";
    }

    @RequestMapping(value = "/listExperimentGenes", method = RequestMethod.POST)
    public @ResponseBody
    void listExperimentGenes(HttpServletRequest request,
            HttpServletResponse response, Model model) {
        response.setContentType("text/html");
        Integer experimentID = Integer.parseInt(request.getParameter("experimentID"));

        List<Layout> layouts = experimentService.listLayouts(experimentID);
        List<LayoutDTO> layoutDTOList = new ArrayList<LayoutDTO>();
        //List<String> layoutStrList = new ArrayList<String>();
        for (Layout layout : layouts) {
            // System.out.println("aac layout: "+layout);

            LayoutDTO layoutDTO = new LayoutDTO(layout.getId(), layout.getWorksheetName(),
                    layout.getCreatedDate(), layout.getLastModifiedDate());
            layoutDTO.setReferenceGenes(layout.getRefGeneNames());
            layoutDTO.setTargetGenes(layout.getTargetGeneNames());
            layoutDTOList.add(layoutDTO);
            //layoutStrList.add(layoutDTO.getName()+" "+layoutDTO.getReferenceGenes());
            //logger.warning("listLayout: "+layoutDTO.getName()+" "+layoutDTO.getReferenceGenes());
        }
        //if return a simple String object, not need to convert to json.
        //just change the void type to String
        Gson gson = new Gson();
        String json = gson.toJson(layoutDTOList);
        try {
            response.getWriter().write(json.toString());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
        }
    }

    /**
     * listLayoutsByExperiment
     */
    @RequestMapping(value = "/listLayoutsByExperiment", method = RequestMethod.GET)
    String listLayouts(HttpServletRequest request,
            HttpServletResponse response, ModelMap model) {
        response.setContentType("text/html");
        int experimentID = Integer.parseInt(request.getParameter("experimentID"));
        List<Layout> layouts = experimentService.listLayouts(experimentID);
        List<LayoutDTO> layoutDTOList = new ArrayList<LayoutDTO>();

        for (Layout layout : layouts) {
            // System.out.println("aac layout: "+layout);
            //logger.warning("listLayout: "+layout.getExperimentId()+" "+layout.getWorksheetName());
            LayoutDTO layoutDTO = new LayoutDTO(layout.getId(), layout.getWorksheetName(),
                    layout.getCreatedDate(), layout.getLastModifiedDate());
            layoutDTOList.add(layoutDTO);
        }
        //logger.warning("experimentID==xx======="+experimentID);
        model.addAttribute("layoutList", layoutDTOList);


        String myAction = request.getParameter("myAction");
        HttpSession session = request.getSession(true);
        if (myAction != null && myAction.equals("listExperimentDetail")) {

            Experiment experiment = experimentService
                    .getExperimentByID(experimentID);
            ExperimentDTO experimentDTO = new ExperimentDTO(experiment.getId(),
                    experiment.getName(), experiment.getCreatedDate(),
                    experiment.getLastModifiedDate(), experiment.getUser()
                    .getLoginName(), experiment.getHasLayout());
            model.addAttribute("myExperiment", experimentDTO);
            ////////////////
            //load data for download

            WorkBookGenerator workBookGenerator = new WorkBookGenerator(
                    experimentID, -1, layouts, null, null,
                    "worksheetNamePlaceHolder", getTempFilePath(request, "xls"), null);
            session.setAttribute("experimentName", experiment.getName());
            //session.setAttribute("workBook", workBookGenerator);
            WorkBookSerializable workBookSerializable = new WorkBookSerializable(workBookGenerator);
            session.setAttribute("workBook", workBookSerializable);

            session.setAttribute("worksheetMap", workBookGenerator.getWorksheetMap());
            ////////////////////////

            return "listExperimentDetail";
        } else {
            session.setAttribute("myAction", myAction);
            session.setAttribute("experimentID", experimentID);
            return "listLayouts";
        }

    }

    /**
     * saveTemplateJson
     */
    //save the templateJson object to session and save to database at the last step (upload text file)
    @RequestMapping(value = "/saveTemplateJson", method = RequestMethod.POST)
    public @ResponseBody
    String saveTemplateJson(HttpServletRequest request,
            HttpServletResponse response, Model model) {
        //response.setContentType("text/html");
        //logger.warning("saveTemplateJson");
        Integer experimentID = Integer.parseInt(request.getParameter("experimentID"));
        String experimentName = request.getParameter("experimentName");
        String templateJson = request.getParameter("templateJson");
        int userID = getCurrentUser().getId();

        //int newExperimentID = experimentService.saveWholeExperiment(null, templateJson, null,
        //templateJson, worksheetName, experimentID, -1, getCurrentUser().getId(), savedLayoutID);

        //int newExperimentID = experimentService.saveTemplate(experimentID, experimentName, templateJson, userID, savedLayoutID);
        Integer newExperimentID = experimentService.saveExperiment(experimentID, experimentName, templateJson, userID);
        //int newExperimentID = -1;
        HttpSession session = request.getSession(true);
        session.setAttribute("templateJson", templateJson);
        session.setAttribute("experimentID", newExperimentID);
        //
        //logger.warning("xxbbbxSAVE id="+newExperimentID+" experimentName="+experimentName+" userID = "+userID);
        return "" + newExperimentID;
    }

    /**
     * user choose one existing experiment
     */
    @RequestMapping(value = "/assignExperiment", method = RequestMethod.GET)
    String assignExperiment(HttpServletRequest request,
            HttpServletResponse response, ModelMap model) {
        response.setContentType("text/html");
        String experimentID = request.getParameter("experimentID");
        int experiment_id = Integer.parseInt(experimentID);
        if (isCurrentUserOwner(experiment_id)) {//security check, incase someone manually change url experiment id
            int[] hasLayout = {1};
            String json = experimentService.getExperimentJsonString(experimentID, hasLayout);
            if (hasLayout[0] == 0) {//edit template
                model.addAttribute("optionType", "4");
            } else {
                model.addAttribute("optionType", "2");//experiment
            }

            model.addAttribute("selectedJson", json);
            model.addAttribute("id", experimentID);
            return "wren";
        } else {
            return "loginpage";
        }
    }

    @RequestMapping(value = "/assignExperimenLayout", method = RequestMethod.GET)
    String assignExperimentLayout(HttpServletRequest request,
            HttpServletResponse response, ModelMap model) {
        response.setContentType("text/html");
        String experimentID = request.getParameter("experimentID");
        int experiment_id = Integer.parseInt(experimentID);
        if (isCurrentUserOwner(experiment_id)) {//security check, incase someone manually change url experiment id
            int[] hasLayout = {1};
            String json = experimentService.getExperimentJsonString(experimentID, hasLayout);
            model.addAttribute("optionType", "2");//experiment
            model.addAttribute("selectedJson", json);
            model.addAttribute("id", experimentID);
            return "wren";
        } else {
            return "loginpage";
        }
    }

    /**
     * user choose one existing experiment
     */
    @RequestMapping(value = "/assignLayout", method = RequestMethod.GET)
    //public @ResponseBody
    String assignLayout(HttpServletRequest request,
            HttpServletResponse response, ModelMap model) {
        response.setContentType("text/html");
        String layoutID = request.getParameter("layoutID");
        //logger.warning("assignLayout layoutID"+layoutID);
        String json = experimentService.getLayoutJsonString(layoutID);

        HttpSession session = request.getSession(true);
        String myAction = (String) session.getAttribute("myAction");
        model.addAttribute("optionType", "3");//layout
        model.addAttribute("selectedJson", json);

        if ("editLayoutNewExperiment".equals(myAction)) {
            model.addAttribute("id", "-1");
        } else {
            model.addAttribute("id", layoutID);
        }
        return "wren";
    }

    //deleteExperiment
    @RequestMapping(value = "/deleteExperiment", method = RequestMethod.GET)
    public String deleteExperiment(HttpServletRequest request,
            HttpServletResponse response, ModelMap model) {
        response.setContentType("text/html");
        int experimentID = Integer.parseInt(request.getParameter("id"));
        if (isCurrentUserOwner(experimentID)) {//security check, in case someone manually change url experiment id
            experimentService.deleteExperiment(experimentID);
            return "redirect:listExperiments?myAction=listExperimentDetail";
        } else {
            return "loginpage";
        }
    }

    private boolean isCurrentUserOwner(int experimentID) {
        boolean isOwner = false;
        CustomizedUser currentSessionUser = getCurrentUser();
        Experiment experiment = experimentService.getExperimentByID(experimentID);
        try {
            //logger.warning("currentSessionUser.getId()= "+currentSessionUser.getId()+" experiment.getUser().getId()="+experiment.getUser().getId());
            if (currentSessionUser.getRole().equalsIgnoreCase("admin")
                    || (experiment != null && currentSessionUser.getId().equals(experiment.getUser().getId()))) {
                isOwner = true;
            }
        } catch (Exception ex) {
            logger.log(Level.WARNING, "SET user security ERROR: {0}", ex.getMessage());
            //ex.printStackTrace();
        }
        //logger.warning("isOwner= "+isOwner);
        return isOwner;
    }

    /**
     * handle create the excel workbook and save to database
     */
    @RequestMapping(value = "/service/uploadDataFile", method = RequestMethod.POST)
    public @ResponseBody
    void uploadDataFile(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html");
        String[] projectContentString = new String[4];
        FileItem uploadItem = getFileItem(request, projectContentString);
        String worksheetName = "run1";
        if (uploadItem == null) {
            try {
                response.getWriter().write("{}");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
            }
        }
        String type = projectContentString[1];

        File tempDir = (File) request
                .getAttribute("javax.servlet.context.tempdir");

        // create a temporary file in that directory
        File tempFile = null;
        try {
            tempFile = File.createTempFile(request.getClass().getSimpleName(),
                    "tmp.xls", tempDir);
        } catch (IOException e) {
            //e.printStackTrace();
        }

        File tmpDir = new File(request.getSession().getServletContext().getRealPath("/tmp"));
        if (!tmpDir.exists()) {
            tmpDir.mkdir();
        }

        String tempFoldChangeHTMLFileName = tmpDir.getAbsolutePath()
                + "/FoldChangeChart.html";
        File tempFoldChangeHTMLFile = new File(tempFoldChangeHTMLFileName);

        String contents = uploadItem.getString();
        if ("json".equals(type)) {// upload template/layout
            try {
                response.getWriter().write(contents);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
            }
        } else {// upload the inputFile
            HttpSession session = request.getSession(true);
            int experimentID = -2;
            try {
                experimentID = Integer.parseInt(projectContentString[2]);
            } catch (Exception ex) {
            }
            if (experimentID < 0) {
                experimentID = (Integer) session.getAttribute("experimentID");
            }
            int layoutID = -2;
            try {
                layoutID = Integer.parseInt(projectContentString[3]);
            } catch (Exception ex) {
            }
            WorkBookGenerator workBookGenerator;// = null;
            //logger.warning("experimentID=="+experimentID);
            if (experimentID > 0) {//multiple worksheet
                List<Layout> listLayouts = experimentService.listLayouts(experimentID);
                workBookGenerator = new WorkBookGenerator(experimentID, layoutID, listLayouts,
                        contents, projectContentString[0], worksheetName,
                        tempFile.getAbsolutePath(), tempFoldChangeHTMLFile
                        .getAbsolutePath());

            } else {//new and only worksheet in the workbook
                workBookGenerator = new WorkBookGenerator(contents,
                        projectContentString[0], worksheetName, tempFile
                        .getAbsolutePath(), tempFoldChangeHTMLFile
                        .getAbsolutePath());

            }

            //session.setAttribute("workBook", workBookGenerator);
            WorkBookSerializable workBookSerializable = new WorkBookSerializable(workBookGenerator);
            session.setAttribute("workBook", workBookSerializable);
            // save to database
            String templateJson = (String) session.getAttribute("templateJson");
            worksheetName = workBookGenerator.getCurrentWorkSheetName();
            int[] savedLayoutID = {-1};
            experimentService.saveWholeExperiment(workBookGenerator, templateJson, contents,
                    projectContentString[0], worksheetName, experimentID, layoutID, getCurrentUser().getId(), savedLayoutID, null);
            layoutID = savedLayoutID[0];
            //logger.warning("saved LayoutID="+layoutID);
            try {
                String webStr = workBookGenerator.getWebResultString();
                String reCalculateStr2 = ResultObj.reCalculateStr.replace("()", "(" + layoutID + ")");
                if (webStr != null && reCalculateStr2 != null) {
                    webStr = webStr.replace(ResultObj.reCalculateStr, reCalculateStr2);
                    if (webStr == null) {
                        webStr = "WARNIGN: webStr==null";
                    }
                } else {
                    logger.log(Level.WARNING, "WARNING: webStr={0}", webStr);
                }
                response.getWriter().write(webStr);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
            }
        }
    }

    /**
     * handle create the excel workbook and save to database
     */
    @RequestMapping(value = "/service/saveWholeExperiment", method = RequestMethod.POST)
    public @ResponseBody
    String saveWholeExperiment(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("text/html");

        Integer experimentID = Integer.parseInt(request.getParameter("experimentID"));
        Integer layoutID = Integer.parseInt(request.getParameter("layoutID"));
        String experimentName = request.getParameter("experimentName");
        String layoutJson = request.getParameter("layoutJson");
        //int userID = getCurrentUser().getId();

        int[] savedLayoutID = {-1};
        String worksheetName = "run1";


        //Integer newExperimentID = -1;


        File tempDir = (File) request
                .getAttribute("javax.servlet.context.tempdir");

        // create a temporary file in that directory
        File tempFile = null;
        try {
            tempFile = File.createTempFile(request.getClass().getSimpleName(),
                    "tmp.xls", tempDir);
        } catch (IOException e) {
            //e.printStackTrace();
            logger.log(Level.SEVERE, "File IO error: ", e.toString());
            return null;
        }

        File tmpDir = new File(request.getSession().getServletContext().getRealPath("/tmp"));
        if (!tmpDir.exists()) {
            tmpDir.mkdir();
        }

//		String tempFoldChangeHTMLFileName = tmpDir.getAbsolutePath()
//				+ "/FoldChangeChart.html";
        //File tempFoldChangeHTMLFile = new File(tempFoldChangeHTMLFileName);

        //String contents = uploadItem.getString();
        if ("json".equals("XXX")) {// upload template/layout
        } else {// upload the inputFile
            HttpSession session = request.getSession(true);
            String templateJson = (String) session.getAttribute("templateJson");
            experimentService.saveWholeExperiment(null, templateJson, null,
                    layoutJson, worksheetName, experimentID, layoutID, getCurrentUser().getId(), savedLayoutID, experimentName);
            layoutID = savedLayoutID[0];
        }
        return "" + layoutID;
    }

    /**
     * show worksheet web output
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/downloadWeboutput", method = RequestMethod.GET)
    public String downloadWeboutput(HttpServletRequest request, HttpServletResponse response) {
        int experimentID = Integer.parseInt(request.getParameter("experimentID"));
        int layoutID = Integer.parseInt(request.getParameter("layoutID"));
        HttpSession session = request.getSession(true);
        Map<Integer, WorkSheetGenerator> worksheetMap = (Map<Integer, WorkSheetGenerator>) session.getAttribute("worksheetMap");
        WorkSheetGenerator ws = worksheetMap.get(layoutID);
        //logger.warning(ws.getWorkSheetName()+" REFERENCE GENES: "+ws.getReferenceGenes());
        //logger.warning(ws.getWorkSheetName()+" TARGET GENES: "+ws.getTargetGenes());

        String webString = ws.getWebResultReadonly();
        session.setAttribute("layoutWeboutput", webString);
        session.setAttribute("experimentID", experimentID);

        return "viewLayoutWebOutput";

    }

    private List<ExperimentDTO> getExperimentList(String myAction) {
        CustomizedUser currentUser = getCurrentUser();
        String username = currentUser.getUsername();
        //logger.warning("current user:: " + username+" listExperiments");
        List<Experiment> experiments;// = null;
        if (currentUser.getRole() != null && currentUser.getRole().equalsIgnoreCase("admin")) {
            experiments = experimentService
                    .listExperiment();
        } else if (currentUser.getRole() != null && currentUser.getRole().equalsIgnoreCase("user")) {
            experiments = experimentService
                    .listExperimentByUsername(currentUser.getId(), username);
        } else {
            experiments = experimentService
                    .listExperimentByGroup(currentUser.getId(), currentUser.getRole());
        }
        List<ExperimentDTO> experimentDTOList = new ArrayList<ExperimentDTO>();
        boolean toShow = true;
        int userID = currentUser.getId();
        for (Experiment experiment : experiments) {
            //toShow = false;
            int hasLayout = experiment.getHasLayout();
//			if (hasLayout == 0 && myAction.equals("newLayout")){
//				toShow = true;
//			}else if (hasLayout == 1 && !myAction.equals("newLayout")){
//				toShow = true;
//			}else if (myAction.equals("listExperimentDetail")){
//				toShow = true;
//			}
            if (toShow) {
                int experimentUserID = experiment.getUser().getId();
                boolean deletable = false;
                if (userID == experimentUserID) {
                    deletable = true;
                }
                if (!deletable && myAction.equals("editLayout")) {
                    toShow = false;
                } else {
                    ExperimentDTO experimentDTO = new ExperimentDTO(experiment.getId(), experiment.getName(),
                            experiment.getCreatedDate(),
                            experiment.getLastModifiedDate(),
                            experiment.getUser().getLoginName(), hasLayout, deletable);
                    experimentDTOList.add(experimentDTO);
                    toShow = true;
                }
            }
        }
        return experimentDTOList;

    }

    private FileItem getFileItem(HttpServletRequest request,
            String[] projectContentString) {
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        FileItem myItem = null;
        try {
            List<FileItem> items = upload.parseRequest(request);
            for (FileItem item : items) {
                // System.out.println(item.getFieldName()+" name:"+item.getName()+" string: "+item.getString());
                if (!item.isFormField()
                        && ("uploadTemplateForm".equals(item.getFieldName()) || "uploadLayoutForm"
                        .equals(item.getFieldName()))) {
                    myItem = item;
                } else if ("type".equals(item.getFieldName())) {
                    projectContentString[1] = item.getString();
                } else if ("projectObject".equals(item.getFieldName())) {
                    projectContentString[0] = item.getString();
                    // System.out.println("XXX"+item.getFieldName()+"==>"+item.getString());
                } else if ("experimentID".equals(item.getFieldName())) {
                    projectContentString[2] = item.getString();
                } else if ("layoutID".equals(item.getFieldName())) {
                    projectContentString[3] = item.getString();
                    // System.out.println("XXX getFileItem "+item.getFieldName()+"=YYYYYYY=>"+item.getString());
                }
            }
        } catch (Exception e) {
            //System.out.println("Error occured in uploading File");
            logger.log(Level.WARNING, "Error occured in uploading File {0}", e.toString());
            return null;
        }
        return myItem;
    }

    public synchronized CustomizedUser getCurrentUser() {
        Object obj = SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
        CustomizedUser currentUser = null;
        if (obj instanceof CustomizedUser) {
            currentUser = ((CustomizedUser) obj);
        }
        return currentUser;

    }

    public synchronized User getDBCurrentUser() {
        CustomizedUser currentUser = getCurrentUser();
        User dbCurrentUser = experimentService.getUser(currentUser.getId());
        return dbCurrentUser;

    }

    public String getTempFilePath(HttpServletRequest request, String suffix) {
        File tempDir = (File) request
                .getAttribute("javax.servlet.context.tempdir");

        // create a temporary file in that directory
        File tempFile = null;
        try {
            tempFile = File.createTempFile(request.getClass().getSimpleName(),
                    "tmp." + suffix, tempDir);
        } catch (IOException e) {
            //e.printStackTrace();
            logger.log(Level.SEVERE, "File IO Error: ", e.toString());
        }

        return tempFile.getAbsolutePath();
    }
}
