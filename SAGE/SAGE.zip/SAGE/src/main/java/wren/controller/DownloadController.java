package wren.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import wren.dto.WorkBookSerializable;

/**
 * Handles downloads
 *
 * @author Qina Tan
 * @author ningj 2/28/2013, removed warnings
 */
@Controller
@RequestMapping("/")
public class DownloadController {

    protected static final Logger logger = Logger.getLogger("DownloadController");

    /**
     * download experiment excel sheet
     */
    @RequestMapping(value = "/service/downloadWorkbook", method = RequestMethod.GET)
    public @ResponseBody
    void downloadWorkbook(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(true);
        //WorkBookGenerator workBookGenerator = (WorkBookGenerator)session.getAttribute("workBook");
        WorkBookSerializable workBook = (WorkBookSerializable) session.getAttribute("workBook");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + workBook.getWorkBookDisplayName() + "\"");
        //OutputStream out = null;
        try {
            OutputStream out = response.getOutputStream();
            byte[] workbookByte = workBook.getWorkbookByte();
            InputStream in = new ByteArrayInputStream(workbookByte);
            HSSFWorkbook wb = new HSSFWorkbook(in);
            wb.write(out);
            //workBookGenerator.getWorkBook().write(out);
            out.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
            logger.log(Level.SEVERE, "File IO error: ", e.getMessage());
        }
    }

    @RequestMapping(value = "/service/downloadHTML", method = RequestMethod.GET)
    public @ResponseBody
    void downloadHTML(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(true);
//        WorkBookGenerator workBookGenerator = (WorkBookGenerator) session
//			.getAttribute("workBook");
        WorkBookSerializable workBook = (WorkBookSerializable) session.getAttribute("workBook");
        List<String> postGoogleChartNameList = workBook.getPostGoogleChartNameList();
        if (postGoogleChartNameList == null || postGoogleChartNameList.isEmpty()) {//only one html
            downloadOneFile(response, workBook);
        } else {//zip files
            downloadZipFile(request, response, workBook, postGoogleChartNameList);
        }


    }

    private void downloadOneFile(HttpServletResponse response, WorkBookSerializable workBook) {
        response.setHeader("Content-Disposition", "attachment; filename=\""
                + workBook.getHtmlFileName() + "\"");
        //OutputStream out = null;
        try {
            OutputStream out = response.getOutputStream();
            String webResult = workBook.getWebResultWithScript();
            final PrintStream printStream = new PrintStream(out);
            printStream.print(webResult);
            printStream.close();
            out.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
            logger.log(Level.SEVERE, "IO error: ", e.getMessage());
        }

    }

    private void downloadZipFile(HttpServletRequest request, HttpServletResponse response,
            WorkBookSerializable workBook, List<String> postGoogleChartNameList) {
        try {
            HttpSession session = request.getSession(true);
            String path = session.getServletContext().getRealPath("tmp");

            File directory = new File(path);
            String[] files = directory.list();
            if (files != null && files.length > 0) {
                byte[] zip = zipFiles(workBook, directory, postGoogleChartNameList);
                ServletOutputStream sos = response.getOutputStream();
                response.setContentType("application/zip");
                String zipFileName = workBook.getHtmlFileName().replace(".html", ".zip");
                response.setHeader("Content-Disposition", "attachment; filename=\"" + zipFileName + "\"");
                sos.write(zip);
                sos.flush();
            }
        } catch (Exception e) {
            //e.printStackTrace();
            logger.log(Level.SEVERE, "IO error: ", e.getMessage());
        }
    }

    /**
     * Compress the given directory with all its files.
     */
    private byte[] zipFiles(WorkBookSerializable workBook,
            File directory, List<String> postGoogleChartNameList) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(baos);
        byte bytes[] = new byte[2048];
        String FILE_SEPARATOR = "/";
        String tmpDir = "tmp/";

        //addOneHTMLFile();
        String webResult = workBook.getWebResultWithScript();
        String htmlFileName = workBook.getHtmlFileName();
        zos.putNextEntry(new ZipEntry(htmlFileName));
        byte myByte[] = webResult.getBytes();
        zos.write(myByte, 0, myByte.length);
        zos.closeEntry();

        for (String fileName : postGoogleChartNameList) {
            try {
                FileInputStream fis = new FileInputStream(directory.getPath() + FILE_SEPARATOR + fileName);
                BufferedInputStream bis = new BufferedInputStream(fis);
                zos.putNextEntry(new ZipEntry(tmpDir + fileName));
                int bytesRead;
                while ((bytesRead = bis.read(bytes)) != -1) {
                    zos.write(bytes, 0, bytesRead);
                }
                zos.closeEntry();
                bis.close();
                fis.close();
            } catch (Exception ex) {
                logger.log(Level.WARNING, "ZIP file error {0}", ex.getMessage());
                //ex.printStackTrace();
            }

        }
//        for (String fileName : files) {
//        	if (postGoogleChartNameList.contains(fileName)){
//        		 FileInputStream fis = new FileInputStream(directory.getPath() + FILE_SEPARATOR + fileName);
//                 BufferedInputStream bis = new BufferedInputStream(fis);
//                 zos.putNextEntry(new ZipEntry(tmpDir+fileName));
//                 int bytesRead;
//                 while ((bytesRead = bis.read(bytes)) != -1) {
//                     zos.write(bytes, 0, bytesRead);
//                 }
//                 zos.closeEntry();
//                 bis.close();
//                 fis.close();
//        	}
//        }
        zos.flush();
        baos.flush();
        zos.close();
        baos.close();
        return baos.toByteArray();
    }
}
