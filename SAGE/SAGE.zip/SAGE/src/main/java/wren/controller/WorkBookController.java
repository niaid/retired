package wren.controller;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import wren.domain.jsonObject.ProjectObject;
import wren.domain.jsonObject.ReferenceGene;
import wren.service.WorkBookGenerator;

/**
 *
 * @author tanq
 * @author ningj 2/28/2013, removed warnings
 */
public class WorkBookController {

    protected static final Logger logger = Logger.getLogger("WorkBookController");
    int experimentID;
    List<String> inputTexts = new ArrayList<String>();
    List<String> jsonStrings = new ArrayList<String>();
    List<String> workSheetNames = new ArrayList<String>();

    public WorkBookController(int experimentID) {
        this.experimentID = experimentID;
        //get data from database

        //FOR TESTING TEMPORARY

    }

    public WorkBookController(String experimentID) {
        this.experimentID = Integer.parseInt(experimentID);
    }

    //TODO:: DB
    public void populateExistingLayoutData() throws IOException {
//        String[] inputFiles = {"tmp/ROBOT2.txt"};
//        //String[] jsonInputFiles = {"tmp/refGene1.json"};
//        String[] jsonInputFiles = {"tmp/ROBOT2.json"};
//        String[] workSheetNames = {"Project WorkSheet 1"};


        String[] inputFiles = {"../webapps/SAGE/tmp/ROBOT2.txt"};
        //String[] jsonInputFiles = {"tmp/refGene1.json"};
        String[] jsonInputFiles = {"../webapps/SAGE/tmp/ROBOT2.json"};
        String[] wsNames = {"Project WorkSheet 1"};

        //  String[] inputTexts = new String[inputFiles.length];
        //   String[] jsonStrings = new String[jsonInputFiles.length];

        for (int i = 0; i < inputFiles.length; i++) {
            this.inputTexts.add(WorkBookGenerator.readFileAsString(inputFiles[i]));
            this.jsonStrings.add(WorkBookGenerator.readFileAsString(jsonInputFiles[i]));
            this.workSheetNames.add(wsNames[i]);
        }
    }

    public void saveToDatabase(String inputText, List<ReferenceGene> referenceGenes) {
    }

    public static void main(String[] args) throws IOException {
        WorkBookController controller = new WorkBookController(1111);
        controller.parseObject();
    }

    //TODO:: may remove after debug
    ///Applications/NetBeans/glassfish-3.1.1/glassfish/domains/domain1/
    public ProjectObject parseObject() {
        Gson gson = new Gson();
        ProjectObject obj = null;
        try {
            String dir = System.getProperty("user.dir");
            BufferedReader br;// = null;
            if (dir.contains("apache")) {//apache/bin
                br = new BufferedReader(
                        new FileReader("../webapps/SAGE/tmp/ROBOT2.json"));
            } else {
                br = new BufferedReader(
                        new FileReader("tmp/ROBOT2.json"));
            }
            //System.out.println("current dir: " + System.getProperty("user.dir"));
//            BufferedReader br = new BufferedReader(
//                    new FileReader("../webapps/WREN/tmp/ROBOT2.json"));


            //convert the json string back to object
            obj = gson.fromJson(br, ProjectObject.class);

            // System.out.println("PARSED OBJECT: " + obj);

        } catch (IOException e) {
            //e.printStackTrace();
            //System.out.println("FILE: "+System.getProperty("user.dir"));
            logger.log(Level.WARNING, "FILE: {0}", System.getProperty("user.dir"));
        }
        return obj;
    }

    public int getExperimentID() {
        return experimentID;
    }

    public void setExperimentID(int experimentID) {
        this.experimentID = experimentID;
    }

    public List<String> getInputTexts() {
        return inputTexts;
    }

    public void setInputTexts(List<String> inputTexts) {
        this.inputTexts = inputTexts;
    }

    public List<String> getJsonStrings() {
        return jsonStrings;
    }

    public void setJsonStrings(List<String> jsonStrings) {
        this.jsonStrings = jsonStrings;
    }

    public List<String> getWorkSheetNames() {
        return workSheetNames;
    }

    public void setWorkSheetNames(List<String> workSheetNames) {
        this.workSheetNames = workSheetNames;
    }
}
