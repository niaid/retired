package wren.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import wren.domain.CustomizedUser;
import wren.dto.WorkBookSerializable;
import wren.form.ContactUsForm;
import wren.form.CreateNewAccountForm;
import wren.form.ForgetPasswordForm;
import wren.service.MailService;

/**
 * Handles and retrieves the common or admin page depending on the URI template.
 * A user must be log-in first he can access these pages. Only the admin can see
 * the adminpage, however.
 * @author ningj 2/28/2013, removed warnings
 */
@Controller
@RequestMapping("/")
public class MainController {

    @Autowired
    //private ExperimentService experimentService;
    protected static final Logger logger = Logger.getLogger("MainController");
    static final String sendEmailError = "Server encountered problem submitting your request. Please try again";
    static final String createUserError = "Server encountered problem creating new user. Our support team will look into the problem. Thank you.";
    //@Autowired
    //private ExperimentService experimentService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String getIndexPage() {
        return "index";
    }

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public String getIndexPage2() {
        return "index";
    }

    @RequestMapping(value = "/newExpMenu", method = RequestMethod.GET)
    public String getNewExpMenu() {
        return "newExpMenu";
    }

    @RequestMapping(value = "/modifyExpMenu", method = RequestMethod.GET)
    public String getModifyExpMenu() {
        return "modifyExpMenu";
    }

    @RequestMapping(value = "/whatsSAGE", method = RequestMethod.GET)
    public String getWhatsSAGE() {
        return "whatsSAGE";
    }

    @RequestMapping(value = "/FAQ", method = RequestMethod.GET)
    public String getFAQ() {
        return "FAQ";
    }

    @RequestMapping(value = "/disclaimer", method = RequestMethod.GET)
    public String getDisclaimer() {
        return "disclaimer";
    }

    @RequestMapping(value = "/downloadDemoFiles", method = RequestMethod.GET)
    public String getDownloadDemoFiles() {
        return "downloadDemoFiles";
    }
//	@RequestMapping(value = "/contactUs", method = RequestMethod.GET)
//	public String getContactUs() {
//		return "contactUs";
//	}

    @RequestMapping(value = "/contactUs", method = RequestMethod.GET)
    public void contactUsForm(Model model) {
        model.addAttribute(new ContactUsForm());
    }

    @RequestMapping(value = "/contactUs", method = RequestMethod.POST)
    public String processContactUsForm(@Valid ContactUsForm contactUsForm,
            BindingResult result, Map model) {
        if (result.hasErrors()) {
            return "contactUs";
        }
        MailService ms = new MailService();
        boolean emailSent = ms.sendMail(contactUsForm.getSendMessage());
        if (!emailSent) {
            contactUsForm.setErrorMessage(sendEmailError);
        } else {
            contactUsForm.setErrorMessage(null);
        }
        model.put("contactUsForm", contactUsForm);
        return "submitContactUs";
    }

    @RequestMapping(value = "/forgetPassword", method = RequestMethod.GET)
    public void forgetPasswordForm(Model model) {
        model.addAttribute(new ForgetPasswordForm());
    }

    @RequestMapping(value = "/forgetPassword", method = RequestMethod.POST)
    public String processForgetPasswordForm(@Valid ForgetPasswordForm forgetPasswordForm,
            BindingResult result, Map model) {
        if (result.hasErrors()) {
            return "forgetPassword";
        }
        MailService ms = new MailService();
        boolean emailSent = ms.sendMail(forgetPasswordForm.getSendMessage());
        if (!emailSent) {
            forgetPasswordForm.setErrorMessage(sendEmailError);
        } else {
            forgetPasswordForm.setErrorMessage(null);
        }
        model.put("forgetPasswordForm", forgetPasswordForm);
        return "submitForgetPassword";
    }

//	@RequestMapping(value = "/showMessage", method = RequestMethod.POST)
//	public void simple(@ModelAttribute ContactUsForm contactUsForm, Model model) {
//		model.addAttribute("contactUsForm", contactUsForm);
//	}
    @RequestMapping(value = "/createNewAccount", method = RequestMethod.GET)
    public void createNewAccountForm(Model model) {
        //System.out.println("createNewAccount GET");
        model.addAttribute(new CreateNewAccountForm());
    }

    @RequestMapping(value = "/createNewAccount", method = RequestMethod.POST)
    public String processContactUsForm(@Valid CreateNewAccountForm createNewAccountForm,
            BindingResult result, Map model) {
        //System.out.println("createNewAccount POST");
        if (result.hasErrors()) {
            return "createNewAccount";
        }
        //System.out.println("createNewAccount MAILING");
        //MAIL or INSERT TO DB directly
        MailService ms = new MailService();
        boolean emailSent = ms.sendMail(createNewAccountForm.getSendMessage());
        if (!emailSent) {
            createNewAccountForm.setErrorMessage(sendEmailError);
        } else {
            createNewAccountForm.setErrorMessage(null);
        }
        //automatically create user
//		User user = new User();
//		user.setLoginName(createNewAccountForm.getEmail());
//		user.setFirstName(createNewAccountForm.getFirstName());
//		user.setLastName(createNewAccountForm.getLastName());
//		user.setPassword(createNewAccountForm.getEncryptedPassword());
//		//user.setPassword(createNewAccountForm.getEncryptedPassword());
//		user.setRole(User.DEFAULT_ROLE);
//		int userID = experimentService.saveUser(user);
//		if (userID>0) {
//			createNewAccountForm.setErrorMessage(null);
//		}else{
//			createNewAccountForm.setErrorMessage(createUserError);
//			String message = createNewAccountForm.getSendMessage();
//			ms.setErrorTargetEmail();
//			ms.sendMail("Message created by SAGE\nCreate New User ERROR:\n"+message);
//		}
        //end of automatically create user
        model.put("createNewAccountForm", createNewAccountForm);
        return "submitCreateNewAccount";
    }

//	@RequestMapping(value = "/createNewAccount", method = RequestMethod.GET)
//	public String getCreateNewAccount() {
//		return "createNewAccount";
//	}
//
//	@RequestMapping(value = "/submitCreateNewAccount", method = RequestMethod.POST)
//	public String getSubmitCreateNewAccount() {
//		return "showMessage";
//	}
    @RequestMapping(value = "/service/downloadFile", method = RequestMethod.POST)
    public @ResponseBody
    void downloadFile(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("application/force-download");

        String projectName = request.getParameter("downloadName");
        String filetype = "-" + request.getParameter("returnType");

        projectName = projectName.toLowerCase();
        projectName = projectName.replace(' ', '-');


        if (filetype.contains("calculate") || filetype.contains("result")) {
            //download excel file
            //GsonExcelGenerator gsonExcelGenerator = GsonExcelGenerator.getInstance();

            HttpSession session = request.getSession(true);
            //WorkBookGenerator workBookGenerator = (WorkBookGenerator)session.getAttribute("workBook");
            WorkBookSerializable workBook = (WorkBookSerializable) session.getAttribute("workBook");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + workBook.getWorkBookDisplayName() + "\"");
            //OutputStream out = null;
            try {
                OutputStream out = response.getOutputStream();
                // workBookGenerator.getWorkBook().write(out);
                byte[] workbookByte = workBook.getWorkbookByte();
                InputStream in = new ByteArrayInputStream(workbookByte);
                HSSFWorkbook wb = new HSSFWorkbook(in);
                wb.write(out);
                out.close();
            } catch (IOException e) {
            }


        } else {
            //download json object
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonParser parser = new JsonParser();
            JsonObject o = (JsonObject) parser.parse(request.getParameter("data"));
            String fileName = projectName + filetype + ".json";
            File tmp = new File(fileName);
            response.setHeader("Content-Disposition", "attachment; filename=\"" + tmp.getName() + "\"");
            //ServletOutputStream out = null;
            try {
                ServletOutputStream out = response.getOutputStream();
                out.print(gson.toJson(o));
                out.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
                logger.log(Level.SEVERE, "IO error: ", parser);
            }

        }

    }

    /**
     * Handles and retrieves the admin JSP page that only admins can see
     *
     * @return the name of the JSP page
     */
    @RequestMapping(value = "/admin", method = RequestMethod.GET)
    public String getAdminPage() {
        logger.finest("Received request to show admin page");

        // Do your work here. Whatever you like
        // i.e call a custom service to do your business
        // Prepare a model to be used by the JSP page

        // This will resolve to /WEB-INF/jsp/adminpage.jsp
        return "adminpage";
    }

    public synchronized CustomizedUser getCurrentUser() {
        Object obj = SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
        CustomizedUser currentUser = null;
        if (obj instanceof CustomizedUser) {
            currentUser = ((CustomizedUser) obj);
        }
        return currentUser;

    }
}
