package wren.service;

/**
 *
 * @author tanq
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Workbook;

import wren.domain.ResultObj;
import wren.domain.ResultValue;
import wren.domain.jsonObject.Gene;
import wren.domain.jsonObject.Group;
import wren.domain.jsonObject.ProjectObject;
import wren.domain.jsonObject.ReferenceGene;
import wren.domain.jsonObject.TargetGene;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 *
 * @author tanq
 */
public class WorkSheetGenerator implements java.io.Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 5646704327367116248L;
    protected static final Logger logger = Logger.getLogger("WorkSheetGenerator");
    ProjectObject projectObj;
    //private String webFoldChangeHTML = "tmp/webFoldChange.html";
    private String webFoldChangeHTML = "web/tmp/FoldChangeChart.html";
    //private String webAvgCTHTML = "web/tmp/AvgCTTable.html";
    private String outputFileName = "tmp/myWorkSheet.xls";
    String jsonInputString;
    // String inputFile = "tmp/384Input.txt";
    //String jsonInputFile = "tmp/384Json.txt";
//   String inputFile = "tmp/96Input.txt";
//   String jsonInputFile = "tmp/96Json.txt";
    //String inputFile = "tmp/1003-newTemplateInput.txt";
    String inputFile = "tmp/ROBOT2.txt";
    // String jsonInputFile = "tmp/1018.json";
    String jsonInputFile = "tmp/refGene1.json";
    //String jsonInputFile = "tmp/TEST_FILEUPLOAD.json";//test2.json download from web, ok, test1.json, get from FileUploadServlet, not work
    //String jsonInputFile = "tmp/EXIST_LAYOUT_DOWNLOAD2.json";
    private boolean useTab = false;
    Map<String, String> dataMap = new HashMap<String, String>();
    Map<Integer, Short> groupColorMap = new HashMap<Integer, Short>();
    Map<Integer, HSSFCellStyle> groupColorStyleMap = new HashMap<Integer, HSSFCellStyle>();
    //TODO:: groupID,
    Map<Integer, String> groupDataMap = new HashMap<Integer, String>();
    //TODO: size??
    int TOTALROW = 8;
    int TOTALCOL = 12;
    Double[][] dataArray = new Double[TOTALROW][TOTALCOL];
    int[][] geneArray = new int[TOTALROW][TOTALCOL];
    int[][] groupArray = new int[TOTALROW][TOTALCOL];
    final static int Aascii = 65;
    private static final int DATA_START_COLUMN = 1;
    private HSSFWorkbook workBook;
    HSSFSheet worksheet;
    Map<String, CellStyle> styles;
    FormulaEvaluator evaluator;
    static Double EXCLUDE_VALUE = -1.0;
    static String EXCLUDECELL = "(excluded)";
    private Comment exclusionComment;
    //FOR JFREECHART DATA
    //List<List<Double>> geneFoldIncreaseList11 = new ArrayList<List<Double>>();
    StringBuilder allWebOutput = new StringBuilder();
    StringBuilder allAvgCtOutput = new StringBuilder();
    StringBuilder allFoldIncreaseOutput = new StringBuilder();
    ResultObj resultObj;
    String webResultString = "";
    private int WATER_TYPE = 2;
    private String workSheetName = "SAGE Run";
    Map<Integer, Integer> geneGroupAverageRowIndexMap;
    Map<String, Integer> geneGroupAverageMaxColIndexMap;
    Map<Integer, String> geneGroupAverageRowIndexWSMap;
    Map<String, Integer> geneGroupAverageMaxColIndexWSMap;
    Map<Integer, Map<Integer, ResultValue>> geneMap;
    List<String> blankCells = new ArrayList<String>();
    List<String> wbBlankCells = new ArrayList<String>();
    List<ReferenceGene> referenceGenes = new ArrayList<ReferenceGene>();
    List<TargetGene> targetGenes = new ArrayList<TargetGene>();
    String referenceGenesStr = "";
    String targetGenesStr = "";
    private Map<Integer, String> experimentRefGeneMap;

    /* parameters are the data come from web client
     * 1. base on experimentID, file all the inputTexts, jsonStrings and workSheetNames in DB
     * 2. append the current inputText, jsonString and workSheetName and create the array
     * 3. call 'REAL CONSTRUCTOR'
     */
    public static void main(String[] args) {
        WorkSheetGenerator generator = new WorkSheetGenerator(null, null, null, null, null, null, null, null, null, null, null);
    }

    //from jsonString
    public WorkSheetGenerator(WorkBookGenerator parent, HSSFWorkbook workBook, Map<Integer, Map<Integer, ResultValue>> geneMap,
            Map<Integer, String> geneGroupAverageRowIndexWSMap, Map<String, Integer> geneGroupAverageMaxColIndexWSMap, String inputText, String jsonString,
            String workSheetName, String outputFileName, String webFoldChangeHTML, Map<Integer, String> experimentRefGeneMap) {
        //parseJsonDEBUGObject();
        //System.out.println(new Date() + " ##NEW GsonExcelGenerator JSONSTRING");
        if (parent != null) {
            if (parent.getWbBlankCells() != null) {
                this.wbBlankCells = parent.getWbBlankCells();
                //logger.warning(this.workSheetName+": "+this.wbBlankCells);
            }
        }
        if (workBook != null) {
            this.workBook = workBook;
        } else {
            this.workBook = new HSSFWorkbook();
        }
        if (workSheetName != null) {
            this.workSheetName = workSheetName;
        } else {
            this.workSheetName = "SAGE Run";
        }

        if (experimentRefGeneMap != null) {
            this.experimentRefGeneMap = experimentRefGeneMap;
        } else {
            this.experimentRefGeneMap = new HashMap<Integer, String>();
        }
        worksheet = this.workBook.createSheet(this.workSheetName);

        //TODO:: some of these may be move to WorkBookGenerator
        styles = createStyles(workBook);
        evaluator = this.workBook.getCreationHelper().createFormulaEvaluator();
        this.geneGroupAverageRowIndexMap = new HashMap<Integer, Integer>();
        this.geneGroupAverageMaxColIndexMap = new HashMap<String, Integer>();
        if (geneMap != null) {
            this.geneMap = geneMap;
        } else {
            this.geneMap = new LinkedHashMap<Integer, Map<Integer, ResultValue>>();
        }

        if (geneGroupAverageRowIndexWSMap != null) {
            this.geneGroupAverageRowIndexWSMap = geneGroupAverageRowIndexWSMap;
        } else {
            this.geneGroupAverageRowIndexWSMap = new HashMap<Integer, String>();
        }
        if (geneGroupAverageMaxColIndexWSMap != null) {
            this.geneGroupAverageMaxColIndexWSMap = geneGroupAverageMaxColIndexWSMap;
        } else {
            this.geneGroupAverageMaxColIndexWSMap = new HashMap<String, Integer>();
        }


        if (jsonString != null) {
            this.jsonInputString = inputText;
            parseJsonObject(jsonString);
        } else {
            parseJsonObject();
        }
        resultObj = new ResultObj(this.projectObj);
        if (outputFileName != null) {
            this.outputFileName = outputFileName;
        }
        if (webFoldChangeHTML != null) {
            this.webFoldChangeHTML = webFoldChangeHTML;
        }
//       if (webAvgCTHTML != null) {
//           this.webAvgCTHTML = webAvgCTHTML;
//       }

        populateData();
        parseDataFile();
        try {
            //testColor();
            createExcelWorkSheet();
        } catch (Exception ex) {
            Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }


        try {
//           String webFoldChangeStr = resultObj.getAllDataTableOfFoldChangeTable();
//           String webDctStr = resultObj.getAllDctTable();
//          //  webDctStr = "";
//           String webAvgCtStr = resultObj.getAllAvgCtTable();
            webResultString = resultObj.getAllTables();
            webResultString = "&nbsp;<div align='left' style='display:inline;'>" + webResultString + "</div>";

//           //TODO:: remove after debug
            if (webFoldChangeHTML != null) {
                writeToFile(this.webFoldChangeHTML, WorkBookGenerator.jsString1 + webResultString + WorkBookGenerator.jsString2);
            }

            //System.out.println("WEB-ALL DONE CREATED HTML FILES ");
            try {
                File f = new File(this.webFoldChangeHTML);
                //System.out.println("SAGE::: f.getAbsolutePath() " + f.getAbsolutePath());
            } catch (Exception ex) {
                Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }
            //System.out.println("WEB-ALL DONE CREATED HTML FILES ...");
            //System.out.println(this.allWebOutput.toString());
        } catch (Exception ex) {
            Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }



    }

    public String getWebResultString() {
        return webResultString;
    }

    public String getWebResultReadonly() {
        return webResultString.replace(ResultObj.reCalculateStr, "").replace(ResultObj.excludeStr, "").replace(ResultObj.excludeStrEditable, ResultObj.excludeStrReadonly);
    }

    public ResultObj getResultObj() {
        return resultObj;
    }

    public void parseJsonObject(String jsonString) {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            projectObj = gson.fromJson(jsonString, ProjectObject.class);
        } catch (Exception ex) {
            ex.printStackTrace();
            logger.warning(ex.toString());
            logger.warning(jsonString);
        }



    }

    public void parseJsonObject() {
        Gson gson = new Gson();
        try {

            BufferedReader br = new BufferedReader(
                    new FileReader(jsonInputFile));
            //convert the json string back to object
            projectObj = gson.fromJson(br, ProjectObject.class);
        } catch (IOException e) {
            //e.printStackTrace();
            logger.log(Level.WARNING, e.getMessage());
        }

    }

    public void populateData() {
        // System.out.println("xxxxxxxx " + projectObj.getLayoutTable().getTiles().size() + " " + projectObj.getLayoutTable().getTiles().get(0).size());/
        TOTALROW = projectObj.getLayoutTable().getTiles().size();
        TOTALCOL = projectObj.getLayoutTable().getTiles().get(0).size();
        dataArray = new Double[TOTALROW][TOTALCOL];

        //DEBUG
//       for (int i = 0; i < dataArray.length; i++) {
//           for (int j = 0; j < dataArray[0].length; j++) {
//               dataArray[i][j] = projectObj.getMissingValue();
//           }
//       }

        geneArray = new int[TOTALROW][TOTALCOL];
        groupArray = new int[TOTALROW][TOTALCOL];
        //System.out.println("#######TOTALROW=" + TOTALROW + " TOTALCOL=" + TOTALCOL);

        //TODO:: need to fix this, color not correct
        //cannot get a random allIndexedColors[i]
        //create group color map
        IndexedColors[] allIndexedColors = IndexedColors.values();
        int i = 0;
        for (Group group : projectObj.getGroups()) {
            if (i >= allIndexedColors.length) {
                i = i - allIndexedColors.length;
            }
            //System.out.println("put group " + group.getId() + " color: " + allIndexedColors[i].getIndex());
            this.groupColorMap.put(group.getId(), allIndexedColors[i].getIndex());
            HSSFPalette palette = workBook.getCustomPalette();
            byte[] byteArray = hexStringToByteArray(group.getColor());
            //randomly pick a color, black is the first 3 colors, avoid it
            palette.setColorAtIndex(allIndexedColors[i].getIndex(), byteArray[0],
                    byteArray[1], byteArray[2]);

            i++;
        }
    }

    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    public void parseDataFile() {
        int count = 0;
        String line;
        BufferedReader bReader = null;
        try {
            if (jsonInputString != null) {
                //System.out.println("PARSING Json String\n" );
                bReader = new BufferedReader(new StringReader(this.jsonInputString));
            } else if (System.getProperty("user.dir").startsWith("/Users/")) {//if runs stand alone for debug
                bReader = new BufferedReader(new FileReader(inputFile));
            }

            if (bReader != null) {
                while ((line = bReader.readLine()) != null) {
                    String datavalue[] = line.split("\t");
                    if (datavalue == null || datavalue.length == 0) {
                        continue;
                    }
                    String num = datavalue[0];
                    try {
                        int num2 = Integer.parseInt(num);
                        String value1 = datavalue[1];
                        String value2 = datavalue[5];
                        String b = "\"" + value1 + "\" : \"" + value2 + "\"";
                        // System.out.println(b);
                        dataMap.put(value1, value2);
                        //TODO, deal with AA, AB??
                        int rowIndex = Integer.valueOf(value1.charAt(0)) - Aascii;//A is 65
                        int columnIndex = Integer.valueOf(value1.substring(1)) - 1;

                        //System.out.println("setting "+rowIndex+","+columnIndex);
                        try {
                            if (projectObj.getExclusionsTable().getTiles().get(rowIndex).get(columnIndex) == 0) {
                                dataArray[rowIndex][columnIndex] = Double.valueOf(value2);
                            } else {
                                dataArray[rowIndex][columnIndex] = EXCLUDE_VALUE;
                                // System.out.println("data" + rowIndex + "," + columnIndex + "=" + dataArray[rowIndex][columnIndex]+" line="+line);
                            }
                            //System.out.println(" DEBUG data " + rowIndex + "," + columnIndex + "=" + dataArray[rowIndex][columnIndex]+" line="+line);
                        } catch (Exception ex) {
                            //if input data > template
                        }
                    } catch (NumberFormatException e) {
                    }
                }
            }

        } catch (Exception ex) {
            //ex.printStackTrace();
            logger.log(Level.WARNING, ex.getMessage());
        }

//       if (this.projectObj.getMissingValue() > 0) {
//           for (int i = 0; i < dataArray.length; i++) {
//               for (int j = 0; j < dataArray[0].length; j++) {
//                   if (dataArray[0] == null) {
//                       dataArray[i][j] = projectObj.getMissingValue();
//                   }
//
//               }
//           }
//       }else{
//           for (int i = 0; i < dataArray.length; i++) {
//               for (int j = 0; j < dataArray[0].length; j++) {
//                   if (dataArray[0] == null) {
//                       dataArray[i][j] = EXCLUDE_VALUE;
//                   }
//
//               }
//           }
//       }
    }

    public void createExcelWorkSheet() throws Exception {
        //create on excel workbook.

        //File outputFile = new File(outputFileName);

        //FileOutputStream fileOut = new FileOutputStream(outputFileName);
        //System.out.println("OUTPUTFILE: " + outputFileName);
        worksheet.setColumnWidth(0, 25 * 256); //30 characters wide
        worksheet.setColumnWidth(1, 12 * 256);


        int rowIndex = 0;

        createExclusionComment();
        rowIndex = printHeader(worksheet, rowIndex);
        rowIndex = printPlateLayout(worksheet, rowIndex);
        // debugPrint();
        rowIndex = printGenes(worksheet, rowIndex);

//       workBook.write(fileOut);
//       fileOut.flush();
//       fileOut.close();

    }

    private void createExclusionComment() {
        Drawing drawing = worksheet.createDrawingPatriarch();
        CreationHelper factory = workBook.getCreationHelper();

        // When the comment box is visible, have it show in a 1x3 space
        ClientAnchor anchor = factory.createClientAnchor();
//   anchor.setCol1(cell.getColumnIndex());
//   anchor.setCol2(cell.getColumnIndex()+1);
//   anchor.setRow1(row.getRowNul());
//   anchor.setRow2(row.getRowNul()+3);

        // Create the comment and set the text+author
        exclusionComment = drawing.createCellComment(anchor);
        RichTextString str = factory.createRichTextString("Hello, World!");
        exclusionComment.setString(str);
        exclusionComment.setAuthor("Apache POI");


    }

    private int printHeader(HSSFSheet worksheet, int rowIndex) {
        HSSFRow owner = worksheet.createRow(rowIndex++);
        HSSFCell ownerCell = owner.createCell(0);

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);

        ownerCell.setCellValue("(C)NIH/NIAID/OCICB/BCBB, " + year);

        HSSFRow version = worksheet.createRow(rowIndex++);
        HSSFCell versionCell = version.createCell(0);
        versionCell.setCellValue("Version 2.0");

        HSSFRow generateFrom = worksheet.createRow(rowIndex++);
        generateFrom.createCell(0).setCellValue("Generated from: ");
        HSSFCell generateFromCell = generateFrom.createCell(1);
        generateFromCell.setCellValue(System.getProperty("os.name") + "  User: " + System.getProperty("user.name"));


        HSSFRow generateOn = worksheet.createRow(rowIndex++);
        generateOn.createCell(0).setCellValue("Generated on: ");
        HSSFCell generateOnCell = generateOn.createCell(1);
        generateOnCell.setCellValue("" + new Date());

        rowIndex++;


        return rowIndex;
    }

    private int printPlateLayout(HSSFSheet worksheet, int rowIndex) {
        final int startingRowIndex = rowIndex;

        HSSFRow row1 = worksheet.createRow(rowIndex++);
        //Plate Layout
        HSSFCell cellA1 = row1.createCell(0);
        cellA1.setCellValue("Plate Layout");
        cellA1.setCellStyle(styles.get(HEADER));

        //column number
        for (int i = 0; i < projectObj.getLayoutTable().getCol(); i++) {
            HSSFCell cellB1 = row1.createCell(i + 2);
            cellB1.setCellValue("" + (i + 1));
            cellB1.setCellStyle(styles.get(HEADER));
        }
        String key = null;
        int i = 0, j = 0;
        List<Integer> excludeColumnsNeedUpdates = new ArrayList<Integer>(6);
        for (List<Integer> tiles : projectObj.getLayoutTable().getTiles()) {//group
            HSSFRow rowData = worksheet.createRow(rowIndex++);
            //print ABCDEFGH
            char columnChar = (char) (rowIndex - startingRowIndex - 2 + Aascii);
            int columnIndex = DATA_START_COLUMN;
            HSSFCell cell1 = rowData.createCell(columnIndex);
            cell1.setCellValue("" + columnChar);
            cell1.setCellStyle(styles.get(HEADER));

            columnIndex++;
            j = 0;
            //PRINT DATA
            int prevGroup = -1;
            for (int groupId : tiles) {
                if (groupId > 0) {
                    //
                    columnIndex = j + DATA_START_COLUMN + 1;


                    HSSFCell cell = rowData.createCell(columnIndex);

                    key = "" + columnChar + (columnIndex - 1);
                    //cell.setCellValue(dataMap.get(key));
                    if (this.dataArray[i][j] != null) { //if input file data > template data

                        //TODO:: missing value, undetermine
                        //cell.setCellValue(rowIndex+","+columnIndex+": "+i+","+j);

                        if (this.dataArray[i][j] == EXCLUDE_VALUE) {//exclusive
                            // HSSFCell cell = rowData.createCell(columnIndex);
                            geneArray[i][j] = projectObj.getLayoutTable().getLayoutTiles().get(i).get(j);
                            if (groupId < -1) {
                                groupArray[i][j] = -groupId;
                            } else {
                                groupArray[i][j] = prevGroup;
                            }
                            if (prevGroup == -1) {//if first few columns are exclude
                                excludeColumnsNeedUpdates.add(j);
                            }
                            cell.setCellValue(EXCLUDECELL);
                        } else {
                            cell.setCellValue(this.dataArray[i][j]);
                        }

                    }
                    geneArray[i][j] = projectObj.getLayoutTable().getLayoutTiles().get(i).get(j);//gene
                    groupArray[i][j] = groupId;

                    prevGroup = groupArray[i][j];


                    if (excludeColumnsNeedUpdates.size() > 0) {
                        for (int ii = 0; ii < excludeColumnsNeedUpdates.size(); ii++) {
                            groupArray[i][ii] = groupArray[i][j];
                        }
                        excludeColumnsNeedUpdates.clear();
                    }


                    //check if there's better way
                    // System.out.println("groupId=" + groupId);
                    Short s = this.groupColorMap.get(groupId);
                    if (s == null) {
                        s = HSSFColor.LIME.index;
                        //System.out.println(groupId + "color =null: " + groupColorMap);
                    }
                    HSSFCellStyle cellStyle = workBook.createCellStyle();
                    cellStyle.setFillForegroundColor(s);
                    cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
                    cell.setCellStyle(cellStyle);

                    groupColorStyleMap.put(groupId, cellStyle);
                    columnIndex++;
                } else if (this.dataArray[i][j] == this.EXCLUDE_VALUE) {//excludsive
                    HSSFCell cell = rowData.createCell(columnIndex);
                    geneArray[i][j] = projectObj.getLayoutTable().getLayoutTiles().get(i).get(j);
                    if (groupId < -1) {
                        groupArray[i][j] = -groupId;
                    } else {
                        groupArray[i][j] = prevGroup;
                    }
                    //BAD ASSUMPTION
                    //for exclusions, the project.tiles do not store the group information
                    //but the layout need th group information
                    //assumption, the exclusion has the same group number as the preceeding column, or previous column

                    //COULD BE prevGroup or preceeding group, how to tell?
                    //FIX: wren.classes.js, use -groupId as exclusive,

                    if (prevGroup == -1) {//if first few columns are exclude
                        excludeColumnsNeedUpdates.add(j);
                    }
                    cell.setCellValue(EXCLUDECELL);

                    Short s = this.groupColorMap.get(-groupId);
                    if (s == null) {
                        s = HSSFColor.LIME.index;
                        //System.out.println(groupId + "color =null: " + groupColorMap);
                    }
                    HSSFCellStyle cellStyle = workBook.createCellStyle();
                    cellStyle.setFillForegroundColor(s);
                    cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
                    cell.setCellStyle(cellStyle);

                    groupColorStyleMap.put(groupId, cellStyle);
                    //System.out.println("groupID:" + groupId + " geneID:" + geneArray[i][j] + " goupTitle:" + projectObj.getLayoutTable().getTiles().get(i).get(j) + "==data" + this.dataArray[i][j]);
                    columnIndex++;
                } else {
                    //System.out.println("WARNING: groupId="+groupId);
                }
                j++;

            }
            i++;
        }


        return rowIndex;
    }

    private void debugPrint() {
        System.out.println("##############");


//       for (int ii = 0; ii < groupArray.length; ii++) {
//           for (int jj = 0; jj < groupArray[0].length; jj++) {
//               System.out.print(geneArray[ii][jj] + " " + groupArray[ii][jj] + " " + this.dataArray[ii][jj] + "\t");
//           }
//           System.out.println();
//       }

        for (int ii = 0; ii < dataArray.length; ii++) {
            for (int jj = 0; jj < dataArray[0].length; jj++) {
                System.out.println("dataArray[" + ii + "][" + jj + "]=" + dataArray[ii][jj]);
            }
            System.out.println("\n");
        }

        for (int i = 0; i < geneArray.length; i++) {
            for (int j = 0; j < geneArray[0].length; j++) {
                System.out.println("geneArray[" + i + "][" + j + "]=" + geneArray[i][j] + " groupArray[" + i + "][" + j + "]=" + groupArray[i][j]);
            }
        }
        System.out.println();

        for (List<Integer> tiles : projectObj.getLayoutTable().getTiles()) {//group
            System.out.println("tiles=" + tiles);
        }
        System.out.println();
        System.out.println("##############");
    }

    private int printGenes(HSSFSheet worksheet, int rowIndex) {
        Map<Integer, String> geneGroupdCtCellMap = new HashMap<Integer, String>();
        Map<Integer, String> ddctGroupCellIndexMap = new HashMap<Integer, String>();
        Map<Integer, String> dctGroupCellIndexMap = new HashMap<Integer, String>();
        Map<Integer, Integer> ddctGroupCellLengthMap = new HashMap<Integer, Integer>();
        Font boldFont = this.workBook.createFont();
        boldFont.setFontName(HSSFFont.FONT_ARIAL);
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        rowIndex++;
        String linebreak = "\n";
        String colbreak = "\t";

        //DEBUG
//       if (dataArray!= null) {
//    	   for (int i=0; i<dataArray.length; i++){
//    		   for (int j=0; j<dataArray[i].length; j++){
//    			   System.out.println("xxxxxx dataArray["+i+"]["+j+"]="+dataArray[i][j]);
//    		   }
//
//    	   }
//
//       }
        for (Gene gene : projectObj.getGenes()) {//for each gene
            if (gene.isHidden()) {
                continue;
            }
            if (gene.getType() == 0) {//reference Gene
                referenceGenes.add(new ReferenceGene(gene.getId(), gene.getName(), -1));
                experimentRefGeneMap.put(gene.getId(), this.workSheetName + "." + gene.getName());
            } else {//target gene
                targetGenes.add(new TargetGene(gene.getId(), gene.getName(), -1, gene.getControlID(), experimentRefGeneMap.get(gene.getControlID())));
            }
            //System.out.println(this.workSheetName + " ### GENE hidden: " + gene.getName() + ": " + gene.isHidden());
            //blank row
            HSSFRow geneHeaderRow = worksheet.createRow(rowIndex++);
            HSSFCell cellA1 = geneHeaderRow.createCell(0);
            cellA1.setCellValue(gene.getName());
            allWebOutput.append(gene.getName());
            allWebOutput.append(linebreak);
            cellA1.setCellStyle(styles.get(HIGHLIGHT));

            //for each group
            int startColumn = 1;
            for (Group group : projectObj.getGroups()) {//for each group
                //TODO:: multiple control group
                if (group.getType() == WATER_TYPE) {//ignore water
                    continue;
                }
                Double controlGroupAvgDct = 0.0;

                rowIndex++;
                HSSFRow groupHeaderRow = worksheet.createRow(rowIndex++);
                HSSFCell groupHeaderCell = groupHeaderRow.createCell(0);
                groupHeaderCell.setCellValue(group.getName());
                groupHeaderCell.setCellStyle(styles.get(HEADER));

                allWebOutput.append(group.getName());
                allWebOutput.append(colbreak);

                HSSFCell ctCell = groupHeaderRow.createCell(startColumn);
                ctCell.setCellValue("Ct");
                ctCell.setCellStyle(styles.get(HEADER));
                allWebOutput.append("Ct");

                //single, duplicate, triple
                HSSFRow groupDataRow0 = null;
                HSSFRow groupDataRow1 = null;
                HSSFRow groupDataRow2 = null;

                StringBuilder[] groupRows = {new StringBuilder(), new StringBuilder(), new StringBuilder()};
                StringBuilder[] groupRowsCoordinates = {new StringBuilder(), new StringBuilder(), new StringBuilder()};

                String groupRowIndexString = "";
                HSSFCellStyle colorStyle = groupColorStyleMap.get(group.getId());

                int fromRow = 0, endRow = 0;
                int col0 = startColumn;
                int col1 = startColumn, col2 = startColumn;
                for (int i = 0; i < geneArray.length; i++) {
                    for (int j = 0; j < geneArray[0].length; j++) {
                        if (this.geneArray[i][j] == gene.getId() && this.groupArray[i][j] == group.getId()) {
                            HSSFCell ctDataCell = null;

                            int duplicateValue = projectObj.getLayoutTable().getReplicateTiles().get(i).get(j);
                            //System.out.println(gene.getName()+"="+gene.getId()+" GROUP: "+group.getName()+"="+group.getId()+" duplicateValue="+duplicateValue+" coordinates: "+i + ":" + j);


                            if (duplicateValue == 0) {//not replicate
                                //notDup+=dataArray[i][j]+"\t";
                                if (groupDataRow0 == null) {
                                    groupDataRow0 = worksheet.createRow(rowIndex++);
                                    groupRowIndexString += "0,";
                                    // groupRow0.append(linebreak);
                                    fromRow = rowIndex;
                                    endRow = fromRow;
                                }
                                ctDataCell = groupDataRow0.createCell(col0++, HSSFCell.CELL_TYPE_NUMERIC);
                                if (dataArray[i][j] != null) {
                                    ctDataCell.setCellValue(dataArray[i][j]);
                                    groupRows[0].append(dataArray[i][j]);
                                    groupRows[0].append(colbreak);
                                    if (group.getType() == 0) {//control
                                        controlGroupAvgDct += dataArray[i][j];
                                    }
                                } else if (projectObj.getMissingValue() > 0) {
                                    ctDataCell.setCellValue(projectObj.getMissingValue());
                                    groupRows[0].append(projectObj.getMissingValue());
                                    groupRows[0].append(colbreak);
                                } else {
                                    groupRows[0].append(colbreak);
                                }
                                groupRowsCoordinates[0].append(i + ":" + j);
                                groupRowsCoordinates[0].append(colbreak);

                                ctDataCell.setCellStyle(colorStyle);
                            } else if (duplicateValue == 1) {//replicate 1
                                if (groupDataRow1 == null) {
                                    groupDataRow1 = worksheet.createRow(rowIndex++);
                                    groupRowIndexString += "1,";
                                    groupRows[1].append(linebreak);
                                    groupRowsCoordinates[1].append(colbreak);
                                    if (fromRow == 0) {
                                        fromRow = rowIndex;
                                        endRow = fromRow;
                                    }
                                    endRow++;
                                }
                                ctDataCell = groupDataRow1.createCell(col1++, HSSFCell.CELL_TYPE_NUMERIC);
                                if (dataArray[i][j] != null) {
                                    ctDataCell.setCellValue(dataArray[i][j]);
                                    groupRows[1].append(dataArray[i][j]);
                                    groupRows[1].append(colbreak);

                                    if (group.getType() == 0) {//control
                                        controlGroupAvgDct += dataArray[i][j];
                                    }
                                } else if (projectObj.getMissingValue() > 0) {
                                    ctDataCell.setCellValue(projectObj.getMissingValue());
                                    groupRows[1].append(projectObj.getMissingValue());
                                    groupRows[1].append(colbreak);
                                } else {
                                    groupRows[1].append(colbreak);
                                }
                                groupRowsCoordinates[1].append(i + ":" + j);
                                groupRowsCoordinates[1].append(colbreak);
                                ctDataCell.setCellStyle(colorStyle);
                            } else {//replicate 2
                                if (groupDataRow2 == null) {
                                    groupDataRow2 = worksheet.createRow(rowIndex++);
                                    groupRowIndexString += "2,";
                                    groupRows[2].append(linebreak);
                                    groupRowsCoordinates[2].append(colbreak);

                                    if (fromRow == 0) {
                                        fromRow = rowIndex;
                                        endRow = fromRow;
                                    }
                                    endRow++;
                                }
                                ctDataCell = groupDataRow2.createCell(col2++, HSSFCell.CELL_TYPE_NUMERIC);
                                if (dataArray[i][j] != null) {
                                    ctDataCell.setCellValue(dataArray[i][j]);
                                    groupRows[2].append(dataArray[i][j]);
                                    groupRows[2].append(colbreak);
                                    if (group.getType() == 0) {//control
                                        controlGroupAvgDct += dataArray[i][j];
                                    }
                                } else if (projectObj.getMissingValue() > 0) {
                                    ctDataCell.setCellValue(projectObj.getMissingValue());
                                    groupRows[2].append(projectObj.getMissingValue());
                                    groupRows[2].append(colbreak);
                                } else {
                                    groupRows[2].append(colbreak);
                                }

                                groupRowsCoordinates[2].append(i + ":" + j);
                                groupRowsCoordinates[2].append(colbreak);
                                ctDataCell.setCellStyle(colorStyle);
                            }

                            if (dataArray[i][j] != null && dataArray[i][j] == -1.0) {//exclusion
                                ctDataCell.setCellType(Cell.CELL_TYPE_BLANK);
                                //ctDataCell.setCellComment(this.exclusionComment);
                            }
                        }
                    }
                }

//               for (int i=0; i<groupRows.length; i++){
//            	   System.out.println("xxgroupRows["+i+"]=" + groupRows[i] + " groupRowsCoordinates: " + groupRowsCoordinates[i]);
//               }
                int colLength = col0;
                if (colLength <= 1) {
                    colLength = col1;
                }
                if (colLength <= 1) {
                    colLength = col2;
                }
                String[] groupRowIndexArray = groupRowIndexString.split(",");
                //System.out.println("@@@@@@@@@@ " + gene.getName() + " group: " + group.getName() + " colLength" + colLength);
                Double[][] geneGroupValues = new Double[groupRowIndexArray.length][colLength - 1];
                String[][] geneGroupCoordinates = new String[groupRowIndexArray.length][colLength - 1];

                //TODO:: DEBUG:

//               for (int i=0; i<geneGroupCoordinates.length; i++){
//                   for (int j=0; j<geneGroupCoordinates[i].length; j++){
//                       geneGroupCoordinates[i][j] = "";
//                   }
//               }

                int geneGroupVabluesIndex = 0;
                for (String groupRowIndex : groupRowIndexArray) {
                    if (groupRowIndex != null && groupRowIndex.trim().length() > 0) {

                        //TODO:: handle if index not int
                        int index = Integer.parseInt(groupRowIndex);
                        allWebOutput.append(colbreak);
                        allWebOutput.append(groupRows[index]);
                        //if missingValue, groupRows
                        //System.out.println("!!!!!!!!!!groupRows[" + index + "]=#" + groupRows[index] + "#");
                        //populate geneGroupValues
                        String rowValues[] = groupRows[index].toString().trim().split(colbreak);
                        //System.out.println("groupRowIndex="+groupRowIndex+" VALUE="  + groupRows[index].toString().trim());
                        String rowValuesCoordinates[] = groupRowsCoordinates[index].toString().trim().split(colbreak);

                        if (rowValues != null) {
                            for (int ii = 0; ii < rowValues.length; ii++) {
                                //System.out.println("rowValues["+ii+"]="+rowValues[ii]);
                                if (rowValues[ii].trim().length() > 0) {
                                    try {
                                        geneGroupValues[geneGroupVabluesIndex][ii] = Double.parseDouble(rowValues[ii].trim());
                                        geneGroupCoordinates[geneGroupVabluesIndex][ii] = rowValuesCoordinates[ii];
                                    } catch (Exception ex) {
                                        if (this.projectObj.getMissingValue() > 0 && geneGroupVabluesIndex > geneGroupValues.length
                                                && ii > geneGroupValues[geneGroupVabluesIndex].length) {
                                            geneGroupValues[geneGroupVabluesIndex][ii] = projectObj.getMissingValue();
                                            geneGroupCoordinates[geneGroupVabluesIndex][ii] = rowValuesCoordinates[ii];
                                        }
                                    }
                                }
                            }
                        }
                        geneGroupVabluesIndex++;
                    }
                }

                //TODO:: to verify, one workbook one geneMap
                resultObj.add(geneMap, gene, group, geneGroupValues, geneGroupCoordinates);
//               allWebOutput.append(groupRow0);
//               //allWebOutput.append(linebreak);
//                allWebOutput.append(groupRow1);
//               //allWebOutput.append(linebreak);
//                allWebOutput.append(groupRow2);
                allWebOutput.append(linebreak);
                //average Ct
                HSSFRow averageTitleRow = worksheet.createRow(rowIndex++);
                HSSFCell averageTitleCell = averageTitleRow.createCell(startColumn);
                averageTitleCell.setCellValue("Average Ct");
                averageTitleCell.setCellStyle(styles.get(HEADER));

                allWebOutput.append("Average Ct");
                allWebOutput.append(linebreak);

                HSSFRow averageRow = worksheet.createRow(rowIndex++);
                final int averageRowIndex = rowIndex;
                if (gene.getType() == 0) {//control
                    geneGroupAverageRowIndexMap.put(gene.getId() + group.getId(), averageRowIndex);
                    geneGroupAverageMaxColIndexMap.put(gene.getId() + "," + group.getId(), (colLength - 1));
                    //logger.warning("geneGroupAverageMaxColIndexMap put gene:"+gene.getName()+" group:"+group.getName()+" maxCol="+(colLength-1));
                    geneGroupAverageRowIndexWSMap.put(gene.getId() + group.getId(), workSheetName + "!" + averageRowIndex);
                    geneGroupAverageMaxColIndexWSMap.put(gene.getId() + "," + group.getId(), (colLength - 1));
                    //geneGroupAverageRowIndexMap.put(gene.getId() + group.getControlID(), averageRowIndex);
                    //System.out.println(" put geneGroupAverageRowIndexMap " + gene.getName() + " " + group.getName() + "==>" + gene.getId() + " " + group.getId() + " " + workSheetName);
                }
                //col0
//                Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.WARNING,
//                              "col0 - 1= "+(col0 - 1)+" col1 - 1= "+(col1 - 1)+" col2 - 1= "+(col2 - 1));

                for (int i = 0; i < colLength - 1; i++) {

                    HSSFCell averageCell = averageRow.createCell(startColumn + i);
                    String ref = (char) ('A' + i + 1) + "" + fromRow + ":" + (char) ('A' + i + 1) + (endRow - 1);
                    averageCell.setCellFormula("AVERAGE(" + ref + ")");
                    allWebOutput.append("AVERAGE(").append(ref).append(")");
                    allWebOutput.append(colbreak);
                    if (group.getType() == 0) {//control
                        //geneGroupAverageRowIndexValueMap.put(gene.getId() + group.getId(), averageRowIndex);
                    }
                    //DEBUG
//                   Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.WARNING,
//                              averageRow.getRowNum()+","+(startColumn+i)+" set ave:  "+ref);
//                   averageCell.setCellValue("AVERAGE(" + ref + ")");
                    if (Cell.CELL_TYPE_ERROR == evaluator.evaluate(averageCell).getCellType()) {

                        averageCell.setCellType(Cell.CELL_TYPE_BLANK);
                        String cellString = (char) ('A' + i + 1) + "" + (averageRowIndex);//location of blank avgcell
                        //logger.warning("BLANK AVGCELL="+ref+" cell: "+cellString);
                        blankCells.add(cellString);
                        wbBlankCells.add("'" + workSheetName + "'!" + cellString);
                    }
                    // System.out.println("XXXX blankCells="+blankCells);

                }
                allWebOutput.append(linebreak);

                //dct
                if (gene.getType() == 1) {//target
                    //dct for target genes
                    //the difference between the average Ct for the target gene and the average Ct for the reference gene
                    // System.out.println(gene.getType()+" "+gene.getControlID());
                    int controlAverageRowIndex = 0;
                    String controlAverageRowWS = "";
                    try {
                        controlAverageRowIndex = geneGroupAverageRowIndexMap.get(gene.getControlID() + group.getId());
                        //System.out.println("geneGroupAverageRowIndexMap FOUND geneControlID" + gene.getControlID() + " Geneid:" + gene.getId() + " " + group.getId());
                    } catch (Exception ex) {
                        //if geneGroupAverageRowIndexMap.get(gene.getControlID()+group.getId())==null
                        //controlAverageRowIndex = averageRowIndex;
                        controlAverageRowIndex = -1;
                        //System.out.println("geneGroupAverageRowIndexMap !!!NOT FOUND geneControlID" + gene.getControlID() + " Geneid:" + gene.getId() + " " + group.getId());
                    }
                    if (controlAverageRowIndex <= 0) {
                        controlAverageRowWS = geneGroupAverageRowIndexWSMap.get(gene.getControlID() + group.getId());
                        if (controlAverageRowWS != null && controlAverageRowWS.length() > 0) {
                            String[] tmp = controlAverageRowWS.split("!");
                            controlAverageRowWS = "'" + tmp[0] + "'!";
                            controlAverageRowIndex = Integer.parseInt(tmp[1]);
                        }
                        if (controlAverageRowWS == null || controlAverageRowWS.equals("null")) {
                            controlAverageRowWS = "";
                        }
                    }
                    if (controlAverageRowIndex < 1) {
//                       System.out.println(this.workSheetName+" "+gene.getName()+" ###GETTING::: getting geneControlID" + gene.getControlID() + " Geneid:" + gene.getId() + " " + group.getId()
//       +" got:"+controlAverageRowIndex+" ws: "+controlAverageRowWS);
                        logger.log(Level.WARNING, "{0} {1} ###GETTING::: getting geneControlID{2} Geneid:{3} {4} got:{5} ws: {6}",
                                new Object[]{this.workSheetName, gene.getName(), gene.getControlID(), gene.getId(), group.getId(), controlAverageRowIndex, controlAverageRowWS});
                    }

                    HSSFRow dctTitleRow = worksheet.createRow(rowIndex++);
                    final int dctRowIndex = rowIndex;
                    HSSFCell dctTitleCell = dctTitleRow.createCell(startColumn);
                    dctTitleCell.setCellValue("dCt");
                    dctTitleCell.setCellStyle(styles.get(HEADER));

                    HSSFRow dctRow = worksheet.createRow(rowIndex++);


                    ddctGroupCellLengthMap.put(group.getId(), colLength - 1);
                    int avgDctColIndex = 0;
                    char dctStartColIndex = 'A';
                    char dctEndColIndex = 'A';
                    for (int i = 0; i < colLength - 1; i++) {
                        HSSFCell dctCell = dctRow.createCell(startColumn + i);
                        String dctLocation = (char) ('A' + i + startColumn) + "" + (dctRowIndex + 1);
                        avgDctColIndex = startColumn + i;
                        if (i == 0) {
                            dctStartColIndex = (char) ('A' + i + 1);
                        } else if (i == colLength - 2) {
                            dctEndColIndex = (char) ('A' + i + 1);
                        }
                        final String avgCell = (char) ('A' + i + 1) + "" + averageRowIndex;
                        final String controlAverageCell = controlAverageRowWS + (char) ('A' + i + 1) + "" + controlAverageRowIndex;

                        String ref = avgCell + "-" + controlAverageCell;
                        if (controlAverageRowIndex < 1) {
                            dctCell.setCellValue(ref);//will set as blank at later step
                        } else {
                            dctCell.setCellFormula(ref);
                        }
                        //dctCell.setCellValue(ref);
//                       String cellString = (i + 1) + "," + (controlAverageRowIndex);
//                       String avgCellString = (i + 1) + "," + (averageRowIndex);
                        // String cellString = controlAverageRowWS+(char) ('A' + i + 1) + "" + (controlAverageRowIndex);
                        //String avgCellString = controlAverageRowWS+(char) ('A' + i + 1) + "" + (averageRowIndex);
                        int maxCol = i + 1;
                        try {
                            maxCol = geneGroupAverageMaxColIndexMap.get(gene.getControlID() + "," + group.getId());
                            //System.out.println("geneGroupAverageRowIndexMap FOUND geneControlID" + gene.getControlID() + " Geneid:" + gene.getId() + " " + group.getId());
                        } catch (Exception ex) {
                            //if geneGroupAverageRowIndexMap.get(gene.getControlID()+group.getId())==null
                            //controlAverageRowIndex = averageRowIndex;
                            maxCol = -1;
                            //System.out.println("geneGroupAverageRowIndexMap !!!NOT FOUND geneControlID" + gene.getControlID() + " Geneid:" + gene.getId() + " " + group.getId());
                        }
                        if (maxCol <= 0) {
                            try {
                                maxCol = geneGroupAverageMaxColIndexWSMap.get(gene.getControlID() + "," + group.getId());
                            } catch (Exception ex) {
                                maxCol = -1;
                            }
                        }
                        //ABC
                        //logger.warning("maxCol: "+gene.getName()+" "+group.getName()+"=="+maxCol+" current col="+(i+1));


                        if (this.blankCells.contains(avgCell) || this.blankCells.contains(controlAverageCell) || i >= maxCol || controlAverageRowIndex < 1
                                || this.wbBlankCells.contains(avgCell) || this.wbBlankCells.contains(controlAverageCell)) {
                            dctCell.setCellType(Cell.CELL_TYPE_BLANK);
                            blankCells.add(dctLocation);
                            wbBlankCells.add("'" + workSheetName + "'!" + dctLocation);
                            //cellString = (startColumn + i) + "," + (rowIndex);
                            //System.out.println("dct BLANK: "+dctLocation);
                        }
                        //System.out.println("XXXDCT: "+gene.getName()+" "+group.getName()+" "+cellString);
//                        if (Cell.CELL_TYPE_ERROR == evaluator.evaluate(dctCell).getCellType()){
//                           dctCell.setCellType(Cell.CELL_TYPE_BLANK);
//                        }
                        //dctCell.setCellValue(ref);
                    }
                    //avg.dCt
                    avgDctColIndex += 2;
                    HSSFCell avgDctTitleCell = dctRow.createCell(avgDctColIndex);
                    avgDctTitleCell.setCellValue("Avg.dCt=");
                    avgDctTitleCell.setCellStyle(styles.get(HEADER));

                    HSSFCell avgDctCell = dctRow.createCell(avgDctColIndex + 1);


                    String ref1 = dctStartColIndex + "" + (dctRowIndex + 1) + ":" + dctEndColIndex + "" + (dctRowIndex + 1);
                    avgDctCell.setCellFormula("AVERAGE(" + ref1 + ")");

                    String controlAveDctCell = null;
                    if (group.getType() != 1) {//control and water
                        controlAveDctCell = "$" + (char) ('A' + avgDctColIndex + 1) + "$" + (dctRowIndex + 1);
                        geneGroupdCtCellMap.put(gene.getId() + group.getId(), controlAveDctCell);
                        // System.out.println("##########geneGroupdCtCellMap put " + gene.getId() + group.getId() + "==>" + controlAveDctCell);
                    }

                    //ddct - the difference between the dCt for this gene and group and the average dCt
                    //for test group, the average dCt will be taken from the designated control group
                    HSSFRow ddctTitleRow = worksheet.createRow(rowIndex++);
                    HSSFCell ddctTitleCell = ddctTitleRow.createCell(startColumn);
                    ddctTitleCell.setCellValue("ddCt");
                    ddctTitleCell.setCellStyle(styles.get(HEADER));

                    final int ddctRowIndex = rowIndex;
                    HSSFRow ddctRow = worksheet.createRow(rowIndex++);
                    String ddctCellIndex = null;
                    for (int i = 0; i < colLength - 1; i++) {
                        HSSFCell ddctCell = ddctRow.createCell(startColumn + i);
                        String ddctLocation = "$" + (char) ('A' + i + startColumn) + "$" + (ddctRowIndex + 1);
                        String controlCell = null;
                        //System.out.println(gene.getName()+" "+group.getName()+" "+group.getType()+ " group.ID="+group.getId()+ " group.getControlID="+group.getControlID());
                        if (group.getType() == 1) { //test
                            controlCell = geneGroupdCtCellMap.get(gene.getId() + group.getControlID());
                        } else {
                            controlCell = controlAveDctCell;
                            if (group.getType() == 0) { //TODO control?? TODO,multiple control??, 0326-should be ok
                            }
                        }
                        if (i == 0) {
                            ddctCellIndex = "$" + (char) ('A' + startColumn + i) + "$" + (rowIndex);
                            ddctGroupCellIndexMap.put(group.getId(), ddctCellIndex);
                            String dctCellIndex = "$" + (char) ('A' + startColumn + i) + "$" + (rowIndex - 2);
                            dctGroupCellIndexMap.put(group.getId(), dctCellIndex);
                        }

                        final String dctCell = (char) ('A' + i + 1) + "" + (dctRowIndex + 1);
                        String ref = dctCell + "-" + controlCell;
                        //TODO:: WARNING: if the control gene/group does not put as first gene/group, ERROR
                        //XXXXXXXXXXXXHERE
                        try {
                            ddctCell.setCellFormula(ref);
                        } catch (Exception ex) {
                            ddctCell.setCellValue(ref);
                            logger.log(Level.WARNING, "ERROR: ddctCell: {0}", ref);
                            //ex.printStackTrace();
                        }

                        // ddctCell.setCellValue(ref);
                        // String cellString = (i + 1) + "," + (dctRowIndex + 1);
                        // String cellString = (char) ('A' + 1 + i)+""+ (dctRowIndex + 1);
                        if (this.blankCells.contains(dctCell) || this.wbBlankCells.contains(dctCell) || this.blankCells.contains(controlCell) || this.wbBlankCells.contains(controlCell)) {
                            ddctCell.setCellType(Cell.CELL_TYPE_BLANK);
                            //blankCells.add(cellString);
                            //cellString = "$" + (char) ('A' + startColumn + i) + "$" + (rowIndex);
                            blankCells.add(ddctLocation);
                            wbBlankCells.add("'" + workSheetName + "'!" + ddctLocation);
                            // logger.warning("ddct BLANK: "+ddctLocation);
                        }

                    }
                    //rowIndex++;

                }
            }


            //fold increase
            if (gene.getType() == 1) {
                rowIndex += 2;
                HSSFRow fiTitleRow = worksheet.createRow(rowIndex++);
                HSSFCell fiTitleCell = fiTitleRow.createCell(0);
                fiTitleCell.setCellValue("Fold Change");
                fiTitleCell.setCellStyle(styles.get(HEADER));
                int j = 1;
                for (Group g : projectObj.getGroups()) {
                    if (g.getType() == WATER_TYPE) {//ignore water
                        continue;
                    }
                    HSSFCell fiCellTitle = fiTitleRow.createCell(j);
                    fiCellTitle.setCellValue(g.getName());
                    HSSFCellStyle cs = groupColorStyleMap.get(g.getId());
                    if (cs != null) {
                        cs.setFont(boldFont);
                        fiCellTitle.setCellStyle(cs);
                    }

                    j++;
                }
                // worksheet.createRow(rowIndex++).createCell(1).setCellValue("ABDFDFD");

                j = 1;
                final int startingRow = rowIndex;
                List<Double> groupFoldIncrease = new ArrayList<Double>();
                for (Group g : projectObj.getGroups()) {
                    if (g.getType() == WATER_TYPE) {//ignore water
                        continue;
                    }
                    String startCellIndex = ddctGroupCellIndexMap.get(g.getId());
                    if (startCellIndex != null) {
                        int length = ddctGroupCellLengthMap.get(g.getId());
                        final String ref = startCellIndex;
                        char startChar = (char) (startCellIndex.charAt(1));
                        HSSFRow fiRow = null;
                        String myRef = null;
                        for (int i = 0; i < length; i++) {
                            String fiLocation = null;
                            if (j == 1) {//first group
                                fiRow = worksheet.createRow(rowIndex);
                                rowIndex++;
                            } else {
                                fiRow = worksheet.getRow(startingRow + i);
                            }
                            //if the first group has less fold increase value than the current group
                            if (fiRow == null) {
                                fiRow = worksheet.createRow(rowIndex);
                                rowIndex++;
                            }
                            if (i > 0) {
                                char myChar = (char) (startChar + i);
                                myRef = ref.substring(0, 1) + "" + myChar + ref.substring(2);
                            } else {
                                myRef = ref;
                            }
                            if (fiRow != null) {
                                HSSFCell fiCell = fiRow.createCell(j);
                                fiCell.setCellFormula("2^-" + myRef);
                                //get fold increase for web output
                                //TODO:: WEBOUTPUT
                                fiCell.getNumericCellValue();
//                               Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.WARNING,
//                                       gene.getName() + "," + g.getName() + " == " + fiCell.getNumericCellValue() + " == 2^-" + myRef);
                                groupFoldIncrease.add(10.0 + Math.random() * 3);

                                String cellString = myRef;
                                if (this.blankCells.contains(myRef) || this.wbBlankCells.contains(myRef)) {
                                    fiCell.setCellType(Cell.CELL_TYPE_BLANK);
                                    //logger.warning("fi BLANK: "+myRef);
                                }
                            }
                        }
                    } else {
                        logger.log(Level.WARNING, "ddctGroupCellIndexMap.get.ID: {0}== NULL ", g.getId());
                    }

                    j++;
                }
                // geneFoldIncreaseList.add(groupFoldIncrease);
            }


            //1/dct
            if (gene.getType() == 1) {
                rowIndex += 2;
                HSSFRow fiTitleRow = worksheet.createRow(rowIndex++);
                HSSFCell fiTitleCell = fiTitleRow.createCell(0);
                fiTitleCell.setCellValue("1/dct");
                fiTitleCell.setCellStyle(styles.get(HEADER));
                int j = 1;
                for (Group g : projectObj.getGroups()) {
                    if (g.getType() == WATER_TYPE) {//ignore water
                        continue;
                    }
                    HSSFCell fiCellTitle = fiTitleRow.createCell(j);
                    fiCellTitle.setCellValue(g.getName());
                    HSSFCellStyle cs = groupColorStyleMap.get(g.getId());
                    if (cs != null) {
                        cs.setFont(boldFont);
                        fiCellTitle.setCellStyle(cs);
                    }

                    j++;
                }
                // worksheet.createRow(rowIndex++).createCell(1).setCellValue("ABDFDFD");

                j = 1;
                final int startingRow = rowIndex;
                List<Double> groupFoldIncrease = new ArrayList<Double>();
                for (Group g : projectObj.getGroups()) {
                    if (g.getType() == WATER_TYPE) {//ignore water
                        continue;
                    }
                    String startCellIndex = dctGroupCellIndexMap.get(g.getId());

                    if (startCellIndex != null) {
                        int length = ddctGroupCellLengthMap.get(g.getId());
                        final String ref = startCellIndex;
                        char startChar = (char) (startCellIndex.charAt(1));
                        HSSFRow fiRow = null;
                        String myRef = null;
                        for (int i = 0; i < length; i++) {
                            if (j == 1) {//first group
                                fiRow = worksheet.createRow(rowIndex);
                                rowIndex++;
                            } else {
                                fiRow = worksheet.getRow(startingRow + i);
                            }
                            //if the first group has less fold increase value than the current group
                            if (fiRow == null) {
                                fiRow = worksheet.createRow(rowIndex);
                                rowIndex++;
                            }
                            if (i > 0) {
                                char myChar = (char) (startChar + i);
                                myRef = ref.substring(0, 1) + "" + myChar + ref.substring(2);
                            } else {
                                myRef = ref;
                            }
                            if (fiRow != null) {
                                HSSFCell fiCell = fiRow.createCell(j);
                                fiCell.setCellFormula("1/" + myRef);
                                //get fold increase for web output
                                //TODO:: WEBOUTPUT
                                fiCell.getNumericCellValue();
//                               Logger.getLogger(WorkSheetGenerator.class.getName()).log(Level.WARNING,
//                                       gene.getName() + "," + g.getName() + " == " + fiCell.getNumericCellValue() + " == 2^-" + myRef);
                                //  groupFoldIncrease.add(10.0 + Math.random() * 3);

                                String cellString = myRef;
                                if (this.blankCells.contains(myRef) || this.wbBlankCells.contains(myRef)) {
                                    fiCell.setCellType(Cell.CELL_TYPE_BLANK);
                                    //logger.warning("1/dct BLANK: "+myRef);
                                }
                            }
                        }
                    } else {
                        logger.log(Level.WARNING, "ddctGroupCellIndexMap.get.ID: {0}== NULL ", g.getId());
                    }

                    j++;
                }
                // geneFoldIncreaseList.add(groupFoldIncrease);
            }

            //add two blank rows
            rowIndex += 2;

            //HSSFRow borderRow = worksheet.createRow(rowIndex++);
        }
        return rowIndex;
    }
    //

    private void testColor() throws Exception {
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet();
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell(0);
        cell.setCellValue("Default Palette");

        //apply some colors from the standard palette,
        // as in the previous examples.
        //we'll use red text on a lime background

        HSSFCellStyle style = wb.createCellStyle();
        style.setFillForegroundColor(HSSFColor.LIME.index);
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        HSSFFont font = wb.createFont();
        font.setColor(HSSFColor.RED.index);
        style.setFont(font);

        cell.setCellStyle(style);

        //save with the default palette
        FileOutputStream out = new FileOutputStream("tmp/default_palette.xls");
        wb.write(out);
        out.close();

        //now, let's replace RED and LIME in the palette
        // with a more attractive combination
        // (lovingly borrowed from freebsd.org)

        cell.setCellValue("Modified Palette");

        //creating a custom palette for the workbook
        HSSFPalette palette = wb.getCustomPalette();

        //replacing the standard red with freebsd.org red
        palette.setColorAtIndex(HSSFColor.RED.index,
                (byte) 153, //RGB red (0-255)
                (byte) 0, //RGB green
                (byte) 0 //RGB blue
                );
        //replacing lime with freebsd.org gold
        palette.setColorAtIndex(HSSFColor.LIME.index, (byte) 255, (byte) 204, (byte) 102);

        //save with the modified palette
        // note that wherever we have previously used RED or LIME, the
        // new colors magically appear
        out = new FileOutputStream("modified_palette.xls");
        wb.write(out);
        out.close();

    }

    private void setHeaderBorder(HSSFCellStyle c) {
        c.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        c.setBorderRight(HSSFCellStyle.BORDER_THIN);
        c.setLeftBorderColor(HSSFColor.GREY_50_PERCENT.index);
        c.setRightBorderColor(HSSFColor.GREY_50_PERCENT.index);
    }
    /**
     * Create a library of cell styles
     */
    static String HEADER = "header";
    static String HIGHLIGHT = "highlight";
    static String TITLE = "title";

    private Map<String, CellStyle> createStyles(Workbook wb) {

        Font normalFont = wb.createFont();
        Font boldFont = wb.createFont();
        Font underlineFont = wb.createFont();
        normalFont.setFontName(HSSFFont.FONT_ARIAL);
        boldFont.setFontName(HSSFFont.FONT_ARIAL);
        boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        underlineFont.setFontName(HSSFFont.FONT_ARIAL);
        underlineFont.setColor(HSSFColor.BLUE.index);


        Map<String, CellStyle> styles = new HashMap<String, CellStyle>();
        CellStyle style;
        Font titleFont = wb.createFont();
        titleFont.setFontHeightInPoints((short) 18);
        titleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        style.setFont(titleFont);
        styles.put(TITLE, style);


        style = wb.createCellStyle();
        style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setFont(boldFont);

        short borderColor = IndexedColors.DARK_TEAL.getIndex();
        style.setLeftBorderColor(borderColor);
        style.setBorderLeft(CellStyle.BORDER_THICK);

        style.setRightBorderColor(borderColor);
        style.setBorderRight(CellStyle.BORDER_THICK);

        style.setBorderTop(CellStyle.BORDER_THICK);
        style.setTopBorderColor(borderColor);

        style.setBorderBottom(CellStyle.BORDER_THICK);
        style.setBottomBorderColor(borderColor);

        styles.put(HIGHLIGHT, style);


        style = wb.createCellStyle();
        // style.setAlignment(CellStyle.ALIGN_CENTER);
        // style.setVerticalAlignment(CellStyle.ALIGN_LEFT);
        style.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.getIndex());
        style.setFillPattern(HSSFCellStyle.NO_FILL);
        style.setFont(boldFont);
        style.setWrapText(true);
        styles.put(HEADER, style);


        //the following not in used
        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setWrapText(true);
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderLeft(CellStyle.BORDER_THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderTop(CellStyle.BORDER_THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());
        style.setBorderBottom(CellStyle.BORDER_THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        styles.put("cell", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setDataFormat(wb.createDataFormat().getFormat("0.00"));
        styles.put("formula", style);

        style = wb.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        style.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        style.setDataFormat(wb.createDataFormat().getFormat("0.00"));
        styles.put("formula_2", style);

        return styles;
    }

    public String getFileName() {
        return this.outputFileName;
    }

    public String getDisplayFileName() {
        if (projectObj.getProjectName() != null) {
            return this.projectObj.getProjectName() + ".xls";
        } else {
            return "SAGE.xls";
        }
    }

    public String getHtmlFileName() {
        if (projectObj.getProjectName() != null) {
            return this.projectObj.getProjectName() + ".html";
        } else {
            return "SAGE.html";
        }
    }

    public HSSFWorkbook getWorkBook() {
        return workBook;
    }

//   public List<List<Double>> getGeneFoldIncreaseList() {
//       return geneFoldIncreaseList;
//   }
//
//   public void setGeneFoldIncreaseList(List<List<Double>> geneFoldIncreaseList) {
//       this.geneFoldIncreaseList = geneFoldIncreaseList;
//   }
    public List<ReferenceGene> getReferenceGenes() {
        return referenceGenes;
    }

    public void setReferenceGenes(List<ReferenceGene> referenceGenes) {
        this.referenceGenes = referenceGenes;
    }

    public List<TargetGene> getTargetGenes() {
        return targetGenes;
    }

    public void setTargetGenes(List<TargetGene> targetGenes) {
        this.targetGenes = targetGenes;
    }

    public String getReferenceGenesStr() {
        String str = "";
        for (ReferenceGene rg : referenceGenes) {
            str += rg.getGeneName() + ";";
        }
        referenceGenesStr = str;
        return referenceGenesStr;
    }

    public String getTargetGenesStr() {
        String str = "";
        for (TargetGene rg : targetGenes) {
            str += rg.getGeneName() + " References: " + rg.getControlGeneName() + ";";
        }
        targetGenesStr = str;
        return targetGenesStr;
    }

    public String getWorkSheetName() {
        return workSheetName;
    }

    public ProjectObject getProjectObj() {
        return projectObj;
    }

    private void displayWebOutput() {
        // this.resultObj.getAllDataCtTable();
    }

    static public void writeToFile(String filename, String inputString) {

        // new File(filename);

        BufferedWriter bufferedWriter = null;

        try {

            //Construct the BufferedWriter object
            bufferedWriter = new BufferedWriter(new FileWriter(filename));

            //Start writing to the output stream
            bufferedWriter.write(inputString);

        } catch (FileNotFoundException ex) {
            //ex.printStackTrace();
            logger.log(Level.SEVERE, "File not foud: ", ex.getMessage());
        } catch (IOException ex) {
            //ex.printStackTrace();
            logger.log(Level.WARNING, "IO error: ", ex.getMessage());
        } finally {
            //Close the BufferedWriter
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.flush();
                    bufferedWriter.close();
                }
            } catch (IOException ex) {
                //ex.printStackTrace();
                logger.log(Level.WARNING, "IO error: ", ex.getMessage());
            }
        }
    }
}
