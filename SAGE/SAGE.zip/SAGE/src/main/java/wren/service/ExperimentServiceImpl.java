package wren.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import wren.dao.ExperimentDAO;
import wren.domain.Experiment;
import wren.domain.Layout;
import wren.domain.ReferenceGene;
import wren.domain.User;

@Service
public class ExperimentServiceImpl implements ExperimentService {

    @Autowired
    private ExperimentDAO experimentDAO;

    @Transactional
    public List<Experiment> listExperiment() {
        return experimentDAO.listExperiment();
    }

    @Transactional
    public List<Experiment> listExperimentByUsername(Integer id, String username) {
        return experimentDAO.listExperimentByUsername(id, username);
    }

    @Transactional
    public List<Experiment> listExperimentByGroup(Integer id, String role) {
        return experimentDAO.listExperimentByGroup(id, role);
    }

    @Transactional
    public Integer saveExperiment(Experiment experiment) {
        return experimentDAO.saveExperiment(experiment);
    }

    @Transactional
    public Integer saveLayout(Layout layout) {
        return experimentDAO.saveLayout(layout);
    }

    @Transactional
    public Integer saveReferenceGene(ReferenceGene refGene) {
        return experimentDAO.saveReferenceGene(refGene);
    }

    @Transactional
    public String getExperimentJsonString(String experimentID, int[] hasLayout) {
        return experimentDAO.getExperimentJsonString(experimentID, hasLayout);
    }

    @Transactional
    public List<Layout> listLayouts(int experimentID) {
        return experimentDAO.listLayouts(experimentID);
    }

    @Transactional
    public Integer saveWholeExperiment(WorkBookGenerator workBookGenerator,
            String templateJson, String inputFile, String layoutJson,
            String worksheetName, Integer experimentID, Integer layoutID, Integer userID, int[] savedLayoutID, String experimentName) {
        return experimentDAO.saveWholeExperiment(workBookGenerator, templateJson, inputFile, layoutJson,
                worksheetName, experimentID, layoutID, userID, savedLayoutID, experimentName);

    }

    @Transactional
    public List<Layout> listLayoutsByUsername(String username) {
        return experimentDAO.listLayoutsByUsername(username);
    }

    @Transactional
    public String getLayoutJsonString(String layoutID) {
        return experimentDAO.getLayoutJsonString(layoutID);
    }

    public User getUser(Integer id) {
        return experimentDAO.getUser(id);
    }

    @Transactional
    public Experiment getExperimentByID(int id) {
        return experimentDAO.getExperimentByID(id);

    }

    @Transactional
    public int saveExperiment(Integer experimentID, String experimentName,
            String templateJson, int userID) {
        return experimentDAO.saveExperiment(experimentID, experimentName, templateJson, userID);
    }

    @Transactional
    public int saveTemplate(Integer experimentID, String experimentName,
            String templateJson, int userID, int[] savedLayoutID) {
        return experimentDAO.saveTemplate(experimentID, experimentName, templateJson, userID, savedLayoutID);
    }

    @Transactional
    public void deleteExperiment(int experimentID) {
        experimentDAO.deleteExperiment(experimentID);

    }

    @Transactional
    public int saveUser(User user) {
        return experimentDAO.saveUser(user);
    }
}