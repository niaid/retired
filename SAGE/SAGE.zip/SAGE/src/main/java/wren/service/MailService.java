package wren.service;

import java.util.Properties;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailService {

    protected static final Logger logger = Logger.getLogger("MailService");
    final static private String targetErrorEmail = "EMAIL";
    final static private String targetDefaultEmail = "EMAIL";
    private final static String defaultSubject = "Require Support Action on SAGE";
    private final static String smptServer = "EMAIL SERVER";
    private String targetEmail = targetDefaultEmail;
    private final static String sendFrom = targetDefaultEmail;
    private String subject = defaultSubject;

    public boolean sendMail(String message) {

        boolean emailSent = false;
        try {
            boolean debug = false;

            // Set the host smtp address
            Properties props = new Properties();
            props.put("mail.smtp.host", smptServer);

            // create some properties and get the default Session
            Session session = Session.getDefaultInstance(props, null);
            session.setDebug(debug);

            // create a message
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(sendFrom));
            // set the from and to address
            InternetAddress addressFrom[] = new InternetAddress[1];
            addressFrom[0] = new InternetAddress(targetEmail);
            msg.setReplyTo(addressFrom);


            // Pave team recipient address
            InternetAddress[] addressTo = new InternetAddress[1];
            addressTo[0] = new InternetAddress(targetEmail);
            msg.setRecipients(Message.RecipientType.TO, addressTo);

            // Setting the Subject and Content Type
            msg.setSubject(subject);
            msg.setContent(message, "text/plain");
            Transport.send(msg);

            emailSent = true;

        } catch (Exception e) {
            // Error sending email
            logger.warning(e.getMessage());
            //e.printStackTrace();
        }
        return emailSent;
    }

    public String getTargetEmail() {
        return targetEmail;
    }

    public void setTargetEmail(String targetEmail) {
        this.targetEmail = targetEmail;
    }

    public void setErrorTargetEmail() {
        this.targetEmail = targetErrorEmail;

    }

    public void setDefaultTargetEmail() {
        this.targetEmail = targetDefaultEmail;

    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
