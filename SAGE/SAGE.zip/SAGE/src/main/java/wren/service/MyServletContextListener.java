package wren.service;

import java.io.File;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Enumeration;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class MyServletContextListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent event) {
        File webDir = new File(event.getServletContext().getRealPath("/"));
        WorkBookGenerator.webDir = webDir.toString() + "/";
    }

    public void contextDestroyed(ServletContextEvent event) {
        String prefix = getClass().getSimpleName() + " destroy() ";
        ServletContext ctx = event.getServletContext();
        try {
            Enumeration<Driver> drivers = DriverManager.getDrivers();
            while (drivers.hasMoreElements()) {
                DriverManager.deregisterDriver(drivers.nextElement());
            }
        } catch (Exception e) {
            ctx.log(prefix + "Exception caught while deregistering JDBC drivers", e);
        }
        ctx.log(prefix + "complete");

    }
}
