package wren.service;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

/**
 *
 * @author tanq
 */
public class Calculator {

    public static void main(final String[] args) {

//        StandardDeviation standardDeviation = new StandardDeviation() ;
//        double[] sampleValues = {34.22996, 37.347, 78.03751};
//        double value = standardDeviation.evaluate(sampleValues);
//        System.out.println("value="+value);
        Calculator calculator = new Calculator();
        //double[] sampleValues = {34.22996, 37.347, 0, 78.03751};
        double[][] sampleValues = {{0.057, 0.05, 0.06, 0.07}, {0.08}};
        calculator.getConfidenceInterval(sampleValues);

    }

    static public double[][] getConfidenceInterval(double[][] sampleValues) {
        double[][] confidenceIntervalMean = new double[sampleValues.length][4];
        int groupIndex = 0;
        for (double[] svs : sampleValues) {
            double[] cis;// = null;
            if (svs != null && svs.length > 0) {
                cis = getConfidenceInterval(svs);
                confidenceIntervalMean[groupIndex++] = cis;
            } else {
                cis = new double[4];
                for (int i = 0; i < cis.length; i++) {
                    cis[i] = -1;
                }
                confidenceIntervalMean[groupIndex++] = cis;
            }
        }
        return confidenceIntervalMean;
    }

    static public double[] getConfidenceInterval(double[] sampleValues) {
//System.out.println("==========");
        double[] confidenceInterval = new double[4];
        int sampleSize = 0;

        DescriptiveStatistics stats = new DescriptiveStatistics();

        double validPoint = 0;

        for (int i = 0; i < sampleValues.length; i++) {
//            if (sampleValues[i]<0){
//                    System.out.println("sampleValues["+i+"]="+sampleValues[i]);
//                }
            if (sampleValues[i] != 0 && sampleValues[i] != -1.0) {
                sampleSize++;
                stats.addValue(sampleValues[i]);
                //System.out.println("sampleValues["+i+"]="+sampleValues[i]);
                if (validPoint == 0 && sampleValues[i] > 0) {
                    validPoint = sampleValues[i];
                }
            } else {
                // System.out.println("222sampleValues["+i+"]="+sampleValues[i]);
            }
        }

        // Compute some statistics
        double mean = stats.getMean();
        double std = stats.getStandardDeviation();


        double standardError = std * 1.0 / (Math.sqrt(sampleSize)) * 1.0;

        //95% confidence
        double CDF = 1.96;
        double lowerLimit = mean - CDF * standardError;
        double UpperLimit = mean + CDF * standardError;


        confidenceInterval[0] = lowerLimit;
        confidenceInterval[1] = UpperLimit;
        confidenceInterval[2] = mean;
        confidenceInterval[3] = validPoint;

//        System.out.println("standardError=" + standardError + " mean=" + mean);
//        System.out.println("lowerLimit=" + lowerLimit + " UpperLimit=" + UpperLimit+" sampleValues=");
//        for (int i=0; i<sampleValues.length; i++){
//        	System.out.println(sampleValues[i]+"\t");
//        }
//        System.out.println();


        return confidenceInterval;

    }

    static public void getCoEffVar(double[][] sampleValues, double[] avgCts, double[] stdDev, double[] coeffVar) {
        //double[][] coEffVar = new double[sampleValues.length][3];
        int sampleSize = 0;

        for (int c = 0; c < sampleValues[0].length; c++) {
            sampleSize = 0;
            DescriptiveStatistics stats = new DescriptiveStatistics();
            int excludedCount = 0;
            for (int r = 0; r < sampleValues.length; r++) {
                if (sampleValues[r][c] == -1.0) {
                    excludedCount++;
                }
                if (sampleValues[r][c] != 0 && sampleValues[r][c] != -1.0) {
                    sampleSize++;
                    stats.addValue(sampleValues[r][c]);
                }
            }

            double mean = stats.getMean();
            double sdt = stats.getStandardDeviation();
            double coeff = sdt / mean * 100;

            if (sampleSize == 1) {
                sdt = 0;
                coeff = 0;
            } else if (sampleSize == 0) {
                mean = 0;
                sdt = 0;
                coeff = 0;
            }

            avgCts[c] = mean;
            if (excludedCount == sampleValues.length) {
                avgCts[c] = -1;
            }
            stdDev[c] = sdt;
            coeffVar[c] = coeff;

        }
    }
}
