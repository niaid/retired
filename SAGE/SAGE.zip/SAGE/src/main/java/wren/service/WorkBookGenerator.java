package wren.service;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import wren.domain.Layout;
import wren.domain.ResultObj;
import wren.domain.ResultValue;
import wren.domain.jsonObject.ReferenceGene;

/**
 *
 * @author tanq
 */
public class WorkBookGenerator {

    private HSSFWorkbook workBook = new HSSFWorkbook();
    // Map<Integer, Integer> geneGroupAverageRowIndexMap = new HashMap<Integer, Integer>();
    Map<Integer, String> geneGroupAverageRowIndexWSMap = new HashMap<Integer, String>();
    Map<String, Integer> geneGroupAverageMaxColIndexWSMap = new HashMap<String, Integer>();
    List<String> wbBlankCells = new ArrayList<String>();
    Map<Integer, Map<Integer, ResultValue>> geneMap = new LinkedHashMap<Integer, Map<Integer, ResultValue>>();
    Map<Integer, String> experimentRefGeneMap = new HashMap<Integer, String>();
    private String webResultString = null;
    private String webResultStringReadonly = null;
    private String displayName = null;
    private String htmlFileName = null;
    WorkSheetGenerator currentWorkSheet;
    Map<Integer, WorkSheetGenerator> worksheetMap = new HashMap<Integer, WorkSheetGenerator>();
    /* parameters are the data come from web client
     * 1. base on experimentID, file all the inputTexts, jsonStrings and workSheetNames in DB
     * 2. append the current inputText, jsonString and workSheetName and create the array
     * 3. call 'REAL CONSTRUCTOR'
     */
    //private String experimentName;
    private String templateJson;
    private String inputFile;
    private String layoutJson;
    List<ReferenceGene> referenceGenes;
    private String currentWorkSheetName;

    public Map<Integer, WorkSheetGenerator> getWorksheetMap() {
        return worksheetMap;
    }

    public String getCurrentWorkSheetName() {
        return currentWorkSheetName;
    }

    public void setCurrentWorkSheetName(String currentWorkSheetName) {
        this.currentWorkSheetName = currentWorkSheetName;
    }

    public WorkSheetGenerator getCurrentWorkSheet() {
        return currentWorkSheet;
    }

    public String getExperimentName() {
        return currentWorkSheet.getProjectObj().getProjectName();
    }

    public String getTemplateJson() {
        return templateJson;
    }

    public String getInputFile() {
        return inputFile;
    }

    public String getLayoutJson() {
        return layoutJson;
    }

    public List<ReferenceGene> getReferenceGenes() {
        return currentWorkSheet.getReferenceGenes();
    }

    public List<String> getWbBlankCells() {
        return wbBlankCells;
    }

    public void setWbBlankCells(List<String> wbBlankCells) {
        this.wbBlankCells = wbBlankCells;
    }

    public WorkBookGenerator(int experimentID, int layoutID, List<Layout> listLayouts,
            String inputText, String jsonString, String workSheetName, String outputFileName, String webFoldChangeHTML) {



        // WorkBookController controller;
        try {
            // controller = new WorkBookController(experimentID);
            // controller.populateExistingLayoutData();
            List<Integer> layoutIDs = new ArrayList<Integer>(4);
            List<String> inputTexts = new ArrayList<String>(4);
            List<String> jsonStrings = new ArrayList<String>(4);
            List<String> workSheetNames = new ArrayList<String>(4);
            int count = 1;
            boolean newLayoutAdded = false;
            //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "looping ");
//            for (Layout layout : listLayouts) {
//            	Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "display only workSheetName= "+layout.getWorksheetName()+"  layoutID="+layoutID+" layout.getId()="+layout.getId());
//            }
            if (listLayouts != null && listLayouts.size() > 0) {
                for (Layout layout : listLayouts) {
                    //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"inputText "+inputText );
                    if (layout.getId() != layoutID) {// if update, put it to the last
                        layoutIDs.add(layout.getId());
                        inputTexts.add(layout.getInputfile());
                        jsonStrings.add(layout.getLayoutJson());
                        // workSheetNames.add(layout.getWorksheetName()+"-"+(count++));
                        //workSheetNames.add(layout.getWorksheetName());
                        //workSheetName = layout.getWorksheetName();
                        workSheetNames.add("run" + count);//if update, worksheet name cause problem; fix with using the count instead of fileName
//						Logger.getLogger(WorkBookGenerator.class.getName())
//								.log(
//										Level.INFO,
//										"worksheet: "
//												+ layout.getWorksheetName());
                        count++;
                        // Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "1workSheetName= "+workSheetName+"  layoutID="+layoutID+" layout.getId()="+layout.getId()
                        //		 +" count="+count);
                        //	Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"1111111" );
                    } else if (inputText == null || inputText.trim().length() == 0) {//if user did not upload any file, get from database (inputText==null)
                        layoutIDs.add(layout.getId());
                        //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"DB id="+layout.getId() );
                        inputTexts.add(layout.getInputfile());
                        inputText = null;
                        if (jsonString == null || jsonString.trim().length() == 0) {
                            jsonStrings.add(layout.getLayoutJson());
                            jsonString = null;
                            //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"DB jsonString="+layout.getLayoutJson());
                        } else {
                            jsonStrings.add(jsonString);
                            //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"UPLOAD jsonString="+jsonString );
                        }

                        // workSheetNames.add(layout.getWorksheetName()+"-"+(count++));
                        //workSheetNames.add(layout.getWorksheetName());
                        workSheetName = layout.getWorksheetName();
                        workSheetNames.add("run" + count);//if update, worksheet name cause problem; fix with using the count instead of fileName
                        count++;
                        //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "2workSheetName= "+workSheetName+"  layoutID="+layoutID+" layout.getId()="+layout.getId() +" count="+count);
//						Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"22222222222" );
//						Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"id="+layout.getId() );
//						Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"text="+layout.getInputfile() );

                    } else {
                        layoutIDs.add(layoutID);
                        inputTexts.add(inputText);
                        jsonStrings.add(jsonString);
                        workSheetName = layout.getWorksheetName();
                        workSheetNames.add("run" + count);
                        newLayoutAdded = true;
                        // Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "new worksheet: "+workSheetName);
                        count++;
                        // Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "3workSheetName= "+workSheetName+"  layoutID="+layoutID+" layout.getId()="+layout.getId() +" count="+count);
                        //Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO,"333333333" );
                    }


                }
            }
            if (!newLayoutAdded && inputText != null && inputText.trim().length() > 0) {
                layoutIDs.add(-1);
                inputTexts.add(inputText);
                jsonStrings.add(jsonString);

                //workSheetName = workSheetName+"-"+(count++);
                workSheetName = "run" + (count++);
                workSheetNames.add(workSheetName);
                // Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "new worksheet: "+workSheetName);
            }


            if (layoutID == -1) {
                workSheetName = "run" + (count++);
            }
            // Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.INFO, "xxx current ws= "+workSheetName+"  layoutID="+layoutID);

            this.setCurrentWorkSheetName(workSheetName);
            doGenerateWorkBook(layoutIDs, inputTexts, jsonStrings, workSheetNames, workSheetName, outputFileName, webFoldChangeHTML);
            // System.out.println("ExperimentID = "+experimentID);

        } catch (Exception ex) {
            Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public WorkBookGenerator(String inputText, String jsonString, String workSheetName, String outputFileName, String webFoldChangeHTML) {

        workSheetName = workSheetName + "1";
        this.setCurrentWorkSheetName(workSheetName);
        if (inputText != null) {
            FileOutputStream fileOut = null;
            try {
                fileOut = new FileOutputStream(outputFileName);

                WorkSheetGenerator generator = new WorkSheetGenerator(this, workBook, geneMap, geneGroupAverageRowIndexWSMap, geneGroupAverageMaxColIndexWSMap,
                        inputText, jsonString, workSheetName, outputFileName, webFoldChangeHTML, experimentRefGeneMap);
                currentWorkSheet = generator;
                webResultString = generator.getWebResultString();
                webResultStringReadonly = generator.getWebResultReadonly();
                displayName = generator.getDisplayFileName();
                htmlFileName = generator.getHtmlFileName();
                workBook.write(fileOut);
                fileOut.flush();
                fileOut.close();
            } catch (Exception ex) {
                Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    //REAL CONSTRUCTOR
    void doGenerateWorkBook(List<Integer> layoutIDs, List<String> inputTexts, List<String> jsonStrings, List<String> workSheetNames, String workSheetName, String outputFileName, String webFoldChangeHTML) {
        if (inputTexts != null) {
            FileOutputStream fileOut = null;
            try {
                fileOut = new FileOutputStream(outputFileName);
                currentWorkSheet = null;
                for (int i = 0; i < inputTexts.size(); i++) {
                    //adding multiple worksheets to the same workbook
                    //one workbook == one experiment
                    WorkSheetGenerator generator = new WorkSheetGenerator(this, workBook, geneMap, geneGroupAverageRowIndexWSMap, geneGroupAverageMaxColIndexWSMap,
                            inputTexts.get(i), jsonStrings.get(i), workSheetNames.get(i), outputFileName, webFoldChangeHTML, experimentRefGeneMap);

                    worksheetMap.put(layoutIDs.get(i), generator);

                    if (workSheetNames.get(i).equals(workSheetName)) {
                        currentWorkSheet = generator;
                        webResultString = generator.getWebResultString();
                        displayName = generator.getDisplayFileName();
                    } else if (currentWorkSheet == null && (i == inputTexts.size() - 1)) {//last one
                        currentWorkSheet = generator;
                        webResultString = generator.getWebResultString();
                        displayName = generator.getDisplayFileName();
                    }
                    webResultStringReadonly = generator.getWebResultReadonly();
                    htmlFileName = generator.getHtmlFileName();
                }

                workBook.write(fileOut);
                fileOut.flush();
                fileOut.close();
            } catch (Exception ex) {
                Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }
            //TODO:: SAVE DATA TO DATABASE
        }
    }

    //REAL CONSTRUCTOR:: will be RETIRED, for standalone??
    private WorkBookGenerator(String[] inputTexts, String[] jsonStrings, String[] workSheetNames, String workSheetName, String outputFileName, String webFoldChangeHTML) {
        if (inputTexts != null) {
            FileOutputStream fileOut = null;
            try {
                fileOut = new FileOutputStream(outputFileName);
                webResultString = null;
                for (int i = 0; i < inputTexts.length; i++) {
                    //adding multiple worksheets to the same workbook
                    //one workbook == one experiment
                    WorkSheetGenerator generator = new WorkSheetGenerator(this, workBook, geneMap, geneGroupAverageRowIndexWSMap, geneGroupAverageMaxColIndexWSMap,
                            inputTexts[i], jsonStrings[i], workSheetNames[i], outputFileName, webFoldChangeHTML, experimentRefGeneMap);


                    if (workSheetNames[i].equals(workSheetName)) {
                        webResultString = generator.getWebResultString();
                        displayName = generator.getDisplayFileName();
                    } else if (webResultString == null && (i == inputTexts.length - 1)) {//last one
                        webResultString = generator.getWebResultString();
                        displayName = generator.getDisplayFileName();
                    }
                    webResultStringReadonly = generator.getWebResultReadonly();
                    htmlFileName = generator.getHtmlFileName();

                }

                workBook.write(fileOut);
                fileOut.flush();
                fileOut.close();
            } catch (Exception ex) {
                Logger.getLogger(WorkBookGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    //add debug files for inputTexts and jsonStrings
    public static void main(String[] args) throws IOException {

        String[] inputFiles = {"tmp/ROBOT2.txt", "tmp/ROBOT2b.txt"};
        //String[] jsonInputFiles = {"tmp/refGene1.json"};
        String[] jsonInputFiles = {"tmp/ROBOT2.json", "tmp/ROBOT2b.json"};
        String[] workSheetNames = {"Project WorkSheet 1", "Project WorkSheet 2"};

        String[] inputTexts = new String[inputFiles.length];
        String[] jsonStrings = new String[jsonInputFiles.length];

        for (int i = 0; i < inputFiles.length; i++) {
            inputTexts[i] = WorkBookGenerator.readFileAsString(inputFiles[i]);
            jsonStrings[i] = WorkBookGenerator.readFileAsString(jsonInputFiles[i]);
        }
        String webFoldChangeHTML = "tmp/SAGEFoldChangeChart.html";
        String outputFileName = "tmp/SAGEWorkBook.xls";


        new WorkBookGenerator(inputTexts, jsonStrings, workSheetNames, "worksheet1", outputFileName, webFoldChangeHTML);
    }

    public HSSFWorkbook getWorkBook() {
        return workBook;
    }

    public String getWebResultString() {
        return webResultString;
    }

    public String getWebResultWithScript() {

        //return webResultString.replace(ResultObj.reCalculateStr, "").replace(ResultObj.excludeStr, "").replace(ResultObj.excludeStrEditable, ResultObj.excludeStrReadonly);
        String cleanedString = webResultStringReadonly;
        cleanedString = cleanedString.replace(ResultObj.downloadHTMLStr, "");
        cleanedString = cleanedString.replace(ResultObj.copyImageStr, ResultObj.copyImageDisabledStr);
        cleanedString = cleanedString.replace(ResultObj.overflowDivStr2, "");

        return jsString1 + cleanedString + jsString2;
    }

    public static String readFileAsString(String filePath) throws IOException {
        StringBuffer fileData = new StringBuffer(1000);
        BufferedReader reader = new BufferedReader(
                new FileReader(filePath));
        char[] buf = new char[1024];
        int numRead = 0;
        while ((numRead = reader.read(buf)) != -1) {
            fileData.append(buf, 0, numRead);
        }
        reader.close();
        return fileData.toString();
    }

    public String getDisplayFileName() {
        return displayName;
    }

    public String getHtmlFileName() {
        if (htmlFileName != null) {
            htmlFileName = htmlFileName.replace('/', '-').replace(' ', '-');
        }
        return htmlFileName;
    }

    public void setHtmlFileName(String htmlFileName) {
        this.htmlFileName = htmlFileName;
    }
    static StringBuffer hideShowFunc = new StringBuffer();
    public static String webDir = null;

    static {
        hideShowFunc.append("	function hideshow(selectobj, geneName) {\n");
        hideShowFunc.append("		var avgTable = document.getElementById(geneName+\"_avgCT\");\n");
        hideShowFunc.append("	    var foldIncreaseTable = document.getElementById(geneName+\"_fc\");\n");
        hideShowFunc.append("	    var dctTable = document.getElementById(geneName+\"_dct\");\n");
        hideShowFunc.append("		if (selectobj.selectedIndex == 0) {\n");
        hideShowFunc.append("			if (selectobj.length == 1){\n");
        hideShowFunc.append("				avgTable.style.display = \"block\";	\n");
        hideShowFunc.append("			}else{	\n");
        hideShowFunc.append("				foldIncreaseTable.style.display = \"block\";	\n");
        hideShowFunc.append("				dctTable.style.display = \"none\";	\n");
        hideShowFunc.append("				avgTable.style.display = \"none\";	\n");
        hideShowFunc.append("			}	\n");
        hideShowFunc.append("	    }else if (selectobj.selectedIndex == 1) {\n");
        hideShowFunc.append("			foldIncreaseTable.style.display = \"none\";	\n");
        hideShowFunc.append("			dctTable.style.display = \"block\";	\n");
        hideShowFunc.append("			avgTable.style.display = \"none\";	\n");
        hideShowFunc.append("	    }else{\n");
        hideShowFunc.append("			foldIncreaseTable.style.display = \"none\";	\n");
        hideShowFunc.append("			dctTable.style.display = \"none\";	\n");
        hideShowFunc.append("			avgTable.style.display = \"block\";	\n");
        hideShowFunc.append("		}	\n");
        hideShowFunc.append("   }	\n");
    }
    public final static String jsString1 = "<html><head><script type='text/javascript'>\n"
            //+"function addExclusion(ele, data, msg){\n"
            //	+ "ele.innerHTML='(excluded)'; \n"
            //   + " }\n"
            // +"ZeroClipboard.setMoviePath('tmp/ZeroClipboard.swf');"
            //	        +  "function toClipboard(me, thisID) {\n"//not work for file not put to web container
            //
            //	        +  "}\n"

            + "function showTab(element,tabNumber, totalNumber) {\n"
            + "   for (var i = 0; i < totalNumber; i++) {\n"
            + "     var thisGeneName = document.getElementById('Gene'+i);\n"
            + "     \n"
            + "     document.getElementById('gene'+i).style.display = (tabNumber == i ? 'block' : 'none');\n"
            + "     if (tabNumber == i){\n"
            + "          thisGeneName.style.color = 'blue';\n"
            + "          var selectobj = document.getElementById('outputType_'+i);\n"
            + "          hideshow(selectobj, 'gene_'+tabNumber);\n"
            + "     }else{\n"
            + "       thisGeneName.style.color = '#808080';//dark gray\n"
            + "     }\n"
            + "   }\n"
            + "}\n\n"
            + hideShowFunc.toString()
            + "</script></head><body>";
    public final static String jsString2 = "\n</body></html>";
}
