/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

/**
 *
 * @author tanq
 */
public class Gene implements Comparable<Gene>{

    int id;
    String name;
    int type;
    int controlID;
    String replicates;
    int patternType;
    boolean hidden;
    int o;

    public boolean isHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }
    
    
    public int getControlID() {
        if (o>0 && o!=controlID){
           setControlID(o); 
        }
        //System.out.println("getControlID: "+controlID);
        return controlID;
    }

    public void setControlID(int controlID) {
        this.controlID = controlID;
       //  System.out.println("setControlID: "+controlID);
    }

    public int getO() {
        return o;
    }

    public void setO(int o) {
        this.o = o;
        if (o>0 && o!=controlID){
           setControlID(o); 
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPatternType() {
        return patternType;
    }

    public void setPatternType(int patternType) {
        this.patternType = patternType;
    }

    public String getReplicates() {
        return replicates;
    }

    public void setReplicates(String replicates) {
        this.replicates = replicates;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Gene other = (Gene) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    
    
    @Override
    public String toString() {
        return "Gene{" + "id=" + id + ", name=" + name + ", type=" + type + ", controlID=" + controlID + ", replicates=" + replicates + ", patternType=" + patternType  + "}\n";
    }

	public int compareTo(Gene gene2) {
		//put type = 0 (control gene) first
		return this.getType() - gene2.getType();
	}
    
    
}
