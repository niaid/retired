/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

/**
 *
 * @author tanq
 */
public class ProjectObject {

	protected static Logger logger = Logger.getLogger("ProjectObject");

    private String projectName;
    private double missingValue = 40;
    private int coVarianceValue = 5;
    private int tableType = 1;
    List<Group> groups = new ArrayList<Group>();
    List<Gene> genes = new ArrayList<Gene>();
    TemplateTable templateTable = new TemplateTable();
    LayoutTable layoutTable = new LayoutTable();
    ExclusionsTable exclusionsTable = new ExclusionsTable();
    
    List<ReferenceGene> referenceGenes = new ArrayList<ReferenceGene>();
    
    String experimentID;
    String workSheetName;
    int layoutID;
    
    //TemplateTable, LayoutTable, ExclusionsTable have the same structure
//    TemplateTable templateTable = new TemplateTable();
//    TemplateTable layoutTable = new TemplateTable();
//   // TemplateTable exclusionsTable = new TemplateTable();

    public String getExperimentID() {
        return experimentID;
    }

    public void setExperimentID(String experimentID) {
        this.experimentID = experimentID;
    }

    public String getWorkSheetName() {
        return workSheetName;
    }

    public void setWorkSheetName(String workSheetName) {
        this.workSheetName = workSheetName;
    }
    

//    @Override
//    public String toString() {
//        return "ProjectObject{" + "porjectName=" + porjectName + ",\n groups=" + groups + ",\n genes=" + genes + ",\n templateTable=" + templateTable + "\n}\n";
//    }

    public int getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(int layoutID) {
		this.layoutID = layoutID;
	}

	public List<ReferenceGene> getReferenceGenes() {
        return referenceGenes;
    }

    public void setReferenceGenes(List<ReferenceGene> referenceGenes) {
        this.referenceGenes = referenceGenes;
    }

    
    
    public int getCoVarianceValue() {
        return coVarianceValue;
    }

    public void setCoVarianceValue(int coVarianceValue) {
        this.coVarianceValue = coVarianceValue;
    }

   
    
    public double getMissingValue() {
        if (missingValue<=0){
            missingValue = -1;
        }
        return missingValue;
    }

    public void setMissingValue(double missingValue) {
        this.missingValue = missingValue;
    }

    
    
    public ExclusionsTable getExclusionsTable() {
        return exclusionsTable;
    }

    public void setExclusionsTable(ExclusionsTable exclusionsTable) {
        this.exclusionsTable = exclusionsTable;
    }

    public List<Gene> getGenes() {
    	
    	Collections.sort(genes);
    	//logger.warning("GENES: "+genes);
        return genes;
    }
    

    public void setGenes(List<Gene> genes) {
        this.genes = genes;
    }

    public List<Group> getGroups() {
    	Collections.sort(groups);
    	//logger.warning("GROUPS: "+groups);
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }

    public LayoutTable getLayoutTable() {
        return layoutTable;
    }

    public void setLayoutTable(LayoutTable layoutTable) {
        this.layoutTable = layoutTable;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String porjectName) {
        this.projectName = porjectName;
    }

    public TemplateTable getTemplateTable() {
        return templateTable;
    }

    public void setTemplateTable(TemplateTable templateTable) {
        this.templateTable = templateTable;
    }
    
    public int getTableType() {
		return tableType;
	}

	public void setTableType(int tableType) {
		this.tableType = tableType;
	}

	@Override
    public String toString() {
        return "ProjectObject{" + "porjectName=" + projectName + ",\n groups=" + groups + ",\n\n genes=" + genes + ",\n\n templateTable=" + templateTable  + 
            "\n\n, layoutTable=" + layoutTable + ",\n\n exclusionsTable=" + exclusionsTable + '}';
    }

    
        
  
}
