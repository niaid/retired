package wren.domain;

import java.util.logging.Logger;
import wren.domain.jsonObject.Gene;
import wren.domain.jsonObject.Group;
import wren.service.Calculator;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * ResultValue on each gene and each group
 *
 * @author tanq
 */
public class ResultValue {

    ResultObj parent;
    Gene gene;
    Group group;
    double[][] inputValues;
    String[][] inputValuesCooridnates;
    double[] avgCts;
    double[] stdDev;
    double[] coeffVar;
    double[] dctValues;
    double[] overDctValues;
    double[] ddctValues;
    double[] logDdctValues; //fold change
    double avgDctValue;
    double sumDctValue;
    double[][] foldChangeValues;
    //double[][2] confidence interval of foldChangeValues;
    double[][] foldChangeConfidenceInterval;
    //double[][] inputValues;
    //double[] averageCtValues;
    //double[] dctValues;
    //double[] ddctValues;
    //double avgDctValue;
    //on gene level, double[][] foldChangeValues;
    //on gene level, double[][2] confidence interval of foldChangeValues;
    protected static final Logger logger = Logger.getLogger("ResultValue");

    public ResultValue(ResultObj parent, Gene gene, Group group, Double[][] geneGroupValues, String[][] geneGroupCoordinates) {
        this.parent = parent;
        this.gene = gene;
        this.group = group;
        this.inputValues = new double[geneGroupValues.length][geneGroupValues[0].length];
        this.inputValuesCooridnates = new String[geneGroupValues.length][geneGroupValues[0].length];

        // System.out.println("##############################################");
        // System.out.println(gene.getName()+" group: "+group.getName());
        for (int i = 0; i < geneGroupValues.length; i++) {
            for (int j = 0; j < geneGroupValues[0].length; j++) {
                if (geneGroupValues[i][j] != null) {
                    inputValues[i][j] = geneGroupValues[i][j];
                    inputValuesCooridnates[i][j] = geneGroupCoordinates[i][j];
                } else if (parent.projectObj.getMissingValue() > 0) {
                    inputValues[i][j] = parent.projectObj.getMissingValue();
                    inputValuesCooridnates[i][j] = geneGroupCoordinates[i][j];
                }
                //System.out.println("geneGroupValues["+i+"]["+j+"]="+geneGroupValues[i][j]);
                //System.out.println("xxxxxx inputValues["+i+"]["+j+"]="+inputValues[i][j]);
            }
        }


        //populate avgCts
        avgCts = new double[inputValues[0].length];
        stdDev = new double[inputValues[0].length];
        coeffVar = new double[inputValues[0].length];

        //populate avgCts, stdDev, coeffVar
        Calculator.getCoEffVar(inputValues, avgCts, stdDev, coeffVar);


        //populate dctValues
        if (gene.getType() == 1) {//target gene
            //double[] controlAvgCts = parent.getAveCtTable(gene.getControlID(), group.getId());
            //TODO:: deal with multiple control groupXXXXXXXX

            double[] controlAvgCts = parent.getAveCtTable(gene.getControlID(), group.getId());
            if (controlAvgCts != null) {
                dctValues = new double[controlAvgCts.length];
                ddctValues = new double[controlAvgCts.length];
                logDdctValues = new double[controlAvgCts.length];
//                double[] myValues = new double[controlAvgCts.length];
//                for (int mm=0; mm<myValues.length; mm++){
//                	myValus[mm] = inputValues[mm][j];
//                }
                //TODO:: with exclusion, the controlAvgCts.length > avgCts.length
                int countIncluded = 0;
                for (int i = 0; i < controlAvgCts.length; i++) {
                    if (i < avgCts.length && controlAvgCts[i] != -1 && controlAvgCts[i] != 0 && avgCts[i] != -1 && avgCts[i] != 0) {
                        countIncluded++;
                        dctValues[i] = avgCts[i] - controlAvgCts[i];
                        sumDctValue += dctValues[i];
                        // System.out.println("avgCts["+i+"]="+avgCts[i]+" controlAvgCts["+i+"]="+controlAvgCts[i]+" dctValues["+i+"]="+dctValues[i]);
                    } else if (i < avgCts.length && avgCts[i] == -1) {
                        dctValues[i] = -1;
                    }
                    if (controlAvgCts[i] == -1) {//if control sample value all excluded
                        dctValues[i] = -1;
                    }
                    //System.out.println("avgCts["+i+"]="+avgCts[i]+" controlAvgCts["+i+"]="+controlAvgCts[i]+" dctValues["+i+"]="+dctValues[i]);
                }

                if (group.getType() == 0) { //control
                    avgDctValue = sumDctValue / countIncluded;
                    // System.out.println("GENE "+gene.getName()+" CONTROL GROUP: "+group.getName()+" avgDctValue="+avgDctValue+" ("+sumDctValue +"/ "+countIncluded+")");
                } else {
                    avgDctValue = parent.getAveDctValue(gene.getId(), group.getControlID());
                    //System.out.println("GENE "+gene.getName()+" FROM MAP GROUP: "+group.getName()+" avgDctValue="+avgDctValue);
                }
                //System.out.println("avgDctValue="+avgDctValue);
                //for testing, check desktop db, 0412-02run2 and 0412-03run1, and  0412-04run1
                if (avgDctValue != -1) {//if not excluded
                    for (int i = 0; i < ddctValues.length; i++) {
                        //if not excluded, what if it's really 0??
                        boolean doCalculate = false;
                        if (dctValues[i] == 0.0 && inputValues.length > 0 && i < inputValues[0].length && inputValues[0][i] == 0) {//if replicate = 1
                            //System.out.println("xxGENE "+gene.getName()+" GROUP: "+group.getName()+" i="+i+" stdDev.length="+stdDev.length);
                        } else if (dctValues[i] == 0.0 && inputValues.length > 0 && i < inputValues[0].length && inputValues[0][i] != 0 && inputValues[0][i] != -1) {//if replicate = 1, replace by 40
                            doCalculate = true;
                        } else if (dctValues[i] != -1 && !(dctValues[i] == 0 && avgCts.length > i && avgCts[i] == 0)
                                && !(dctValues[i] == 0 && controlAvgCts.length > i && controlAvgCts[i] == 0)
                                && !(dctValues[i] == 0.0 && stdDev.length > i && stdDev[i] == 0)) {
                            doCalculate = true;
                        }
                        if (doCalculate) {
                            ddctValues[i] = dctValues[i] - avgDctValue;

                            if (ddctValues[i] != 0) {
                                logDdctValues[i] = Math.pow(2, -ddctValues[i]);
                            } else {
                                //logDdctValues[i] = -1;
                                logDdctValues[i] = 1;//Math.pow(2,0)==1
                            }
                        }
                        // System.out.println("GENE "+gene.getName()+" GROUP: "+group.getName()+"inputValues[0]["+i+"]="+inputValues[0][i]+" avgDctValue="+avgDctValue+" dctValues["+i+"]="+dctValues[i]+" ddctValues["+i+"]="+ddctValues[i]+" logDdctValues["+i+"]="+logDdctValues[i]);
                    }
                }
//                if (gene.getName().equals("Gene 3") && group.getName().equals("Group 9")){
//                	logger.warning("11avgDctValue="+avgDctValue+" dctValues[0]="+dctValues[0]+ " ddctValues[0]="+ddctValues[0]+ "logDdctValues[0]="+logDdctValues[0]);
//                }
            }

        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ResultValue other = (ResultValue) obj;
        if (this.gene != other.gene && (this.gene == null || !this.gene.equals(other.gene))) {
            return false;
        }
        if (this.group != other.group && (this.group == null || !this.group.equals(other.group))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public String toString() {
        String output = "";
        for (int i = 0; i < inputValues.length; i++) {
            //output+="Row: "+i+": ";
            for (int j = 0; j < inputValues[0].length; j++) {
                output += inputValues[i][j] + " ";
            }
            output += "\n";
        }
        output += "Avg Ct:\t";
        for (int i = 0; i < avgCts.length; i++) {
            output += avgCts[i] + " ";
        }
        output += "\n";

        if (gene.getType() == 1) {//target gene
            if (dctValues != null && dctValues.length > 0) {
                output += "dCt:\t";
                for (int i = 0; i < dctValues.length; i++) {
                    output += dctValues[i] + " ";
                }
                output += "\n";
                output += "Avg dCt:\t" + this.avgDctValue;
                output += "\n";
                output += "ddCt:\t";
                for (int i = 0; i < ddctValues.length; i++) {
                    output += ddctValues[i] + " ";
                }
                output += "\n";
            } else {
                output += "Gene/GroupID " + gene.getControlID() + "/" + group.getId() + " not found \n";
            }
        }

        return output;
    }

    public double[] getAvgCts() {
        return avgCts;
    }

    public void setAvgCts(double[] avgCts) {
        this.avgCts = avgCts;
    }

    public double getAvgDctValue() {
        return avgDctValue;
    }

    public double[][] getInputValues() {
        return inputValues;
    }

    public double[] getDdctValues() {
        return ddctValues;
    }

    public double[] getLogDdctValues() {
//    	if (logDdctValues!=null){
//    		for (int i=0; i<logDdctValues.length; i++){
//    			if (logDdctValues[i] == 0.0){
//    				logDdctValues[i] = -1;
//    			}
//    		}
//    	}
        return logDdctValues;
    }

    public void setInputValues(double[][] inputValues) {
        this.inputValues = inputValues;
    }

    public double[] getCoeffVar() {
        return coeffVar;
    }

    public void setCoeffVar(double[] coeffVar) {
        this.coeffVar = coeffVar;
    }

    public double[] getStdDev() {
        return stdDev;
    }

    public void setStdDev(double[] stdDev) {
        this.stdDev = stdDev;
    }

    public double[] getDctValues() {
        return dctValues;
    }

    public double[] getOverDctValues() {
        if (dctValues != null) {
            overDctValues = new double[dctValues.length];
            int i = 0;
            for (double dct : dctValues) {
                if (dct != 0) {
                    overDctValues[i] = 1.0 / dct;
                } else {
                    overDctValues[i] = 0;
                }
                i++;
            }
        }
        return overDctValues;
    }

    public void setDctValues(double[] dctValues) {
        this.dctValues = dctValues;
    }

    public double[][] getFoldChangeConfidenceInterval() {
        return foldChangeConfidenceInterval;
    }

    public void setFoldChangeConfidenceInterval(double[][] foldChangeConfidenceInterval) {
        this.foldChangeConfidenceInterval = foldChangeConfidenceInterval;
    }

    public double[][] getFoldChangeValues() {
        return foldChangeValues;
    }

    public void setFoldChangeValues(double[][] foldChangeValues) {
        this.foldChangeValues = foldChangeValues;
    }

    public Gene getGene() {
        return gene;
    }

    public void setGene(Gene gene) {
        this.gene = gene;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public ResultObj getParent() {
        return parent;
    }

    public void setParent(ResultObj parent) {
        this.parent = parent;
    }

    public double getSumDctValue() {
        return sumDctValue;
    }

    public void setSumDctValue(double sumDctValue) {
        this.sumDctValue = sumDctValue;
    }

    public String[][] getInputValuesCooridnates() {
        return inputValuesCooridnates;
    }

    public void setInputValuesCooridnates(String[][] inputValuesCooridnates) {
        this.inputValuesCooridnates = inputValuesCooridnates;
    }
}
