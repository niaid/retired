package wren.domain;

import java.io.Serializable;
import java.util.Calendar;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */
@Entity
@Table(catalog = "wren", name = "User")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "SAGE/wren/domain", name = "User")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String DEFAULT_ROLE = "user";
    /**
     */
    @Column(name = "id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @XmlElement
    Integer id;
    /**
     */
    @Column(name = "login_name", length = 45, nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String loginName;
    /**
     */
    @Column(name = "firstName", length = 45)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String firstName;
    /**
     */
    @Column(name = "lastName", length = 45)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String lastName;
    /**
     */
    @Column(name = "password", length = 45)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String password;
    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Calendar createdDate = Calendar.getInstance();
    /**
     */
    @Column(name = "role", length = 45)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String role;
    @Column(name = "email", length = 45)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String email;

    /**
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     */
    public Integer getId() {
        return this.id;
    }

    /**
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    /**
     */
    public String getLoginName() {
        return this.loginName;
    }

    /**
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     */
    public String getPassword() {
        return this.password;
    }

    /**
     */
    public void setCreatedDate(Calendar createdDate) {
        this.createdDate = createdDate;
    }

    /**
     */
    public Calendar getCreatedDate() {
        return this.createdDate;
    }

    /**
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     */
    public String getRole() {
        return this.role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /**
     */
    public User() {
    }

    public User(Integer id, String loginName, String firstName,
            String lastName, String password, Calendar createdDate, String role) {
        super();
        this.id = id;
        this.loginName = loginName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.createdDate = createdDate;
        this.role = role;
    }

    /**
     * Copies the contents of the specified bean into this bean.
     *
     */
    public void copy(User that) {
        setId(that.getId());
        setLoginName(that.getLoginName());
        setFirstName(that.getFirstName());
        setLastName(that.getLastName());
        setPassword(that.getPassword());
        setCreatedDate(that.getCreatedDate());
        setRole(that.getRole());
    }

    /**
     * Returns a textual representation of a bean.
     *
     */
    public String toString() {

        StringBuilder buffer = new StringBuilder();

        buffer.append("id=[").append(id).append("] ");
        buffer.append("loginName=[").append(loginName).append("] ");
        buffer.append("firstName=[").append(firstName).append("] ");
        buffer.append("lastName=[").append(lastName).append("] ");
        buffer.append("password=[").append(password).append("] ");
        buffer.append("createdDate=[").append(createdDate).append("] ");
        buffer.append("role=[").append(role).append("] ");

        return buffer.toString();
    }

    /**
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (int) (prime * result + ((id == null) ? 0 : id.hashCode()));
        return result;
    }

    /**
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof User)) {
            return false;
        }
        User equalCheck = (User) obj;
        if ((id == null && equalCheck.id != null) || (id != null && equalCheck.id == null)) {
            return false;
        }
        if (id != null && !id.equals(equalCheck.id)) {
            return false;
        }
        return true;
    }
}
