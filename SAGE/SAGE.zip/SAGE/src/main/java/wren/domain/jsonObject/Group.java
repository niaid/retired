/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tanq
 */
public class Group implements Comparable<Group>{

    int id;
    String name;
    int type;
    int controlID;
    int o;
    String color;
    List<String> claimedTiles = new ArrayList<String>();

    public List<String> getClaimedTiles() {
        return claimedTiles;
    }

    public void setClaimedTiles(List<String> claimedTiles) {
        this.claimedTiles = claimedTiles;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getControlID() {
        if (o>0 && o!=controlID){
           setControlID(o); 
        }
        //System.out.println("getControlID: "+controlID);
        return controlID;
    }

    public void setControlID(int controlID) {
        this.controlID = controlID;
       //  System.out.println("setControlID: "+controlID);
    }

    public int getO() {
        return o;
    }

    public void setO(int o) {
        this.o = o;
        if (o>0 && o!=controlID){
           setControlID(o); 
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    
    @Override
    public String toString() {
        return "Group{" + "id=" + id + ", name=" + name + ", type=" + type + ", controlID=" + controlID + ", color=" + color + ", claimedTiles=" + claimedTiles + "}\n";
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Group other = (Group) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

	public int compareTo(Group group2) {
		//put type = 0 (control group) first
		return this.getType() - group2.getType();
	}
    
    
}
