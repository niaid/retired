/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;
import java.util.List;
/**
 *
 * @author tanq
 */
public class ExclusionsTable {
    int type;
    int row;
    int col;
    int idNum;
    String id;
    List<List<Integer>> tiles;
    List<List<Integer>> layoutTiles;
    List<List<Integer>> replicateTiles;
    int geneID;
    int nextLine;
    LayoutModule module;

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public int getGeneID() {
        return geneID;
    }

    public void setGeneID(int geneID) {
        this.geneID = geneID;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getIdNum() {
        return idNum;
    }

    public void setIdNum(int idNum) {
        this.idNum = idNum;
    }

    public List<List<Integer>> getLayoutTiles() {
        return layoutTiles;
    }

    public void setLayoutTiles(List<List<Integer>> layoutTiles) {
        this.layoutTiles = layoutTiles;
    }

    public LayoutModule getModule() {
        return module;
    }

    public void setModule(LayoutModule module) {
        this.module = module;
    }

    public int getNextLine() {
        return nextLine;
    }

    public void setNextLine(int nextLine) {
        this.nextLine = nextLine;
    }

    public List<List<Integer>> getReplicateTiles() {
        return replicateTiles;
    }

    public void setReplicateTiles(List<List<Integer>> replicateTiles) {
        this.replicateTiles = replicateTiles;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public List<List<Integer>> getTiles() {
        return tiles;
    }

    public void setTiles(List<List<Integer>> tiles) {
        this.tiles = tiles;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    
   @Override
    public String toString() {
        return "ExclusionsTable{" + "type=" + type + ", row=" + row + ", col=" + col + ", idNum=" + idNum + ", id=" + id + 
                ",\n tiles=" + tiles + ",\n layoutTiles=" + layoutTiles + ",\n replicateTiles=" + replicateTiles 
                + ",\n geneID=" + geneID + ",\n nextLine=" + nextLine + ",\n module=" + module + '}';
    }

    
}
