/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

import java.util.List;

/**
 *
 * @author tanq
 */
public class TemplateModule {
    String selector;
//    accordion;
//    table;
//    data;
//    dataID;
//    dataIndex;
    List<List<String>> claimedTiltes;
    List<List<String>> layoutTiles;
    //int active;
    int activeID;
    boolean firstRun;
    int activePatternID;
    boolean stop;
    int hue;
   // activeElement;

    @Override
    public String toString() {
        return "TemplateModule{" + "selector=" + selector + ", claimedTiltes=" + claimedTiltes + ", layoutTiles=" + layoutTiles + ", activeID=" + activeID + ", firstRun=" + firstRun + ", activePatternID=" + activePatternID + ", stop=" + stop + ", hue=" + hue + '}';
    }
    
    
}
