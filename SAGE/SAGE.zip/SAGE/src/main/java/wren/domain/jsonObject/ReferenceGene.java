/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

/**
 *
 * @author tanq
 */
public class ReferenceGene {
    int id;
    String geneName;
    int layoutID;
    

    public ReferenceGene(int id, String geneName, int layoutID) {
        this.id = id;
        this.geneName = geneName;
        this.layoutID = layoutID;
    }

    public String getGeneName() {
        return geneName;
    }

    public void setGeneName(String geneName) {
        this.geneName = geneName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public int getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(int layoutID) {
		this.layoutID = layoutID;
	}

	@Override
	public String toString() {
		return "\nReferenceGene [geneName=" + geneName + ", id=" + id
				+ ", layoutID=" + layoutID + "]";
	}
    
    
}
