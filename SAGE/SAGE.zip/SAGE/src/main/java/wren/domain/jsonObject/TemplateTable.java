/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

import java.util.List;

/**
 *
 * @author tanq
 */
public class TemplateTable {
    int type;
    int row;
    int col;
    int idNum;
    String id;
    List<List<Integer>> tiles;
    List<List<Integer>> layoutTiles;
    List<List<Integer>> replicateTiles;
    int geneID;
    int nextLine;
    TemplateModule module;

    @Override
    public String toString() {
        return "TemplateTable{" + "type=" + type + ", row=" + row + ", col=" + col + ", idNum=" + idNum + ", id=" + id + 
                ",\n tiles=" + tiles + ",\n layoutTiles=" + layoutTiles + ",\n replicateTiles=" + replicateTiles 
                + ",\n geneID=" + geneID + ",\n nextLine=" + nextLine + ",\n module=" + module + '}';
    }
    
    
}
