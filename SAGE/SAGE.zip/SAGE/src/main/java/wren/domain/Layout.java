package wren.domain;

import java.io.Serializable;
import java.util.Calendar;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 */
@Entity
@Table(catalog = "wren", name = "Layout")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "SAGE/wren/domain", name = "Layout")
public class Layout implements Serializable {

    private static final long serialVersionUID = 2L;
    /**
     */
    @Column(name = "id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @XmlElement
    Integer id;
    /**
     */
    @Column(name = "inputfile", columnDefinition = "LONGTEXT")
    @Basic(fetch = FetchType.EAGER)
    @Lob
    @XmlElement
    String inputfile;
    /**
     */
    @Column(name = "Experiment_id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Integer experimentId;
    /**
     */
    @Column(name = "layout_json", columnDefinition = "LONGTEXT")
    @Basic(fetch = FetchType.EAGER)
    @Lob
    @XmlElement
    String layoutJson;
    /**
     */
    @Column(name = "worksheet_name", length = 45)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String worksheetName;
    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Calendar createdDate;
    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "last_modified_date")
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Calendar lastModifiedDate;
    @Column(name = "refgenenames", columnDefinition = "TEXT")
    @Basic(fetch = FetchType.EAGER)
    @Lob
    @XmlElement
    String refGeneNames;
    @Column(name = "targetgenenames", columnDefinition = "TEXT")
    @Basic(fetch = FetchType.EAGER)
    @Lob
    @XmlElement
    String targetGeneNames;

//	@ManyToOne
//	private Experiment experiment;
    /**
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     */
    public Integer getId() {
        return this.id;
    }

    /**
     */
    public void setInputfile(String inputfile) {
        this.inputfile = inputfile;
    }

    /**
     */
    public String getInputfile() {
        return this.inputfile;
    }

    /**
     */
    public void setExperimentId(Integer experimentId) {
        this.experimentId = experimentId;
    }

    /**
     */
    public Integer getExperimentId() {
        return this.experimentId;
    }

    /**
     */
    public void setLayoutJson(String layoutJson) {
        this.layoutJson = layoutJson;
    }

    /**
     */
    public String getLayoutJson() {
        return this.layoutJson;
    }

    /**
     */
    public void setCreatedDate(Calendar createdDate) {
        this.createdDate = createdDate;
    }

    /**
     */
    public Calendar getCreatedDate() {
        return this.createdDate;
    }

    /**
     */
    public void setLastModifiedDate(Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    /**
     */
    public Calendar getLastModifiedDate() {
        return this.lastModifiedDate;
    }

//	public Experiment getExperiment() {
//		return experiment;
//	}
//
//	public void setExperiment(Experiment experiment) {
//		this.experiment = experiment;
//	}
    public String getWorksheetName() {
        return worksheetName;
    }

    public void setWorksheetName(String worksheetName) {
        this.worksheetName = worksheetName;
    }

    public String getRefGeneNames() {
        return refGeneNames;
    }

    public void setRefGeneNames(String refGeneNames) {
        this.refGeneNames = refGeneNames;
    }

    public String getTargetGeneNames() {
        return targetGeneNames;
    }

    public void setTargetGeneNames(String targetGeneNames) {
        this.targetGeneNames = targetGeneNames;
    }

    /**
     */
    public Layout() {
    }

    /**
     * Copies the contents of the specified bean into this bean.
     *
     */
    public void copy(Layout that) {
        setId(that.getId());
        setInputfile(that.getInputfile());
        setExperimentId(that.getExperimentId());
        setLayoutJson(that.getLayoutJson());
        setCreatedDate(that.getCreatedDate());
        setLastModifiedDate(that.getLastModifiedDate());
    }

    /**
     * Returns a textual representation of a bean.
     *
     */
//	public String toString() {
//
//		StringBuilder buffer = new StringBuilder();
//
//		buffer.append("id=[").append(id).append("] ");
//		buffer.append("inputfile=[").append(inputfile).append("] ");
//		buffer.append("experimentId=[").append(experimentId).append("] ");
//		buffer.append("layoutJson=[").append(layoutJson).append("] ");
//		buffer.append("createdDate=[").append(createdDate).append("] ");
//		buffer.append("lastModifiedDate=[").append(lastModifiedDate).append(
//				"] ");
//
//		return buffer.toString();
//	}
    /**
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (int) (prime * result + ((id == null) ? 0 : id.hashCode()));
        return result;
    }

    @Override
    public String toString() {
        return "Layout [createdDate=" + createdDate + ", experimentId="
                + experimentId + ", id=" + id + ", inputfile=" + inputfile
                + ", lastModifiedDate=" + lastModifiedDate + ", refGeneNames="
                + refGeneNames + ", targetGeneNames=" + targetGeneNames
                + ", worksheetName=" + worksheetName + "]";
    }

    /**
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Layout)) {
            return false;
        }
        Layout equalCheck = (Layout) obj;
        if ((id == null && equalCheck.id != null)
                || (id != null && equalCheck.id == null)) {
            return false;
        }
        if (id != null && !id.equals(equalCheck.id)) {
            return false;
        }
        return true;
    }
}
