package wren.domain;

import java.io.Serializable;
import java.util.Calendar;
import javax.persistence.*;
import javax.xml.bind.annotation.*;

/**
 */
@Entity
//@NamedQueries( {
//		@NamedQuery(name = "findAllExperiments", query = "select myExperiment from Experiment myExperiment"),
//		@NamedQuery(name = "findExperimentByUserId", query = "select myExperiment from Experiment myExperiment where myExperiment.userId = ?1") })
@Table(catalog = "wren", name = "Experiment")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "SAGE/wren/domain", name = "Experiment")
public class Experiment implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     */
    @Column(name = "id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @XmlElement
    Integer id;
    /**
     */
    @Column(name = "name", length = 45, nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String name;
    /**
     */
    @Column(name = "template_json", columnDefinition = "LONGTEXT")
    @Basic(fetch = FetchType.EAGER)
    @Lob
    @XmlElement
    String templateJson;
    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Calendar createdDate;
    /**
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "last_modified_date")
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Calendar lastModifiedDate;
    /**
     */
//	@Column(name = "User_id", nullable = false)
//	@Basic(fetch = FetchType.EAGER)
//	@XmlElement
//	Integer userId;
    @Column(name = "hasLayout")
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Integer hasLayout;

    /**
     */
    /**
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     */
    public Integer getId() {
        return this.id;
    }

    /**
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     */
    public String getName() {
        return this.name;
    }

    /**
     */
    public void setTemplateJson(String templateJson) {
        this.templateJson = templateJson;
    }

    /**
     */
    public String getTemplateJson() {
        return this.templateJson;
    }

    /**
     */
    public void setCreatedDate(Calendar createdDate) {
        this.createdDate = createdDate;
    }

    /**
     */
    public Calendar getCreatedDate() {
        return this.createdDate;
    }

    /**
     */
    public void setLastModifiedDate(Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    /**
     */
    public Calendar getLastModifiedDate() {
        return this.lastModifiedDate;
    }
    /**
     */
//	public void setUserId(Integer userId) {
//		this.userId = userId;
//	}
//
//	/**
//	 */
//	public Integer getUserId() {
//		return this.userId;
//	}
    @ManyToOne
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getHasLayout() {
        return hasLayout;
    }

    public void setHasLayout(Integer hasLayout) {
        this.hasLayout = hasLayout;
    }

    /**
     */
    public Experiment() {
    }

    /**
     * Copies the contents of the specified bean into this bean.
     *
     */
    public void copy(Experiment that) {
        setId(that.getId());
        setName(that.getName());
        setTemplateJson(that.getTemplateJson());
        setCreatedDate(that.getCreatedDate());
        setLastModifiedDate(that.getLastModifiedDate());
        //setUserId(that.getUserId());
    }

    /**
     * Returns a textual representation of a bean.
     *
     */
    public String toString() {

        StringBuilder buffer = new StringBuilder();

        buffer.append("id=[").append(id).append("] ");
        buffer.append("name=[").append(name).append("] ");
        buffer.append("templateJson=[").append(templateJson).append("] ");
        buffer.append("createdDate=[").append(createdDate).append("] ");
        buffer.append("lastModifiedDate=[").append(lastModifiedDate).append(
                "] ");
        //buffer.append("userId=[").append(userId).append("] ");

        return buffer.toString();
    }

    /**
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (int) (prime * result + ((id == null) ? 0 : id.hashCode()));
        return result;
    }

    /**
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Experiment)) {
            return false;
        }
        Experiment equalCheck = (Experiment) obj;
        if ((id == null && equalCheck.id != null)
                || (id != null && equalCheck.id == null)) {
            return false;
        }
        if (id != null && !id.equals(equalCheck.id)) {
            return false;
        }
        return true;
    }
}
