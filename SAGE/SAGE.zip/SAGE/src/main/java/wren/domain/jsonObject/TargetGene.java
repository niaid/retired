/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package wren.domain.jsonObject;

/**
 *
 * @author tanq
 */
public class TargetGene {
    int id;
    String geneName;
    int layoutID;
    int controlID;
    String controlGeneName;//refer to which reference gene;
    

    public TargetGene(int id, String geneName, int layoutID, int controlID, String controlGeneName) {
        this.id = id;
        this.geneName = geneName;
        this.layoutID = layoutID;
        this.controlID = controlID;
        this.controlGeneName = controlGeneName;
    }

    public String getGeneName() {
        return geneName;
    }

    public void setGeneName(String geneName) {
        this.geneName = geneName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public int getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(int layoutID) {
		this.layoutID = layoutID;
	}

	public int getControlID() {
		return controlID;
	}

	public void setControlID(int controlID) {
		this.controlID = controlID;
	}

	public String getControlGeneName() {
		return controlGeneName;
	}

	public void setControlGeneName(String controlGeneName) {
		this.controlGeneName = controlGeneName;
	}

	@Override
	public String toString() {
		return "\nTargetGene [controlGeneName=" + controlGeneName
				+ ", controlID=" + controlID + ", geneName=" + geneName
				+ ", id=" + id + ", layoutID=" + layoutID + "]";
	}


	
    
}
