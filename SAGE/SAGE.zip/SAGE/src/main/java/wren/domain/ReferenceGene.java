package wren.domain;

import java.io.Serializable;
import javax.persistence.*;
import javax.xml.bind.annotation.*;

/**
 */
@Entity
@Table(catalog = "wren", name = "Reference_Gene")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(namespace = "SAGE/wren/domain", name = "ReferenceGene")
public class ReferenceGene implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     */
    @Column(name = "id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @Id
    //@GeneratedValue(strategy=GenerationType.IDENTITY)
    @XmlElement
    Integer id;
    /**
     */
    @Column(name = "gene_name", length = 45, nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    String geneName;
    /**
     */
    @Column(name = "Experiment_id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Integer experimentId;
    /**
     */
    @Column(name = "Layout_id", nullable = false)
    @Basic(fetch = FetchType.EAGER)
    @XmlElement
    Integer layoutId;

    /**
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     */
    public Integer getId() {
        return this.id;
    }

    /**
     */
    public void setGeneName(String geneName) {
        this.geneName = geneName;
    }

    /**
     */
    public String getGeneName() {
        return this.geneName;
    }

    /**
     */
    public void setExperimentId(Integer experimentId) {
        this.experimentId = experimentId;
    }

    /**
     */
    public Integer getExperimentId() {
        return this.experimentId;
    }

    /**
     */
    public void setLayoutId(Integer layoutId) {
        this.layoutId = layoutId;
    }

    /**
     */
    public Integer getLayoutId() {
        return this.layoutId;
    }

    /**
     */
    public ReferenceGene() {
    }

    /**
     * Copies the contents of the specified bean into this bean.
     *
     */
    public void copy(ReferenceGene that) {
        setId(that.getId());
        setGeneName(that.getGeneName());
        setExperimentId(that.getExperimentId());
        setLayoutId(that.getLayoutId());
    }

    /**
     * Returns a textual representation of a bean.
     *
     */
    public String toString() {

        StringBuilder buffer = new StringBuilder();

        buffer.append("id=[").append(id).append("] ");
        buffer.append("geneName=[").append(geneName).append("] ");
        buffer.append("experimentId=[").append(experimentId).append("] ");
        buffer.append("layoutId=[").append(layoutId).append("] ");

        return buffer.toString();
    }

    /**
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (int) (prime * result + ((id == null) ? 0 : id.hashCode()));
        return result;
    }

    /**
     */
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ReferenceGene)) {
            return false;
        }
        ReferenceGene equalCheck = (ReferenceGene) obj;
        if ((id == null && equalCheck.id != null) || (id != null && equalCheck.id == null)) {
            return false;
        }
        if (id != null && !id.equals(equalCheck.id)) {
            return false;
        }
        return true;
    }
}
