package wren.domain;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import wren.domain.jsonObject.Gene;
import wren.domain.jsonObject.Group;
import wren.domain.jsonObject.ProjectObject;
import wren.service.Calculator;
import wren.service.WorkBookGenerator;
import wren.service.WorkSheetGenerator;

/**
 *
 * @author tanq
 * @author ningj 2/28/2013, removed warnings
 */
public class ResultObj {

    protected static final Logger logger = Logger.getLogger("ResultObj");
    ProjectObject projectObj;
    DecimalFormat df = new DecimalFormat("#.#####");
    DecimalFormat tableDf = new DecimalFormat("#.##");
    DecimalFormat chartDf = new DecimalFormat("#.#");
    StringBuffer msg = new StringBuffer();
    Map<Integer, Map<Integer, ResultValue>> geneMap;
    Map<Integer, String> geneIdMap = new HashMap<Integer, String>();
    Map<Integer, String> groupIdMap = new HashMap<Integer, String>();
    private String COEFF_WARNING_COLOR = "red";
    private static final int EACH_COLUMN_WIDTH = 80;
    static private int MAX_GROUP_CHART = 1;
    static private int MAX_GROUP_NUMBER = 8;//table
    static private int MAX_GROUP_LABEL = 1;//google chart, if >MAX_GROUP_LABEL, use extract label
    private int MAX_GOOGLE_CHART_LENGTH = 1;//1900; all use folder
    private int UI_WIDTH_MAX = 880;
    private int UI_WIDTH_MIN = 500;
    private int UI_HEIGHT1 = 200;
    private int UI_HEIGHT2 = 300;
    public static String reCalculateStr = "<a href=\"javascript:reCalculate()\"><b>Re-Calculate</b></a>";
    public static String excludeStr = "title=\"click to exclude\" alt=\"click to exclude\"";
    public static String excludeStrEditable = "*Blue color indicates user can click on it and exclude the cell from calculation<br>";
    public static String excludeStrReadonly = "*Blue color indicates sample value is out of Coeff. Of Variation<br>";
    public static String downloadHTMLStr = " &nbsp;<a href='service/downloadHTML'><img src='images/download.png' border='0' width='20px'align='bottom' alt='download' title='download'></a> \n";
    public static String copyImageStr = "img src='images/copy.png' style='display:inline' ";
    public static String copyImageDisabledStr = "img src='images/copy.png' style='display:none' ";
    public static String overflowDivStr = "' style='display:none;overflow:auto;width:880px'>";
    public static String overflowDivDisabledStr = "' style='display:none;'>";
    public static String overflowDivStr2 = "overflow:auto;width:880px";
    public static String footnote1 = "a. Values in red are outside 95% confidence interval<br>";
    public static String footnote2 = "b. In chart, grey bars indicate group means; dots indicate individual values; error bars represent 95% confidence intervals<br>";
    public static String footnote3 = "c. Y axis is fold change relative to control group<br>";
    public static String footnote2b = "a. In chart, grey bars indicate group means; dots indicate individual values; error bars represent 95% confidence intervals<br>";
    public static String footnote3b = "b. Y axis is fold change relative to control group<br>";
    private List<String> postGoogleChartNameList = new ArrayList<String>();

    public ResultObj(ProjectObject projectObj) {
        this.projectObj = projectObj;
    }

    private String getAllAvgCtTable(Map<String, String> avgCTMap, List<Integer> allGeneIDs) {
        boolean valueOutOfBound = false;
        StringBuilder output = new StringBuilder();
        final String exclusionJS = "<a href=\"javascript:void()\" " + excludeStr + " onClick=\"javascript:addExclusion(this,'LOCATION','MSG')\">INPUTVALUE</a>";
        int count = 0;
        String uniqueID = null;
        for (int thisGeneID : allGeneIDs) {
            Map<Integer, ResultValue> myGroupMap = geneMap.get(thisGeneID);
            Set<Map.Entry<Integer, ResultValue>> groupSet = myGroupMap.entrySet();
            int i = 0;
            String geneName;// = null;
            for (Map.Entry<Integer, ResultValue> myResult : groupSet) {
                ResultValue resultValue = myResult.getValue();
                if (i == 0) {
                    geneName = this.geneIdMap.get(thisGeneID);
                    if (geneName == null) {
                        continue;
                    }
                    output.setLength(0);
                    uniqueID = "gene_" + count + "_avgCT";
                    output.append("<div id='").append(uniqueID).
                            append(overflowDivStr).append(reCalculateStr).
                            append("<table><tr valign='top'><th colspan='2' align='left' valign='top'>Gene:").
                            append(geneName).append("</th></tr>\n");
                    //good, no extrac line, the width:880px cause the extract line; but pure html do not has extract line
//                    output.append("<div id='"+uniqueID+"' style='display:none;'>"+reCalculateStr+
//                    		"<table><tr valign='top'><th colspan='2' align='left' valign='top'>xxxxGene:"
//                    		+ geneName + "</th></tr>\n");
                    count++;
                }
                double[][] inputValues = resultValue.getInputValues();
                String[][] inputValueCooridnates = resultValue.getInputValuesCooridnates();
                double[] avgCts = resultValue.getAvgCts();
                double[] stdDev = resultValue.getStdDev();
                double[] coeffVar = resultValue.getCoeffVar();
                //DEBUG

//               for (int vv=0; vv<inputValues.length; vv++){
//            	   for (int jj=0; jj<inputValues[vv].length; jj++){
//            		   System.out.println("inputValues["+vv+"]["+jj+"]="+inputValues[vv][jj]);
//            	   }
//               }

                //  double[] dctValues = resultValue.getDctValues();
                // double[] ddctValues = resultValue.getDdctValues();
//                if (dctValues!=null && ddctValues!=null){
//	                for (int vv=0; vv<dctValues.length; vv++){
//	                	System.out.println(dctValues[vv]+"\t"+ddctValues[vv]);
//
//	                }
//                }
//                //DEBUG
//            if (!resultValue.group.getName().equals("SAL")){
//                continue;
//            }

                output.append("<tr valign='top'><th align='left' colspan='").
                        append(inputValues[0].length + 1).append("'>").
                        append(resultValue.group.getName()).append("</th></tr>");

                for (int r = 0; r < inputValues.length; r++) {
                    output.append("<tr valign='top'><td width='200'>replicate ").
                            append(r + 1).append("</td>");
                    for (int c = 0; c < inputValues[r].length; c++) {
                        if (inputValues[r][c] == 0) {
                            output.append("<td>&nbsp;</td>");
                        } else {
                            if (coeffVar[c] > this.projectObj.getCoVarianceValue()) {
                                String js = exclusionJS;
                                try {
                                    js = exclusionJS.replace("LOCATION", inputValueCooridnates[r][c]).replaceAll("INPUTVALUE", df.format(inputValues[r][c]));
                                } catch (Exception ex) {
                                }
                                if ((js != null && js.contains("INPUTVALUE")) || (inputValues[r][c] == -1)) {
                                    output.append("<td>").
                                            append(df.format(inputValues[r][c])).
                                            append("</td>");
                                } else {
                                    valueOutOfBound = true;
                                    //String msg = "Excluded: " + geneName + " " + resultValue.group.getName() + " replicate " + (r + 1);
                                    String message = df.format(inputValues[r][c]);
                                    js = js.replace("MSG", message);
                                    //System.out.println("JS: "+js);
                                    output.append("<td><font color='").
                                            append(COEFF_WARNING_COLOR).
                                            append("'>").append(js).
                                            append("</font></td>");
                                }

                            } else {
                                output.append("<td>").
                                        append(df.format(inputValues[r][c])).
                                        append("</td>");
                            }
                        }
                    }
                    output.append("</tr'>");
                }
                output.append("<tr valign='top'><td width='50'>Std.Dev.</td>");
                for (int r = 0; r < stdDev.length; r++) {
                    output.append("<td>").append(df.format(stdDev[r])).
                            append("</td>");
                }
                output.append("</tr'>");
                output.append("<tr valign='top'><td width='50'>Mean</td>");
                for (int r = 0; r < avgCts.length; r++) {
                    output.append("<td>").append(df.format(avgCts[r])).
                            append("</td>");
                }
                output.append("</tr'>");
                output.append("<tr valign='top'><td width='50'>Coeff. Of Variation</td>");
                for (int r = 0; r < coeffVar.length; r++) {
                    if (coeffVar[r] > this.projectObj.getCoVarianceValue()) {
                        valueOutOfBound = true;
                        output.append("<td><font color='").
                                append(COEFF_WARNING_COLOR).append("'>").
                                append(df.format(coeffVar[r])).
                                append("</font></td>");
                    } else {
                        if (coeffVar[r] > 0) {
                            output.append("<td>").append(df.format(coeffVar[r])).
                                    append("</td>");
                        } else {
                            output.append("<td>").append(coeffVar[r]).
                                    append("</td>");//NaN
                        }

                    }

                }
                output.append("</tr'>\n");
                i++;
            }
            output.append("</table></div>");
            avgCTMap.put(uniqueID, output.toString());
        }
        if (valueOutOfBound) {
            output.append("<br>*Red color indicates certain group contains sample value out of Coeff. Of Variation<br>");
            output.append(excludeStrEditable);
        }
        //output.append("</div>");

        return output.toString();
    }

    public String getAllTables() {
        StringBuilder tables = new StringBuilder();
        List<String> allGeneNames = new ArrayList<String>(10);
        List<Integer> allGeneIDs = new ArrayList<Integer>(10);

        //tables.append("<table align='left'><tr><td align='left'>"+getOutputHeader(allGeneNames, allGeneIDs)+"</td></tr></table>");
        tables.append("<div align='left'>").
                append(getOutputHeader(allGeneNames, allGeneIDs)).append("</div>");
        Map<String, String> geneFoldChangeMap = new HashMap<String, String>();
        Map<String, String> dctMap = new HashMap<String, String>();
        Map<String, String> avgCTMap = new HashMap<String, String>();

        try {
            getAllDataTableOfFoldChangeTable(geneFoldChangeMap, allGeneIDs);
        } catch (Exception ex) {
            //ex.printStackTrace();
            logger.log(Level.WARNING, ex.getMessage());
        }
        try {
            getAllDctTable(dctMap, allGeneIDs);
        } catch (Exception ex) {
            //ex.printStackTrace();
            logger.log(Level.WARNING, ex.getMessage());
        }
        try {
            getAllAvgCtTable(avgCTMap, allGeneIDs);
        } catch (Exception ex) {
            //ex.printStackTrace();
            logger.log(Level.WARNING, ex.getMessage());
        }

        //logger.warning("geneFoldChangeMap size="+avgCTMap.size());

        //tables.append(webFoldChangeStr);
        int i = 0;
        for (String geneName : allGeneNames) {
            String foldChangeTable = geneFoldChangeMap.get("gene_" + i + "_fc");
            String dctTable = dctMap.get("gene_" + i + "_dct");
//			String foldChangeTable = "<div id='gene_"+i+"_fc'  style='display:block'>No Fold Change Report for "+geneName+" </div>";
//			String dctTable = "<div id='gene_"+i+"_dct'  style='display:none'>No 1/dct Report for "+geneName+" </div>";
            String avgCTTable = avgCTMap.get("gene_" + i + "_avgCT");

            if (i == 0) {
                tables.append("<table align='left' id='gene").append(i).
                        append("' style='display:block'><tr><td align='left'>");
            } else {
                //tables.append("<div align='left' id='gene"+i+"' style='display:none'>");
                tables.append("<table align='left' id='gene").append(i).
                        append("' style='display:none'><tr><td align='left'>");
            }
            if (foldChangeTable == null) {//reference gene, only show Average CT Value
                tables.append("<form><select id='outputType_").append(i).
                        append("'>\n<option>Average CT Value</option>\n</select></form>\n");
                avgCTTable = avgCTTable.replaceFirst("style='display:none", "style='display:block");
                tables.append(avgCTTable);
            } else {
                //use gene name here since getAllDataTableOfFoldChangeTable may has differenct order on Set
                if (i == 0) {
//					tables.append("<form><select id='outputType_"+i+"' onChange='hideshow(this, \"gene_"+i+"\")'>\n<option>Average CT Value</option>\n<option>Fold Change</option>\n<option>1/dct</option>\n</select></form>\n");
//					avgCTTable = avgCTTable.replaceFirst("style='display:none","style='display:block");
//					tables.append(avgCTTable);
//					foldChangeTable = foldChangeTable.replaceFirst("style='display:block","style='display:none");
//					tables.append(foldChangeTable);
//					tables.append(dctTable);

                    tables.append("<form><select id='outputType_").append(i).
                            append("' onChange='hideshow(this, \"gene_").append(i).
                            append("\")'>\n<option>Fold Change</option>\n<option>1/dct</option>\n<option>Average CT Value</option>\n</select></form>\n");
                    tables.append(foldChangeTable);
                    tables.append(dctTable);
                    tables.append(avgCTTable);

                } else {
                    tables.append("<form><select id='outputType_").append(i).
                            append("' onChange='hideshow(this, \"gene_").append(i).
                            append("\")'>\n<option>Fold Change</option>\n<option>1/dct</option>\n<option>Average CT Value</option>\n</select></form>\n");
                    tables.append(foldChangeTable);
                    tables.append(dctTable);
                    tables.append(avgCTTable);
                }


            }




            tables.append("</td></tr></table>\n\n");
            i++;
        }
        //tables.append(webDctStr);
        //tables.append(webAvgCtStr);
        return tables.toString();
    }

    private String getOutputHeader(List<String> allGeneNames, List<Integer> allGeneIDs) {
        StringBuilder header = new StringBuilder();

        Set<Map.Entry<Integer, Map<Integer, ResultValue>>> geneSet = geneMap.entrySet();
        String geneName;// = null;
        int i = 0;
        final String totalTabNumber = "TOTAL_TAB_NUMBER";
        /*
         for (Map.Entry<Integer, Map<Integer, ResultValue>> myGeneMap : geneSet) {
         Map<Integer, ResultValue> myGroupMap = myGeneMap.getValue();
         Set<Map.Entry<Integer, ResultValue>> groupSet = myGroupMap.entrySet();
         for (Map.Entry<Integer, ResultValue> myResult : groupSet) {
         ResultValue resultValue = myResult.getValue();
         if (resultValue.gene.getType() == 1) {//Target gene
         if (i == 0) {
         //count++;
         geneName = this.geneIdMap.get(myGeneMap.getKey());
         if (geneName != null) {
         allGeneNames.add(geneName);
         header.append("<a href='javascript:void(0)' onClick='showTab("+i+", "+totalTabNumber+");'>"+geneName+"</a>");
         header.append("&gt;&nbsp;");
         i++;
         }
         }
         }
         }
         }
         */
        for (Map.Entry<Integer, Map<Integer, ResultValue>> myGeneMap : geneSet) {
            Integer id = myGeneMap.getKey();
            geneName = this.geneIdMap.get(id);
            if (geneName != null) {
                allGeneIDs.add(id);
                allGeneNames.add(geneName);
                if (i > 0) {
                    header.append(" | ");
                    header.append("<a href='javascript:void(0)' style='color:#808080;' id='Gene").append(i).
                            append("' onClick='showTab(this,").append(i).
                            append(", " + totalTabNumber + ");'><b>").
                            append(geneName).append("</b></a>");
                } else {
                    header.append("<a href='javascript:void(0)'  style='color:blue;' id='Gene").append(i).
                            append("' onClick='showTab(this,").append(i).
                            append(", " + totalTabNumber + ");'><b>").
                            append(geneName).append("</b></a>");
                }

                i++;
            }
        }
        header.append(downloadHTMLStr);
        header.append("\n");
        return header.toString().replace(totalTabNumber, "" + i);
    }

    private String getAllDataTableOfFoldChangeTable(Map<String, String> geneFoldChangeMap, List<Integer> allGeneIDs) {
        boolean valueOutOfBound = false;
        StringBuilder output = new StringBuilder();
        int NumberOfGroups = 0;
        int maxNumberOfRows = 0;
        int transientRowNumber = 30;
        int count = 0;
        for (int thisGeneID : allGeneIDs) {
            Map<Integer, ResultValue> myGroupMap = geneMap.get(thisGeneID);
            Set<Map.Entry<Integer, ResultValue>> groupSet = myGroupMap.entrySet();
            NumberOfGroups = groupSet.size();
            int i = 0;
            double[][] foldChangeTempArray = new double[transientRowNumber][NumberOfGroups];
            double[][] groupOrientedfoldChangeArray = new double[NumberOfGroups][];
            int groupIndex = 0;
            String[] groupNameArray = new String[NumberOfGroups];
            boolean targetGene = false;
            String geneName = null;
            int maxGroupOrientedfoldChangeArrayColumn = 0;
            String copyTextID = "FOLDCHANGETABLE";
            for (Map.Entry<Integer, ResultValue> myResult : groupSet) {
                ResultValue resultValue = myResult.getValue();
                if (resultValue.gene.getType() != 1) {//NOT Target gene
                    if (i == 0) {
                        targetGene = false;
                        copyTextID = "gene_" + count + "_fc";
                        output.setLength(0);
                        if (count == 0) {
                            output.append("<div id='").append(copyTextID).append("'>");
                        } else {
                            output.append("<div id='").append(copyTextID).
                                    append(overflowDivStr);
                        }
                        geneName = this.geneIdMap.get(thisGeneID);
                        output.append("NO Fold Change Report Available for Non-Target Gene: ").
                                append(geneName).append("</div>");
                        //geneFoldChangeMap.put(copyTextID, output.toString());
                        geneFoldChangeMap.put(copyTextID, null);
                        count++;
                    }
                } else if (resultValue.gene.getType() == 1) {//Target gene
                    targetGene = true;
                    if (i == 0) {
                        geneName = this.geneIdMap.get(thisGeneID);
                        if (geneName != null) {
                            output.setLength(0);
                            copyTextID = "gene_" + count + "_fc";
                            if (count == 0) {
                                output.append("<div id='").append(copyTextID).
                                        append("'>");
                            } else {
                                output.append("<div id='").append(copyTextID).
                                        append(overflowDivStr);
                            }
                            String copyJS;// = null;
                            //if the first gene is target gene, the copy button is not glued; copy button is glued on hideshow();
                            if (count == 0) {
                                copyJS = "&nbsp;<img src='images/copy.png' style='display:inline' border='0' width='15px' id='" + copyTextID + "_img' onmouseover=\"toClipboardMouseOver('gene_" + count + "');\"></img>&nbsp;<font size=-2><label id='"
                                        + copyTextID + "_textarea_copied' style='display:none'>copied</label></font>";
                            } else {
                                copyJS = "&nbsp;<img src='images/copy.png' style='display:inline' border='0' width='15px' id='" + copyTextID + "_img'></img>&nbsp;<font size=-2><label id='"
                                        + copyTextID + "_textarea_copied' style='display:none'>copied</label></font>";
                            }
                            output.append("<table><tr valign='top'><th colspan='2' align='left' valign='top' nowrap='true'>Gene:").
                                    append(geneName).append(copyJS).
                                    append("</th></tr>\n");
                            count++;
                        } else {
                            targetGene = false;
                        }


                    }
                    if (geneName == null) {//target gene from other worksheet
                        targetGene = false;
                    }
                    double[] foldChanges = resultValue.getLogDdctValues();
//                    System.out.println("GGENE: "+resultValue.gene.getName()+"  GROUP: "+resultValue.group.getName()+"\t");
//                    for (double dd: foldChanges){
//                    	System.out.print(dd+"\t");
//                    }
//                    System.out.println("\n");
                    if (foldChanges != null && foldChanges.length > maxGroupOrientedfoldChangeArrayColumn) {
                        maxGroupOrientedfoldChangeArrayColumn = foldChanges.length;
                    }
                    groupOrientedfoldChangeArray[groupIndex] = foldChanges;
                    groupIndex++;
                    if (foldChanges != null && maxNumberOfRows < foldChanges.length) {
                        maxNumberOfRows = foldChanges.length;
                    }
                    //output.append("Group:" + resultValue.group.getName() + "\t");
                    groupNameArray[i] = resultValue.group.getName();
//                    logger.warning("GENE: "+resultValue.gene.getName()+" GROUP:"+groupNameArray[i]+":\t");
//                    for (double dd: foldChanges){
//                    	logger.warning("\t"+dd);
//                    }
                    int colIndex = 0;
                    if (foldChanges != null) {
                        for (double foldChange : foldChanges) {
                            //output.append(foldChange + " ");
                            foldChangeTempArray[colIndex][i] = foldChange;
                            colIndex++;
                        }
                    }
                    //output.append("\n");
                } else {
                    break;
                }
                i++;
            }

            if (targetGene) {
                double[][] confidenceIntervalArray = Calculator.getConfidenceInterval(groupOrientedfoldChangeArray);
                double[][] foldChangeArray = new double[maxNumberOfRows][groupNameArray.length];

                for (int gg = 0; gg < groupNameArray.length; gg += MAX_GROUP_NUMBER) {
                    output.append("<tr><td valign='top'><table border='0' cellspacing='5'><tr>");
                    //print group name header
                    int max = gg + MAX_GROUP_NUMBER;
                    if (max > groupNameArray.length) {
                        max = groupNameArray.length;
                    }
                    for (int c = gg; c < max; c++) {
                        output.append("<th>").append(groupNameArray[c]).
                                append("</th>");
                    }
                    output.append("</tr>\n");
                    //print data
                    for (int r = 0; r < foldChangeArray.length; r++) {
                        output.append("<tr>\n");
                        for (int c = gg; c < max; c++) {
                            foldChangeArray[r][c] = foldChangeTempArray[r][c];
                            if (foldChangeArray[r][c] == 0) {
                                output.append("<td>&nbsp;</td>");
                            } else {
                                if (foldChangeArray[r][c] >= confidenceIntervalArray[c][0] && foldChangeArray[r][c] <= confidenceIntervalArray[c][1]) {
                                    output.append("<td>").
                                            append(df.format(foldChangeArray[r][c])).
                                            append("</td>");
                                } else {
                                    output.append("<td><font color='").
                                            append(COEFF_WARNING_COLOR).append("'>").
                                            append(df.format(foldChangeArray[r][c])).
                                            append("</font></td>");
                                    valueOutOfBound = true;
                                }

                            }
                        }
                        output.append("</tr>\n");
                    }
                    //statitics line
                    //user request to remove
//                    output.append("<tr>");
//                    for (int c = gg; c < max; c++) {
//                        output.append("<td>" + tableDf.format(confidenceIntervalArray[c][0]) + "</td>");
//                    }
//                    output.append("</tr>\n");
//                    output.append("<tr>");
//                    for (int c = gg; c < max; c++) {
//                        output.append("<td>" + tableDf.format(confidenceIntervalArray[c][1]) + "</td>");
//                    }
//                    output.append("</tr>\n");
                    //end of statictis
                    output.append("</table></td>\n");



                }
                //logger.warning(geneName+"\n"+foldChangeGeneTable.toString());
                String imageURL = getPostChartURL(geneName, groupNameArray, foldChangeArray, groupOrientedfoldChangeArray, maxGroupOrientedfoldChangeArrayColumn,
                        confidenceIntervalArray).toString();

                output.append("</tr>\n");
                output.append("<tr><td>");
                if (imageURL.indexOf("<iframe") == -1) {//short google chart url
                    output.append("<img src='").append(imageURL).
                            append("' border='0'><br>");
                } else {
                    output.append(imageURL);
                }
                output.append("</td>\n");
                output.append("</tr>\n");
                output.append("<tr><td colspan='2'>&nbsp;</td></tr>\n");
                output.append("\n");
                output.append("</table>\n");
                StringBuilder foldChangeGeneTable = this.getFoldChangeGeneTable(groupNameArray, foldChangeArray);
                output.append("<textarea style=\"display:none;\" id='").
                        append(copyTextID).append("_textarea' >").
                        append(foldChangeGeneTable.toString()).
                        append("</textarea>");
                output.append("\n");

                output.append("<font size='-2' color='gray'>");
                if (valueOutOfBound) {
                    output.append("<br>").append(footnote1);
                    output.append(footnote2);
                    output.append(footnote3);
                } else {
                    output.append("<br>").append(footnote2b);
                    output.append(footnote3b);
                }
                output.append("</font>");

//                output.append("*Chart:<ul>black lines indicate confidence intervals</ul>");
//                output.append("<ul>grey bars indicate mean of sample values</ul>");
//                output.append("<ul>blue dots indicate sample values</ul>");
                output.append("</div>");


                geneFoldChangeMap.put(copyTextID, output.toString());
                //end of one gene


                //gger.warning(foldChangeGeneTable.toString());
            }

//            output.append("<tr><td colspan='2'>&nbsp;</td></tr>\n");
//            output.append("\n");
        }

        // output.append("</table>");
//        if (valueOutOfBound){
//        	output.append("<br>*Red color indicates sample value is out of confidence interval<br>");
//        }
//        output.append("*Chart:<ul>black lines indicate confidence intervals</ul>");
//        output.append("<ul>grey bars indicate mean of sample values</ul>");
//        output.append("<ul>blue dots indicate sample values</ul>");
//        output.append("</div>");

        // logger.warning("FC total map geneFoldChangeMap "+geneFoldChangeMap.size());
        return output.toString();
    }

    private String getAllDctTable(Map<String, String> dctMap, List<Integer> allGeneIDs) {
        boolean valueOutOfBound = false;
        //TODO:: may need to reorganize this code
        //the extract <br> is needed, otherwise the copy clipboard will copy fold change instead of dctTable
        //may change to http://beckelman.net/2009/01/22/copy-to-clipboard-with-zeroclipboard-flash-10-and-jquery/
        StringBuilder output = new StringBuilder("<div align='left' style='display:none' id='dctTable'><br><table>\n");
        int NumberOfGroups = 0;
        int maxNumberOfRows = 0;
        int transientRowNumber = 30;
        //Set<Map.Entry<Integer, Map<Integer, ResultValue>>> geneSet = geneMap.entrySet();

        int count = 0;
        for (int thisGeneID : allGeneIDs) {
            Map<Integer, ResultValue> myGroupMap = geneMap.get(thisGeneID);
            Set<Map.Entry<Integer, ResultValue>> groupSet = myGroupMap.entrySet();
            NumberOfGroups = groupSet.size();
            int i = 0;
            double[][] foldChangeTempArray = new double[transientRowNumber][NumberOfGroups];
            double[][] groupOrientedfoldChangeArray = new double[NumberOfGroups][];
            int groupIndex = 0;
            String[] groupNameArray = new String[NumberOfGroups];
            boolean targetGene = false;
            String geneName = null;
            int maxGroupOrientedfoldChangeArrayColumn = 0;
            String copyTextID = "DCTTABLE";
            for (Map.Entry<Integer, ResultValue> myResult : groupSet) {
                ResultValue resultValue = myResult.getValue();
                if (resultValue.gene.getType() != 1) {//NOT Target gene
                    if (i == 0) {
                        targetGene = false;
                        copyTextID = "gene_" + count + "_dct";
                        output.setLength(0);
                        output.append("<div id='").append(copyTextID).
                                append(overflowDivStr);
                        geneName = this.geneIdMap.get(thisGeneID);
                        output.append("NO 1/dct Report Available for Non-Target Gene: ").
                                append(geneName).append("</div>");
                        //dctMap.put(copyTextID, output.toString());
                        dctMap.put(copyTextID, null);
                        count++;
                    }
                } else if (resultValue.gene.getType() == 1) {//Target gene
                    targetGene = true;
                    if (i == 0) {
                        geneName = this.geneIdMap.get(thisGeneID);
                        if (geneName != null) {
                            output.setLength(0);
                            copyTextID = "gene_" + count + "_dct";
                            output.append("<div id='").append(copyTextID).
                                    append(overflowDivStr);
                            String copyJS = "&nbsp;<img src='images/copy.png' style='display:inline' border='0' width='15px' id='" + copyTextID + "_img'></img>&nbsp;<font size=-2><label id='" + copyTextID
                                    + "_textarea_copied' style='display:none;'>copied</label></font>";
                            output.append("<table><tr valign='top'><th colspan='2' align='left' valign='top' nowrap='true'>Gene: ").
                                    append(geneName).append(copyJS).append("</th></tr>\n");
                            count++;
                        } else {
                            targetGene = false;//target gene from other worksheet
                        }

                    }
                    if (geneName == null) {//target gene from other worksheet
                        targetGene = false;
                    }
                    double[] foldChanges = resultValue.getOverDctValues();
                    if (foldChanges != null && foldChanges.length > maxGroupOrientedfoldChangeArrayColumn) {
                        maxGroupOrientedfoldChangeArrayColumn = foldChanges.length;
                    }
                    groupOrientedfoldChangeArray[groupIndex] = foldChanges;
                    groupIndex++;
                    if (foldChanges != null && maxNumberOfRows < foldChanges.length) {
                        maxNumberOfRows = foldChanges.length;
                    }
                    //output.append("Group:" + resultValue.group.getName() + "\t");
                    groupNameArray[i] = resultValue.group.getName();

                    int colIndex = 0;
                    for (double foldChange : foldChanges) {
                        //output.append(foldChange + " ");
                        foldChangeTempArray[colIndex][i] = foldChange;
                        colIndex++;
                    }
                    //output.append("\n");
                } else {
                    break;
                }
                i++;
            }

            if (targetGene) {
                //System.out.println("############################# "+geneName+" ############################");
                double[][] confidenceIntervalArray = Calculator.getConfidenceInterval(groupOrientedfoldChangeArray);
                double[][] foldChangeArray = new double[maxNumberOfRows][groupNameArray.length];
//
//                for (int ii=0; ii<groupOrientedfoldChangeArray.length; ii++){
//                	for (int jj=0; jj<groupOrientedfoldChangeArray[ii].length; jj++){
//                		System.out.println(" groupOrientedfoldChangeArray["+ii+"]["+jj+"]"+groupOrientedfoldChangeArray[ii][jj]+"\t");
//                	}
//                	System.out.println();
//                }
//
//                for (int ii=0; ii<confidenceIntervalArray.length; ii++){
//                	for (int jj=0; jj<confidenceIntervalArray[ii].length; jj++){
//                		System.out.println("confidenceIntervalArray["+ii+"]["+jj+"]"+confidenceIntervalArray[ii][jj]+"\t");
//                	}
//                	System.out.println();
//                }
                for (int gg = 0; gg < groupNameArray.length; gg += MAX_GROUP_NUMBER) {
                    output.append("<tr><td valign='top'><table border='0' cellspacing='5'><tr>");
                    //print group name header
                    int max = gg + MAX_GROUP_NUMBER;
                    if (max > groupNameArray.length) {
                        max = groupNameArray.length;
                    }
                    for (int c = gg; c < max; c++) {
                        output.append("<th>").append(groupNameArray[c]).
                                append("</th>");
                    }
                    output.append("</tr>\n");
                    //print data
                    for (int r = 0; r < foldChangeArray.length; r++) {
                        output.append("<tr>\n");
                        for (int c = gg; c < max; c++) {
                            foldChangeArray[r][c] = foldChangeTempArray[r][c];
                            if (foldChangeArray[r][c] == 0) {
                                output.append("<td>&nbsp;</td>");
                            } else {
                                if (foldChangeArray[r][c] >= confidenceIntervalArray[c][0] && foldChangeArray[r][c] <= confidenceIntervalArray[c][1]) {
                                    output.append("<td>").
                                            append(df.format(foldChangeArray[r][c])).
                                            append("</td>");
                                } else {
                                    output.append("<td><font color='").
                                            append(COEFF_WARNING_COLOR).
                                            append("'>").
                                            append(df.format(foldChangeArray[r][c])).
                                            append("</font></td>");
                                    valueOutOfBound = true;
                                }

                            }
                        }
                        output.append("</tr>\n");
                    }


                    //statitics line
                    //user request to remove
//                    output.append("<tr>");
//                    for (int c = gg; c < max; c++) {
//                        output.append("<td>" +c+"==>"+ tableDf.format(confidenceIntervalArray[c][0]) + "</td>");
//                    }
//                    output.append("</tr>\n");
//                    output.append("<tr>");
//                    for (int c = gg; c < max; c++) {
//                        output.append("<td>" +c+"==>"+ tableDf.format(confidenceIntervalArray[c][1]) + "</td>");
//                    }
//                    output.append("</tr>\n");
                    //end of statictis

                    output.append("</table></td>\n");

                }
                //logger.warning(geneName+"\n"+foldChangeGeneTable.toString());
                String imageURL = getPostChartURL(geneName, groupNameArray, foldChangeArray, groupOrientedfoldChangeArray, maxGroupOrientedfoldChangeArrayColumn,
                        confidenceIntervalArray).toString();
                output.append("</tr>\n");
                output.append("<tr><td>");
                if (imageURL.indexOf("<iframe") == -1) {//short google chart url
                    output.append("<img src='").append(imageURL).
                            append("' border='0'><br>");
                } else {
                    output.append(imageURL);
                }
                output.append("</td>\n");
                output.append("</tr>\n");


                output.append("<tr><td colspan='2'>&nbsp;</td></tr>\n");
                output.append("\n");
                output.append("</table>");
                StringBuilder foldChangeGeneTable = this.getFoldChangeGeneTable(groupNameArray, foldChangeArray);
                output.append("<textarea style=\"display:none;\" id='").
                        append(copyTextID).append("_textarea' >").
                        append(foldChangeGeneTable.toString()).
                        append("</textarea>");
                output.append("\n");
                output.append("<font size='-2' color='gray'>");
                if (valueOutOfBound) {
                    output.append("<br>").append(footnote1);
                    output.append(footnote2);
                    output.append(footnote3);
                } else {
                    output.append("<br>").append(footnote2b);
                    output.append(footnote3b);
                }
                output.append("</font>");
//                if (valueOutOfBound){
//                	output.append("<br>*Red color indicates sample value is out of confidence interval<br>");
//                }
//                output.append("*Chart:<ul>black lines indicate confidence intervals</ul>");
//                output.append("<ul>grey bars indicate mean of sample values</ul>");
//                output.append("<ul>blue dots indicate sample values</ul>");
                output.append("</div>");
                dctMap.put(copyTextID, output.toString());
            }
        }

        output.append("</table>");
//        if (valueOutOfBound){
//        	output.append("<br>*Red color indicates sample value is out of confidence interval<br>");
//        }
//        output.append("*Chart:<ul>black lines indicate confidence intervals</ul>");
//        output.append("<ul>grey bars indicate mean of sample values</ul>");
//        output.append("<ul>blue dots indicate sample values</ul>");
//        output.append("</div>");
        return output.toString();
    }

    private StringBuilder getFoldChangeGeneTable(final String[] groupNameArray,
            final double[][] foldChangeArray) {
        StringBuilder foldChangeGeneTable = new StringBuilder();
        for (int c = 0; c < groupNameArray.length; c++) {
            foldChangeGeneTable.append(groupNameArray[c]).append("\t");
        }
        foldChangeGeneTable.append("\n");
        for (int r = 0; r < foldChangeArray.length; r++) {
            for (int c = 0; c < groupNameArray.length; c++) {
                if (foldChangeArray[r][c] == 0) {
                    foldChangeGeneTable.append("\t");
                } else {
                    foldChangeGeneTable.append(foldChangeArray[r][c]).append("\t");

                }
            }
            foldChangeGeneTable.append("\n");// not break into multiple tables
        }
        return foldChangeGeneTable;
    }
    /*
     * return html format of foldChange table
     */
    //input, gene name (only if target gene)

    public StringBuffer getDataTableOfFoldChangeTable(String geneID) {
        return null;
    }

    /*
     * 1. base on fold change table, calculate confidence interval
     * 2. generate google chart parameters
     */
    //input: gene name (only if target gene)
    public StringBuilder getPostChartURL(String geneName, String[] groupNameArray, double[][] foldChangeArray, double[][] groupOrientedFoldChangeArray,
            int maxGroupOrientedfoldChangeArrayColumn, double[][] confidenceIntervalArray) {
        String uid = UUID.randomUUID().toString();
        //only System.currentTimeMillis() is not good enough
        String fileNameNoPath = "post_googleChart_" + System.currentTimeMillis() + "_" + uid + ".html";
        String fileName = "tmp/" + fileNameNoPath;
        StringBuilder iframeOutput = new StringBuilder();
        StringBuilder chartURL = getChartURL(geneName, groupNameArray, foldChangeArray, groupOrientedFoldChangeArray, maxGroupOrientedfoldChangeArrayColumn,
                confidenceIntervalArray, iframeOutput, fileName);

        if (chartURL != null && chartURL.length() < MAX_GOOGLE_CHART_LENGTH) {
            //logger.warning("short google chart "+chartURL.length());
            iframeOutput.setLength(0);
            iframeOutput.append(chartURL);
        } else {
            // logger.warning("LONG google chart "+chartURL.length());
            postGoogleChartNameList.add(fileNameNoPath);
            //create form
            StringBuilder formSB = new StringBuilder();
            fillFormHeader(formSB);

            if (chartURL != null) {
                int index = chartURL.indexOf("?");
                String chartURLString = chartURL.substring(index + 1);
                String[] parameterNameValues = chartURLString.split("&");
                if (parameterNameValues != null) {
                    for (String parameterNameValue : parameterNameValues) {
                        if (parameterNameValue != null) {
                            String[] nameValueArr = parameterNameValue.split("=");
                            if (nameValueArr != null && nameValueArr.length == 2) {
                                if (nameValueArr[1].indexOf("%3D") != -1) {
                                    nameValueArr[1] = nameValueArr[1].replace("%3D", "=");
                                }
                                formSB.append("      <input type='hidden' name='").
                                        append(nameValueArr[0]).append("' value='").
                                        append(nameValueArr[1]).append("'/>\n");

                            }
                        }
                    }
                }
            }
            //System.out.println("XXX FORM\n"+formSB.toString());
            fillFormFooter(formSB);
            //write to file
            String webDir = WorkBookGenerator.webDir;
            String webFileName = webDir + fileName;
            if (System.getProperty("user.dir").startsWith("/Users/")) {//if runs standalone for debug
                webFileName = fileName;
            }

            WorkSheetGenerator.writeToFile(webFileName, formSB.toString());
            //return iframe to add to the webout page
            if (System.getProperty("user.dir").startsWith("/Users/")) {//if runs standalone for debug
                String output = iframeOutput.toString().replace("tmp/", "");
                iframeOutput.setLength(0);
                iframeOutput.append(output);
            }
        }

        return iframeOutput;

    }

    private void fillFormHeader(StringBuilder formSB) {
        formSB.append("<html xmlns=\"http://www.w3.org/1999/xhtml\">\n");
        formSB.append("  <head>\n");
        formSB.append("    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n");
        formSB.append("    <script type='application/javascript'>\n");
        formSB.append("      function loadGraph() {\n");
        formSB.append("        var frm = document.getElementById('post_form');\n");
        formSB.append("        if (frm) {\n");
        formSB.append("         frm.submit();\n");
        formSB.append("        }\n");
        formSB.append("      }\n");
        formSB.append("    </script>\n");
        formSB.append("  </head>\n");
        formSB.append("  <body onload=\"loadGraph()\">\n");
        formSB.append("    <form action='https://chart.googleapis.com/chart' method='POST' id='post_form' onsubmit=\"this.action = 'https://chart.googleapis.com/chart?chid=' + (new Date()).getMilliseconds(); return true;\">\n");
    }

    private void fillFormFooter(StringBuilder formSB) {
        formSB.append("</form></body></html>\n");
    }

    public StringBuilder getChartURL(String geneName, String[] groupNameArray, double[][] foldChangeArray, double[][] groupOrientedFoldChangeArray,
            int maxGroupOrientedfoldChangeArrayColumn, double[][] confidenceIntervalArray, StringBuilder iframeOutput, String fileName) {
        StringBuilder foldChangeChartOutput = new StringBuilder();
        final int validPointStart = 5;
        //int chartWidth = groupNameArray.length * EACH_COLUMN_WIDTH;
        int chartWidth = 800;
//        if (chartWidth > UI_WIDTH_MAX) {//GOOGLE CHART limit is 1000, SAGE layout limit is 880
//            chartWidth = UI_WIDTH_MAX;
//        }else if (chartWidth < UI_WIDTH_MIN){
//        	chartWidth = UI_WIDTH_MIN;
//        }


        int height = UI_HEIGHT1;
        int numOfColumns = groupOrientedFoldChangeArray.length;
        final int columnLength = groupNameArray.length;
        String chartSize = chartWidth + "x" + UI_HEIGHT1;
        if (columnLength > MAX_GROUP_LABEL) { //if too many groups, extract label need
            chartSize = chartWidth + "x" + UI_HEIGHT2;
            height = UI_HEIGHT2;
        }

                iframeOutput.append("<iframe src=\"").append(fileName).
                        append("\" width=\"").append(chartWidth + 30).
                        append("\" height=\"").append(height + 30).
                        append("\" frameborder=\"0\"></iframe>");

                foldChangeChartOutput.append("http://chart.googleapis.com/chart?chs=").
                        append(chartSize).append("&cht=bvg");

        //TODO:: base on foldChangeArray, calculate 25%, mean, 75%

        StringBuilder chd = new StringBuilder("&chd=t0:");


        //5 rows: min, 25%, 75%,max, median
        //DEBUG
        double[][] boxChartArray = new double[validPointStart + maxGroupOrientedfoldChangeArrayColumn][groupOrientedFoldChangeArray.length];
        //System.out.println("##boxChartArray:: " + boxChartArray.length + ", " + boxChartArray[0].length);

        int boxChartRowIndex = 0;
        double maxChD = -10000000;
        double minChD = 10000000;

        for (int i = 0; i < groupOrientedFoldChangeArray.length; i++) {
            double confidenceIntervalMin = confidenceIntervalArray[i][0],
                    confidenceIntervalMax = confidenceIntervalArray[i][1], median = confidenceIntervalArray[i][2];
            double validPoint = confidenceIntervalArray[i][3];
//            boxChartArray[0][boxChartRowIndex] = confidenceIntervalMin;
//            boxChartArray[1][boxChartRowIndex] = median;
//            boxChartArray[2][boxChartRowIndex] = 0.000000001;//start point of the gray bar
//           // boxChartArray[2][boxChartRowIndex] = confidenceIntervalMin;
//            boxChartArray[3][boxChartRowIndex] = confidenceIntervalMax;
//            boxChartArray[4][boxChartRowIndex] = median;

            boxChartArray[0][boxChartRowIndex] = median;
            boxChartArray[1][boxChartRowIndex] = median;
            boxChartArray[2][boxChartRowIndex] = 0.000000001;//start point of the gray bar
            // boxChartArray[2][boxChartRowIndex] = confidenceIntervalMin;
            boxChartArray[3][boxChartRowIndex] = confidenceIntervalMax;
            boxChartArray[4][boxChartRowIndex] = confidenceIntervalMin;

            //boxChartArray[5][boxChartRowIndex] = validPoint;//may not need this validpoint?
            if (confidenceIntervalMax > maxChD) {
                maxChD = confidenceIntervalMax;
            }
            if (confidenceIntervalMin < minChD) {
                minChD = confidenceIntervalMin;
            }
            // int count = 0;
            // int sum = 0;
            //System.out.println("groupOrientedFoldChangeArray[" + i+ "].length= " + groupOrientedFoldChangeArray[i].length);
            if (groupOrientedFoldChangeArray[i] != null) {
                for (int j = 0; j < groupOrientedFoldChangeArray[i].length; j++) {
                    boxChartArray[validPointStart + j][boxChartRowIndex] = groupOrientedFoldChangeArray[i][j];
                    // sum+=groupOrientedFoldChangeArray[i][j];
                    // count++;
                    if (boxChartArray[validPointStart + j][boxChartRowIndex] > maxChD) {
                        maxChD = boxChartArray[validPointStart + j][boxChartRowIndex];
                    } else if (boxChartArray[validPointStart + j][boxChartRowIndex] < minChD) {
                        minChD = boxChartArray[validPointStart + j][boxChartRowIndex];
                    }
                }
//                if (sum == -1 * count){//if all -1 points, set all confidenceInterval, median as -1
//                	for (int b=0; b<validPointStart; b++){
//                		boxChartArray[b][boxChartRowIndex] = -1;
//                	}
//                }
            }

            boxChartRowIndex++;
        }
        /*
         *     double absMinChD = 0;
         if (minChD < 0){
         absMinChD = Math.abs(minChD);
         }
         double totalMaxChD = maxChD + absMinChD;
         */

//        double absMinChD = Math.abs(minChD);
//        double totalMaxChD = maxChD + absMinChD;

        double totalMaxChD = maxChD - minChD;

        //logger.warning("xxx absMinChD="+absMinChD+"  totalMaxChD"+totalMaxChD);
        // System.out.println("#################  GENE: "+geneName+" maxChD="+maxChD+" minChD="+minChD+" totalMaxChD="+totalMaxChD);

//        for (int i = 0; i < boxChartArray.length; i++) {
//            for (int j = 0; j < boxChartArray[i].length; j++) {
//            	System.out.print("boxChartArray["+i+"]["+j+"]="+boxChartArray[i][j]+" ("+((boxChartArray[i][j] - minChD)* 100.0/ totalMaxChD)+")\t");
//            }
//            System.out.println();
//
//        }

        for (int i = 0; i < boxChartArray.length; i++) {

            chd.append("-1,");
            for (int j = 0; j < boxChartArray[i].length; j++) {
                if (boxChartArray[i][j] != 0.0000) {
                    double thisValue = 0;
                    if (i == 2) {//0.0000001
                        thisValue = boxChartArray[i][j];
                        //thisValue = (boxChartArray[i][j] - minChD)* 100.0/ totalMaxChD;
                    } else {
                        try {
                            thisValue = (boxChartArray[i][j] - minChD) * 100.0 / totalMaxChD;
                        } catch (Exception ex) {
                            //ex.printStackTrace();
                        }
                        if (Double.isNaN(thisValue)) {
                            thisValue = -1;//don't show in chart
                        }
                    }
                    //System.out.print("boxChartArray["+i+"]["+j+"]="+boxChartArray[i][j]+" ("+thisValue+")\t");

                    //logger.warning("xxx boxChartArray["+i+"]["+j+"]="+boxChartArray[i][j]+"==>"+thisValue);
                    chd.append(thisValue);
                } else {
                    //logger.warning("000 boxChartArray["+i+"]["+j+"]="+boxChartArray[i][j]);
                    chd.append("-1");//not exist, don't show in chart
                }
                chd.append(",");
            }
            chd.append("-1");
            if (i != boxChartArray.length - 1) {
                chd.append("|");
            }
        }


        foldChangeChartOutput.append(chd);

        // String chdStr = "&chd=t0:-1.2,5,10,7,12,-1|-1,25,30,27,24,-1|-1,40,45,47,39,-1|-1,55,63,59,80,-1|-1,30,40,35,30,-1|-1,-1,5,70,90,-1|-1,-1,-1,80,5,-1";
        //foldChangeChartOutput.append(chdStr);
        StringBuilder chm = new StringBuilder("&chm=");




        //chm.append("F,A1A1A1,7,1:4,40|");
        //TODO:: put color, but this could variant color could cause the error bar or spotting dot not show
//        String[] colors = new String[numOfColumns];
//        for (int i=0; i<numOfColumns; i++){
//        	colors[i] = "A1A1A1";
//        }
//        for (int i=0; i<numOfColumns; i++){
//        	chm.append("F,"+colors[i]+",0,"+(i+1)+",20|");
//        }
//        chm.append("F,A1A1A1,0,1:"+numOfColumns+",20|");//solid bar: mean, color gray, A1A1A1=lightGray
//        chm.append("H,202020,0,1:"+numOfColumns+",1:20|");//confidence interval lower, 00FF00=green
//        chm.append("H,202020,3,1:"+numOfColumns+",1:20|");//confidence interval upper

        chm.append("F,A1A1A1,0,,20|");//solid bar: mean, color gray, A1A1A1=lightGray
        chm.append("H,202020,4,,1:10|");//confidence interval lower, 00FF00=green
        chm.append("H,202020,3,,1:10|");//confidence interval upper

        for (int j = 0; j < foldChangeArray.length; j++) {
            chm.append("o,0000FF,").append(validPointStart + j).
                    append(",-1,5|");//all valid points, 5 is the dot size
        }

        chm.deleteCharAt(chm.length() - 1);
        foldChangeChartOutput.append(chm);
        String equalStr = "%3D";
        StringBuilder chdl = new StringBuilder("&chdl=");
        foldChangeChartOutput.append("&chxt=y,x&chxl=1:||");

        // System.out.println("columnLength="+columnLength);
        StringBuilder chdlpOrderStr = new StringBuilder();
        for (int j = 0; j < groupNameArray.length; j++) {
            if (columnLength > MAX_GROUP_LABEL) { //if too many groups, extract label need

                foldChangeChartOutput.append((j + 1));//put label as number in chart
                foldChangeChartOutput.append("|");

                chdl.append(j + 1).append(equalStr).append(groupNameArray[j]);//add extract label
                chdl.append("|");
                chdlpOrderStr.append(j).append(",");
            } else {
                foldChangeChartOutput.append(groupNameArray[j]);
                foldChangeChartOutput.append("|");
            }
        }
        //foldChangeChartOutput.append("|2:||fold change*|");

        //foldChangeChartOutput.append("&chds=1,7");
        //Y-xis nubmer
        //foldChangeChartOutput.append("&chxr=1,7");
        //chxr,chxr=<axis_index>,<start_val>,<end_val>,<opt_step>
        StringBuilder chxr = new StringBuilder("&chxr=0,");
        chxr.append(minChD);
        chxr.append(",");
        chxr.append(maxChD);
        foldChangeChartOutput.append(chxr);



        if (columnLength > MAX_GROUP_LABEL) {//if too many groups, extract label need
            foldChangeChartOutput.append("&chco=ADD8E6");//light blue
            chdl.append("&chdlp=b|");
            chdl.append(chdlpOrderStr);
            foldChangeChartOutput.append(chdl);
        }
        //logger.warning("GOOGLE CHART: \n" + foldChangeChartOutput);
        // System.out.println("GOOGLE CHART: \n" + foldChangeChartOutput);
        //System.out.println("GOOGLE CHART: \n" + foldChangeChartOutput.length());
        return foldChangeChartOutput;
    }

    /*
     * return html format of Average Ct Value table
     */
    //input, gene name (only if target gene)
    public double[] getAveCtTable(int geneId, int groupId) {
        double[] avgCts = null;
        Map<Integer, ResultValue> thisGroupMap = geneMap.get(geneId);
        if (thisGroupMap != null) {
            ResultValue resultValue = thisGroupMap.get(groupId);
            if (resultValue != null) {
                avgCts = resultValue.getAvgCts();
            }
        } else {
            //System.out.println("Gene ID not found: " + geneId);
            logger.log(Level.WARNING, "Gene ID not found: {0}", geneId);
        }


        return avgCts;
    }

    public double getAveDctValue(int geneId, int groupId) {
        double avgDct = -1;
        Map<Integer, ResultValue> thisGroupMap = geneMap.get(geneId);
        if (thisGroupMap != null) {
            ResultValue resultValue = thisGroupMap.get(groupId);
            if (resultValue != null) {
                avgDct = resultValue.getAvgDctValue();
            } else {
                logger.log(Level.WARNING, "Group ID not found: {0} (geneId: {1})", new Object[]{groupId, geneId});
                logger.log(Level.WARNING, "thisGroupMap=: {0}", thisGroupMap);
                //System.out.println("Group ID not found: " + groupId + " (geneId: " + geneId + ")");
                //System.out.println("thisGroupMap=: " + thisGroupMap);
            }
        } else {
            // System.out.println("Gene ID not found: " + geneId);
            logger.log(Level.WARNING, "Gene ID not found: {0}", geneId);
        }


        return avgDct;
    }

    //double[][] inputValues;
    //double[] averageCtValues;
    //double[] dctValues;
    //double[] ddctValues;
    //double avgDctValue;
    //on gene level, double[][] foldChangeValues;
    //on gene level, double[][2] confidence interval of foldChangeValues;
    public void add(Map<Integer, Map<Integer, ResultValue>> thisGeneMap, Gene gene, Group group, Double[][] geneGroupValues, String[][] geneGroupCoordinates) {
        this.geneMap = thisGeneMap;
        Map<Integer, ResultValue> groupMap = this.geneMap.get(gene.getId());
        if (groupMap == null) {//not found
            groupMap = new LinkedHashMap<Integer, ResultValue>();
            ResultValue resultValue = new ResultValue(this, gene, group, geneGroupValues, geneGroupCoordinates);
            groupMap.put(group.getId(), resultValue);
            this.geneMap.put(gene.getId(), groupMap);
//            Logger.getLogger(ResultObj.class.getName()).log(Level.WARNING,
//                    "###ADD gene: " + gene.getId() + ", group:" + group.getId() + ":" + resultValue.toString());
            msg.append("ADD gene: ").append(gene.getId()).append(", group:").
                    append(group.getId()).append(":\t").
                    append(resultValue.toString()).append("\n");
            //System.out.println("NEW ADD gene: " + gene.getId() + ", group:" + group.getId() + ":\t" + resultValue.toString() + "\n");
            // System.out.println("NEW ADD gene: " + gene.getName() + ", group:" + group.getName() + ":\t" + resultValue.toString() + "\n");
        } else {
//            Logger.getLogger(ResultObj.class.getName()).log(Level.WARNING,
//                    "gene: " + gene.getName() + ", group:" + group.getName() + " already added");
            ResultValue resultValue = new ResultValue(this, gene, group, geneGroupValues, geneGroupCoordinates);
            groupMap.put(group.getId(), resultValue);
            geneMap.put(gene.getId(), groupMap);
//            Logger.getLogger(ResultObj.class.getName()).log(Level.WARNING,
//                    "###ADD gene: " + gene.getId() + ", group:" + group.getId() + ":" + resultValue.toString());
            msg.append("ADD gene: ").append(gene.getId()).append(", group:").
                    append(group.getId()).append(":\t").
                    append(resultValue.toString()).append("\n");
            //System.out.println("ADD gene: " + gene.getId() + ", group:" + group.getId() + ":\t" + resultValue.toString() + "\n");
            //System.out.println("ADD gene: " + gene.getName() + ", group:" + group.getName() + ":\t" + resultValue.toString() + "\n");
        }
        geneIdMap.put(gene.getId(), gene.getName());
        groupIdMap.put(group.getId(), group.getName());
    }

    public StringBuffer getMsg() {
        return msg;
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();

        Set<Map.Entry<Integer, Map<Integer, ResultValue>>> geneSet = geneMap.entrySet();

        for (Map.Entry<Integer, Map<Integer, ResultValue>> myGeneMap : geneSet) {
            Map<Integer, ResultValue> myGroupMap = myGeneMap.getValue();
            Set<Map.Entry<Integer, ResultValue>> groupSet = myGroupMap.entrySet();
            for (Map.Entry<Integer, ResultValue> myResult : groupSet) {
                output.append("Gene:").
                        append(this.geneIdMap.get(myGeneMap.getKey())).
                        append("\t");
                output.append("Group:").
                        append(this.groupIdMap.get(myResult.getKey())).
                        append("\t");
                output.append("\n\tValue: ").append(myResult.getValue());
                output.append("\n");
            }
            output.append("\n");
        }

        output.append("\n");

        return output.toString();
    }

    public List<String> getPostGoogleChartNameList() {
        return postGoogleChartNameList;
    }
}
