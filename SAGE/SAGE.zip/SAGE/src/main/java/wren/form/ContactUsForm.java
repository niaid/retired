package wren.form;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class ContactUsForm {

    @NotEmpty(message = "Name is required.")
    @Size(min = 2, max = 45, message = "Name must between 2 to 45 Characters.")
    String name;
    String department;
    String organization;
    @NotEmpty(message = "Email is required.")
    @Size(min = 2, max = 45, message = "Email must between 2 to 45 Characters.")
    @Email(message = "Invalid Eamil.")
    String email;
    @NotEmpty(message = "Subject is required.")
    String subject;
    @NotEmpty(message = "Comments is required.")
    String comments;
    String errorMessage;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSendMessage() {
        String result = "";
        result += "The following request was made on the SAGE \"Contact Us\" page:\n\n";
        result += "Name: " + this.getName() + "\n";
        result += "Department: " + this.getDepartment() + "\n";
        result += "Organization: " + this.getOrganization() + "\n";
        result += "Email: " + this.getEmail() + "\n";
        result += "Subject: " + this.getSubject() + "\n";
        result += "Questions/comments:\n" + this.getComments() + "\n";
        return result;
    }
}
