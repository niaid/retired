package wren.form;

import javax.validation.constraints.AssertTrue;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

//@FieldMatch.List({
//    @FieldMatch(first = "password", second = "reenteredPassword", message = "The password fields must match"),
//})
public class ForgetPasswordForm {

    @NotEmpty(message = "First Name is required.")
    String firstName;
    @NotEmpty(message = "Last Name is required.")
    String lastName;
    @NotEmpty(message = "Password is required.")
    String password;
    @NotEmpty(message = "Retype Password is required.")
    String reenteredPassword;
    @NotEmpty(message = "Email is required.")
    @Email(message = "Invalid Eamil.")
    String email;
    String errorMessage;
    boolean isValid;
    String encryptedPassword;
    String comments;

    @AssertTrue(message = "Password should match retyped password")
    public boolean isValid() {
        isValid = false;
        if (password == null) {
            return reenteredPassword == null;
        } else {
            isValid = password.equals(reenteredPassword);
            return isValid;
        }
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getReenteredPassword() {
        return reenteredPassword;
    }

    public void setReenteredPassword(String reenteredPassword) {
        this.reenteredPassword = reenteredPassword;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getSendMessage() {
        String message = "The following request was made on the SAGE \"Update Password\" page:\n\n"
                + "Email=" + email + "\nFirstName="
                + firstName + "\nLastName=" + lastName + "\nPassword=" + password + "\nComments=" + comments + "\n\n";

        String sql = "update User set password = '" + this.getEncryptedPassword() + "' where email='" + this.email + "' and firstName='" + this.firstName
                + "'  and lastName='" + this.lastName + "';";
        //System.out.println("SQL: "+sql);

        String replayMessage = "\n\nReply message: Thanks for contacting NIAID SAGE Support. Your password has been updated.";
        return message + sql + replayMessage;
    }

    public String getEncryptedPassword() {
        encryptedPassword = MD5(this.password);
        return encryptedPassword;
    }

    public void setEncryptedPassword(String encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }

    private String MD5(String md5) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest
                    .getInstance("MD5");
            byte[] array = md.digest(md5.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100)
                        .substring(1, 3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
        }
        return null;
    }
}
