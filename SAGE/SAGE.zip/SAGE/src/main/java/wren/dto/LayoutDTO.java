package wren.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class LayoutDTO {

    int id;
    String name;
    String createDate;
    String modifiedDate;
    List<String> referenceGenes = new ArrayList<String>();
    List<String> targetGenes = new ArrayList<String>();

    public LayoutDTO(int id, String name, Calendar createDate,
            Calendar modifiedDate) {
        super();
        this.id = id;
        this.name = name;
        this.createDate = ExperimentDTO.getCalenderString(createDate);
        this.modifiedDate = ExperimentDTO.getCalenderString(modifiedDate);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public List<String> getReferenceGenes() {
        return referenceGenes;
    }

    public void setReferenceGenes(String refGeneNamesStr) {
        if (refGeneNamesStr != null) {
            String[] genes = refGeneNamesStr.split(";");
            referenceGenes = Arrays.asList(genes);
        }
    }

    public List<String> getTargetGenes() {
        return targetGenes;
    }

    public void setTargetGenes(String targetGeneNamesStr) {
        if (targetGeneNamesStr != null) {
            String[] genes = targetGeneNamesStr.split(";");
            targetGenes = Arrays.asList(genes);
        }
    }
}
