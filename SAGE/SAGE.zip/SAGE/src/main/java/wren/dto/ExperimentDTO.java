package wren.dto;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ExperimentDTO {

    int id;
    String name;
    String createDate;
    String modifiedDate;
    String userName;
    int hasLayout;
    boolean deletable = false; //deletable + editable

    public ExperimentDTO(int id, String name, Calendar createDate,
            Calendar modifiedDate, String userName, int hasLayout) {
        this(id, name, createDate, modifiedDate, userName, hasLayout, false);
    }

    public ExperimentDTO(int id, String name, Calendar createDate,
            Calendar modifiedDate, String userName, int hasLayout, boolean deletable) {
        super();
        this.id = id;
        this.name = name;
        this.createDate = getCalenderString(createDate);
        this.modifiedDate = getCalenderString(modifiedDate);
        this.userName = userName;
        this.hasLayout = hasLayout;
        this.deletable = deletable;
    }

    public static String getCalenderString(Calendar date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        String calendarStr = sdf.format(date.getTime());
        return calendarStr;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getHasLayout() {
        return hasLayout;
    }

    public void setHasLayout(int hasLayout) {
        this.hasLayout = hasLayout;
    }

    public boolean isDeletable() {
        return deletable;
    }

    public void setDeletable(boolean deletable) {
        this.deletable = deletable;
    }
}
