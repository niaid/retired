package wren.dto;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import wren.service.WorkBookGenerator;

/**
 * HSSFWorkbook cannot be Serializable in WorkBookGenerator So
 * WorkBookSerializable is created for transporting information in servlet
 * session
 *
 * @author Qina Tan
 */
public class WorkBookSerializable implements java.io.Serializable {

    private static final long serialVersionUID = 5379641761866376255L;
    byte[] workbookByte;
    String workBookDisplayName;
    List<String> postGoogleChartNameList;
    String WebResultWithScript;
    String htmlFileName;

    public WorkBookSerializable(WorkBookGenerator workBook) {
        workBookDisplayName = workBook.getDisplayFileName();
        postGoogleChartNameList = workBook.getCurrentWorkSheet().getResultObj().getPostGoogleChartNameList();
        WebResultWithScript = workBook.getWebResultWithScript();
        //workbookByte = workBook.getWorkBook().getBytes();
        htmlFileName = workBook.getHtmlFileName();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            workBook.getWorkBook().write(out);
            workbookByte = out.toByteArray();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
        }
    }

    public byte[] getWorkbookByte() {
        return workbookByte;
    }

    public void setWorkbookByte(byte[] workbookByte) {
        this.workbookByte = workbookByte;
    }

    public String getWorkBookDisplayName() {
        return workBookDisplayName;
    }

    public void setWorkBookDisplayName(String workBookDisplayName) {
        this.workBookDisplayName = workBookDisplayName;
    }

    public List<String> getPostGoogleChartNameList() {
        return postGoogleChartNameList;
    }

    public void setPostGoogleChartNameList(List<String> postGoogleChartNameList) {
        this.postGoogleChartNameList = postGoogleChartNameList;
    }

    public String getWebResultWithScript() {
        return WebResultWithScript;
    }

    public void setWebResultWithScript(String webResultWithScript) {
        WebResultWithScript = webResultWithScript;
    }

    public String getHtmlFileName() {
        return htmlFileName;
    }
}
