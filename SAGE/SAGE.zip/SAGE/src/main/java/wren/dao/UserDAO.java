package wren.dao;

import wren.domain.User;

public interface UserDAO {
	public User searchDatabase(String loginName);
}
