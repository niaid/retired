package wren.dao;

import com.google.gson.Gson;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import wren.domain.Experiment;
import wren.domain.Layout;
import wren.domain.ReferenceGene;
import wren.domain.User;
import wren.domain.jsonObject.ProjectObject;
import wren.service.WorkBookGenerator;

/**
 *
 * @author jning 2/28/2013, removed warnings
 */
@Repository
public class ExperimentDAOImpl implements ExperimentDAO {
	@Autowired
	private SessionFactory sessionFactory;
	protected static final Logger logger = Logger.getLogger(ExperimentDAOImpl.class
			.getName());

	public List<Experiment> listExperiment() {
		//logger.warning("ADMIN listExperiment");
		return sessionFactory.getCurrentSession()
				.createQuery("from Experiment exp order by exp.createdDate desc").list();
	}

	public List<Experiment> listExperimentByUsername(Integer id, String username) {
		//logger.warning("user listExperimentByUsername "+username);
		return sessionFactory.getCurrentSession()
				.createQuery("from Experiment exp where exp.user.id = '"+id+"' order by exp.createdDate desc" ).list();
	}

	public List<Experiment> listExperimentByGroup(Integer id, String group) {
		//logger.warning("user listExperimentByGroup "+group);
		return sessionFactory.getCurrentSession()
				.createQuery("from Experiment exp where exp.user.role = '"+group+"' order by exp.createdDate desc").list();
	}

	// save Experiment after template is created, and user click on next to
	// layout table
	public Integer saveExperiment(Experiment experiment) {
		//logger.warning("saveOrUpdate expeirment");
		sessionFactory.getCurrentSession().saveOrUpdate(experiment);
		return experiment.getId();
	}

	public Integer saveLayout(Layout layout) {
		//logger.warning("saveOrUpdate Layout");
		sessionFactory.getCurrentSession().saveOrUpdate(layout);
		return layout.getId();

	}

	public Integer saveReferenceGene(ReferenceGene refGene) {
		//logger.warning("saveOrUpdate ReferenceGene");
		sessionFactory.getCurrentSession().saveOrUpdate(refGene);
		return refGene.getId();
	}

	public void deleteExperiment(int id){
		sessionFactory.getCurrentSession().delete(sessionFactory.getCurrentSession().load(Experiment.class, id));
	}
	public String getExperimentJsonString(String experimentID, int[] hasLayout) {
		//logger.warning("getExisingTemplateJson experimentID=" + experimentID);
		Gson gson = new Gson();
		// Gson gson = new GsonBuilder().setPrettyPrinting().create();
		//ProjectObject projectObject = null;
		String json = null;
		try {
			Experiment experiment = (Experiment) sessionFactory
					.getCurrentSession().get(Experiment.class,
							Integer.parseInt(experimentID));
			ProjectObject projectObject = gson.fromJson(experiment.getTemplateJson(),
					ProjectObject.class);
			projectObject.setProjectName(experiment.getName());
			projectObject.setExperimentID("" + experiment.getId());

			hasLayout[0] = experiment.getHasLayout();
			List<ReferenceGene> referenceGenes = sessionFactory
					.getCurrentSession().createQuery(
							"from ReferenceGene where experimentId = "
									+ experimentID).list();
			if (referenceGenes != null && referenceGenes.size() > 0) {
				for (ReferenceGene referenceGene : referenceGenes) {
					wren.domain.jsonObject.ReferenceGene refGene = new wren.domain.jsonObject.ReferenceGene(
							referenceGene.getId(), referenceGene.getGeneName(), referenceGene.getLayoutId());
					projectObject.getReferenceGenes().add(refGene);
				}
			}
			json = gson.toJson(projectObject);
			// sessionFactory.getCurrentSession().createQuery("from Experiment");
		} catch (Exception ex) {
			logger.severe(ex.toString());
			//ex.printStackTrace();
		}
		return json;
	}

	public List<Layout> listLayouts(int experimentID) {
		List<Layout> layouts = sessionFactory.getCurrentSession().createQuery(
				"from Layout where experimentId = " + experimentID).list();
		return layouts;

	}

	//saveTemplate
	public int saveExperiment(Integer experimentID, String experimentName, String templateJson, int userID) {
		//logger.warning("saveOrUpdate expeirment");

		Experiment experiment;// = null;
		if (experimentID > 0) {
			experiment = getExperimentByID(experimentID);
			//experiment.setId(experimentID);
			//TODO:: need to see the date from database
		}else{//new experiment
			experiment = new Experiment();
			experiment.setCreatedDate(Calendar.getInstance());
			experiment.setHasLayout(0);//no layout, only template
		}
		experiment.setName(experimentName);

		//experiment.setUserId(userID);

		User dbCurrentUser = this.getUser(userID);

		experiment.setUser(dbCurrentUser);
		experiment.setTemplateJson(templateJson);
		experiment.setLastModifiedDate(Calendar.getInstance());

		int newExperimentID = saveExperiment(experiment);
		//logger.warning("SAVED: "+newExperimentID);

		return newExperimentID;
	}

	public int saveTemplate(Integer experimentID, String experimentName, String templateJson, int userID, int[] savedLayoutID) {
		//return saveWholeExperiment(null, templateJson, null, templateJson, "run1", experimentID, -1, userID, savedLayoutID, experimentName);
		return -1;
	}


//	public Integer saveWholeExperiment(WorkBookGenerator workBookGenerator,
//			String templateJson, String inputFile, String layoutJson,
//			String worksheetName, int experimentID, int layoutID, int userID, int[] savedLayoutID) {
//		return saveWholeExperiment(workBookGenerator, templateJson, inputFile, templateJson, worksheetName, experimentID, layoutID, userID, savedLayoutID, null);
//	}

	public Integer saveWholeExperiment(WorkBookGenerator workBookGenerator,
			String templateJson, String inputFile, String layoutJson,
			String worksheetName, int experimentID, int layoutID, int userID, int[] savedLayoutID, String experimentName) {
		Integer newExperimentID = null;

		try {
			// sessionFactory.getCurrentSession().beginTransaction();

			Experiment experiment;// = null;
			if (experimentID > 0) {
				experiment = getExperimentByID(experimentID);
				//experiment.setId(experimentID);
				//TODO:: need to see the date from database
			}else{//new experiment
				experiment = new Experiment();
				experiment.setCreatedDate(Calendar.getInstance());
			}
			if (workBookGenerator!=null){
				experiment.setName(workBookGenerator.getExperimentName());
			}else{
				experiment.setName(experimentName);
			}
			experiment.setHasLayout(1);

			//experiment.setUserId(userID);

			User dbCurrentUser = this.getUser(userID);

			experiment.setUser(dbCurrentUser);
			experiment.setTemplateJson(templateJson);
			experiment.setLastModifiedDate(Calendar.getInstance());

			//logger.warning("experiment=" + experiment.getName());

			// System.out.println("experiment=" + experiment);
			newExperimentID = saveExperiment(experiment);

			if (newExperimentID == null || newExperimentID <= 0) {
				return newExperimentID;
			}

			Layout layout;// = null;
			if (layoutID > 0) {
				//layout.setId(layoutID);
				layout = getLayoutByID(layoutID);
				worksheetName = layout.getWorksheetName();
			}else{//new layout
				if (experimentID > 0) {
					try{
						int count = getNoOfLayout(experimentID);
						worksheetName = "run"+(count+1);
					}catch(Exception ex){
						//ex.printStackTrace();
                        logger.log(Level.WARNING, layoutJson, ex.getMessage());
					}

				}
				layout = new Layout();
				layout.setCreatedDate(Calendar.getInstance());
			}
			if (inputFile!=null && inputFile.trim().length()>0){
				layout.setInputfile(inputFile);
			}

			layout.setExperimentId(newExperimentID);
			// layout.setExperiment(experiment);
			layout.setWorksheetName(worksheetName);
			if (workBookGenerator!=null){
				layout.setRefGeneNames(workBookGenerator.getCurrentWorkSheet().getReferenceGenesStr());
				layout.setTargetGeneNames(workBookGenerator.getCurrentWorkSheet().getTargetGenesStr());
			}
			if (layoutJson!=null && layoutJson.trim().length()>0){
				layout.setLayoutJson(layoutJson);
			}
			layout.setLastModifiedDate(Calendar.getInstance());
			//logger.warning("save layout: experimentID: " + experiment.getId()
			//		+ " layout "+layoutID);
			// System.out.println("experiment=" + experiment);
			Integer newLayoutID = saveLayout(layout);
			savedLayoutID[0] = newLayoutID;
			//logger.warning("xxsaved LayoutID="+layoutID);
			if (newLayoutID == null || newLayoutID <= 0) {
				return newLayoutID;
			}

			//TODO:: if update layout, need to take care of ophen reference gene
			//do just create new layout, and delete layout=layoutID
			// Integer newLayoutID = 1;
			//logger.warning("checking refGenes");
			if (workBookGenerator!=null){
				List<wren.domain.jsonObject.ReferenceGene> refGenes = workBookGenerator
						.getReferenceGenes();
				if (refGenes != null && refGenes.size() > 0) {
					for (wren.domain.jsonObject.ReferenceGene refGene : refGenes) {
						wren.domain.ReferenceGene dbRefGene = new wren.domain.ReferenceGene();
						// TODO:: refGene id need to get from templateJson
						dbRefGene.setId(refGene.getId());
						dbRefGene.setGeneName(refGene.getGeneName());
						dbRefGene.setExperimentId(newExperimentID);
						dbRefGene.setLayoutId(newLayoutID);
						//logger.warning("saving refGenes " + dbRefGene);
						saveReferenceGene(dbRefGene);
					}
				}
			}

			// sessionFactory.getCurrentSession().getTransaction().commit();
		} catch (Exception ex) {
			// sessionFactory.getCurrentSession().getTransaction().rollback();
			// throw e; // or display error message
			//ex.printStackTrace();
            logger.log(Level.SEVERE, layoutJson, ex.getMessage());
		}

		return newExperimentID;

	}
	public List<Layout> listLayoutsByUsername(String username) {
		return sessionFactory.getCurrentSession()
		.createQuery("from Layout").list();
	}

	public String getLayoutJsonString(String layoutID) {
		//logger.warning("getLayoutJsonString layoutID=" + layoutID);
		Gson gson = new Gson();
		// Gson gson = new GsonBuilder().setPrettyPrinting().create();
		//ProjectObject projectObject = null;
		String json = null;
		try {
			Layout layout = (Layout) sessionFactory
					.getCurrentSession().get(Layout.class,
							Integer.parseInt(layoutID));
			Experiment experiment = (Experiment) sessionFactory
				.getCurrentSession().get(Experiment.class,layout.getExperimentId());

			ProjectObject projectObject = gson.fromJson(layout.getLayoutJson(),
					ProjectObject.class);
			projectObject.setProjectName(experiment.getName());
			projectObject.setExperimentID("" + layout.getExperimentId());
			projectObject.setLayoutID(layout.getId());

			List<ReferenceGene> referenceGenes = sessionFactory
					.getCurrentSession().createQuery(
							"from ReferenceGene where experimentId = "
									+ layout.getExperimentId()).list();
			if (referenceGenes != null && referenceGenes.size() > 0) {
				for (ReferenceGene referenceGene : referenceGenes) {
					wren.domain.jsonObject.ReferenceGene refGene = new wren.domain.jsonObject.ReferenceGene(
							referenceGene.getId(), referenceGene.getGeneName(), referenceGene.getLayoutId());
					//logger.warning(" referenceGene.getGeneName()=" +  referenceGene.getGeneName()+" LayoutId="+referenceGene.getLayoutId());
					projectObject.getReferenceGenes().add(refGene);
				}
			}
			json = gson.toJson(projectObject);
			// sessionFactory.getCurrentSession().createQuery("from Experiment");
		} catch (Exception ex) {
			logger.severe(ex.toString());
			//ex.printStackTrace();
		}
		return json;
	}

	public User getUser(Integer id) {
//		return (User) sessionFactory.getCurrentSession()
//		.createQuery("from User user where user.id = '"+id+"'").list().get(0);
		return  (User) sessionFactory.getCurrentSession().load(User.class, id);
	}

	public Experiment getExperimentByID(int id) {

	//	return  (Experiment) sessionFactory.getCurrentSession().load(Experiment.class, id);
		return (Experiment) sessionFactory.getCurrentSession()
		.createQuery("from Experiment exp where exp.id = '"+id+"'").list().get(0);
	}

	public Layout getLayoutByID(Integer id) {
//		return (Layout) sessionFactory.getCurrentSession()
//		.createQuery("from Layout layout where layout.id = '"+id+"'").list().get(0);

		return  (Layout) sessionFactory.getCurrentSession().load(Layout.class, id);
	}

	public int saveExperiment(Integer experimentID, String experimentName,
			String templateJson, int userID, int[] savedLayoutID) {
		// TODO Auto-generated method stub
		return 0;
	}

	private int getNoOfLayout(int experimentID) {
		return sessionFactory.getCurrentSession().createQuery("from Layout l where l.experimentId="+experimentID).list().size();
	}

	public int saveUser(User user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		return user.getId();
	}
}
