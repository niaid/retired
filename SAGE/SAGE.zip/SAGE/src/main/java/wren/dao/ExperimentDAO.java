package wren.dao;

import java.util.List;
import wren.domain.Experiment;
import wren.domain.Layout;
import wren.domain.ReferenceGene;
import wren.domain.User;
import wren.service.WorkBookGenerator;

public interface ExperimentDAO {
	public List<Experiment> listExperiment();
	public List<Experiment> listExperimentByUsername(Integer id, String username);
	public Integer saveExperiment(Experiment experiment);
	public Integer saveLayout(Layout layout);
	public Integer saveReferenceGene(ReferenceGene refGene);
	public String getExperimentJsonString(String experimentID, int[] hasLayout);
	public List<Layout> listLayouts(int experimentID);
	public Integer saveWholeExperiment(WorkBookGenerator workBookGenerator,
			String templateJson, String contents, String string,
			String worksheetName, int experimentID, int layoutID, int userID, int[] savedLayoutID, String experimentName);
	public List<Layout> listLayoutsByUsername(String username);
	public String getLayoutJsonString(String layoutID);
	public List<Experiment> listExperimentByGroup(Integer id, String role);
	public User getUser(Integer id);
	public Experiment getExperimentByID(int id);
	public int saveExperiment(Integer experimentID, String experimentName,
			String templateJson, int userID);
	public void deleteExperiment(int experimentID);
	public int saveTemplate(Integer experimentID, String experimentName,
			String templateJson, int userID, int[] savedLayoutID);
	public int saveUser(User user);
}
