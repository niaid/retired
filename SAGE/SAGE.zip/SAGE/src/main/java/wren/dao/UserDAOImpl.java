package wren.dao;

import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import wren.domain.User;

/**
 *
 * @author jning 2/282/2013, removed warnings
 */
@Repository
public class UserDAOImpl implements UserDAO {

    @Autowired
    private SessionFactory sessionFactory;
    //@Autowired
    //private HttpSession session;
    protected static final Logger logger = Logger.getLogger(UserDAOImpl.class.getName());

    public User searchDatabase(String loginName) {
        //sessionFactory.getCurrentSession();
        //sessionFactory.getCurrentSession().createQuery("from User");
        //sessionFactory is null
        List<User> users = sessionFactory.getCurrentSession().createQuery("from User").list();
        for (User dbUser : users) {
            //logger.warning("user: "+dbUser.getLoginName()+" input:"+loginName);
            if (dbUser.getLoginName().equals(loginName)) {
                //logger.warning("User found "+dbUser.getLoginName());
                //session.setAttribute("user", dbUser);
                // return matching user
                return dbUser;
            }
        }
        logger.log(Level.SEVERE, "User does not exist! {0} @ {1}", new Object[]{loginName, new Date()});
        throw new RuntimeException("User does not exist!");
    }
}
