#!/bin/bash

trap 'stop' SIGINT

function errdie() {
  echo -e "\n\n${1}"
  exit 1
}

# This script is the entrypoint for starting the Abctransporter  application in a running container.
# It's split into three phases; pre-start, start, and post-start to split up tasks that
# should run at those different stages of starting the application

#
# Pre-start
#

prestart(){
    echo "[NEP][info] - Running pre-start steps..."
    echo ""
    
    echo "[NEP][info] - Finished pre-start steps."
}


#
# Start
#

start(){
  echo "[NEP][info] - Starting Tomcat..."
  nohup catalina.sh run &
  echo "[NEP][info] - Finished start steps."
}


#
# Post-start
#

poststart(){
    echo "[NEP][info] - Running post-start steps..."
    # Run any scripts or commands here that should happen after the Apache has started.
    #Installing naccess
    #echo "[NEP][info] - Installing naccess ..."
    #cd /usr/local/naccess-2.1.1
    #csh install.scr
    #creating symbolic link
    #ln -s /usr/local/naccess-2.1.1/naccess /usr/local/bin/
    #echo "[NEP][info] - Created symbolic links ..."

    printf "[NEP][info] - HTTP GET returns: "
    curl -sL -w "%{http_code}" "http://localhost:8888" -o /dev/null

    echo "[NEP][info] - Finished post-start steps."
}

#
# Stop
#

stop(){
    echo "[NEP][info] - Stopping application..."
    exit 0
}

# entrypoint

echo "[NEP][info] - Begining controlled startup..."
prestart
start
poststart
echo "[NEP][info] - Controlled startup finished!"

#
# run indefinitely, until error, or SIGINT
#
while true
do
    # nothing..
    sleep 100
done


