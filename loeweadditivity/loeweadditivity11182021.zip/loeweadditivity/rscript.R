pkgs = c('data.table',
        'DT', 
        'dplyr',
        'ggplot2',
        'kableExtra',
        'knitr',
        'latex2exp',
        'metR',
        'rhandsontable',
        'rootSolve',
        'shinydashboard',
        'tidyr',
        'viridis'
        )

install.packages(pkgs, repos='https://cran.rstudio.com/')