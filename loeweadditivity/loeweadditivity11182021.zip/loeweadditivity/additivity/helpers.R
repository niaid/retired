transform_GIA <- function(gia_df,
                          uRBC = 0,
                          iRBC = 100){
  gia_df$GIA <- (gia_df - urBC) / (iRBC - uRBC)
  return(gia_df)
  
}


est_gia <- function(par,
                    dose_A,
                    dose_B){
#  browser()
  beta_A <- par["beta_A"]
  beta_B <- par["beta_B"]
  gamma_A <- par["gamma_A"]
  gamma_B <- par["gamma_B"]
  tau_1 <- par["tau_1"]
  tau_2 <- par["tau_2"]
  
  A_star <- dose_A / beta_A
  B_star <- dose_B / beta_B
  lambda <- (A_star) / (A_star + B_star)
  u <- (A_star + B_star + tau_1 * A_star * B_star)
  v <- gamma_A * lambda + 
    gamma_B * (1 - lambda) +
    tau_1 * tau_2 * gamma_A * gamma_B * (lambda) * (1-lambda)
  psi <- log(2) * u^v
  gia_est <- 100 * (1 - exp(-psi))
  gia_est <- ifelse(is.nan(gia_est), 0, gia_est) 
  return(gia_est)
}

sse_gia <- function(par, gia){
  gia_est <- est_gia(par, gia$dose_A,
                     gia$dose_B)
  sse <- sum((gia$GIA - gia_est)^2)
  return(sse)
  
}

make_grid <- function (n = 40, par,
                       Amax = 2,
                       Bmax = 2){
  beta_A <- par["beta_A"]
  beta_B <- par["beta_B"]
  seq_A <- seq(0, beta_A * Amax, length.out = n)
  seq_B <- seq(0, beta_B * Bmax, length.out = n)
  grid_df <- expand.grid(dose_A = seq_A,
                         dose_B = seq_B)  

  return(grid_df)
  
}

#' Calculate Hewlett S
#'
#' @param best_pars vector of named best parameters
#' @param u_fun function for u
#' @param v_fun function for v1
#' @return Hewlett S
#' @export
calc_S <- function(best_pars, ed = 50){
 # browser()
  U <- max(best_pars[c("beta_A", "beta_B")])
  b <- rootSolve::uniroot.all(root_fxn_gen, interval = c(0, 10),
                              par = best_pars, ed = 50)
  if(length(b) == 0) b <- 100# <- NA
  # browser()
  return(min(1 / (2 * b), na.rm = TRUE))
}


#' Function to calculate the root to get GIA 50 value
#'
#' @param x a number between 0 and 100
#' @param par vector of named parameters
#' @param ed GIA value we want to calculate
#' @param u_fun function for u
#' @param v_fun function for v
#' @return difference between out and ed
root_fxn_gen <- function(x, par, ed = 50){
#  browser()
  gia <- data.frame(dose_A = x * par["beta_A"],
                    dose_B = x * par["beta_B"])
  out <- est_gia(par = par, dose_A = gia$dose_A,
                 dose_B = gia$dose_B)
  return(out - ed)
  
}



get_ed_line <- function(grid_width = 50,
                        par, ed_val = 50){
  
  beta_A <- par["beta_A"]
  beta_B <- par["beta_B"]
  
  vals_B <- seq(0, beta_B, length.out = grid_width)
  vals_A <- c(beta_A, rep(NA, grid_width - 2), 0)
  vals_A[2:(grid_width - 1)] <- sapply(2:(length(vals_B) - 1), function(ii){
    roots <- rootSolve::uniroot.all(root_ed_fxn, c(0, beta_A),
                           y = vals_B[ii],
                           par = par,
                           ed = ed_val)
    min(roots)[1]
  })
  df <- data.frame(dose_A = vals_A, dose_B = vals_B, GIA = ed_val)
  return(df)
  
  
  
}

root_ed_fxn <- function(x, y,
                        par, ed = 50){
  gia <- data.frame(dose_A = x,
                    dose_B = y)
  
  out <- est_gia(par = par, 
                 dose_A = gia$dose_A,
                 dose_B = gia$dose_B)
  return(out - ed)
  
}




#' Helper function for bootstrap
#' 
boot_gia <- function(par, gia,
                     gia_est,
                     n_sims = 100){
 # browser()
  ## Get standard error
  res2 <- (gia_est - gia$GIA)^2
  x <- (100 - gia$GIA)^2
  mod <- lm(res2~x)
  sd <- sqrt(abs(mod$fit))
  obs_gia <- gia$GIA
  df <- gia
  par_mat <- matrix(0, nrow = n_sims, ncol = length(par))
  for(ii in 1:n_sims){
    df$GIA <- gia_est + rnorm(length(gia_est), mean = 0, sd = sd)
    
    
    best_pars <- optim(par = par, fn = sse_gia,
                       gia = df)
    par_mat[ii,] <- best_pars$par
  }
  return(list(par_mat = par_mat))
}






#' Helper function to generate code to run an experiment
#'
#' @param levels_A levels of A used in the combination
#' @param levels_B levels of B used in the combination
#' @param par named vector of model parameters
#' @param n_rep number of total repetitions of experiment
#' @param n_sims number of simulations to run
#' @param noise_par named vector with 'a0' and 'a1' which are used to generate noise for the GIA.
#' @return NULL
#' @details prints out code to copy and paste into \code{R} to simulate the expected coverage of your experiment under your designed hypothesis
#' @example design_experiment()
design_experiment <- function(levels_A = c(0, 1 * 2^(-4:2)),
                              levels_B = c(0, 2 * 2^(-4:2)),
                              par = c("beta_A" = 1,
                                      "beta_B" = 2,
                                      "gamma_A" = .5,
                                      "gamma_B" = .5,
                                      "tau_1" = 3,
                                      "tau_2" = .05),
                              n_rep = 1,
                              n_sims = 100,
                              noise_par = c("a0" = 3,
                                            "a1" = .01)){
  
  cat(
    paste0("\nlibrary(loewesadditivity)\nlevels_A <- c(",
           paste(levels_A, collapse = ", "),
           ")\n",
           "levels_B <- c(",
           paste(levels_B, collapse = ", "),
           ")\n",
           "par <- c(",
           paste(paste0("  '", names(par), "' = ", par), collapse = ", \n"),
           ")\n",
           "my_grid <- design_grid(levels_A = levels_A, \n  levels_B = levels_B, \n",
           paste0("  n_rep = ", n_rep, ")\n"),
           "## SIMULATE COVERAGE\n",
           "sim_results <- simulate_coverage(",
           paste0("n_sims = ", n_sims, ",\n  "),
           paste0("n_boot = ", 100, ",\n  "),
           "experimental_grid = my_grid, \n  ",
           "model_par = par,\n  ",
           "alpha = .05,\n  ",
           paste0("noise_par = c(", paste0("'", names(noise_par), "' = ", noise_par, collapse = ", \n  "), "))\n"),
           "## LOOK AT RESULTS\n",
           "sim_results\n",
           "## Uncomment below to write the grid to a .csv file you can open in Excel or google spreadsheets\n",
           "#write.csv(sim_results, 'coverage_results.csv')\n"
    ))
  
  
  
  invisible("## Generated by loewes-additivity")
}

#' Function to design an experimental grid of combinations
#'
#' @param levels_A levels of A used in the combination
#' @param levels_B levels of B used in the combination
#' @param n_rep number of total repetitions of experiment
#' @return data frame with columns dose_A, dose_B, and GIA for all possible combinations
design_grid <- function(levels_A = c(0, 1 * 2^(-4:2)),
                        levels_B = c(0, 2 * 2^(-4:2)),
                        n_rep = 1){
  
  base_grid <- expand.grid(dose_A = levels_A,
                           dose_B = levels_B)
  A_seq <- rep(base_grid$dose_A, each = n_rep)
  B_seq <- rep(base_grid$dose_B, each = n_rep)
  df <- data.frame(dose_A = A_seq,
                   dose_B = B_seq,
                   GIA = 0)
  return(df)
}












