## app.R ##
library(shinydashboard)
library(rhandsontable)
library(data.table)
library(DT)
library(knitr)
library(kableExtra)
library(viridis)
library(ggplot2)
library(rootSolve)
library(latex2exp)
source("helpers.R")
library(tidyr)
library(metR)


load(file = "data/rh5_ama1ron2_list.rda")
load("data/cyrpa_ripr_list.rda")


ui <- htmlTemplate("index.html",  
                   
  dashboardmain = dashboardPage(skin = "red",
                    dashboardHeader(title = "Loewe's Additivity"),
                    dashboardSidebar(
                      sidebarMenu(
                        id = "tabs",
                        menuItem("Intro", tabName = "intro", icon = icon("star")),
                        menuItem(
                          "The Model",
                          tabName = "model",
                          icon = icon("calculator")
                        ),
                        menuItem("Data", tabName = "data", icon = icon("table")),
                        menuItem(
                          "Parameter estimates",
                          tabName = "par",
                          icon = icon("equals")
                        ),
                        menuItem(
                          "Graphs",
                          icon = icon("chart-area"),
                          startExpanded = FALSE,
                          menuItem(
                            "Response surface",
                            tabName = "response-surface",
                            icon = icon("paint-roller")
                          ),
                          menuItem(
                            "Response curves",
                            tabName = "response-curves",
                            icon = icon("chart-line")
                          ),
                          menuItem(
                            "Isobologram",
                            tabName = "iso",
                            icon = icon("chart-line")
                          )
                        ),
                        menuItem(
                          "Design an experiment",
                          tabName = "sims",
                          icon = icon("robot")
                        )
                      )
                    ), 
  dashboardBody(withMathJax(),
    # Boxes need to be put in a row (or column)
    tabItems(
      # First tab content
      tabItem(tabName = "intro",
              fluidRow(
                box(width = 12,
                  column(width = 5,
                  h2("Loewe's Additivity"),
                  h4("0. Learn about the model"),
                  h4("1. Enter your data"),
                  h4("2. Estimate parameters"),
                  h4("3. Visualize results"),
                  h4("4. Simulate")
                    ),
                  br(),
                  br(),
                column(width = 5,
                       actionButton("start_data", "Get started!",
                                    style="color: #fff; background-color: #337ab7; border-color: #2e6da4",
                                    width = 200),
                       br(),
                       br(),
                       actionButton("learnModel", "Learn about the model", width = 200),
                       br(),
                       br(),
                       actionButton("start_sim", "Design an experiment", width = 200)
                       )
              ))),
      tabItem(tabName = "model",
              fluidRow(box(width = 12,
                           h2("The model"),
                           actionButton("data2", "Enter Data", width = 150),
                           actionButton("sim2", "Design an Experiment", width = 150),
                           br(),
                           p("To estimate the GIA% for combinations of compound and compound B (e.g. in mg/mL), we use the the following formula."),
                           withMathJax(h4("$$GIA_i = 100\\% * (1 - \\exp(-\\psi_i))$$")),
                           withMathJax(h4("$$\\psi_i = log(2)u_i^{v_i}$$")),
                           withMathJax(h4("$$u_i = A^*_i + B^*_i + \\tau_1 A^*_i B^*_i$$")),
                           withMathJax(h4("$$v_i = \\gamma_A\\lambda_i + \\gamma_B (1-\\lambda_i) + \\tau_1 \\tau_2 \\gamma_A \\gamma_B\\lambda_i (1-\\lambda_i)$$")),
                           withMathJax(h4("$$A_i^* = A_i / \\beta_A$$")),
                           withMathJax(h4("$$B_i^* = B_i / \\beta_B$$")),
                           withMathJax(h4("$$\\lambda_i = A_i^* / (A_i^* + B_i^*)$$")),
                           withMathJax(p("The parameters are \\(\\beta_A, \\beta_B, \\gamma_A, \\gamma_B, \\tau_1, \\tau_2\\) where the \\(\\beta\\)s are the respective ED50s of the two compounds, the \\(\\gamma\\)s are shape parameters, and the \\(\\tau\\)s are interaction parameters.")),
                           withMathJax(p("Note that when \\(B_i=0\\), then the equation reduces to")),
                           withMathJax(h4("$$\\psi_i = log(2) (A_i^*)^{\\gamma_A},$$")),
                           withMathJax(p("which is a fairly standard way to measure monobodies.  The case is similar when \\(A_i = 0\\).  Finally note that when the dose is \\((\\beta_A, 0)\\) or \\((0, \\beta_B)\\), then the estimated GIA is 50%, which is what we expect."))
                           ))
      ),
      
      # Second tab content
      tabItem(tabName = "data",
              fluidRow(
                box(width = 12,
                    h2("Load/Enter data"),
                p("In this page, either select a pre-loaded set of data or enter your own."),
            #    p("uRBC and iRBC are the shown minimum and maximum observations but have no effect on the calculations in the next sections."),
                actionButton("estimate1", "Estimate parameters",
                             style="color: #fff; background-color: #337ab7; border-color: #2e6da4")
              )
              ),
              fluidRow(
                box(
                  h2("Experimental Data"),
                  p("For the Custom data, you can use Ctrl+C and Ctrl+V to copy and paste but right clicking is currently not supported"),
                  rHandsontableOutput("hot", height = 600)),
                       box(
                         h2("Meta Data"),
                         p("Enter the compound names here."),
                         br(),
                         rHandsontableOutput("hot2")),
#                         br(), br(),
                         #rHandsontableOutput("hot3")),
                box(
                  h2("Source"),
                  p("Choose custom and enter your data or choose one of the pre-loaded data sets."),
                  br(),
                radioButtons("data_source", NULL,
                             c("Custom" = "custom",
                               "RH5-AMA1RON2 (pre-loaded)" = "rh5ama1ron2",
                               "CyRPA-RIPR (pre-loaded)" = "cyrparipr"),
                selected = "rh5ama1ron2"),
                uiOutput("n_obs")
                )
               
              )
              
      ),
      tabItem(tabName = "par",
              fluidRow(box(width = 12,
                           actionButton("mod1", HTML("Model<br>Info"), width = 150),
                           actionButton("vis1", HTML("Visualize<br>Surface"), 
                                        width = 150),
                           actionButton("vis2", HTML("Visualize<br>Curves"), 
                                        width = 150),
                           actionButton("vis3", HTML("Visualize<br>Isobologram"), width = 150),
                           p("In this section, we estimate the model parameters from the data you loaded/entered previously.  We require initial values to help find the best parameters.  The process is not guaranteed to converge to a global maxima so we provide the sum of squared error (SSE) so the user can compare one set of starting values to another.  Smaller SSE is better."),
                           p("We estimate 95% CIs using a parametric bootstrap.  Select the number of parametric bootstraps to run.  More bootstraps will provide a more accurate CI but will take longer to compute."),
                           h3("Instructions"),
                           h4("1. Enter initial parameter value guesses and number of bootstrap simulations."),
                           h4("2. Click 'Estimate parameters.'")
                           )),
              fluidRow(
                box(width = 6,
                  h2("Initial guesses"),
                  column(width = 4,
                         numericInput(inputId = "beta_A",
                                      label = withMathJax("\\(\\beta_A\\)"),
                                      value = .5),
                         numericInput(inputId = "gamma_A",
                                      label = withMathJax("\\(\\gamma_A\\)"),
                                      value = .5),
                         numericInput(inputId = "tau_1",
                                      label = withMathJax("\\(\\tau_1\\)"),
                                      value = 0)  
                  ),
                  
                  column(width = 4,
                  numericInput(inputId = "beta_B",
                               label = withMathJax("\\(\\beta_B\\)"),
                               value = .5),
                  numericInput(inputId = "gamma_B",
                               label = withMathJax("\\(\\gamma_B\\)"),
                               value = .5),
                  numericInput(inputId = "tau_2",
                               label = withMathJax("\\(\\tau_2\\)"),
                               value = 0)
                  
                  )
                ),
                column(width = 6,
                       h4("Number of bootstrap simulations"),
                  numericInput("n_sims", NULL, value = 100,
                               width = 100,
                               min = 0, 
                               max = 5000,
                               step = 100),
                  actionButton("optim", 
                             "Estimate parameters",
                             style="color: #fff; background-color: #337ab7; border-color: #2e6da4"),
                  textOutput("load_data")
              )),
              fluidRow(
                box(width = 12,
                    h5("Minimized sum of square error results"),
                withMathJax(tableOutput("best_pars")),
                br(),
                br(),
                h5("Bootstrap Results"),
                withMathJax(tableOutput("par_tab")),
                h5("Hewlett S"),
                withMathJax(tableOutput("S_df")),
                h3("Output info"),
                p("The first table is the estimates found from the optimization of the sum of squared errors along with the total sum of squared errors for the input data set."),
                p("The second table (if applicable), is the result of the parametric bootstrap to obtain a 95% CI for the parameter estimates.  We report the 2.5, 50, and 97.5 marginal quantiles from the parametric bootstrap for each parameter"),
                p("The third table shows the estimate (mean) of Hewlett's S, which measures the interaction between compounds.  A value of \\(S > 1\\) indicates synergy, a value of \\(S < 1\\) indicates antagonism, and \\(S=1\\) indicates additivity.  We report the 2.5, 50, and 97.5 quantiles of parametric bootstrap of S as well.")
                )
              )
              ),
      tabItem(tabName = "response-surface",
              fluidRow(box(width = 12,
                h2("Estimated GIA surface"),
                plotOutput("surface")
              )
              )
      ),
      tabItem(tabName = "response-curves",
              fluidRow(box(width = 12,
                           h2("Estimated GIA curves with 95% CIs"),
                           plotOutput("linesA", height = 600),
                           br(),
                           plotOutput("linesB", height = 600)
                           ))
              ),
      tabItem(tabName = "iso",
              fluidRow(box(width = 12,
                        h2("Estimated Isobologram"),
                        plotOutput("iso")
                           ))
        
      ),
      tabItem(tabName = "sims",
              fluidRow(box(width = 12,
                           withMathJax(h2("Design an experiment")),
                           actionButton("sim_cov", 
                                        "Generate `R` code",
                                        style="color: #fff; background-color: #337ab7; border-color: #2e6da4"),
                           br(),
                           br(),
                           verbatimTextOutput('sim_code'),
                            h3("Instructions"),
              h4("1. Change the parameters, grid, and noise to your liking."),
              h4("2. Click 'Generate 'R' Code."),
              h4("3. Copy code into 'R' and run."),
              p("This section allows a way to estimate the power of our model to detect significant interactions for a given grid of dose combinations, experiment replications, and other model parameters.")
              
              )),
              box(width = 12,
                  h4("Input model parameters"),
                  p("Input your best guesses for the model parameters."),
                  p("Recall that \\(\\beta_A\\) and \\(\\beta_B\\) are the respective ED50s (in the same unit)."),
                  p("The shape parameters are \\(\\gamma_A\\) and \\(\\gamma_B\\), which in our general experience are between 0 and 1.  We recommend a starting value of 0.5."),
                  p("The interaction parameters are \\(\\tau_1\\) and \\(\\tau_2\\).  The relationship between Hewlett'S and \\(\\tau_1\\) are shown at the bottom of this page.  We recommend a small value of \\(\\tau\\) such as between 0 and .1 to start.  The initial estimate of \\(\\tau_1\\) is typically more important than the initialestimate of \\(\\tau_2\\), in our experience.  Warning:  if $$\\tau_2 = -2\\frac{\\gamma_A + \\gamma_B}{\\tau_1\\gamma_A\\gamma_B }$$ then estimate of GIA will be 50%, regardless of the dose combo."),
              column(width = 4,
                     numericInput(inputId = "beta_A2",
                                  label = withMathJax("\\(\\beta_A\\)"),
                                  value = .5),
                     numericInput(inputId = "gamma_A2",
                                  label = withMathJax("\\(\\gamma_A\\)"),
                                  value = .5)
              ),
              column(width = 4,
                     
                     numericInput(inputId = "beta_B2",
                                  label = withMathJax("\\(\\beta_B\\)"),
                                  value = .5),
                     numericInput(inputId = "gamma_B2",
                                  label = withMathJax("\\(\\gamma_B\\)"),
                                  value = .5)
              ),
              column(width = 4,
                     
                     numericInput(inputId = "tau_12",
                                  label = withMathJax("\\(\\tau_1\\)"),
                                  value = 0),
                     numericInput(inputId = "tau_22",
                                  label = withMathJax("\\(\\tau_2\\)"),
                                  value = 0)
              )),
 
              fluidRow(box(width = 12,
                           h3("Potential Grid of Points"),
                           h4("In terms of doubling/halving the ED50s"),
                           p("We assume that the researcher is going have a grid of combinations of different doubling/halving values of the estimated ED50 of the doses.  Use the below parameters to make your ideal grid.  The number of replicates is the number of times we expect the researcher to repeat the entire grid of combinations."),
                           column(width = 6,
                           sliderInput("slide_A", label = withMathJax("Range of ED50A \\(2^{-k}\\)"),
                                       min = -6, max = 4, value = c(-4,2), width = 200),
                           numericInput("n_ptsA", label = "# of points for A",
                                        min = 3, max = 30, value = 6, width = 200),
                           sliderInput("slide_B", label = withMathJax("Range of ED50B \\(2^{-k}\\)"),
                                       min = -6, max = 4, value = c(-4,2), width = 200),
                           numericInput("n_ptsB", label = "# of points for B",
                                        min = 3, max = 30, value = 6, width = 200),
                           numericInput("n_reps", label = "Number of replicates",
                                        min = 1, max = 100, step = 1, value = 1, width = 200)
                           ),
                           column(width = 6,
                                  plotOutput("grid", width = 250, height = 300)
                           ))),
              fluidRow(box(width = 12,
                           h3("Noise simulation"),
                           h4("We simulate noise according to the following model"),
                           withMathJax(h4("$$GIA_{sim,i} = GIA_i + \\epsilon_i$$")),
                           withMathJax(h4("$$\\epsilon_i \\sim N(0, \\sigma_i^2)$$")),
                           withMathJax(h4("$$\\sigma^2_i = \\left |a_0 + a_1(100 - GIA_i)^2 \\right |$$")),
                           withMathJax(p("This noise structure allows for larger error for smaller values of GIA and smaller error for larger values of GIA.  See the below graph to see what the standard errors look like for your selection of \\(a_1\\) and \\(a_2\\).")),
                           p("This step is very important to the power simulation.  If the errors are too small, than the power to detect significant interactions will be overestimated."),
                           numericInput("a0", withMathJax("\\(a_0\\)"), value = 3, width = 100),
                           numericInput("a1", withMathJax("\\(a_1\\)"), value = .01, width = 100,
                                        min = 0, max = .1, step = .0001),
                           plotOutput("error")
                           )),
              
              fluidRow(box(width = 12,
                           p("Below we have provided a plot of the typical relationship between $\\tau_1$ and S"),
                           plotOutput("tau_plot")
              ))
             
      
    )
  )
)
)#dasboard end
)#index end


server <- function(input, output, session) {
  

  
  ## update tabs
  observeEvent(input$learnModel, {
    updateTabItems(session, "tabs", "model")
  })
  
  ## update tabs
  observeEvent(input$start_data, {
    updateTabItems(session, "tabs", "data")
  })
  
  ## update tabs
  observeEvent(input$start_sim, {
    updateTabItems(session, "tabs", "sims")
  })
  
  ## update tabs
  observeEvent(input$estimate1, {
    updateTabItems(session, "tabs", "par")
  })
  
  ## update tabs
  observeEvent(input$mod1, {
    updateTabItems(session, "tabs", "model")
  })
  
  observeEvent(input$data2, {
    updateTabItems(session, "tabs", "data")
  })
  
  observeEvent(input$mod1, {
    updateTabItems(session, "tabs", "sims")
  })
  
  observeEvent(input$vis3, {
    updateTabItems(session, "tabs", "iso")
  })
  
  observeEvent(input$vis2, {
    updateTabItems(session, "tabs", "response-curves")
  })
  
  observeEvent(input$vis1, {
    updateTabItems(session, "tabs", "response-surface")
  })
  
  
  output$error <- renderPlot({
    x <- seq(-5, 105, by = .5)
    y <- abs(input$a0 + input$a1 * (100 - x)^2)
    ggdf <- data.frame(x = x, y = sqrt(y))
    
     ggplot(data = ggdf, aes(x = x, y = y)) + geom_line(size = 2) +
       labs(x = "True GIA%", 
            y = TeX("Standard deviation of $\\;\\epsilon_i$"),
            title = "Proposed noise structure") +
       theme_bw(base_size = 16)
    
  })
  
  
  
  set.seed(122)
  histdata <- rnorm(500)
  
  df <- data.frame(dose_A = 0, dose_B = 0, GIA = 0)
  
  output$grid <- renderPlot({
    A_seq <- c(0, 2^(seq(input$slide_A[1], input$slide_A[2], length.out = input$n_ptsA - 1)))
    B_seq <- c(0, 2^(seq(input$slide_B[1], input$slide_B[2], length.out = input$n_ptsB - 1)))
    base_grid <- expand.grid(dose_A = A_seq * input$beta_A2, dose_B = B_seq * input$beta_B2)
    A_seq <- rep(base_grid$dose_A, each = input$n_reps)
    B_seq <- rep(base_grid$dose_B, each = input$n_reps)
    df <- data.frame(dose_A = A_seq, dose_B = B_seq, GIA = 0)
    ggplot(data = df, aes(x = dose_A, y = dose_B)) + geom_point() +
      labs(x = "Dose A (mg/mL)", y = "Dose B (mg/mL)",
           title = "Potential Grid Points",
           subtitle = paste(nrow(df), "Total Points")) +
      theme_bw(base_size = 12) +
      scale_x_sqrt() + scale_y_sqrt()
  })

  
  
  
  
  dose_A <- c(0, 2^(-4:2))
  dose_B <- c(0, 2^(-4:2))
  base_df <- expand.grid(dose_A = dose_A,
                    dose_B = dose_B,
                    GIA = 0)
  

  
  
  v3 <- reactiveValues(show_code = FALSE,
                       levels_A = NULL,
                       levels_B = NULL,
                       par = NULL,
                       n_rep = NULL,
                       noise_par = NULL
                       )
  
  observeEvent(input$sim_cov, {
    
    ## COVERAGE SIMULATIONS
    A_seq <- c(0, 2^(seq(input$slide_A[1], input$slide_A[2], length.out = input$n_ptsA - 1)))
    B_seq <- c(0, 2^(seq(input$slide_B[1], input$slide_B[2], length.out = input$n_ptsB - 1)))
    base_grid <- expand.grid(dose_A = A_seq * input$beta_A2, dose_B = B_seq * input$beta_B2)
    A_seq <- rep(base_grid$dose_A, each = input$n_reps)
    B_seq <- rep(base_grid$dose_B, each = input$n_reps)
    df <- data.frame(dose_A = A_seq, dose_B = B_seq, GIA = 0)
    print("ok")
    par <- c("beta_A" = input$beta_A2,
      "beta_B" = input$beta_B2,
      "gamma_A" = input$gamma_A2,
      "gamma_B" = input$gamma_B2,
      "tau_1" = input$tau_12,
      "tau_2" = input$tau_22)
    show_code <- TRUE
    v3$levels_A <- A_seq
    v3$levels_B <- B_seq
    v3$par <- par
    v3$n_rep <- input$n_reps
    v3$noise_par <- c("a0" = input$a0,
                      "a1" = input$a1)
    v3$show_code <-  show_code
 

  })
  
  output$sim_code <- renderPrint({
    if(!v3$show_code) return("Click the button when you are ready")
    design_experiment(levels_A = v3$levels_A,
                      levels_B = v3$levels_B,
                      par = v3$par,
                      n_rep = v3$n_rep,
                      n_sims = 100,
                      noise_par = v3$noise_par)
  })
  
  
  output$pow_sig <- renderUI({

    if(is.null(v3$tau_zero) | (length(v3$tau_zero) == 0)){
      withMathJax("Times \\(\\tau_1=0\\) lay in the 95% CI: ")
    } else{

      withMathJax(paste0("Times \\(\\tau_1=0\\) lay in the 95% CI: ", 
                 sum(v3$tau_zero) / length(v3$tau_zero) * 100, "%"))
    }
  })
  

  output$load_data <- renderText({
    
    out <- is.null(input$hot)
    if(out){
      msg <- "First load data in data tab"
    } else if(v$bad_params){
      msg <- "You are either missing numbers in the data or have initial parameters that do not return a viable result."
    } else {
      msg <- "Click button to estimate parameters"
    }
    return(msg)
  })


  
  output$hot = renderRHandsontable({
    if(input$data_source == "rh5ama1ron2"){
      df <- rh5_ama1ron2_list$data
      
    } else if(input$data_source == "cyrparipr"){
      df <- cyrpa_ripr_list$data
    }else if(input$data_source == "custom"){
      if(!is.null(v2$df)){
        df <- v2$df
      } else {
        df <- base_df
      }
      
    }
    rhandsontable(
      df
    ) %>% hot_cols(renderer=htmlwidgets::JS("safeHtmlRenderer"))
  })
  
  
  meta_df_base <- data.frame(name_A = "Compound A",
                        name_B = "Compound B")
  uirbc_base <- data.frame(uRBC = 0,
                      iRBC = 100)
  output$hot2 = renderRHandsontable({
    if(input$data_source == "rh5ama1ron2"){
      meta_df <- data.frame(name_A = rh5_ama1ron2_list$name_A,
                            name_B = rh5_ama1ron2_list$name_B)
      
    } else if(input$data_source == "cyrparipr"){
      print(cyrpa_ripr_list$name_A)
      meta_df <- data.frame(name_A = cyrpa_ripr_list$name_A,
                            name_B = cyrpa_ripr_list$name_B)
    }else if(input$data_source == "custom"){
      meta_df <- meta_df_base
    }

    rhandsontable(meta_df) 
  })
  
  output$hot3 = renderRHandsontable({
    if(input$data_source == "rh5ama1ron2"){
      uirbc <- data.frame(uRBC = rh5_ama1ron2_list$uRBC,
                            iRBC = rh5_ama1ron2_list$iRBC)
      
    } else if(input$data_source == "cyrparipr"){
     uirbc <- data.frame(uRBC = cyrpa_ripr_list$uRBC,
                            iRBC = cyrpa_ripr_list$iRBC)
    }else if(input$data_source == "custom"){
      uirbc <- uirbc_base
    }
    rhandsontable(uirbc)
  })
  

  
  #use hot_to_r to glue 'transform' the rhandsontable input into an R object
  #
  output$my_tab = renderDataTable({
    names <- hot_to_r(input$hot)
    datatable(names,
              options = list(lengthMenu = c(100, 50, 5),
                             pageLength = 100)
    )
  })
   
   
  ### Estimate params
  ### 
  

    output$linesA <- renderPlot({
    if(is.null(v$gia_df)) return(NULL)
    meta_df <- hot_to_r(input$hot2)
    gg_df <- v$gia_df
    gg_df
    
    print(head(v$gia_df))
    ggplot() + geom_ribbon(data = gg_df,
                           aes(x = dose_A,
                               ymin = est + lower,
                               ymax = est + upper,
                               fill = dose_B), 
                           alpha = .3) +
      geom_line(data = gg_df,
                         aes(x = dose_A,
                             y = est,
                             col = dose_B),
                         size = 1) +
      facet_wrap(~dose_B, ncol = 3) + #,
               #  labeller = label_both) +
      theme_bw(base_size = 16) +
      scale_color_viridis(name = paste(meta_df$name_B, "(mg/mL)")) +
      scale_fill_viridis(name = paste(meta_df$name_B, "(mg/mL)")) +
      geom_point(data = gg_df,
                 aes(x = dose_A,
                     y = GIA)) +
      labs(x = paste(meta_df$name_A, "(mg/mL)"),
           y = "GIA%")
  })
    
    
    output$linesB <- renderPlot({
      if(is.null(v$gia_df)) return(NULL)
      meta_df <- hot_to_r(input$hot2)
      gg_df <- v$gia_df
      gg_df
      
      print(head(v$gia_df))
      ggplot() + geom_ribbon(data = gg_df,
                             aes(x = dose_B,
                                 ymin = est + lower,
                                 ymax = est + upper,
                                 fill = dose_A), 
                             alpha = .3) +
        geom_line(data = gg_df,
                  aes(x = dose_B,
                      y = est,
                      col = dose_A),
                  size = 1) +
        facet_wrap(~dose_A, ncol = 3) + #,
        #  labeller = label_both) +
        theme_bw(base_size = 16) +
        scale_color_viridis(name = paste(meta_df$name_A, "(mg/mL)")) +
        scale_fill_viridis(name = paste(meta_df$name_A, "(mg/mL)")) +
        geom_point(data = gg_df,
                   aes(x = dose_B,
                       y = GIA)) +
        labs(x = paste(meta_df$name_B, "(mg/mL)"),
             y = "GIA%")
    })
    

  
  v <- reactiveValues(best_pars = NULL,
                      tab = NULL,
                      par_tab = NULL,
                      S_df = NULL,
                      did_est = FALSE,
                      did_boot = FALSE,
                      par = NULL,
                      gia_df = NULL,
                      bad_params = FALSE)
  
  observeEvent(input$optim,{
    v$bad_params <- FALSE
    v$did_est <- FALSE
    par <- c("beta_A" = input$beta_A,
            "beta_B" = input$beta_B,
            "gamma_A" = input$gamma_A,
            "gamma_B" = input$gamma_B,
            "tau_1" = input$tau_1,
            "tau_2" = input$tau_2)
    print(par)
    if(is.null(input$hot)) return(NULL)
    gia_df <- hot_to_r(input$hot)
    
    try <- sse_gia(par = par,
                   gia = gia_df)
    if(is.na(try)){
      v$bad_params <- TRUE
      return(NULL)
    }
    best_pars <- optim(par = par, fn = sse_gia,
                       gia = gia_df)
    print(best_pars$par)
    tab <- matrix(c(best_pars$par, best_pars$val), nrow = 1)
    tab <- as.data.frame(tab)
    tab <- data.frame(Type = "Est.", tab)
    
    v$tab <- tab
    v$best_pars <- best_pars$par
    
    v$did_est <- TRUE
    
    S_df <- data.frame(Mean = 0, Q2.5 = NA, Q50 = NA, Q97.5 = NA)
    S_df$Mean <- calc_S(best_pars$par, ed = 50)
    v$S_df <- S_df
    
 ##########################################   
    if(input$n_sims > 0){
   #   browser()
      print("boot")
      ## Simulate error
      best_gia <- est_gia(par = best_pars$par,
                          dose_A = gia_df$dose_A,
                          dose_B = gia_df$dose_B)
      res2 <- (gia_df$GIA - best_gia)^2
      mod <- lm(res2~gia_df$GIA)
      err_mat <- matrix(0, nrow = length(res2),
                        ncol = input$n_sims)
      par_mat <- matrix(0, nrow = input$n_sims, 
                        ncol = length(best_pars$par))
      boot_resids <- matrix(0, length(res2),
                            ncol = input$n_sims)
      S_vec <- numeric(length(input$n_sims))
      sigma2 <- ifelse(mod$fit > 0, mod$fit, .5)
      for(ii in 1:input$n_sims){
        err_mat[,ii] <- rnorm(n = length(res2),
                              mean = 0,
                              sd = sqrt(sigma2))
      }
      
      
      ## get parameter values
      gia_boot <- gia_df
      gia_boot$GIA <- best_gia
    #  browser()
      for(jj in 1:input$n_sims){
        new_data <- gia_boot
        new_data$GIA <- gia_boot$GIA + err_mat[,jj]
        
        
        boot_pars <- optim(best_pars$par, fn = sse_gia,
                           gia = new_data)
        par_mat[jj,] <- boot_pars$par
        boot_est <- est_gia(par = boot_pars$par,
                            dose_A = new_data$dose_A,
                            dose_B = new_data$dose_B)
        boot_resids[,jj] <- boot_est - new_data$GIA
        S_vec[jj] <- calc_S(boot_pars$par, ed = 50)
      }
      
      
      par_sum <- apply(par_mat, 2, quantile,
                       prob = c(.025, .5, .975))
      print(par_sum)
      
      par_sum <- as.data.frame(par_sum)
      v$par_tab <- data.frame(Type = c("2.5 Quantile",
                                     "50 Quantile",
                                     "97.5 Quantile"),
                            par_sum,
                            SSE = NA)
      rownames(v$par_tab) <- NULL
      
      #browser()
      
      gia_df$median <- apply(boot_resids, 1, quantile,
                             prob = .5)
      gia_df$lower <- apply(boot_resids, 1, quantile,
                     prob = .025) - gia_df$median
      gia_df$upper <- apply(boot_resids, 1, quantile,
                            prob = .975) - gia_df$median
      gia_df$est <- best_gia
      S_df$Q2.5 <- quantile(S_vec, .025)
      S_df$Q50 <- quantile(S_vec, .5)
      S_df$Q97.5 <- quantile(S_vec, .975)
      
      print(S_df)
      v$S_df <- S_df
      v$gia_df <- gia_df
      
      
      
      
    }
    
  })
  

    
    
    
   
 
  
  
  output$best_pars <- function(){
    if(is.null(v$tab)) return(NULL)
    v$tab %>% kable("html", digits = 3,
                    col.names = c("Type",
                                  "\\(\\beta_A\\)",
                                  "\\(\\beta_B\\)",
                                  "\\(\\gamma_A\\)",
                                  "\\(\\gamma_B\\)",
                                  "\\(\\tau_1\\)",
                                  "\\(\\tau_2\\)", 
                                  "SSE"),
                                  align = "c",
                    escape = FALSE) %>%
      kable_styling("striped", full_width = T)

  }
  
  
  output$par_tab <- function(){
    if(is.null(v$par_tab)) return(NULL)
    v$par_tab %>% kable("html", digits = 3,
                    col.names = c("Type",
                                  "\\(\\beta_A\\)",
                                  "\\(\\beta_B\\)",
                                  "\\(\\gamma_A\\)",
                                  "\\(\\gamma_B\\)",
                                  "\\(\\tau_1\\)",
                                  "\\(\\tau_2\\)",
                                  "SSE"),
                    align = "c",
                    escape = FALSE) %>%
      kable_styling("striped", full_width = T)
    
  }
  
  output$S_df <- function(){
    if(is.null(v$S_df)) return(NULL)
    v$S_df %>% kable("html", digits = 3,
                        align = "c",
                        escape = FALSE) %>%
      kable_styling("striped", full_width = T)
    
  }
  
  output$iso <- renderPlot({
    if(!v$did_est) return(NULL)
   # browser()
    beta_A <- v$best_pars["beta_A"]
    beta_B <- v$best_pars["beta_B"]
    ed50_df <- get_ed_line(grid_width = 50,
                           par = v$best_pars,
                           ed_val = 50)
    
    S1 <- v$S_df$Q2.5
    S2 <- v$S_df$Q97.5
    SM <- v$S_df$Q50
    S_CI <- data.frame( x =  1 / (2 * c(S1, S2))  ,
                        y =  1 / (2 * c(S1, S2)),
                        type = "Inverse Hewlett S")
    
    meta_df <- hot_to_r(input$hot2)
    
    ed50_df$type <- "Estimate"
    dummy <- seq(1, 0, length.out = 100)
    df2 <- data.frame(dose_A = dummy * v$best_pars["beta_A"] , 
                      dose_B =(1 -dummy ) * v$best_pars[ "beta_B"] ,
                      type = "Baseline")
    g <- ggplot(data = ed50_df, aes(x = dose_A / v$best_pars[ "beta_A"],
                                     y = dose_B / v$best_pars["beta_B"],
                                     col = type)) +
      geom_line(size = 2) +
      geom_line(data = df2,  linetype = "dashed",
                size = 2) +
      geom_line(data = S_CI, aes(x = x, y = y),
                size = 2) +
      theme_bw(base_size = 13) +
      scale_color_manual(values = c("red", "black", "cornflowerblue"),
                         name = "Type") +
      labs(x = paste(meta_df$name_A, " / ED50"),
           y = paste(meta_df$name_B, " / ED50")) +
      theme(legend.position = "bottom")
    
    if(is.null(g)) return(null)
    return(g)
    
   
    
  })
  
  output$tau_plot <- renderPlot({
   
  #  browser()
    tau_df <- data.frame(tau1 = seq(-.95, 50, by = .5), S = NA)
    tau_df$b <- ifelse(abs(tau_df$tau1) > 0.00000001, 
                       -1 / tau_df$tau1 * (1 - sqrt(1 + tau_df$tau1)), .5)
    tau_df$S <- 1 /(2 * tau_df$b)
    tau_df$tau2 <- -2 * (input$gamma_A2 + input$gamma_B2) / 
      (tau_df$tau1 * input$gamma_A2 * input$gamma_B2)
    
    melt_df <- tau_df %>% pivot_longer(-c(tau1, b))
                       
    
    ggplot(data = tau_df,
           aes(x = tau1,
               y = S) )+ 
      geom_line(size = 2) +
      theme_bw(base_size = 15) + 
      labs(x = TeX("$\\tau_1$"), y = "Hewlett S",
                   title = TeX("Relationship between $\\tau_1$ and S")) #+
     # facet_wrap(~name, scales = "free")
    
    
  })
  
  output$surface <- renderPlot({
    if(!v$did_est) return(NULL)
    beta_A <- v$best_pars["beta_A"]
    beta_B <- v$best_pars["beta_B"]
    gia_obs <- hot_to_r(input$hot)
    Amax <-  max(gia_obs$dose_A / beta_A)
    Bmax <- max(gia_obs$dose_B / beta_B)
    #browser()
    df_grid <- make_grid(n = 40, par = v$best_pars,
                         Amax = Amax,
                         Bmax = Bmax)
    df_grid$GIA <- est_gia(par = v$best_pars,
                           dose_A = df_grid$dose_A,
                           dose_B = df_grid$dose_B)
    

    
    meta_df <- hot_to_r(input$hot2)
    
    g1 <- ggplot() +
      geom_tile(data = df_grid,
                aes(x = dose_A / beta_A , 
                    y = dose_B / beta_B,
                    fill = GIA)) +
      viridis::scale_fill_viridis(option = "magma",
                                  limits = c(-10,120),
                                   name = "GIA") +
      labs(x = paste(meta_df$name_A,
                     "scaled by ED50"),
           y = paste(meta_df$name_B,
                     "scaled by ED50")) +
      theme_bw(base_size = 20) +
      geom_contour(data = df_grid,
                   aes( x = dose_A / beta_A,
                   y = dose_B / beta_B,
                   z = GIA),  col = "white") +
      metR::geom_text_contour(data = df_grid,
                              ggplot2::aes(x = dose_A / beta_A,
                                           y = dose_B / beta_B,
                                           z = GIA))
    
    ## Add observations
    g1 <- g1 + ggplot2::geom_point(data = gia_obs,
                                   ggplot2::aes(x = dose_A / beta_A,
                                                y = dose_B / beta_B), size = 5,
                                   col = "black") +
      ggplot2::geom_point(data = gia_obs,
                          ggplot2::aes(x = dose_A / beta_A,
                                       y = dose_B / beta_B,
                                       col = GIA), size = 3) +
      viridis::scale_color_viridis(option = "magma",
                                  limits = c(-10,120),
                                  name = "GIA") #+
      #scale_x_sqrt()

    #  ggplot2::coord_cartesian(xlim = c(Amin, Amax), ylim = c(Bmin, Bmax)) +
    #  ggplot2::labs(...)
    ##
    g1
  })
  
  
  ############
  ############ NUMBER OF OBSERVATIONS FOR DATA
  output$n_obs <- renderUI({
    if(input$data_source == "custom")
    tagList(
      numericInput("obs", "Number of observations", value = 36,
                   min = 8, step = 1, width = 200)
    )
  })
  
  v2 <- reactiveValues(df = NULL)
  
  observeEvent(input$obs, {

    v2$df <- data.frame(dose_A = 0, dose_B = 0, GIA = rep(0, input$obs))
    
  })
  
  
}

shinyApp(ui, server)