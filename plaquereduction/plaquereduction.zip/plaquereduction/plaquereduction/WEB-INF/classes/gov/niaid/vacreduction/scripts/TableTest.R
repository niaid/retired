
# Contingency table script for Steve Whitehead's webtool

#usage:
# R CMD BATCH --slave --no-save --no-restore '--args a=XX b=XX c=XX d=XX' TableTest.R outFile

args=(commandArgs(TRUE));      
      
if(length(args)==0){
    cat("No arguments supplied.")
 } else{
     for(i in 1:length(args)){
		eval(parse(text=args[[i]]))
     }
}


# input list:

# a         count in cell "A"
# b         count in cell "B"
# c         count in cell "C"
# d         count in cell "D"
# cNames    column names
# rNames    row names

TableTest = function(a,b,c,d,cNames = c("c1","c2"),rNames = c("r1","r2")){                             # create function for table analysis

	mat = matrix(c(a,b,c,d),nc=2,nr=2,dimnames = list(rNames,cNames))                                # create a 2x2 table from data

	Pea = chisq.test(mat)                                                                            # compute Pearson's chi-square test for table

	Fsh = fisher.test(mat, alternative="less")                                                                           # compute Fisher's exact test for table

	#print(mat)                                                                                       # Print results
	
	print(Fsh)

	
	Fsh2=fisher.test(mat, alternative="greater")
	
	print(Fsh2)
	
	Fsh3=fisher.test(mat);
	
	print(Fsh3)
	
	print(Pea)
	
}

# Define sample inputs and run example

#a         = 10
#b         = 22
#c         = 17
#d         = 4
cNames    = c("Yes","No")
rNames    = c("Positive", "Negative")

TableTest(a,b,c,d,cNames,rNames)


