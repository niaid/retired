
#usage:
# R CMD BATCH --slave --no-save --no-restore '--args m1=XX m2=XX s1=XX s2=XX n1=X n2=X' StudentTTest.R outFile

args=(commandArgs(TRUE));      
      
if(length(args)==0){
    cat("No arguments supplied.")
 } else{
     for(i in 1:length(args)){
		eval(parse(text=args[[i]]))
     }
}


StudentsT <-function(m1, m2, s1, s2, n1, n2, null = 0){                                                # create function for T-test
	T   = (m1 - m2) / sqrt(((s1^2)/n1) + ((s2^2)/n2))                                                # compute Student's T-statistic
	df  = ((((s1^2)/n1) + ((s2^2)/n2))^2) / ((((s1^2)/n1)^2)/(n1 - 1) + (((s2^2)/n2)^2)/(n2 - 1))    # compute degrees of freedom
	p   = 2*pt(q = abs(T), df = df, ncp = null, lower.tail = FALSE)                                  # compute two-sided p-value
	#out = list(statistic = round(T, 4), df = round(df, 4), p = round(p, 4))
    out = list(statistic = round(T, 4), df = trunc(df+0.5), p = round(p, 4))
    # create a list of output and round numbers to 4 decimal places
	}                                                                                      # display output
	
	

m<-StudentsT(m1,m2,s1,s2,n1,n2)

print (m);
	