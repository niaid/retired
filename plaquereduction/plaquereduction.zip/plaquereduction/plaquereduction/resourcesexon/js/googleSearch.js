//updated by Song Chen on 3/24/2010

//search settings to the search result page

//var sPage = "/_LAYOUTS/NIAID.Internet.Controls/SearchResults.aspx?getfields=description&q=";
var sPage ="http://www.niaid.nih.gov/_LAYOUTS/NIAID.Internet.Controls/SearchResults.aspx?getfields=description&q=";
//var linksPage = "/_LAYOUTS/NIAID.Internet.Controls/SearchResults.aspx?getfields=description&as_lq="
var linksPage = "http://www.niaid.nih.gov/_LAYOUTS/NIAID.Internet.Controls/SearchResults.aspx?getfields=description&as_lq=";

var sPath = window.location.pathname;

//main site search (top right corner), on enter key pressed
function doSearch(e, input) {
  var is_major = parseInt(navigator.appVersion);
  var is_minor = parseFloat(navigator.appVersion); 
  var agt = navigator.userAgent.toLowerCase(); 
  var is_mac = (agt.indexOf('mac') != -1);
  var is_ie = ((agt.indexOf('msie') != -1) && (agt.indexOf('opera') == -1));
  var searchVal;
  
   searchVal = encodeURIComponent(input);
  
  if(e.keyCode == 13){
    if(input.length>0){

       window.location=sPage + searchVal;

	  return(false);
    }else{
      return(false);
    }
  }else{
    return(true);
  }
}

//main site search search button click
function doSearchClick(e, input) {
  var is_major = parseInt(navigator.appVersion);
  var is_minor = parseFloat(navigator.appVersion); 
  var agt = navigator.userAgent.toLowerCase(); 
  var is_mac = (agt.indexOf('mac') != -1);
  var is_ie = ((agt.indexOf('msie') != -1) && (agt.indexOf('opera') == -1));
  var searchVal;
  
  searchVal = encodeURIComponent(input);

  if(input.length>0){

    window.location=sPage + searchVal;
    
    return(false);
  }else{
    return(false);
  }
}

//for advanced search page, on key press 
function GoogleAdvancedSearch(e, q, epq, oq, eq, num, lr, filetype, qdr, occt) {
  var is_major = parseInt(navigator.appVersion);
  var is_minor = parseFloat(navigator.appVersion); 
  var agt = navigator.userAgent.toLowerCase(); 
  var is_mac = (agt.indexOf('mac') != -1);
  var is_ie = ((agt.indexOf('msie') != -1) && (agt.indexOf('opera') == -1));
  var qFiletype = "";

  q = encodeURIComponent(q);
  epq = encodeURIComponent(epq);
  oq = encodeURIComponent(oq);
  eq = encodeURIComponent(eq);
 
  if (filetype.length > 0) {
    qFiletype = " filetype%3A" + filetype;
  }
  
   if(e.keyCode == 13){
    if(q.length>0 || epq.length>0 || oq.length>0 || eq.length>0){
      window.location= sPage + q + qFiletype + '&num=' + num + '&as_epq=' + epq + '&as_oq=' + oq + '&as_eq=' + eq + '&lr=' + lr + '&as_qdr=' + qdr + '&as_occt=' + occt;
	  return(false);
    }else{
      return(false);
    }
  }else{
    return(true);
  }
}

//for advanced search page, onclick event
function GoogleAdvancedSearchClick(q, epq, oq, eq, num, lr, filetype, qdr, occt) {
  var is_major = parseInt(navigator.appVersion);
  var is_minor = parseFloat(navigator.appVersion); 
  var agt = navigator.userAgent.toLowerCase(); 
  var is_mac = (agt.indexOf('mac') != -1);
  var is_ie = ((agt.indexOf('msie') != -1) && (agt.indexOf('opera') == -1));
  var qFiletype = "";
 
  q = encodeURIComponent(q);
  epq = encodeURIComponent(epq);
  oq = encodeURIComponent(oq);
  eq = encodeURIComponent(eq);

  if (filetype.length > 0) {
    qFiletype = " filetype%3A" + filetype;
  }

  if(q.length>0 || epq.length>0 || oq.length>0 || eq.length>0){
    window.location= sPage + q + qFiletype + '&num=' + num + '&as_epq=' + epq + '&as_oq=' + oq + '&as_eq=' + eq + '&lr=' + lr + '&as_qdr=' + qdr + '&as_occt=' + occt;
  }else{
    return(false);
  }
}

//advanced serach link to page, on enter key pressed
function linkToPage(event, lq) {
	if(event.keyCode == 13){
		linkToPageClick(lq);
	} else {
	  return(true);
	}
}

//advanced search link to page button
function linkToPageClick(lq) {
	if(lq.length>0) {
	  var regexp = new RegExp("^(?:http|https|ftp)://[a-zA-Z0-9\.\-]+(?:\:\d{1,5})?(?:[A-Za-z0-9\-\\_\.\;\:\@\&\=\+\$\,\?/]|%u[0-9A-Fa-f]{4}|%[0-9A-Fa-f]{2})*$","i");
	  if (regexp.test(lq)) {
	     window.location= linksPage + encodeURIComponent(lq);
	  } else {
	     alert('Please enter a valid url, format: http://www.niaid.nih.gov');
	  }
	}
	else {
	  return(false);
	}
}

//search result page, search on enter key pressed
function BodySearch(event, input)
{
    if(event.keyCode == 13)
    { 
     return BodySearchClick(input);
    }
    return(true);	
}

//serach result page, main search in the middle of the page
function BodySearchClick(input)
{
    if (input.length>0)
    {
      window.location = sPage + encodeURIComponent(input);

      return false;
    } else {
     return false;
    }
}

//serach result page, clear search input
function clearAll()
{
    document.forms[0].q.value = "";
    restrict = "";
}
  