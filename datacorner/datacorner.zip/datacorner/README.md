# Docker-based Drupal 8 Installation

## Introduction

This repository conssists of Dockerized Drupal 8. Running Drupal 8, Apache 2.4, MySql 5.7 and PHP 7. These instructions will get you a copy of the project up and running on your local machine. 

## Stack

The  stack consist of the following containers:

| Container     | Versions                | Service name    | Image                              | Default |
| ------------- | ----------------------- | --------------- | ---------------------------------- | ------- |
| [Apache+php]  | 2.4 * 7.2               | `bcbb_drupal`     | [php:7.2-apache]                 |         |
| [mysql]       | 5.7                     | `bcbb_mysql_db`   | [mysql/5.7]                      |         |

### Prerequisites

In order to have a running instance of this application the following tools are pre-request 

```
Git  
Docker 
docker-compose
Composer - optional
```

And in addition to havin the tools, it is also manadatory to have access to nih GitHub enterprise. 

## Reference
Please refer the documentation below to install the prerequests locally.

[Git Installation](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)

[Docker Installation](https://docs.docker.com/install/#reporting-security-issues)

[Docker Compose Installation](https://docs.docker.com/compose/install/)

[Composer Installation](https://getcomposer.org/doc/00-intro.md)


## Installation and Configuration

Download/clone repository:

```
$ git clone git@github.niaid.nih.gov:bcbb/bcbb-drupal.git
```
The above command will clone the lastet  project file from the repository. 

Once the project is cloned locally, Please change directory to the project directory
```
$ cd bcbb-drupal/
```


###### Edit Key Configuration files 
The repository comes with enviromental configuration file. 

  ## .env file 

    A file used to store environment specific configuration of containers,Please modify the values in .env file:
    
        ```
        DB_NAME=Database Name
        DB_USER=Database username
        DB_PASSWORD=Database password for $DB_USER
        DB_ROOT_PASSWORD=Mysql Root Password
        DB_HOST=HostNamae 
        DB_DRIVER=mysql
        MYSQL_VERSION=5.7 (Mysql Version/ Recommended to leave it with 5.7)
        HOST_MYSQL_PORT= Docker container Mapping port for mysql
        HOST_APACHE_PORT= Docker container Mapping port for apache
        MYSQL_NAME=bcbb_mysql_db /Docker container name for mysql container
        WEB_NAME=bcbb_drupal /Docker container name for php+apache container
         ```
         
For local development .evn can be edited to match local configuration. 

## settings.php 

 ```
 $ cp docroot/sites/default/default.settings.php  docroot/sites/default/settings.php 
```

## Create 'files' Directory 

This is wehre Drupal stores site specific files. we need to create this folder under sites/default/ and set permissions for your webserver user to read/write. But, for local development it is safe to set the permission for everyone to read/write. 

 ```
 $ mkdir docroot/sites/default/files && chmod -R 777 docroot/sites/default/files
```

## Build your stack

 ```
 $ docker-compose up --build -d
```




Docker creates two containers one for Apache+PHP and another one MySql.  

### Now go to the URL below to beging installation of Drupal on your container


```
Open: http://localhost:HOST_APACHE_PORT (The port number you configured on .env file)
```

During installation on database configuration page click advanced setting to change the database host to mysql container name you configure on .env file.



### Configure Drupal config directory 

## Change config Sync direcory on Settings.php file  
```
$config_directories = array(
       CONFIG_SYNC_DIRECTORY => '/home/config/sync',
);
```

## To run drush command: 
```
docker exec -it bcbb_drupal drush
```

## To ssh/login to your container: 
```
docker exec -it bcbb_drupal bash
```

## Access your local site
Open: http://localhost:HOST_APACHE_PORT (The port number you configured on .env file)

