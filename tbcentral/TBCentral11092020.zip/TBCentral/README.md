# Docker-based Drupal 8 website for TBPortal 

## Introduction

This repository consists of Dockerized Drupal 8  website for TBPortal. Running Drupal 8.6, Apache 2.4, MySql 5.7 and PHP 7. These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. 

## Stack

The  stack consist of the following containers:

| Container     | Versions                | Service name    | Image                              | Default |
| ------------- | ----------------------- | --------------- | ---------------------------------- | ------- |
| [Apache+php]  | 2.4 * 7.2               | `tbc_site`      | [apache2-php7-alpine3.8]           |         |
| [mysql]       | 5.7                     | `tbc_db`        | [mysql/5.7]                        |         |

### Prerequisites

In order to have a running instance of this application the following tools are pre-request 

```
Git  
Docker 
Composer
```

And in addition to having the tools, it is also mandatory to have access to nih GitHub enterprise.  

## Reference
Please refer the documentation below to install prerequisites locally.

[GitInstallation](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git)
[DockerInstallation](https://docs.docker.com/install/#reporting-security-issues)
[ComposerInstallation](https://getcomposer.org/doc/00-intro.md)


## Installation and Configuration

Download/clone repository:

```
$ git clone git@github.niaid.nih.gov:bcbb/TBCentral.git
```
The above command will clone the latest TBCentral project file from the repository using SSH . 

Once the project is cloned locally, Please change directory to the project directory
```
$ cd TBCentral/
```


###### Edit Key Configuration files 
The repository comes with environmental configuration file. 

  ** .env file ** 
    A file used to store environment specific configuration of containers. Please modify the values in .env file:
    
        ```
        DB_NAME=Database Name
        DB_USER=Database username
        DB_PASSWORD=Database password for $DB_USER
        DB_ROOT_PASSWORD=Mysql Root Password
        DB_HOST=HostNamae 
        DB_DRIVER=mysql
        MYSQL_VERSION=5.7 (Mysql Version/ Recommended to leave it with 5.7)
        HOST_MYSQL_PORT= Docker container Mapping port for mysql
        HOST_APACHE_PORT= Docker container Mapping port for apache
         ```
         
For local development .evn can be edited to match local configuration. 

Build your stack
 ```
 $ docker-compose up --build -d
```

Docker creates two containers one for Apache+PHP and MySql.  

### Now go to the URL below to install Drupal on your container


```
Open: http://localhost:HOST_APACHE_PORT (The port number you configured on .env file)
```

During installation on database configuration advanced setting to  the database host to mysql container name.


### Import existing mysql Database dump

- [x] Get Database dump
- [x] Copy the database backup to Drupal4GovCon/db-backups/

    ```
     
     $ docker exec -it tbc_db bash
     # import database from dump file. Use database name from .env file
     $ root@container_id:/# mysql -u root -p database_name < /var/mysql/backups/database_dump.sql
     $ root@container_id:/# exit
 
    ```  

###### Configure settings.php file 

    ```
      #docroot/sites/default/settings.php
      $databases['default']['default'] = array (
     'database' => 'Dbname',
     'username' => 'Dbusername',
     'password' => 'Dbpassword',
     'prefix' => '',
     'host' => 'tbc_db',
     'port' => '3306',
     'namespace' => 'Drupal\\Core\\Database\\Driver\\mysql',
     'driver' => 'mysql',
     );
    ```

### Configure Drupal config directory 

## Change config Sync directory on settings.php file ot 
```
$config_directories = array(
       CONFIG_SYNC_DIRECTORY => '/home/config/sync',
);
```

## To run drush command: 
```
docker exec -it tbc_site drush
```



## Access your local site
Open: http://localhost:HOST_APACHE_PORT (The port number you configured on .env file)


# Build and Deploy Procedure

TPortal Central project uses GOCD for setting up continuous integration/continuous delivery (CI/CD). Pipelines has been created to support build, deploy, scan workflow.  In order to create this workflow, GOCD templates provided by monrach team has been used.

### [TBPORTALS_BuildDeployDev](https://gocd.niaid.nih.gov/go/admin/pipelines/TBPORTALS_BuildDeployDev/general)

This pipeline is created to deploy changes to dev environment. This pipeline  uses 'dev' branch as a source and uses 'Build_DeployDev' GOCD template.

### [TBPORTALS_Build_Deploy_Qa_Scan](https://gocd.niaid.nih.gov/go/admin/pipelines/TBPORTALS_Build_Deploy_Qa_Scan/general)

This pipeline is created to run security scans and deploy changes to qa environment  . This pipeline uses 'qa' branch as a source and uses 'Build_DeployQA_Scan' GOCD template.


### [Promote_DeployProd_TBPORTALS](https://gocd.niaid.nih.gov/go/admin/pipelines/Promote_DeployProd_TBPORTALS/general)

This pipeline is created to deploy successfully promoted image from qa to prod environment. The upstream for this stage is 'TBPORTALS_Build_Deploy_Qa_Scan'. 



# TPortal Central database configuration: 

# GOCD Environmental Variable 

Configuration variable are different across each managed environment, this makes the idea of having a hardcoded application configuration impossible. The way we solve this problem on TBcentral website is to use Environment Variables. GoCD allows setting both plain text and secured environmental variables for pipelines. TBcentral website defines sensitive information as a secure environmental variable including (Database name, user, password, database host and more... ) on GOCD pipeline.


![Environmental Variable configuration](images/env_config.png)


### Reading Environmental variable on container


All environmental  variables defined on pipeline can be accessed on the container. Here is how we read environmental variable on settings.php file

```php
// Read environmental variable 
$IntializeEnvironmentVariable = exec("eval $(/bin/aws-env) > /dev/null 2>&1");

$DPX_ENV = exec("printenv TBCENTRAL_ENV");
$DB_NAME = exec("printenv DB_NAME");
$DB_USER = exec("printenv DB_USER");
$DB_PASSWORD = exec("printenv DB_PASSWORD");
$DB_HOST = exec("printenv DB_HOST");
$AWS_CONTAINER_CREDENTIALS_RELATIVE_URI = exec("printenv AWS_CONTAINER_CREDENTIALS_RELATIVE_URI");
$ACCESS_KEY = exec("curl -s 169.254.170.2$AWS_CONTAINER_CREDENTIALS_RELATIVE_URI | jq .AccessKeyId");
$SECRET_ACCESS_KEY = exec("curl -s 169.254.170.2$AWS_CONTAINER_CREDENTIALS_RELATIVE_URI | jq .SecretAccessKey");
```


# Monarch Database configuration

Monarch is used to create database and database credentials. Either portal or monarch-cli can be used to create a new database resource or update existing one. For TBPortal website, we have three database created each for different environments:

[Dev Database](https://monarch.niaid.nih.gov/ui/v1/#/databases/5ceef27026fa09001bedd7ba)
[QA Database](https://monarch.niaid.nih.gov/ui/v1/#/databases/5d52c8263c0d89001cbf02f3)
[Production Database](https://monarch.niaid.nih.gov/ui/v1/#/databases/5d9ddef6af60cb001dfe7a3c)

Information like Endpoint and Username can be retrived from monarch porta or using the monarch-cli. Some common monarch-cli includes: 

```
//List databases
monarch db:list
```

```
//Get info about a managed database
monarch db:get name
```

For more information on monarch CLI, please refer monarch team's documentation [here](https://monarchdocs.niaid.nih.gov/tools/cli/)

# Connect to managed database 

Each  managed environments (Dev, QA, and Prod) of TBPoral website has it's own RDS instance that uses Aurora SQL database. It is possible to connect/access this database using phpmyadmin or monarch cli.

### PHPMyadmin

The Platform Team hosts an instance of PHP MyAdmin for management of any database created in one of our managed RDS instances, dev, qa, and prod. It can be access at https://monarch-phpmyadmin.niaidawscoreinfra.net using any of the users defined in our configuration.

![phpmyadmin landing page](/images/phpmyadmin.png)

As shown on the figure above, it is possible to use phpmyadmin to access databases from each managed environments.

#### Import & Export database using phpmyadmin

phpmyadmin can be used to export or import databases. 

##### Export database

![phpmyadmin export database](/images/phpmyadmin_export.png)

##### Import Database 

![phpmyadmin import database](/images/phpmyadmin_export.png)

### Monarch CLI (Recommended)

Another way to access database from a local computer is to use monarch CLI. SSH tunnel to any of the managed environments can be created using monarch cli, below is an example to connect to 3D Print Dev environment database. [Monarch CLI Further Reading](https://monarchdocs.niaid.nih.gov/tools/cli/)


```
//create a tunnel to aurora dev
monarch ssh:tunnel aurora-mysql-dev -c #This will use the default mysql port of 3306, incase the port is in use use the next command

//create a tunnel to aurora dev on a diffrent local port
monarch ssh:tunnel aurora-mysql-dev -c --localport=3737

#connect to your database server on the port you specified 

mysql -u DBUserName -p --host=127.0.0.1 --port=3737 

```
#### Import & Export database using monarch cli

Importing database using phpmyadmin has a size limitation (By the time this documentation was written phpmyadmin allows maximum of 512MB during import), this is not an issue when using monarch cli. 

```
//after successful connection to database server, we can import/export databases using mysql command

#Export
mysqldump -u DBUserName -p --host=127.0.0.1 --port=3737 > mysqldump_name.sql

#Import
mysql -u DBUserName -p --host=127.0.0.1 --port=3737 DatabaseName < mysqldump_name.sql

```

# Project Directory Structure 

![Project Directory Structure](/images/tbc_folder.png)


