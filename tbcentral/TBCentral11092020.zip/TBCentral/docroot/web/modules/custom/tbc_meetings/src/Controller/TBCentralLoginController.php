<?php

namespace Drupal\tbc_meetings\Controller;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBuilder;
use Drupal\externalauth\Authmap;
use Drupal\externalauth\ExternalAuth;



class TBCentralLoginController extends ControllerBase {

  const AUTHENTICATION_PROVIDER_NAME = 'tbc_meetings';
  //const AUTHENTICATION_NAME_DELIMITER = '|';

  /**
   * External Authentication's map between local users and service users.
   *
   * @var \Drupal\externalauth\Authmap
   */
  protected $authmap;

  /**
   * External Authentication's service for authenticating users.
   *
   * @var \Drupal\externalauth\ExternalAuth
   */
  protected $externalauth;

  /**
   * Constructs a new TBCentralLoginController object.
   */
  public function __construct(Authmap $externalauth_authmap, ExternalAuth $externalauth_externalauth) {
    $this->authmap = $externalauth_authmap;
    $this->externalauth = $externalauth_externalauth;
  }

   /**
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('externalauth.authmap'),
      $container->get('externalauth.externalauth')
    );
  }


   
     /**
   * Process a login request.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   The redirect response.
   */
  public function processLoginRequest($client_email) {

    $this->loginUserWithEmail($client_email);

    return $this->redirect('user.page'); //This redirect will be to a meeting landing page
  }
    /**
   * Log the user in, creating the account if it doesn't exist yet.
   *
   *
   * @return \Drupal\user\UserInterface
   *   The registered Drupal user.
   */
  protected function loginUserWithEmail($client_email) {
    $provider = $this->getAuthenticationProviderName();
    $authname = $client_email;
    $account_data = $this->getUserAccountData($client_email);
    \Drupal::logger('tbc_meetings')->notice($client_email);

    if (!$this->authmap->getUid($authname, $provider)) {
    	\Drupal::logger('tbc_meetings')->notice("trying to register");
      return $this->externalauth->loginRegister($authname, $provider, $account_data, $client_email);
    }
    return $this->externalauth->login($authname, $provider);
  }

    public static function getAuthenticationProviderName() {
    return self::AUTHENTICATION_PROVIDER_NAME;
  }



  protected function getUserAccountData($client_email) {
    return [
      'name' => $client_email,
      'mail' => $client_email,
    ];
  }


}