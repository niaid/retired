<?php

namespace Drupal\tbc_meetings\Form;


use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Path\AliasStorage;
use Drupal\Core\Url;


/**
 * Class TBCLoginForm.
 */
class TBCLoginForm extends ConfigFormBase {


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'tbc_meetings_login_form';
  }

   /**
   * {@inheritdoc}
   */
  public function getEditableConfigNames() {
    return ['tbc_meetings.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $sso_config = $this->config('tbc_meetings.settings');


        $form['open_modal'] = [
      '#type' => 'link',
      '#title' => $this->t('Login '),
      '#url' => Url::fromRoute('tbc_meetings.open_modal_form'),
      '#attributes' => [
        'class' => [
          'use-ajax',
          'button',
        ],
      ],
    ];

    // Attach the library for pop-up dialogs/modals.
    $form['#attached']['library'][] = 'core/drupal.dialog.ajax';



    
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $values = $form_state->getValues();

    $sso_config_settings = $this->config('tbc_meetings.settings');
    $sso_config_settings->set('enable_code_authentication', $values['enable_code_authentication']);
     $sso_config_settings->set('api_url', $values['api_url']);
    $sso_config_settings->save();

    parent::submitForm($form, $form_state);

  }


}
