<?php
namespace Drupal\tbc_meetings\Form;


use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Path\AliasStorage;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\InvokeCommand;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\tbc_meetings\Controller\TBCentralLoginController;
use GuzzleHttp\Exception\RequestException;

use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;


/**

 * Class TBCMeetingConfigForm.
 */
class TBCAuthenticationForm extends FormBase {

    /**
   * External Authentication's map between local users and service users.
   *
   * @var \Drupal\externalauth\Authmap
   */
  protected $authmap;

  /**
   * External Authentication's service for authenticating users.
   *
   * @var \Drupal\externalauth\ExternalAuth
   */
  protected $externalauth;

    /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'tbc_authentication_form';
  }

    /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {


    $form['#prefix'] = '<div id="drupal_modal">';
    $form['#suffix'] = '</div>';

    $form['messages']['status'] = [
     '#type' => 'status_messages',
     ];
    $form['status_message'] = [
      '#type' => 'markup',
      '#markup' => '<div id="result-message"></div>'
    ];



   $form['message_text'] = array(
  '#markup' => '<div id="test" class="login_text">Only TB Portals collaborators have access to meeting materials. In order to gain access, you first need to request to become a collaborator. Afterwards, you will be need to login using an identification code based on your e-mail. Please provide your e-mail address below.</div>',
    );

    $form['user_email'] = array(
      '#type' => 'email',
      '#placeholder' => 'Enter Email address',
      '#required' => TRUE,
      '#attributes' => [
        'autocorrect' => 'none',
        'class' => 'tbc_login_text',
        'autocapitalize' => 'none',
        'spellcheck' => 'false',
        'autofocus' => 'autofocus',
      ],
    );

        //this textfield will only be shown when the option 'Other'
    //is selected from the radios above.
    $form['pin_code'] = [
      '#type' => 'textfield',
      '#size' => '60',
      '#placeholder' => 'Enter the 6-digit identification code',
      '#attributes' => [
        'id' => 'pin-code',
        'autocorrect' => 'none',
        'class' => 'tbc_login_text',
        'autocapitalize' => 'none',
        'spellcheck' => 'false',
      ],
      '#states' => [
        //show this textfield only if the radio 'other' is selected above
        'visible' => [
                ':input[name="field_code_exists"]' => array('checked' => TRUE),
        ],
      ],
    ];

 $form['code_exists'] = array(
  '#type' => 'checkbox',
  '#title' => t('I already have a code'),
        '#attributes' => [
        //define static name and id so we can easier select it
        'id' => 'code-exists',
        'name' => 'field_code_exists',
      ],
);

    $form['actions'] = array('#type' => 'actions');

    $form['actions']['validate'] = [
      '#type' => 'submit',
      '#value' => $this->t('Validate Code'),
      '#attributes' => [
        'class' => [
          'use-ajax codes-download',
        ],
      ],
      '#states' => [
        //show this textfield only if the radio 'other' is selected above
        'visible' => [
          ':input[name="field_code_exists"]' => array('checked' => TRUE),
        ],
      ],
      '#ajax' => [
        'callback' => [$this, 'validateCode'],
        'event' => 'click',
      ],
    ];

    $form['actions']['send'] = [
      '#type' => 'submit',
      '#value' => $this->t('SEND CODE'),
      '#attributes' => [
        'class' => [
          'use-ajax codes-download',
        ],
      ],
      '#states' => [
        //show this textfield only if the radio 'other' is selected above
        'visible' => [
           ':input[name="field_code_exists"]' => array('checked' => FALSE),
        ],
      ],
      '#ajax' => [
        'callback' => [$this, 'getCode'],
        'event' => 'click',
      ],
    ];


      $form['footer_message_text'] = [
      '#type' => 'item',
      '#title' => $this->t('<div id="test" class="login_text"><strong>Not registered yet?</strong><p>Please contact us at TBPortalsInfo@niaid.nih.gov </p></div>'),
        '#states' => [
        'visible' => [
          ':input[name="field_code_exists"]' => array('checked' => FALSE),
        ],
      ],
    ];



        $form['actions']['re_send'] = [
      '#type' => 'submit',
      '#value' => $this->t('I have not received my code, please send again'),
      '#attributes' => [
        'class' => [
          'use-ajax codes-download',
          'no_recieved_button',
        ],
      ],

      '#ajax' => [
        'callback' => [$this, 'getCode'],
        'event' => 'click',
      ],
    ];





$form['#attached']['library'][] = 'core/drupal.dialog.ajax';
$form['#attached']['library'][] = 'tbc_meetings/tbc_meetings.validate';
    return $form;
  }




  public function getCode(array &$form, FormStateInterface $form_state )

  {
    $Ajaxresponse = new AjaxResponse();
    $values = $form_state->getValues();

    //Now here validate user
    $sso_config = \Drupal::config('tbc_meetings.settings');

    //get api_url
    $sso_api_url = $sso_config->get('api_url');

    $get_full_url = $sso_api_url."/api/PIN/GetPIN?emailAddress=".$values['user_email'];

    $method = 'GET';
    $options = [
                'header' => [
                  'Accept' => 'application/json'
                ]
                ];

$client = \Drupal::httpClient();

 try {
$response = $client->request($method, $get_full_url, $options);
$code = $response->getStatusCode();
}
  catch (RequestException $e) {
    $code=500;

  }

if ($code == 200) {
      $success_message = ' <p id="sent-text" style="margin-bottom: 0px;">We sent an identification code to the e-mail below:</p>  <p class="email-text">'.$values['user_email'].'</p>';

       \Drupal::messenger()->addMessage($this->t('<p id="sent-text" style="margin-bottom: 0px;">We sent an identification code to the e-mail below:</p>  <p class="email-text"> %email </p>',['%email' =>$values['user_email']]),'status', TRUE);

    $message = [
      '#theme' => 'status_messages',
      '#message_list' => drupal_get_messages(),
    ];

    $messages = \Drupal::service('renderer')->render($message);
    $Ajaxresponse->addCommand(new HtmlCommand('#result-message', $messages));



return $Ajaxresponse;
}
else
{
    \Drupal::messenger()->addMessage($this->t('<div id="test" class="login_text"><strong>Not registered yet?</strong><p>Please contact us at TBPortalsInfo@niaid.nih.gov </p></div>'), 'error', TRUE);
    $message = [
      '#theme' => 'status_messages',
      '#message_list' => drupal_get_messages(),
    ];
    $messages = \Drupal::service('renderer')->render($message);
    $Ajaxresponse->addCommand(new HtmlCommand('#result-message', $messages));
    return $Ajaxresponse;
}
return $Ajaxresponse;
}





/*
This is to validate code
*/
  public function validateCode(array &$form, FormStateInterface $form_state )
  {
    $Ajaxresponse = new AjaxResponse();
    $values = $form_state->getValues();
        //Now here validate user
    $sso_config = \Drupal::config('tbc_meetings.settings');
    //get api_url
    $sso_api_url = $sso_config->get('api_url');
    $validate_url = $sso_api_url."/api/PIN/ValidatePIN";
    $method = 'POST';
    $options = [
                'json' => [
                  'emailAddress' => $values['user_email'],
                  'pin' => $values['pin_code']
                ],

                'header' => [
                  'Accept' => 'application/json'
                ]
                ];

$client = \Drupal::httpClient();

          try {
            $response = $client->request($method, $validate_url, $options);

            $code = $response->getStatusCode();
            $response_data = json_decode($response->getBody(), true);
            }
            catch (RequestException $e) {
              $code=500;
              $response_data='';

            }

    if ($code == 200 and $this->isAllowedRole($response_data)) {

                    $loginProccessor = \Drupal::service('tbc_meetings.login_controller');
                    $loginProccessor->processLoginRequest($values['user_email']);

                    $Redirectmeeting = new RedirectCommand('/Meetings');

                    return $Ajaxresponse->addCommand($Redirectmeeting);
      }

      else
      {
                       \Drupal::messenger()->addMessage($this->t('We cannot confirm the code you have entered. Please either re-enter your code, or request a new code'), 'error', TRUE);
                        $message = [
                                      '#theme' => 'status_messages',
                                      '#message_list' => drupal_get_messages(),
                                    ];
                        $messages = \Drupal::service('renderer')->render($message);
                        $Ajaxresponse->addCommand(new HtmlCommand('#result-message', $messages));
                        return $Ajaxresponse;
      }

                        return $Ajaxresponse;

  }
    /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
}

       //Check if the emial exist
  public function UserExist($userName)
    {
                //check if the user is an active user
           return user_load_by_name($userName);
    }

    public function isAllowedRole($response_data) {
      // Allowed roles.
      $allowed_roles = ['Admin', 'Collaborator'];
      if(in_array($response_data['user']['userRole'],$allowed_roles))
      {
        return TRUE;
      }
      else {
        \Drupal::logger('tbc_login')->debug('User Roe not allowed '.$response_data['user']['userRole']);
        return FALSE;
      }
    }

   public function authenticateUser()
   {
      $authmap = \Drupal::service('externalauth.authmap');
      $externalauth = \Drupal::service('externalauth.externalauth');

   }


  }