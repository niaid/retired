/**
 * @file
 *  Js for  ajax page.
 */
(function ($, Drupal, drupalSettings) {
  'use strict';
  Drupal.behaviors.selectCode = {
    attach: function (context) {

    $(".no_recieved_button").hide();
    console.log("attacjed");
      var result_message = $('#result-message', context);
       
      if(result_message.html() && result_message.html().indexOf("sent")>=0)
      {
        
        var code_sent = $('#code-exists', context);

        code_sent.prop('checked', true);

       $('#code-exists').click().trigger('change');
       $('#code-exists.form-checkbox.form-check-input').click().trigger('change');
       $('input#code-exists.form-checkbox.form-check-input').click().trigger('change');
        
        $('#code-exists').trigger('change');
        $("#code-exists").trigger('click');
        $("#code-exists.form-checkbox.form-check-input").trigger('click');
        $("input#code-exists.form-checkbox.form-check-input").trigger('click');

         $("#code-exists.form-checkbox.form-check-input").hide();
         $("#code-exists.form-checkbox.form-check-input").hide();
        $("input#code-exists.form-checkbox.form-check-input").hide();
        $(".form-item-code-exists").hide();
        
         
         $(".no_recieved_button").show();


      }
      
    
    }
  };
})(jQuery, Drupal, drupalSettings);