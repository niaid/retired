<?php

namespace Drupal\tbc_meetings\Form;


use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Path\AliasStorage;
use Drupal\Core\Url;


/**
 * Class TBCMeetingConfigForm.
 */
class TBCMeetingConfigForm extends ConfigFormBase {


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'tbc_meetings_config_form';
  }

   /**
   * {@inheritdoc}
   */
  public function getEditableConfigNames() {
    return ['tbc_meetings.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $sso_config = $this->config('tbc_meetings.settings');



    $form['enable_code_authentication'] = array(
      '#type' => 'checkbox',
      '#title' => $this->t('Enable code based authentication '),
      '#description' => $this->t('Allow authentication using temporary code'),
      '#default_value' => $sso_config->get('enable_code_authentication'),
    );



    $form['api_url'] = array(
      '#type' => 'url',
      '#title' => $this->t('The API URL'),
      '#default_value' => $sso_config->get('api_url'),
      '#required' => TRUE,
      '#description' => $this->t('Configure a URL to the API.'),
    );


    // Attach the library for pop-up dialogs/modals.
    $form['#attached']['library'][] = 'core/drupal.dialog.ajax';


    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];
    
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $values = $form_state->getValues();

    $sso_config_settings = $this->config('tbc_meetings.settings');
    $sso_config_settings->set('enable_code_authentication', $values['enable_code_authentication']);
     $sso_config_settings->set('api_url', $values['api_url']);
    $sso_config_settings->save();

    parent::submitForm($form, $form_state);

  }


}
