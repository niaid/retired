<?php

namespace Drupal\EventSubscriber\tbc_meetings;

/**
 * Interface InitSubscriberInterface.
 */
interface InitSubscriberInterface {


}