<?php

namespace Drupal\tbc_meetings\EventSubscriber;


use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\user\Entity\User;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\tbc_meetings\Controller\TBCentralController;
use Drupal\Core\Url;


/**
 * Class InitSubscriber.
 */
class InitSubscriber implements EventSubscriberInterface {

  /**
   * Constructs a new InitSubscriber object.
   */
  public function __construct() {

  }

    public function authenticateUser(GetResponseEvent $event) {

      $sso_config = \Drupal::config('tbc_meetings.settings');
      
      //Check if code based authentication is enabled

      $sso_enabled = $sso_config->get('enable_code_authentication');


    if($sso_enabled && \Drupal::currentUser()->isAnonymous() && \Drupal::request()->getRequestUri()=='/Meetings' )
                
          {
            $collaborate_landing_page = Url::fromUri('internal:/node/14');
            
            $response = new RedirectResponse($collaborate_landing_page->toString());
            $event->setResponse($response);
            return;

          }
   
    //$login_url= Url::fromRoute('tbc_meetings.open_modal_form');
    //$response = new RedirectResponse($login_url->toString());
    //$event->setResponse($response);
           // $modalController = \Drupal::service('tbc_meetings.modal_controller');
            //$modalController->openModalForm();
                    //new TBCController();
/*    $options = [
      'dialogClass' => 'use-ajax, button',
      'width' => '50%',
    ];
    $attachments['#attached']['library'][] = 'core/jquery';
    $attachments['#attached']['library'][] = 'core/drupal.dialog.ajax';
    //$event['#attached']['library'][] = 'core/drupal.dialog.ajax';

            // Load authentication Form 
    $authentication_form = \Drupal::formBuilder()->getForm('Drupal\tbc_meetings\Form\TBCAuthenticationForm');
    $response = new AjaxResponse();
    $response->addCommand(new OpenModalDialogCommand('Request Identification Code', $authentication_form, $options));*/

/*    $response = new AjaxResponse();
    $login_url= Url::fromRoute('tbc_meetings.tbc_meetings_login_form');
    $response = new RedirectResponse($login_url->toString());
    $event->setResponse($response);
     
       return $response;
       

  }
    else
    {

    return 1;
     }*/

     return 1;

    }

        public static function getSubscribedEvents() {
                  $events[KernelEvents::REQUEST][] = array('authenticateUser', -10);
                  return $events;
               }

    public function UserExist($userName)
    {

                //check if the user is an active user
           return user_load_by_name($userName);


    }


    public function SSOLogin($userName)
    {
                //Login process 
        $user = user_load_by_name($userName);
        user_login_finalize($user);
        \Drupal::logger('TBC Meetings')->notice('SSO Session open for %name.', array('%name' => $user->getAccountName(),));

    return 1;

    }

 public function getUserName($username_mapping)

 {
       foreach (getallheaders() as $name => $value) {

                if($name == $username_mapping)
                {
                  return $value;
                }

            }
            return NULL; //No value was found to map the header

 }

}
