/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.tbcentral_theme = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
