package gov.nih.niaid.graphview

import javax.swing.JPanel
import java.awt.BorderLayout
import java.awt.Color
import java.awt.Dimension
import java.io.File
import java.util.concurrent.TimeUnit
import org.gephi.layout.plugin.fruchterman.{FruchtermanReingold, FruchtermanReingoldBuilder}
import org.gephi.layout.spi.LayoutBuilder
import org.gephi.graph.api.{GraphController,GraphModel}
import org.gephi.layout.plugin.force.yifanHu.YifanHuLayout
import org.gephi.layout.plugin.force.StepDisplacement
import org.gephi.layout.plugin.forceAtlas2.{ForceAtlas2,ForceAtlas2Builder}
import org.gephi.io.importer.api.{Container,ImportController}
import org.gephi.io.exporter.api.ExportController
import org.gephi.io.exporter.spi.GraphExporter
import org.gephi.io.processor.plugin.DefaultProcessor
import org.gephi.preview.api._
import org.gephi.preview.types.DependantOriginalColor
import org.gephi.project.api.ProjectController
import org.gephi.project.api.Workspace
import org.openide.util.Lookup
import org.gephi.preview.types.EdgeColor
import org.gephi.layout.plugin.openord.{OpenOrdLayout,OpenOrdLayoutBuilder}
import processing.core.PApplet

/** This is a Swing JPanel object that supports a Gephi "Preview" underneath.
  * We do not require that the content be provided upon construction because 
  * there are times--like when using UI builders--when you need to construct 
  * the UI in advance and then populate with content later.
  * 
  * To use this class you are likely to need to import the `implicit` conversion
  * managed by the companion object (i.e. `import PreviewPanel._`). The implicit
  * conversions there allow one to treat the `PreviewPanel` as if it was the
  * controller for purposes of manipulating the visualization, including the
  * fancy "return-this" chaining described for the controller. Here is a typical
  * usage of this class:
  * 
  *  {{{
  *   val preview = new PreviewPanel(new GraphPreviewController(file))
  *   preview.showLabels.
  *           setNodeLabelColor(Color.BLACK).
  *           setStraightEdges.setEdgeOpacity(50).
  *           setEdgeRadius(10).
  *           setBackgroundColor(Color.WHITE).
  *           setFruchtermanReingoldLayout(20000).
  *           refresh   
  *  }}}
  * 
  * @note The graph layout algorithms such as the Fruchterman-Reingold algorithm
  *       from the example above are quite costly. They require a tremendous
  *       amount of computation, especially for large graphs. This is why they
  *       have time constraints. But they are iterative, so you can trade 
  *       quality for time. For instance, in the example above, the 
  *       Fruchterman-Reingold layout is restricted to 20 seconds (20,000ms). 
  *       Unfortulately, the layout algorithms are also (inherently?) sequential
  *       and so they will fully occupy one core while the other cores are doing
  *       nothing in particular. It may be wise for users to run the layout in
  *       a `Future` so that other jobs can at least make some progress.  
  * 
  * @todo Find a way to get rid of the setter for the content controller. 
  *  
  * @author Jamie Lawson
  * 
  * @param contentController 	The a GraphPreviewController that provides the
  * 					        content for this panel. 
  */
class JPreviewPanel(contentController: GraphPreviewController) extends JPanel(new BorderLayout) {
  def this() = this(null)
  private var preview: GraphPreviewController = null
  setContentController(contentController)
  setVisualizationToDefaults
  
  def setVisualizationToDefaults = {
    preview.hideLabels
    preview.useStraightEdges
    preview.setBackgroundColor(JPreviewPanel.DefaultBackgroundColor)
    preview.setNodeLabelColor(JPreviewPanel.DefaultNodeLabelColor)
    preview.setEdgeOpacity(JPreviewPanel.DefaultEdgeOpacity)
    setGraphColorsToDefaults
  }
  
  def setGraphColorsToDefaults = {
    preview.setEdgeColorCustom(JPreviewPanel.DefaultEdgeColor)
  }
  
  
  /** Need this for Java interoperability where none of the implicit calls work. 
    * 
    * @return The preview controller.
    */ 
  def viewContentController = preview
  
  /** Called to establish the content of the panel. This should probably only
    * be called once, but that is not currently enforced. 
    * 
    * @param preview	
    */
  def setContentController(contentController: GraphPreviewController) = {
    if (contentController != null) {
      preview = contentController
      add(preview.applet, BorderLayout.CENTER)    
      preview.refresh
    }
  }
  
  override def setBounds(x: Int, y: Int, width: Int, height: Int): Unit = {
    //  Overriding setBounds allows us to pickup resize events and refresh,
    //  whereas without this we would have to wait for something that caused a
    //  refresh.
    super.setBounds(x,y,width,height)
    preview.refresh
  }
}

/** Implicit conversions to accompany the `PreviewPanel` class. 
  * 
  * @author Jamie Lawson
  */
object JPreviewPanel {
  val DefaultBackgroundColor = Color.WHITE
  val DefaultNodeLabelColor = Color.BLACK
  val DefaultEdgeColor = new Color(0xFF6000)
  val DefaultNodeColor = Color.ORANGE
  val DefaultEdgeOpacity = 50
  
  /**
   * This implicit conversion allows the client to treat the `JPreviewPanel` as
   * if it was the `GraphPreviewController` that sits underneath it. So you can
   * call `setStraightEdges` or what not directly on the panel.
   * 
   * @param panel	The `PreviewPanel` the call is being made on.
   * 
   * @return The `GraphPreviewController` that actually processes the call.
   */
  implicit def previewPanelToGraphPreviewController(panel: JPreviewPanel): GraphPreviewController = panel.preview
}

  
import org.gephi.ranking.api.{Ranking,RankingController,Transformer}
import org.gephi.ranking.plugin.transformer.AbstractColorTransformer

/** This is a controller class for a Gephi "preview" (graph visualization). It
  * is based on the PreviewJFrame code in the Gephi Toolkit by Mathieu Bastian,
  * however it evolved substantially from that. It provides a number of methods
  * for manipulating the visualization. These employ the "return-this" idiom,
  * allowing them to be chained. So instead of writing:
  * 
  * {{{
  *   myPreview.showLabels
  *   myPreview.setStraightEdges
  *   myPreview.setForceAtlasLayout(20000)
  * }}}  
  * 
  * You can instead just write:
  * 
  * {{{
  *   myPreview.showLabels.setStraightEdges.setForceAtlasLayout(20000)
  * }}}
  *
  * @author Jamie Lawson
  */
class GraphPreviewController(graphFile: File) {
  //----------------------------------------------------------------------------
  // Most of this stuff is here to make a really ugly property-based API look
  // a bit more like an O-O API.
  //----------------------------------------------------------------------------
  
  //Init a project - and therefore a workspace
  private val pc:ProjectController = Lookup.getDefault().lookup(classOf[ProjectController])
  pc.newProject()
  private val workspace:Workspace = pc.getCurrentWorkspace()

  //Import file
  private val importController:ImportController = Lookup.getDefault().lookup(classOf[ImportController])
  //var container:Container = null
            
  private val container:Container = importController.importFile(graphFile)

  //Append imported data to GraphAPI
  importController.process(container, new DefaultProcessor, workspace)
  
  private def exportController: ExportController = Lookup.getDefault.lookup(classOf[ExportController])
  private def gexfExporter:GraphExporter = exportController.getExporter("gexf").asInstanceOf[GraphExporter]     //Get GEXF exporter
  private def pngExporter = exportController.getExporter("png").asInstanceOf[org.gephi.io.exporter.preview.PNGExporter]     //Get GEXF exporter 

  /** Export the visible region of the graph (i.e. filtered) in Gexf format.
    * 
    * @param file	The file to export to.
    * 
    * @throws IOException	if the graph cannot be exported to the given file.
    */
  def exportVisibleToGexf(file: File) = {
    val exporter = gexfExporter
    exporter.setExportVisible(true)  //Only exports the visible (filtered) graph
    exporter.setWorkspace(workspace)
    exportController.exportFile(file, exporter)
  }
  
  /** Export the visible region of the graph (i.e. filtered) in PNG format.
    * 
    * @param file	The file to export to.
    * 
    * @throws IOException	if the graph cannot be exported to the given file.
    */
  def exportVisibleToPNG(file: File) = {
    exportController.exportFile(file, pngExporter)
  }  

  //Preview configuration
  private val previewController:PreviewController = Lookup.getDefault().lookup(classOf[PreviewController])
  private val previewModel = previewController.getModel

  //New Processing target, get the PApplet
  private val target:ProcessingTarget = previewController.getRenderTarget(RenderTarget.PROCESSING_TARGET).asInstanceOf[ProcessingTarget]
  
  /** Accessor for the Processing PApplet that is the user facing part of the
    * visualization.
    * 
    * @return The visualization 
    */
  val applet:PApplet = target.getApplet
  applet.init

  //Refresh the preview and reset the zoom
  previewController.render(target);
  target.refresh
  target.resetZoom
  refresh
  //applet.redraw
  
  def refresh = {
    previewController.refreshPreview
    previewController.render(target)
    target.refresh
  }
  
  def redraw = applet.redraw
  
  //////////////////////////////////////////////////////////////////////////////
  //
  //  These methods do the actual manipulation of the visualization.
  //
  //////////////////////////////////////////////////////////////////////////////
  
  
  def showLabels = {
    // The object we call "deriveFont" on is a java.awt.Font object. There are
    // several "deriveFont" methods on it. The one that takes floats sets the
    // point size.ExportController ec = Lookup.getDefault().lookup(ExportController.class);
    previewModel.getProperties.putValue(PreviewProperty.NODE_LABEL_FONT, previewModel.getProperties.getFontValue(PreviewProperty.NODE_LABEL_FONT).deriveFont(10.0f))    
    previewModel.getProperties.putValue(PreviewProperty.SHOW_NODE_LABELS, true)
    this
  }
  def hideLabels = {
    previewModel.getProperties.putValue(PreviewProperty.SHOW_NODE_LABELS, false)
    this
  }
  def setNodeLabelColor(color: Color) = {
    previewModel.getProperties.putValue(PreviewProperty.NODE_LABEL_COLOR, new DependantOriginalColor(color))
    this
  }
  def useCurvedEdges = {
    previewModel.getProperties.putValue(PreviewProperty.EDGE_CURVED, true)
    this
  }
  def useStraightEdges = {
    previewModel.getProperties.putValue(PreviewProperty.EDGE_CURVED, false)
    this
  }
  def setEdgeOpacity(opacity: Int) = {
    previewModel.getProperties.putValue(PreviewProperty.EDGE_OPACITY, opacity)
    this
  }
  
  def setEdgeColorCustom(color: Color) = {
    val degreeRanking = getRankingController.getModel.getRanking(Ranking.NODE_ELEMENT, Ranking.DEGREE_RANKING)
    val colorTransformer = getRankingController.getModel.getTransformer(Ranking.NODE_ELEMENT, Transformer.RENDERABLE_COLOR).asInstanceOf[AbstractColorTransformer[Any]]
    colorTransformer.setColors(Array(color,color))
    getRankingController.transform(degreeRanking, colorTransformer)
    this    
    //previewModel.getProperties.putValue(PreviewProperty.EDGE_COLOR, new EdgeColor(color))
  }
  
  /*
  def setEdgeColorMixed = {
    //previewModel.getProperties.putValue(PreviewProperty.EDGE_COLOR, EdgeColor.Mode.CUSTOM)
  }
  */
  /*
  def setNodeColor(color: Color) = {
    previewModel.getProperties.putValue(PreviewProperty.NODE_)
  }
  */
  
  def setEdgeRadius(radius: Float) = {
    previewModel.getProperties().putValue(PreviewProperty.EDGE_RADIUS, radius)
    this
  }
  def setBackgroundColor(color: Color) = {
    previewModel.getProperties().putValue(PreviewProperty.BACKGROUND_COLOR, color)
    this
  }
  
  /** Used by the layout methods.
    * 
    */
  private def getGraphModel: GraphModel = Lookup.getDefault.lookup(classOf[GraphController]).getModel
  
  /** Applies the Fruchterman-Reingold graph layout algorithm to the 
    * visualization. The Fruchterman-Reingold algorithm is a force-directed
    * layout algorithm that represents nodes by steel rings and the edges are 
    * springs between them. The attractive force is analogous to the spring 
    * force and the repulsive force is analogous to the electrical force. The 
    * basic idea is to minimize the energy of the system by moving the nodes and 
    * changing the forces between them.
    * 
    * Note that the Fruchterman-Feingold algorithm is an iterative heuristic and  
    * if you spend more time on it, you get a better layout. So this method 
    * provides a "maxTime" that you want to spend laying out the graph. The 
    * method will use all of that time, unless the algorithm completely 
    * converges (which is unlikely).
    * 
    * @param stopper	A predicate that tells the layout algorithm how long it
    * 					can run. Typically, the stopper will either have a
    *     				maximum time associated with it, or will have some way
    *         			for the user to interrupt it manually, or both.
    *         
    * @return This object.
    */
  def useFruchtermanReingoldLayout(stopper: Stopper) = {
    val layout = new FruchtermanReingold(new FruchtermanReingoldBuilder)
    layout.setGraphModel(getGraphModel)
    layout.initAlgo
    layout.resetPropertiesValues
    while (stopper.continue && layout.canAlgo) layout.goAlgo
    layout.endAlgo
    this
  }
  
  /** Applies the Yifan Hu graph layout algorithm to the visualization. The 
   *  Yifan Hu graph layout algorithm is an efficient force-directed layout
    * algorithm that is of high quality for large graphs. It employs a 
    * multilevel approach that effectively overcomes local minima using the 
    * Barnes and Hut octree algorithm which approximates short and long range 
    * forces satisfactorily and efficiently. See "Efficient and High Quality 
    * Force-Directed Graph Drawing", Yifan Hu (unknown publication if any--Hu
    * is a researcher at Wolfram).
    * 
    * Note that the Yifan Hu algorithm is an iterative heuristic and if you 
    * spend more time on it, you get a better layout. So this method provides
    * a "maxTime" that you want to spend laying out the graph. The method will
    * use all of that time, unless the algorithm completely converges (which is
    * unlikely).
    * 
    * @param stopper	A predicate that tells the layout algorithm how long it
    * 					can run. Typically, the stopper will either have a
    *     				maximum time associated with it, or will have some way
    *         			for the user to interrupt it manually, or both.
    * 
    * @return This object.
    */
  def useYifanHuLayout(stopper: Stopper) = {   
    val layout:YifanHuLayout = new YifanHuLayout(null, new StepDisplacement(1f))
    layout.setGraphModel(getGraphModel)
    layout.initAlgo
    layout.resetPropertiesValues
    layout.setOptimalDistance(200f)
    while (stopper.continue && layout.canAlgo) layout.goAlgo
    layout.endAlgo
    this
  }
  
  /** Applies the Force Atlas layout algorithm to the visualization. Force Atlas
    * is a force-directed layout algorith that is scaled for small to 
    * medium-sized graphs, and is adapted to qualitative interpretation of 
    * graphs. It is a very fast layout algorithm, and is good enough to deal 
    * with very small graphs (10 nodes) and fast enough to spatialize 10,000 
    * nodes graphs in few minutes, with the same quality. If you have time, it 
    * can deal with even bigger graphs.
    * 
    * Force Atlas is a continuous algorithm, that allows you to manipulate the 
    * graph while it is rendering (a classic force-vector, like 
    * Fruchterman Rheingold, and unlike OpenOrd). It has a linear-linear model 
    * (attraction and repulsion proportional to distance between nodes). The 
    * shape of the graph is between Früchterman & Rheingold’s layout and Noack’s 
    * LinLog. It features a unique adaptive convergence speed that allows most 
    * graphs to converge efficiently.
    * 
    * Note that the Force Atlas algorithm is an iterative heuristic and if you 
    * spend more time on it, you get a better layout. So this method provides
    * a "maxTime" that you want to spend laying out the graph. The method will
    * use all of that time, unless the algorithm completely converges (which is
    * unlikely).
    * 
    * @param stopper	A predicate that tells the layout algorithm how long it
    * 					can run. Typically, the stopper will either have a
    *     				maximum time associated with it, or will have some way
    *         			for the user to interrupt it manually, or both.
    *      
    * @return This object.  
    */
  def useForceAtlasLayout(stopper: Stopper) = {    
    val layout:ForceAtlas2 = new ForceAtlas2(new ForceAtlas2Builder)
    layout.setGraphModel(getGraphModel)
    layout.initAlgo
    layout.resetPropertiesValues
    while (stopper.continue && layout.canAlgo) layout.goAlgo
    layout.endAlgo
    this
  }

  /** Applies the OpenOrd layout algorithm to the visualization. OpenOrd
    * is one of the few force-directed layout algorithms that can scale to over 
    * 1 million nodes, making it ideal for large graphs. However, small graphs 
    * (hundreds or less) do not always end up looking so good. This algorithm 
    * expects undirected weighted graphs and aims to better distinguish 
    * clusters. It can be run in parallel to speed up computing.
    * 
    * The algorithm is originally based on Frutcherman-Reingold and works with 
    * a fixed number of iterations. The algorithm is using simulated annealing 
    * and has five different phases: liquid, expansion, cool-down, crunch, and 
    * simmer. Each stage is a fraction of the total iterations and several 
    * parameters like temperature, attraction and damping are changing. The 
    * default schedule spends approximately 25% of its time in the liquid stage, 
    * 25% in the expansion stage, 25% in the cool-down stage, 10% in the 
    * crunch stage, and 15% in the simmer stage.
    * 
    * @param stopper	A predicate that tells the layout algorithm how long it
    * 					can run. Typically, the stopper will either have a
    *     				maximum time associated with it, or will have some way
    *         			for the user to interrupt it manually, or both.
    *      
    * @return This object.  
    */  
  def useOpenOrdLayout(stopper: Stopper) = {
    val layout:OpenOrdLayout = new OpenOrdLayout(new OpenOrdLayoutBuilder)   
    layout.setGraphModel(getGraphModel)
    layout.resetPropertiesValues
    println("NUMIT: " + layout.getNumIterations)
    layout.setNumIterations(20000)
    //println("EXP: " + layout.getExpansionStage)
    //layout.setExpansionStage(600)
    //println("EXP: " + layout.getExpansionStage)
    if (layout.canAlgo) {
      layout.initAlgo
      while (stopper.continue && layout.canAlgo) layout.goAlgo
      layout.endAlgo
    }
    this
  }

  /** Used by the "ranking" methods.
    * 
    */
  private def getRankingController = Lookup.getDefault.lookup(classOf[RankingController])
  
  /** Gives a "heat map" view of the graph.
    * 
    */
  def setNodeRanking(coldColor:Color=GraphPreviewController.DEFAULT_COLD_COLOR, 
                     hotColor:Color=GraphPreviewController.DEFAULT_HOT_COLOR) = {
    val degreeRanking = getRankingController.getModel.getRanking(Ranking.NODE_ELEMENT, Ranking.DEGREE_RANKING)
    val colorTransformer = getRankingController.getModel.getTransformer(Ranking.NODE_ELEMENT, Transformer.RENDERABLE_COLOR).asInstanceOf[AbstractColorTransformer[Any]]
    colorTransformer.setColors(Array(coldColor,hotColor))
    getRankingController.transform(degreeRanking, colorTransformer)
    this
  }
  
  import org.gephi.filters.api.FilterController
  import org.gephi.filters.plugin.graph.EgoBuilder._
  import org.gephi.graph.api.GraphView
  
  /** Used by filter methods.
    * 
    * @return The active filter controller.
    */
  private def getFilterController = Lookup.getDefault.lookup(classOf[FilterController])
  
  /** This thing is a cache for the restorable view, in case the graph has been
    * filtered. It is crucial that we keep this thing synchronized correctly,
    * hence all of the logic in the filter and clear filter methods.
    */
  private var restoreView:Option[GraphView] = None
  
  def filterGraphByNodeName(nodeName: String, depth:Int = 1) = {    
    restoreView match {
      case Some(view) => // If there is a view to restore then there is already a filter, so do nothing.
      case None       =>
        restoreView = Some(getGraphModel.getVisibleView)
        val filterController = getFilterController
        val egoFilter = new EgoFilter
        egoFilter.setPattern(nodeName)
        egoFilter.setDepth(depth)
        val query = filterController.createQuery(egoFilter)
        val view = filterController.filter(query)
        getGraphModel.setVisibleView(view)
    }
  }
  
  import org.gephi.graph.api.UndirectedGraph
  import org.gephi.partition.api._
  import org.gephi.filters.plugin.partition.PartitionBuilder._
  import org.gephi.data.attributes.api._
  import org.gephi.filters.api._
  import org.gephi.graph.api.Edge
 
  def filterGraphByEdgeAttributeVAlue[T](attrName: String, attrValue: T) = {
    // Filter, keep partition where the graph attribute = attribute value
    // The code comes originally from a sample on the Gephi Wiki at 
    //
    //     http://wiki.gephi.org/index.php/Toolkit_-_Filter
    //
    // We have cleaned it all up and made it reasonable Scala code, changed 
    // nodes to edges, but that  page is the inspiration.
    val attributeModel:AttributeModel = Lookup.getDefault().lookup(classOf[AttributeController]).getModel
    val partitionController:PartitionController = Lookup.getDefault().lookup(classOf[PartitionController])
    val graph:UndirectedGraph = getGraphModel.getUndirectedGraph
    // Figure out what the type parameter is supposed to be. It's not documented.
    val p:Partition[_<:Any] = partitionController.buildPartition(attributeModel.getEdgeTable.getColumn(attrName), graph)
    val partitionFilter:EdgePartitionFilter = new EdgePartitionFilter(p)
    partitionFilter.unselectAll
    partitionFilter.addPart(p.getPartFromValue(attrValue))
    val filterController = getFilterController
    val query:Query = filterController.createQuery(partitionFilter);
    val view:GraphView = filterController.filter(query);
    getGraphModel.setVisibleView(view)    //Set the filter result as the visible view
  }
  
  def clearFilters = {
    restoreView match {
      case Some(view) =>  //  So a filter was applied. We need to clear queries and restore the view. 
        val filterController = getFilterController
        filterController.getModel.getQueries.foreach(query => {
            filterController.remove(query)
          })
        // getFilterController.setCurrentQuery(null)
        getGraphModel.setVisibleView(view)
        restoreView = None
      case None =>        //  There were no filters applied so there is nothing to do.
    }
  }
  
  /** This method is unsupported.
    *
    * @throws UnsupportedOperationException  
    */
  def setEdgeRanking(coldColor:Color=GraphPreviewController.DEFAULT_COLD_COLOR, 
                     hotColor:Color=GraphPreviewController.DEFAULT_HOT_COLOR) = {
    throw new UnsupportedOperationException
    val degreeRanking = getRankingController.getModel.getRanking(Ranking.EDGE_ELEMENT, Ranking.DEGREE_RANKING)   
    val colorTransformer = getRankingController.getModel.getTransformer(Ranking.NODE_ELEMENT, Transformer.RENDERABLE_COLOR).asInstanceOf[AbstractColorTransformer[Any]]    
    colorTransformer.setColors(Array(coldColor,hotColor))   
    getRankingController.transform(degreeRanking, colorTransformer)   
    this
  }
  
  def getEdgeCount: Int = {
    getGraphModel.getGraph.getEdgeCount
  }
  
  def getNodeCount: Int = {
    getGraphModel.getGraph.getNodeCount
  }
}

/** Holds some constants that deal with how the default visualizations look.
  * 
  * @author Jamie Lawson
  */
object GraphPreviewController {
  val DEFAULT_COLD_COLOR = new Color(0x0070A0)
  val DEFAULT_HOT_COLOR = new Color(0xC00000)
}