package gov.nih.niaid.graphview

import java.awt.BorderLayout
import java.awt.Color
import java.io.File
import javax.swing.JFrame
 
/** This object is a simple runner class for the PreviewPanel class. It just 
  * creates and views a PreviewPanel.
  * 
  * @author Jamie Lawson 
  */ 
object Preview {
  def main(args: Array[String]) = {
    val inputName1 = "./data/Java.gexf"
    val inputName2 = "./data/lesmiserables.gml"      
    try {
      val file = new File(inputName1)
      val preview = new JPreviewPanel(new GraphPreviewController(file))
      preview.showLabels.
              setNodeLabelColor(Color.BLACK).
              useStraightEdges.setEdgeOpacity(50).
              setEdgeRadius(10).
              setBackgroundColor(Color.WHITE).
              useOpenOrdLayout(new TimeBasedStopper(10000)).
              setNodeRanking().
              //setEdgeRanking().
              refresh 
      
      //Add the applet to a JFrame and display
      val frame = new JFrame("Test Preview")
      frame.setLayout(new BorderLayout)  
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)    
      frame.add(preview, BorderLayout.CENTER)  
      frame.pack
      frame.setVisible(true)
    } catch {
      case t: Throwable =>
        t.printStackTrace
    }   
  }
}
