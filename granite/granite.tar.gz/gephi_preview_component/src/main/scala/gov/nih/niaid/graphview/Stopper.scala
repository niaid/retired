package gov.nih.niaid.graphview

/** Because laying out a graph can take a very long period of time, it is likely
  * that a user might want to interrupt the process, and ''Stoppers'' are used
  * to govern the process. Instead of simply giving the layout an amount of 
  * time, we offer the layout algorithm a stopper. When the stopper says we are
  * done, we are done. That could be an amount of time, that could be when the
  * user says he or she has waited long enough, or that could be both. It could
  * also be some other criteria, all of which are buried in the ''continue''
  * predicate method. Typical use goes something like this:
  * 
  * {{{
  *   class InterruptableBackgroundProcess(stopper: Stopper) {
  *     def run = {
  *       while (stopper.continue) {
  *         doAnotherIterationOfTheAlgorithm
  *       }
  *     }
  *   }
  * }}}
  * 
  * @author Jamie Lawson
  * 
  */
trait Stopper {
  /** A predicate that determines whether or not to continue doing the layout.
    *  
    * @return Whether to continue doing graph layout.
    */ 
  def continue: Boolean
}

/** A simple form of stopper that stops the layout after a certain amount of
  * time has elapsed. 
  * 
  * @author Jamie Lawson
  * 
  * @param howLong	The amount of time to give the layout algorithm.
  */
class TimeBasedStopper(howLong: Long) extends Stopper { 
  private val endTime = System.currentTimeMillis + howLong
  def continue = System.currentTimeMillis < endTime
  
  /** The overall duration of this time-based stopper.
    * 
    * @return The duration of this stopper, start to finish, in milliseconds.
    */
  def duration = howLong
}

/** A ''TimeBasedStopper'' that is also interruptable so that the user can say
  * "let the graph lay out for so long", but then during that period the user
  * can call ''interrupt'' on the stopper and cause the layout to stop. 
  * 
  * @author Jamie Lawson
  * 
  * @param howLong	How long (in milliseconds) before this thing finishes 
  * 				regardless of interruption.
  */
class InterruptableTimeBasedStopper(howLong: Long) extends TimeBasedStopper(howLong) {  
  // This may be one of the few legitimate uses of a var because whether we stop
  // really does depend on things outside the system, like what mood the user
  // is in.
  private var stop = false
  
  /** Tells the layout algorithm that it's time to stop regardless of how much
    * or how little time has elapsed.  
    */
  def interrupt() = stop = true    
  
  override def continue = if (stop) false else super.continue
}