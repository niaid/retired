package gov.nih.niaid.graphview

import java.io.File
import scala.swing.Panel
import scala.swing.Publisher
import scala.swing.Component
import scala.swing.Alignment
import scala.swing.event._
import javax.swing._

/** Wraps a [[JPreviewPanel]] with a ''Scala-Swing'' object so that it can be
  * used in a ''Scala-Swing'' application with no particular pain.
  * 
  * @author Jamie Lawson
  */
class PreviewPanel(controller: GraphPreviewController) extends Panel {
  override lazy val peer: JPreviewPanel =
    new JPreviewPanel(controller) with SuperMixin

  private def layoutManager = peer.getLayout.asInstanceOf[java.awt.BorderLayout]

  def vGap: Int = layoutManager.getVgap
  def vGap_=(n: Int) { layoutManager.setVgap(n) }
  def hGap: Int = layoutManager.getHgap
  def hGap_=(n: Int) { layoutManager.setHgap(n) }
   
  //////////////////////////////////////////////////////////////////////////////
  //
  //  These methods provide visual control of the preview object.
  //
  //////////////////////////////////////////////////////////////////////////////
  
  def showLabels: PreviewPanel = {
    controller.showLabels
    peer.refresh
    return this
  }
  
  def hideLabels: PreviewPanel = {
    controller.hideLabels
    peer.refresh
    return this
  }
  
  def useStraightEdges: PreviewPanel = {
    controller.useStraightEdges
    peer.refresh
    return this
  }
  
  def useCurvedEdges: PreviewPanel = {
    controller.useCurvedEdges
    peer.refresh
    return this
  }
  
  def useHeatMap: PreviewPanel = {
    controller.setNodeRanking()
    peer.refresh
    this
  }
  
  def useDefaultColors: PreviewPanel = {
    peer.setGraphColorsToDefaults
    peer.refresh
    this
  }
  
  def useFruchtermanReingoldLayout(stopper: Stopper) = {
    peer.useFruchtermanReingoldLayout(stopper)
    peer.refresh
    this
  }
  def useYifanHuLayout(stopper: Stopper) = {    
    peer.useYifanHuLayout(stopper)
    peer.refresh  
    this
  }
  def useForceAtlasLayout(stopper: Stopper) = {   
    peer.useForceAtlasLayout(stopper)
    peer.refresh
    this
  }
  def useOpenOrdLayout(stopper: Stopper) = {
    peer.useOpenOrdLayout(stopper)
    peer.refresh
    this
  }
  def filterGraphByNodeName(nodeName:String, depth:Int = 1) = {
    peer.filterGraphByNodeName(nodeName, depth)
    peer.refresh
    this
  }
  def clearFilters = {
    peer.clearFilters
    peer.refresh
    this
  }
  def getEdgeCount = peer.getEdgeCount
  def getNodeCount = peer.getNodeCount
}
