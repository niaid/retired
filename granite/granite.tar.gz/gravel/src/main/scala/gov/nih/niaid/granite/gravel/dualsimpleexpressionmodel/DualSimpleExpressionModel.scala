package gov.nih.niaid.granite.gravel.dualsimpleexpressionmodel

import gov.nih.niaid.granite.core.model.DataModel
import gov.nih.niaid.granite.gravel.simpleexpressionmodel.SimpleExpressionModel

/** This ''DataModel'' combines two ''SimpleExpressionModels into a single model
  * to facilitate comparisons. Say for instance you have a population of healthy
  * people and a population of sick people and you suspect that the genetics 
  * plays a role in the difference. So you capture differential expression data 
  * (say for some drug treatment) and you want to compare the two populations
  * to see what is different in gene expression. It would be natural to have a
  * data model that contains data models for both populations, but keeps them
  * separate. That is what this data model does.
  * 
  * @author Jamie Lawson 
  * 
  * @param model1	The first ''SimpleExpressionModel''
  * @param model2   The second ''SimpleExpressionModel''
  */
class DualSimpleExpressionModel(modelName: String, model1: Option[Pair[SimpleExpressionModel, String]],
                                                   model2: Option[Pair[SimpleExpressionModel, String]]) extends DataModel {
  def name = modelName
  
  /** Accessor for the models, indexed from 1, so ''apply(1)'' returns the 
    * first model (as an ''Option''), and ''apply(2)'' returns the second
    * model (also as an ''Option'') and either of these may be ''None'' and if
    * you pass any other argument you are guaranteed to get ''None''.
    * 
    * @param number	The number of the model (1 or 2)
    * 
    * @return The associated model (as an ''Option'').  
    * 
    */
  def apply(number: Int): Option[SimpleExpressionModel] = number match {
    case i if i==1 => model1 match {
      case Some(pair) => Some(pair._1)
      case None       => None
    }
    case i if i==2 => model2 match {
      case Some(pair) => Some(pair._1)
      case None       => None
    }
    case _            => None
  }
  
  def tag(number: Int) = number match {
    case i if i==1 => model1 match {
      case Some(pair) => Some(pair._2)
      case None       => None
    }
    case i if i==2 => model2 match {
      case Some(pair) => Some(pair._2)
      case None       => None
    }
    case _            => None
  }
  
  override def equals(other: Any): Boolean = {
    other match {
      case that:DualSimpleExpressionModel => if (this.name != that.name) false
                                             else if (this.tag(2) != that.tag(2)) false      
                                             else if (this.tag(1) != that.tag(1)) false
                                             else if (this(2) != that(2)) false                                             
                                             else if (this(1) != that(1)) false
                                             else true
      case _ => false
    }
  } 
}