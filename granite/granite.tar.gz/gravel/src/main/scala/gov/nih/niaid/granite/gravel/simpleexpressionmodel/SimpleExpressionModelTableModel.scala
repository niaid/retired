package gov.nih.niaid.granite.gravel.simpleexpressionmodel

import javax.swing.table.DefaultTableModel
import scala.collection.mutable.ListBuffer
import gov.nih.niaid.granite.core.model.RowDataModel
import gov.nih.niaid.granite.tools.significance.GeneSignificance

/** Companion object for ''SimpleExpressionModelTableModel''. Gives convenient
  * access to constants like column numbers and column headings
  * 
  * @author Jamie Lawson
  */
object SimpleExpressionModelTableModel {
  val RowNumberColumn = 0
  val GeneSymbolColumn = 1 
  val PValueColumn = 2
  val FoldChangeColumn = 3
  val FoldDescriptionColumn = 4
  val ColumnNoColumn = 5
  val TranscriptIdColumn = 6
  
  val ColumnTitles = Array[Object]("Row#", "Gene Symbol", "P-Value", "Fold Change", "Fold Change Desc", "Column#", "Transcript Id")
}
import SimpleExpressionModelTableModel._

/** A table model appropriate for the display and management of a 
  * ''SimpleExpressionModel''.
  * 
  * @note Cells in a ''SimpleExpressionModelTableModel'' are not editable. That
  *       would lead to problems of human error.
  *  
  * @param dataModel	The model to represent in a table.
  * 
  * @author Jamie Lawson
  */
class SimpleExpressionModelTableModel(dataModel: SimpleExpressionModel) extends DefaultTableModel(dataModel.rows, 7) {
  /** Alternative constructor for when you don't have an actual raw data model
    * yet, but you want a TableModel to put into a display. This builds the
    * ''SimpleExpressionModelTableModel'' with a ''DummySimpleExpressionModel''. 
    */
  def this() = this(new DummySimpleExpressionModel())
  
  var isDummy = dataModel.isInstanceOf[DummySimpleExpressionModel]
  setColumnIdentifiers(ColumnTitles)
  for (row <- 0 to dataModel.rows-1) {
    setValueAt((row+1), row, 0)
    dataModel(row) match {
      case Some(geneSig) => setValueAt(geneSig.geneSymbol, row, GeneSymbolColumn)
    		  				setValueAt(geneSig.pValue, row, PValueColumn)
    		  				setValueAt(geneSig.foldRatio, row, FoldChangeColumn)
    		  				setValueAt(geneSig.foldChangeDescription, row, FoldDescriptionColumn)
    		  				setValueAt(geneSig.columnNumber, row, ColumnNoColumn)
    		  				setValueAt(geneSig.transcriptId, row, TranscriptIdColumn)
      case None => 			for (col <- 1 to 6) setValueAt("", row, col)
    }
  }  
  
  override def isCellEditable(row: Int, column: Int): Boolean = false
  
  /** Provides a view of the data table as a ''SimpleExpressionModel''. The 
    * purpose of this is to provide persistence for the table.  
    * 
    * @param modelName 	The name to assign to the model (default is "Unnamed").
    * 
    * @return A ''SimpleExpressionModel'', an an ''Option'' with data equivalent 
    *         to what is in this table model. 
    */
  def toSimpleExpressionModel(modelName: String="Unnamed"): Option[SimpleExpressionModel] = {
    dataModel match {
      case model:DummySimpleExpressionModel => None
      case _ => 
        val buffer = new ListBuffer[GeneSignificance]    
        for (row <- 0 to getRowCount-1) {
          buffer += GeneSignificance(getValueAt(row, GeneSymbolColumn).asInstanceOf[String],
                                     getValueAt(row, PValueColumn).toString.toDouble,
                                     getValueAt(row, FoldChangeColumn).toString.toDouble,
                                     getValueAt(row, FoldDescriptionColumn).toString,
                                     getValueAt(row, ColumnNoColumn).toString.toInt,
                                     getValueAt(row, TranscriptIdColumn).toString)
        }
        Some(new SimpleExpressionModel(modelName, buffer.toSeq))
    }
  }
  
  override def getColumnClass(col: Int): Class[_] = {
    if      (col == RowNumberColumn)       classOf[Int]
    else if (col == GeneSymbolColumn)      classOf[String]
    else if (col == PValueColumn)          classOf[Double]
    else if (col == FoldChangeColumn)      classOf[Double]
    else if (col == FoldDescriptionColumn) classOf[String]
    else if (col == ColumnNoColumn)        classOf[Int]
    else if (col == TranscriptIdColumn)    classOf[String]
    else throw new AssertionError("Unknown column " + col + " in simpleExpressionModel")
  }
}

/** A "dummy" simple expression model used for populating empty tables. It has
  * as many rows as you specify, but the ''apply(row)'' method returns ''None''
  * for any input.
  * 
  * @author Jamie Lawson   
  * 
  * @param dummyRows	The number of empty rows to give this table. Defaults
  * 					to 20.
  */
class DummySimpleExpressionModel(dummyRows: Int = 20, name:String = "") extends SimpleExpressionModel(name, Seq[GeneSignificance]()) {
  override def rows = dummyRows
  override def apply(row: Int) = None  
}
 