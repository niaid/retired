package gov.nih.niaid.granite.gravel.event

import swing.Component
import swing.event.ActionEvent

/** An event class for signifying that a tab in a ''TabbedPane'' has been 
  * activated. 
  * 
  */
class TabActivated(component: Component) extends ActionEvent(component)

/** In order for the publication stuff to work properly, the event classes need
  * an extractor. This is the extractor.
  * 
  * @author Jamie Lawson
  */ 
object TabActivated {
  def unapply(t: TabActivated): Option[Component] = Some(t.source)
}