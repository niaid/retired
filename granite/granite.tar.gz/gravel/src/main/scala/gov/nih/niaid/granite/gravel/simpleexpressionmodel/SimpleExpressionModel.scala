package gov.nih.niaid.granite.gravel.simpleexpressionmodel

import scala.collection.mutable.{HashMap,ListBuffer}
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.core.model.{RowDataModel,RectangleModel}
import gov.nih.niaid.granite.tools.significance.GeneSignificance

/** A simple expression model is a very simple special case of the 
  * ''RowDataModel'' where each row is a ''GeneSignificance'' element.
  * 
  * @author Jamie Lawson 
  */
class SimpleExpressionModel(modelName: String, dataSeq: Seq[GeneSignificance]) extends RowDataModel[GeneSignificance] {
  private val data = dataSeq.toArray
  
  def rows = data.length
  def apply(row: Int) = if (isValidLocation(row)) Some(data(row)) else None
  def name = modelName
  
  /** Produces a new expression model that contains only the entries from this
    * one that meet the given p-value criteria. 
    * 
    * @param pValue		The maximum acceptable p-value for an entry.
    * 
    * @return A new simple expression model filtered by p-value.
    */
  def filterByPValue(pValue: Double): SimpleExpressionModel = {
    val absPValue = Math.abs(pValue)
    val buffer = new ListBuffer[GeneSignificance]
    for (row <- 0 to rows-1) {
      this(row) match {
        case Some(geneSig) => if (geneSig.pValue <= absPValue) buffer += geneSig
        case None          =>
      }
    }
    new SimpleExpressionModel(name, buffer.toSeq)
  }
  
  /** Produces a new expression model that contains only the entries from this
    * one that meet the given fold change criteria.  
    * 
    * @param foldChange The minimum (absolute value) fold change acceptable for
    *                   an entry.
    *                   
    * @return 	A new simple expression model filtered by fold change.
    */
  def filterByFoldChange(foldChange: Double): SimpleExpressionModel = {
    val absFoldChange = Math.abs(foldChange)
    val buffer = new ListBuffer[GeneSignificance]
    for (row <- 0 to rows-1) {
      this(row) match {
        case Some(geneSig) => if ((geneSig.foldRatio <= -absFoldChange) ||
                                  (geneSig.foldRatio >= absFoldChange)) buffer += geneSig
        case None          =>
      }
    }
    new SimpleExpressionModel(name, buffer.toSeq)
  }
  
  def geneSymbols: Set[String] = {
    val buffer = new ListBuffer[String]
    for (row <- 0 to rows-1) {
      this(row) match {
        case Some(geneSig) => buffer += geneSig.geneSymbol
      }
    }
    buffer.toSet
  }
}

/** Conversion object to transform a raw data model into a simple expression
  * model.  
  * 
  * @author Jamie Lawson
  */
object RawDataToSimpleExpressionModel {
  /** Performs the conversion operation RawData=>SimpleExpressionModel. Note 
    * that since the raw data model is a ''RectangleModel'', where rows and
    * columns are indexed from 0 (not 1) all of the columns here are with 
    * reference to 0 as the first column in the data.
    * 
    * This method produces an ''Option'' of a data model because there are
    * things that could go wrong.   
    * 
    * @param rawDataModel 			 	 The model to convert
    * @param firstRowIsColumnLabels  	 Whether the first row in the raw data  
    *                                	 is to be treated as column headers 
    *                                    (they commonly are).   
    * @param geneSymbolColumn		  	 The column in the raw data model where
    * 								  	 the gene symbol is expected. 
    * @param pValueColumn            	 The column in the raw data model where
    *                                	 the p-value is expected (optional, 
    *                                    default is -1). 
    * @param foldRatioColumn         	 The column in the raw data model where 
    *                                	 the fold ratio is expected (optional, 
    *                                	 default is -1).
    * @param foldChangeDescriptionColumn The column in the raw data model where
    * 									 the fold change description is 
    *           						 expected (optional, default is -1). 
	* @param columnNumberColumn          The column in the raw data model where
	* 									 the "Column#" is expected (optional,
	*           						 default is -1). 
	* @param transcriptIdColumn	         The column in the raw data model where
	* 									 the transcript Id is expected 
	*           						 (optional, default is -1).
	*                  
	* @return An ''Option'' of ''SimpleExpressionModel'' with the data from the 
	* 		  raw data model. 
    */
  def apply(rawDataModel:RectangleModel[String],
            firstRowIsColumnLabels:Boolean,
            geneSymbolColumn:Int, 
            pValueColumn:Int = -1, 
            foldRatioColumn:Int = -1,
            foldChangeDescriptionColumn:Int = -1, 
	        columnNumberColumn:Int = -1, 
	        transcriptIdColumn:Int = -1): Option[SimpleExpressionModel] = {
    // Try to validate the raw model. Return None if the model fails to validate.
    // You can't simply count the issues that come back because many of them 
    // may be warnings (not errors) and it is perfectly okay to go ahead and
    // build a model if we just have warnings from the raw data.
    ValidateModel(rawDataModel, firstRowIsColumnLabels, 
                  geneSymbolColumn, pValueColumn, foldRatioColumn) foreach {issue =>
      if (issue.issueType == ValidationIssueType.Error) return None
    }
    // If we get here, the raw model is valid. Now we need to collect the
    // entries that go into a simple expression model. We use the hash table for
    // detection of duplicates. We also must take care to ignore column labels 
    // in the raw data model, if it has column labels.
    val entries = new HashMap[String, GeneSignificance]
    for (row <- ValidateModel.modelStartRow(firstRowIsColumnLabels) to rawDataModel.rows-1) {
      processRow(rawDataModel, row, 
                 geneSymbolColumn, pValueColumn, foldRatioColumn,
                 foldChangeDescriptionColumn, columnNumberColumn, transcriptIdColumn) match {
        case Some(geneSignificance) =>
          // If an entry for this gene symbol already exists in the entries table,
          // use the one with the lowest p-value. If no such entry exists,
          // just write this one.
          entries.get(geneSignificance.geneSymbol) match {
            case Some(oldGeneSignificance) => 
              if (geneSignificance.pValue < oldGeneSignificance.pValue) {
                entries.put(geneSignificance.geneSymbol, geneSignificance)
              }
            case None =>
              entries.put(geneSignificance.geneSymbol, geneSignificance)
          }
        case None =>
      }  
    }
    Some(new SimpleExpressionModel(getShortLocalFileName(rawDataModel.name), entries.values.toSeq))    
  }
  
  /** Takes a single row in the raw data and turns it into a ''GeneSignificance'',
    * or not depending on whether the data supports it. 
    * 
    */
  private def processRow(rawDataModel: RectangleModel[String],
                         row: Int,
		  			 	 geneSymbolColumn: Int, 
		  			     pValueColumn: Int, 
		  			     foldRatioColumn: Int,
		  			     foldChangeDescriptionColumn:Int = -1, 
		  			     columnNumberColumn:Int = -1, 
		  			     transcriptIdColumn:Int = -1): Option[GeneSignificance] = {
    // Note, we can have an empty string for a gene symbol and still pass 
    // model validation, so we need to screen those out here, and there is a
    // difference, logically, between None and the empty string. Neither leads
    // to a valid GeneSignificance object.
    rawDataModel(row, geneSymbolColumn) match {
      case None => return None
      case Some(geneSymbol) => 
        if (geneSymbol.length == 0) return None  //  Check for empty string.
        else {
          var pValue = 1.0
          var foldRatio = 1.0
          var foldChangeDescription = ""
          var columnNumber = -1
          var transcriptId = ""
          rawDataModel(row,pValueColumn) match {
            case Some(pval) => pValue = pval.toDouble
            case None =>
          }
          rawDataModel(row,foldRatioColumn) match {
            case Some(frat) => foldRatio = frat.toDouble
            case None =>
          }
          rawDataModel(row, foldChangeDescriptionColumn) match {
            case Some(desc) => foldChangeDescription = desc
            case None =>
          }
          rawDataModel(row, columnNumberColumn) match {
            case Some(cn) => try {
                                columnNumber = cn.toInt
                              } catch {
                                case t:Throwable =>
                              }
            case None =>
          }
          rawDataModel(row, transcriptIdColumn) match {
            case Some(tid) => transcriptId = tid
            case None =>
          }
          // We are just about ready. However, many of our data sets come from
          // Excel, and Excel tries to be too smart and sometimes converts a
          // gene symbol into a date, like the gene symbol DEC1 becomes 1-Dec.
          // Yuck! And then when it comes across as CSV, the date turns into the
          // string "1-Dec". More yucky!! So we have to do a bit of processing 
          // to identify these and convert them back. That's what GeneSymbolOf
          // does.
          Some(GeneSignificance(geneSymbol=GeneSymbolOf(geneSymbol),
                                pValue=pValue,
                                foldRatio=foldRatio,
                                foldChangeDescription=foldChangeDescription,
                                columnNumber=columnNumber,
                                transcriptId = transcriptId))
        }
    }
  }
}

/** Many of our data sets come from Excel, and Excel tries to be too smart and 
  * sometimes converts a gene symbol into a date, like the gene symbol DEC1 
  * becomes 1-Dec. Yuck! And then when it comes across as CSV, the date turns 
  * into the string "1-Dec". More yucky!! This is a well known problem. See,
  * for example [[http://nsaunders.wordpress.com/2012/10/22/gene-name-errors-and-excel-lessons-not-learned/]].
  * So we have to do a bit of processing to identify these and convert them 
  * back. That is the purpose of this object. It has an ''apply'' method to 
  * take care of that business.
  * 
  * @author Jamie Lawson
  */
object GeneSymbolOf {
  // We really don't want to do a lot of manual translation on this because it
  // would take a long time to go through all of the possible cases. But the 
  // hash map is a very efficient and well tuned data structure. So we do this
  // in a very brute force way, prepopulating a hash map with all of the
  // standard quirks that might come up, and then we just do a constant time 
  // lookup in the hash map. It means a whole lot of stuff to prepopulate, but
  // we only do it once.
  val translator = Map(	("1-FEB", "FEB1"),
                        ("2-FEB", "FEB2"),
                        ("3-FEB", "FEB3"),
                        ("4-FEB", "FEB4"),
                        ("5-FEB", "FEB5"),
                        ("6-FEB", "FEB6"),
                        ("7-FEB", "FEB7"),
                        ("8-FEB", "FEB8"),
                        ("9-FEB", "FEB9"),
                        ("10-FEB", "FEB10"),
                        ("11-FEB", "FEB11"),
                        ("12-FEB", "FEB12"),
                        ("13-FEB", "FEB13"),
                     	("1-MAR", "MARCH1"), 
                     	("2-MAR", "MARCH2"),
                     	("3-MAR", "MARCH3"),
                     	("4-MAR", "MARCH4"),
                     	("5-MAR", "MARCH5"),
                     	("6-MAR", "MARCH6"),
                     	("7-MAR", "MARCH7"),
                     	("8-MAR", "MARCH8"),
                     	("9-MAR", "MARCH9"),
                     	("10-MAR", "MARCH10"),
                     	("11-MAR", "MARCH11"),
                     	("12-MAR", "MARCH12"),
                     	("13-MAR", "MARCH13"),
                     	("14-MAR", "MARCH14"),
                     	("1-APR", "APR1"),
                     	("2-APR", "APR2"),
                     	("3-APR", "APR3"),
                     	("4-APR", "APR4"),
                     	("5-APR", "APR5"),
                     	("6-APR", "APR6"),
                     	("7-APR", "APR7"),
                     	("8-APR", "APR8"),
                     	("9-APR", "APR9"),
                     	("10-APR", "APR10"),
                     	("1-SEP", "SEPT1"),
                     	("2-SEP", "SEPT2"),
                     	("3-SEP", "SEPT3"),
                     	("4-SEP", "SEPT4"),
                     	("5-SEP", "SEPT5"),
                     	("6-SEP", "SEPT6"),
                     	("7-SEP", "SEPT7"),
                     	("8-SEP", "SEPT8"),
                     	("9-SEP", "SEPT9"),
                     	("10-SEP", "SEPT10"),
                     	("11-SEP", "SEPT11"),
                     	("12-SEP", "SEPT12"),
                     	("13-SEP", "SEPT13"),
                     	("14-SEP", "SEPT14"),
                     	("15-SEP", "SEPT15"),
                     	("16-SEP", "SEPT16"),
                     	("17-SEP", "SEPT17"),
                     	("18-SEP", "SEPT18"),
                     	("1-OCT", "OCT1"),
                     	("2-OCT", "OCT2"),
                     	("3-OCT", "OCT3"),
                     	("4-OCT", "OCT4"),
                     	("5-OCT", "OCT5"),
                     	("6-OCT", "OCT6"),
                     	("7-OCT", "OCT7"),
                     	("8-OCT", "OCT8"),
                     	("9-OCT", "OCT9"),
                     	("10-OCT", "OCT10"),
                     	("1-NOV", "NOV1"),
                     	("2-NOV", "NOV2"),
                     	("3-NOV", "NOV3"),
                     	("4-NOV", "NOV4"),
                     	("5-NOV", "NOV5"),
                     	("6-NOV", "NOV6"),
                        ("1-DEC", "DEC1"),
                        ("2-DEC", "DEC2"),
                        ("3-DEC", "DEC3"),
                        ("4-DEC", "DEC4"),
                        ("5-DEC", "DEC5"),
                        ("6-DEC", "DEC6")
                       )
  /** Takes a "proposed" gene symbol and looks for some nasty special cases 
    * and gives back a gene symbol which, in the vast majority of cases, is
    * the same symbol that was input, but in a few corner cases where it is
    * different.
    * 
    * @param symbol		The "proposed" gene symbol.
    * 
    * @return The correct gene symbol for that proposed symbol.
    */
  def apply(symbol: String): String = {
    translator.getOrElse(symbol.toUpperCase, symbol)
  }
}