package gov.nih.niaid.granite.gravel.rawdata

import swing._
import javax.swing.table.DefaultTableModel
import scala.swing.BorderPanel.Position._
import scala.swing.event._
import javax.swing.filechooser.FileNameExtensionFilter
import java.io.{File,FileOutputStream,ObjectOutputStream, BufferedOutputStream}
import gov.nih.niaid.granite.core.model.{RectangleModel, RectangleModelFromCSV}
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.gravel.rectanglemodel._
import gov.nih.niaid.granite.gravel.log._
import gov.nih.niaid.granite.gravel.simpleexpressionmodel._
import gov.nih.niaid.granite.gravel.menus._
import gov.nih.niaid.granite.gravel.simpleexpressionmodel._
import gov.nih.niaid.granite.gravel.networkconstruction._
import gov.nih.niaid.granite.gravel.event._

/** A composite panel that allows the user to review and reason about raw 
  * expression data, and process it into a validated simple expression model. 
  * The top level panel also behaves as a ''Log'' so that it can write to a
  * Gravel logging window (included in this panel).
  * 
  * @author Jamie Lawson
  * 
  * param  panelName        A name for this panel, for instance to put in tab
  * 						labels.
  * @param rawDataModel		A data table, typically with a lot of columns, many
  * 						dealing with gene expression, such as those often 
  *                         exchanged amongst researchers.
  */
class RawDataPanel(panelName: String, rawDataModel: RectangleModel[String]) extends 
	SplitPane(Orientation.Horizontal) with Log with MenuProvider {
  name = panelName
  //////////////////////////////////////////////////////////////////////////////
  // Define all the component of the panel and lay them out.
  //////////////////////////////////////////////////////////////////////////////
  private val rawDataDisplay = new RectangleModelPanel(rawDataModel)
  private val logPanel = new LogPanel
  private val controlPanel = new ModelControlPanel(rawDataModel, rawDataDisplay)
  private val expressionModelPanel = new ExpressionModelPanel(new DummySimpleExpressionModel)
  
  private val saveExpressionModelMenuItem = new MenuItem(Action("Save Expression Model") {
    expressionModelPanel.getModel match {
      case Some(model) => saveModel(model) match {
       case Some(file) => log("Successfully saved expression model " + file.toString)
       case None       => log("Expression model not saved") 
      }
      case None => log("No expression model to save")
    }
  })
  private val exportExpressionModelMenuItem = new MenuItem(Action("Export Expression Model") {
    expressionModelPanel.getModel match {
      case Some(model) => publish(new AddTab(new NetworkConstructionPanel(model.name, Some(model), None)))
                          log("Exported Expression Model as " + model.name)
      case None        => log("No expression model to export.")                          
    }                     			  
  })
  private val closeMenuItem = new MenuItem(Action("Close") {
	log("Closing file")
	publish(new TabClosing(this))
  })  
  
  topComponent = rawDataDisplay  
  bottomComponent = new SplitPane(Orientation.Vertical) {
    leftComponent = controlPanel
    rightComponent = new SplitPane(Orientation.Horizontal) {
      topComponent = expressionModelPanel
      bottomComponent = logPanel
    }
  }
  
  log("Opened raw data file \" " + rawDataModel.name + "\"")
  saveExpressionModelMenuItem.enabled = false
  exportExpressionModelMenuItem.enabled = false
  expressionModelPanel.minimumSize = new scala.swing.Dimension(300,300)  
  
  //////////////////////////////////////////////////////////////////////////////
  // Implement the MenuProvider trait.
  //////////////////////////////////////////////////////////////////////////////  
  /** Menus specific to this panel. Satisfies the ''MenuProvider'' trait.
    */            
  def menus = Seq( ("File", Seq(saveExpressionModelMenuItem,
                    			exportExpressionModelMenuItem,
          			            closeMenuItem 
                  			   )),
                   ("Edit", Seq( new MenuItem(Action("Clear Log") {
                      			   logPanel.clear                     			  
                    			 })
          			           ))
                 )  
  /** The unique identifier used to identify this content panel.
    *                
    * @return The unique id.
    */               
  lazy val uuid = java.util.UUID.randomUUID
  
  /** Save the current model as an "sem" file.
    *   
    * @param model	The model to save.
    */
  private def saveModel(model: SimpleExpressionModel): Option[File] = {
    val startDir = new File(getProperty("startDir"))
    val fileChooser = new FileChooser(startDir) {
      title = "Select File Save Location"
      fileFilter = new FileNameExtensionFilter("Simple Expression Model", "sem")
      selectedFile = new File(model.name)
    }
    fileChooser.showSaveDialog(this) match {
      case FileChooser.Result.Approve => var fn = fileChooser.selectedFile.toString
    		  							 if (!fn.endsWith(".sem")) fn = fn+".sem"
    		  							 val file = new File(fn)
    		  							 val outStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)))
                                         outStream.writeObject(model)
                                         outStream.close
         								 Some(file)
      case _                          => None
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Define all of the reactive event handling for the panel.
  //////////////////////////////////////////////////////////////////////////////    		  					 		      
  listenTo(controlPanel.validateButton)
  listenTo(controlPanel.processButton)
  listenTo(expressionModelPanel.clearButton)
  reactions += {
    case ButtonClicked(component) if component == controlPanel.validateButton =>
      log("Validating raw data model")
      val issues = validate	 
      issues.foreach(issue => log(issue.toString))
      log("Validation identified " + issues.length + " total issues with the raw data")
    case ButtonClicked(component) if component == controlPanel.processButton =>
      log("Processing raw data model")
      val errors = validate.filter(issue => issue.issueType == ValidationIssueType.Error)
      if (errors.length > 0) log("Raw data has " + errors.length + 
                                 " errors and cannot be processed. Run validate for details")
      else {
        RawDataToSimpleExpressionModel(rawDataModel,
                                       controlPanel.isFirstRowColumnLabels.selected,
	 		                           controlPanel.geneSymbolColumn-1,
	 		                           controlPanel.pValueColumn-1,
	 		                           controlPanel.foldRatioColumn-1,
	 		                           controlPanel.foldChangeDescriptionColumn-1, 
	 		                           controlPanel.columnNoColumn-1, 
	 		                           controlPanel.transcriptIdColumn-1) match {
          case Some(newDataModel) =>
            setExpressionModel(newDataModel)
            saveExpressionModelMenuItem.enabled = true
            exportExpressionModelMenuItem.enabled = true
            log("Raw data processing produced a simple expression model with " + newDataModel.rows + " entries.")
          case None =>
            log("Raw data processing did not produce an expression model, probably due to invalid data.")
        }
      }
    case ButtonClicked(component) if component == expressionModelPanel.clearButton =>      
      setExpressionModel(new DummySimpleExpressionModel)
      saveExpressionModelMenuItem.enabled = false
      exportExpressionModelMenuItem.enabled = false
  }  
  
  //////////////////////////////////////////////////////////////////////////////
  // Implement the Log trait, and use it to log an initial message.
  //////////////////////////////////////////////////////////////////////////////
  def log(message: String) = logPanel.log(message)
  
  //////////////////////////////////////////////////////////////////////////////
  // Support methods.
  //////////////////////////////////////////////////////////////////////////////
   /** Slight shorthand for calling the validator, and 
    *  
    *   - Maps the column numbers input parameters (which are indexed from 1 in 
    *     the UI) to 0-based indices consistent with the validator, 
    *   - Maps the results from the validator (which indexes rows from 0) to
    *     1-based indices consistent with the UI.
    * 
    * @return  A sequence of validation issues including both errors and 
    *          warnings.
    */
  private def validate = ValidateModel(rawDataModel, 
    		  					 		controlPanel.isFirstRowColumnLabels.selected,
    		  					 		controlPanel.geneSymbolColumn-1,
    		  					 		controlPanel.pValueColumn-1,
    		  					 		controlPanel.foldRatioColumn-1).map(issue =>
    		  					 		  ValidationIssue(row=issue.row+1, 
    		  					 		      issueType=issue.issueType, 
    		  					 		      description=issue.description))
  /** Takes care of the multiple steps required to change, update or clear the
    * expression model.  
    * 
    * @param newDataModel	The new data model to update to, which might include
    * 						a "dummy" model if you want to clear.                      
    */    		  					 		      
  private def setExpressionModel(newDataModel: SimpleExpressionModel) = {
    expressionModelPanel.update(newDataModel)    
  }
}

/** This panel provides controls so that the user can manage the process of  
  * transforming the raw expression data into a processed expression model.
  * 
  * @todo There are probably too many levels of layout manager here, and it 
  *       can no doubt be simplified.
  *       
  * @author Jamie Lawson
  */
private class ModelControlPanel(rawDataModel: RectangleModel[String],
                                rawDataDisplay: RectangleModelPanel) extends BorderPanel {
  border = titledBorder("Model Control")
  minimumSize = new Dimension(300,430)
  val entityHeight = 20
  val comboSize = new java.awt.Dimension(50, entityHeight)
  
  //////////////////////////////////////////////////////////////////////////////
  // Widgets to listen to or check status of externally, or process internally.
  //////////////////////////////////////////////////////////////////////////////
  val validateButton = new Button("Validate Raw Data")
  val processButton = new Button("Process Raw Data")
  val isFirstRowColumnLabels = new CheckBox {
    getGeneSymbolLikelyColumn(rawDataModel) match {
      case Some(column) => selected = true
      case None         => selected = false
    }
  }
  private val geneSymbolColumnChooser = new ComboBox[Int](1 to rawDataModel.columns) {
    maximumSize = comboSize
    name = "Gene Symbol Column:"
    getGeneSymbolLikelyColumn(rawDataModel) match {
      case Some(column) => peer.setSelectedIndex(column-1)
                           rawDataDisplay.setPreferredColumnWidth(column, candidateColumnPreferredWidth)
      case None         =>
    }
  }
  private val pValueColumnChooser = new ComboBox(1 to rawDataModel.columns) {
    maximumSize = comboSize          
    name = "P-Value Column:"
    getPValueLikelyColumn(rawDataModel) match {
      case Some(column) => peer.setSelectedIndex(column-1)
                           rawDataDisplay.setPreferredColumnWidth(column,candidateColumnPreferredWidth)
      case None         =>
    }          
  }
  private val foldRatioColumnChooser = new ComboBox(1 to rawDataModel.columns) {
    maximumSize = comboSize          
    name = "Fold Change Column:"
    getFoldRatioLikelyColumn(rawDataModel) match {
      case Some(column) => peer.setSelectedIndex(column-1)
                           rawDataDisplay.setPreferredColumnWidth(column,candidateColumnPreferredWidth)
      case None         =>
    }
  }
  private val foldChangeDescriptionColumnChooser = new ComboBox(1 to rawDataModel.columns) {
    maximumSize = comboSize        
    name = "Fold Change Desc. Column:"
    getFoldChangeDescriptionLikelyColumn(rawDataModel) match {
      case Some(column) => peer.setSelectedIndex(column-1)
                           rawDataDisplay.setPreferredColumnWidth(column,candidateColumnPreferredWidth)
      case None         =>
    }           
  }
  private val transcriptIdColumnChooser = new ComboBox(1 to rawDataModel.columns) {
    maximumSize = comboSize        
    name = "Transcript Id Column:"
    getTranscriptIdLikelyColumn(rawDataModel) match {
      case Some(column) => peer.setSelectedIndex(column-1)
                           rawDataDisplay.setPreferredColumnWidth(column,candidateColumnPreferredWidth)
      case None         =>
    }           
  }
  private val columnNoColumnChooser = new ComboBox(1 to rawDataModel.columns) {
    maximumSize = comboSize
    name = "Column# Column:"
    getColumnNumberLikelyColumn(rawDataModel) match {
      case Some(column) => peer.setSelectedIndex(column-1)
                           rawDataDisplay.setPreferredColumnWidth(column,candidateColumnPreferredWidth)
      case None         =>
    }          
  }
  
  private val usePValueSelector = new CheckBox {
    getPValueLikelyColumn(rawDataModel) match {
      case Some(column) => selected = true
      case None         => selected = false
    }
  }
  private val useFoldRatioSelector = new CheckBox {
    getFoldRatioLikelyColumn(rawDataModel) match {
      case Some(column) => selected = true
      case None         => selected = false
    }
  }
  private val useFoldChangeDescriptionSelector = new CheckBox {
    getFoldChangeDescriptionLikelyColumn(rawDataModel) match {
      case Some(column) => selected = true
      case None         => selected = false
    }
  }
  private val useTranscriptIdSelector = new CheckBox {
    getTranscriptIdLikelyColumn(rawDataModel) match {
      case Some(column) => selected = true
      case None         => selected = false
    }
  }
  private val  useColumnNoSelector = new CheckBox {
    getColumnNumberLikelyColumn(rawDataModel) match {
      case Some(column) => selected = true
      case None         => selected = false
    }
  }
  
  /** Returns the column (indexed from 1) for the gene symbol in the raw data.
    * 
    * @return The column in the raw data model where the gene symbol is found.
    */
  def geneSymbolColumn: Int = geneSymbolColumnChooser.selection.item
  
  /** Returns the column (indexed from 1) for the P-Value in the raw data, or
    * -1 if P-Value is not to be included in the expression model. 
    * 
    * @return The column in the raw data model where the P-Value is found.
    */
  def pValueColumn: Int = if (!usePValueSelector.selected) -1
                          else pValueColumnChooser.selection.item
                          
  /** Returns the column (indexed from 1) for the fold-ratio in the raw data, or
    * -1 if fold-ratio is not to be included in the expression model.
    *
    * @return The column in the raw data model where the fold-ratio is found. 
    */
  def foldRatioColumn: Int = if (!useFoldRatioSelector.selected) -1
                             else foldRatioColumnChooser.selection.item
  
  /** Returns the column (indexed from 1) for the fold change description in
    * the raw data, or -1 if the fold change description is not to be included
    * in the expression model.  
    * 
    * @return The column in the raw data model where the fold change description
    *         is found.
    */
  def foldChangeDescriptionColumn: Int = if (!useFoldChangeDescriptionSelector.selected) -1
                             			 else foldChangeDescriptionColumnChooser.selection.item

  /** Returns the column (indexed from 1) for the transcript id in the raw data,
    * or -1 if fold-ratio is not to be included in the expression model.
    *
    * @return The column in the raw data model where the transcript id is found. 
    */  			 
  def transcriptIdColumn: Int = if (!useTranscriptIdSelector.selected) -1
                                else transcriptIdColumnChooser.selection.item
                                
  /** Returns the column (indexed from 1) for the "Column#" in the raw data, or
    * -1 if the Column# is not to be included in the expression model.
    *
    * @return The column in the raw data model where the Column# is found. 
    */

  def columnNoColumn: Int = if (!useColumnNoSelector.selected) -1
                            else columnNoColumnChooser.selection.item                           
  //////////////////////////////////////////////////////////////////////////////
  // Layout the stuff. This is a pretty complex panel, and the main
  // responsibility of the code for this class is to do this layout.
  //////////////////////////////////////////////////////////////////////////////
  layout(new TextArea {
    text = "Name: " + getLocalFileName(rawDataModel.name) + "\n" +
           "Raw Data Rows:    " + rawDataModel.rows + "\n" +
           "Raw Data Columns: " + rawDataModel.columns + "\n"
    editable = false
    background = new java.awt.Color(0xF0F0F0)
  }) = North
  
  layout(new BorderPanel {
    border =  titledBorder("Required Data")
    layout(new GridPanel(3,1) {
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += new Label("First Row is Column Labels?     ")
        contents += isFirstRowColumnLabels
      }
      contents += new BoxPanel(Orientation.Horizontal) {
        contents += new Label("Gene Symbol Column:             ")
        contents += geneSymbolColumnChooser 
      }
    }) = North
    layout(new BorderPanel {
      layout(new GridPanel(2,1) {
        border =  titledBorder("At least one of")
        contents += new BoxPanel(Orientation.Horizontal) {
          contents += new Label("P-Value Column:                      ")
          contents += pValueColumnChooser 
          contents += usePValueSelector 
        }
        contents += new BoxPanel(Orientation.Horizontal) {
          contents += new Label("Fold Change Column:             ")
          contents += foldRatioColumnChooser 
          contents += useFoldRatioSelector 
        }
      }) = North
      layout(new GridPanel(3,1) {
        border =  titledBorder("Optional Data")
        contents += new BoxPanel(Orientation.Horizontal) {
          contents += new Label("\"Column#\" Column:               ")
          contents += columnNoColumnChooser 
          contents += useColumnNoSelector
        }    
        contents += new BoxPanel(Orientation.Horizontal) {
          contents += new Label("Transcript ID Column:           ")
          contents += transcriptIdColumnChooser 
          contents += useTranscriptIdSelector 
        }
        contents += new BoxPanel(Orientation.Horizontal) {
          contents += new Label("Fold Change Desc. Column: ")
          contents += foldChangeDescriptionColumnChooser
          contents += useFoldChangeDescriptionSelector 
        }
      }) = South      
    }) = Center
  }) = Center
  layout(new GridPanel(2,1) {
    contents += validateButton
    contents += processButton
  }) = South    
}