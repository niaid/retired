package gov.nih.niaid.granite.gravel.rectanglemodel

import javax.swing.table.DefaultTableModel
import gov.nih.niaid.granite.core.model.RectangleModel

/** A table model appropriate for the display and management of a 
  * ''RectangleModel[String]''
  *  
  * @param dataModel	The model to represent in a table.
  * 
  * @todo Generalize the model so that it can support any ''RectangleModel''.
  * 
  * @author Jamie Lawson
  */
class RectangleModelTableModel(dataModel: RectangleModel[String]) extends DefaultTableModel(dataModel.rows, dataModel.columns+1) {
  val columnNames = new Array[Object](dataModel.columns+1)
  columnNames(0) = "Row#"
  for (col <- 1 to dataModel.columns) columnNames(col) = col.toString
  setColumnIdentifiers(columnNames)
  for (row <- 0 to dataModel.rows-1) {
    setValueAt((row+1).toString, row, 0)
    for (col <- 1 to dataModel.columns) {
      dataModel(row, col-1) match {
        case Some(value) => setValueAt(value, row, col)
        case None        =>
      }
    }  
  }
  override def isCellEditable(row: Int, column: Int): Boolean = {
    if (column == 0) false
    else super.isCellEditable(row, column)
  }
}