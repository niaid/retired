package gov.nih.niaid.granite.gravel

/** Supplies interfaces and some classes for dealing with applications whose
  * main menu items depend on which components are currently selected. For 
  * instance, in an application that uses a ''TabbedPane'' for top level 
  * interaction with the user, the menus in the menu bar might change depending
  * on what tab is on top. That specific kind of functionality is managed by
  * the class ''MenuManagingTabbedPane''. But the traits provided,
  * (''MenuInfo'', and ''MenuProvider'') can be used to support other kinds of
  * components with similar needs.
  * 
  * @todo Currently, the functionality only supports augmenting existing menus
  *       on the menu bar. But everything is in place to support adding new
  *       menus on the top level menu bar, and this should be done. 
  * 
  * @author Jamie Lawson 
  */
package object menus {
}