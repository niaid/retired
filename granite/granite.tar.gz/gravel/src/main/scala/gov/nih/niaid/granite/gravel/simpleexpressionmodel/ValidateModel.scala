package gov.nih.niaid.granite.gravel.simpleexpressionmodel

import scala.collection.mutable.ListBuffer
import gov.nih.niaid.granite.core.model.RectangleModel

/** An enumeration object to identify whether a validation issue is a warning
  * or an error. 
  * 
  * @author Jamie Lawson
  */
object ValidationIssueType extends Enumeration {
  type ValidationIssueType = Value
  val Warning, Error = Value
}
import ValidationIssueType._

/** A simple case class to describe validation issues.
  * 
  * @author Jamie Lawson
  * 
  * @param row				The row number (indexed from 0) in the original 
  * 						raw model, like a ''RectangleModel'', where the 
  *       					issue was identified.
  * @param issueType		Whether the issue was a warning or an error.
  * @param description		A specific description of the issue.
  */
case class ValidationIssue(row: Int, issueType: ValidationIssueType, description:String) {
  override def toString: String = {
    issueType + ": at row" + row +  " -> " + description
  }  
}

/** Validates a raw ''RectangleModel[String]'' as a model of expression data.
  * Checks for a wide variety of possible errors and suspicious conditions, 
  * including:
  * 
  *  - Are the column numbers for the data valid?
  *  - Is at least one of fold-ratio and p-value present?
  *  - Is there missing data that we don't expect to be missing?
  *  - Are the P-Value and fold-ratio (if present) properly formatted as
  *    floating point numbers and if so, are they in the legal or expected
  *    ranges?
  *    
  * The results of the validation are given back as an array of 
  * ''ValidationIssue'', which gives a type of issue (i.e. error or warning),
  * a row number (indexed from 0, except in the case where the basic schema
  * is wrong (i.e. no valid Gene Symbol column defined) in which case the row
  * number is 0, and a description of the error.
  * 
  * @author Jamie Lawson  
  * 
  * @todo Determine whether a gene symbol that is an empty string is an error, 
  *       or just an entry to be ignored. In the Sardinia data, there were many 
  *       lines that had empty gene symbols. These seem to have been related to 
  *       negative controls. It was somewhat strange and there was some 
  *       discussion about whether or not this was an error.
  */
object ValidateModel {
  /** Checks for, and reports on, a wide range of possible errors in the raw
    * data model.
    * 
    * @param rawDataModel			The model to check
    * @param firstRowIsColumnLabels Whether to ignore the first row of the
    * 								data model (which is often used to give
    *         						column headings so reviewers can understand
    *               				the data.
    * @param geneSymbolColumn       The column (indexed from 0 to model.columns-1)
    *                               where the gene symbol is expected.
    * @param pValueColumn           The column (indexed from 0 to model.columns-1)
    *                               where the P-Value is expected.
    * @param foldRatioColumn        The column (indexed from 0 to model.columns-1)
    *                               where the fold ratio is expected.
    * 
    */
  def apply(rawDataModel:RectangleModel[String],
      firstRowIsColumnLabels:Boolean,
      geneSymbolColumn:Int, 
      pValueColumn:Int = -1, 
      foldRatioColumn:Int = -1): Seq[ValidationIssue] = {
    var errors = 0  // Note that we can't simply use issues.length because there might also be warnings.
    val issues = new ListBuffer[ValidationIssue]
    //  Check to see if the gene symbol column is properly defined.
    if (geneSymbolColumn < 0 || geneSymbolColumn >= rawDataModel.columns) {
      issues += ValidationIssue(row = -1, 
    		  					issueType=Error, 
    		  					description="Gene Symbol column illegally defined. Found " + 
    		  								(geneSymbolColumn) + "expected 0.." + (rawDataModel.columns-1))
      errors += 1
    }
    //  Check to see if the p-value and/or fold ratio columns are properly defined.
    val validFRColumn = foldRatioColumn >= 0 && foldRatioColumn < rawDataModel.columns
    val validPVColumn = pValueColumn >= 0 && pValueColumn < rawDataModel.columns
    if (!validFRColumn && !validPVColumn) {
      issues += ValidationIssue(row = -1, 
    		  					issueType=Error,
    		  					description="At least one of p-value column or fold ratio column must be properly defined")
      errors += 1
    }
    //  If the columns aren't defined in a reasonable way, it makes no sense to
    //  go on, so just return there. Otherwise, go on and find other stuff.
    if (errors > 0) return issues.toSeq
    
    for (row <- modelStartRow(firstRowIsColumnLabels) to rawDataModel.rows-1) {
      validateRow(rawDataModel, row, geneSymbolColumn, pValueColumn, foldRatioColumn) foreach(issue => {
        issues += issue
        if (issue.issueType == Error) errors += 1
      })
      //  If we exceed the maximum allowable errors, return now.
      //  Otherwise, go on to the next row.
      if (errors >= maximumValidationErrors) return issues.toSeq
    }
    issues.toSeq
  }
  
  /** Validates a single row in the data model and returns all issues, including
    * both errors and warnings, discovered in that row.
    * 
    * @param rawDataModel		The data model that supplies the row of data.
    * @param row				The row in the data model to validate.
    * @param geneSymbolColumn  	The column where the gene symbol is.
    * @param pValueColumn		The column where the p-value is.
    * @param foldRatioColumn	The column where the fold ratio is.
    * 
    * @return A sequence containing all issues 
    */
  def validateRow(rawDataModel: RectangleModel[String], 
		  		  row: Int, 
		  		  geneSymbolColumn: Int,
		  		  pValueColumn: Int,
		  		  foldRatioColumn: Int): Seq[ValidationIssue] = {
    val issues = new ListBuffer[ValidationIssue]
    //  Check the gene symbol for errors.
    rawDataModel(row, geneSymbolColumn) match {
      case Some(geneSymbol) => 
        // In the case of the Sardinia data, there are lots of lines with empty string for the gene symbol.
        // This may be an error, or we may just want to ignore those lines as negative controls or something like that. 
        //if (geneSymbol.length == 0) {
        //    return Some(ValidationIssue(lineNo=row+1, issueType=Error, description="Empty gene symbol"))
        //}
      case None => 
        issues += ValidationIssue(row=row, issueType=Error, description="Gene symbol missing or in wrong column")          
    }
      
    //  Check the p-value for errors.
    if (pValueColumn >= 0) rawDataModel(row, pValueColumn) match {
      case Some(pValueString) =>
        try {
          val pVal = pValueString.toDouble
          // Is the value between 0.0 and 1.0?
          if (pVal < 0.0) {
            issues += ValidationIssue(row=row, issueType=Error, description="P-Value cannot be negative. Found value is " + pVal)
          }
          if (pVal > 1.0) {
            issues += ValidationIssue(row=row, issueType=Error, description="P-Value cannot be >1.0. Found value is " + pVal)
          }
        } catch {
          // Was there an error in parsing?
          case nfe:NumberFormatException =>
            issues += ValidationIssue(row=row, issueType=Error, description="P-Value found ("+pValueString+") is not a properly formatted floating point number")
          case npe:NullPointerException =>
            issues += ValidationIssue(row=row, issueType=Error, description="P-Value found was null")
          case _:Throwable =>
            issues += ValidationIssue(row=row, issueType=Error, description="Error when parsing P-Value from string<"+pValueString +">")
        }
      case None => 
        issues += ValidationIssue(row=row, issueType=Error, description="Missing P-value in expected column")
    }
      
    //  Check the fold ratio for errors and warnings.
    if (foldRatioColumn >=0) rawDataModel(row, foldRatioColumn) match {
      case Some(foldRatioString) =>
	    try {
	      val foldRatio = foldRatioString.toDouble
	      if (foldRatio > foldRatioSuspicionThreshold) {
	        issues += ValidationIssue(row=row, issueType=Warning, description="Fold-ratio (" + foldRatioString + ") is suspiciously high")
	      }
	      if (foldRatio < -foldRatioSuspicionThreshold) {
	        issues += ValidationIssue(row=row, issueType=Warning, description="Fold-ratio (" + foldRatioString + ") is suspiciously high")
	      }            
        } catch {
          case nfe:NumberFormatException =>
            issues += ValidationIssue(row=row, issueType=Error, description="Fold-ratio found ("+foldRatioString+") is not a properly formatted floating point number")
          case npe:NullPointerException =>
            issues += ValidationIssue(row=row, issueType=Error, description="Fold-ratio found was null")
          case _:Throwable =>
            issues += ValidationIssue(row=row, issueType=Error, description="Error when parsing fold-ratio from string<"+foldRatioString +">")
        }
      case None => 
        issues += ValidationIssue(row=row, issueType=Error, description="Missing fold-ratio in expected column")
    }
    issues
  }
  
  /** Helper function avoids having to make the starting row in iterations and
    * comprehensions a ''var''. If the first row of the raw data is column 
    * labels, then the real model starts at row 1, elsewise it starts at row 0.
    * 
    * @param firstRowIsColumnLabels	Whether the first row of the raw model is
    *                               used for column labels.
    * 
    * @return The row in the raw data model where the real data starts.
    */
  def modelStartRow(firstRowIsColumnLabels: Boolean) = if (firstRowIsColumnLabels) 1  else 0
}
