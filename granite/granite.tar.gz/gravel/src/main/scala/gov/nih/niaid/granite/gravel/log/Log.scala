package gov.nih.niaid.granite.gravel.log

/** Basic contract for a thing that logs messages.
  * 
  * @author Jamie Lawson
  */
trait Log {
  /** Appends a message to the existing log text.
    * 
    * @param message	The new text to log.
    */
  def log(message: String)
}