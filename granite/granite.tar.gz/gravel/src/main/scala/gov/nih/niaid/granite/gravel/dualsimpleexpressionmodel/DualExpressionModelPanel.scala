package gov.nih.niaid.granite.gravel.dualsimpleexpressionmodel

import scala.swing._
import scala.swing.BorderPanel.Position._
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.gravel.dualsimpleexpressionmodel.DualSimpleExpressionModel
import gov.nih.niaid.granite.gravel.simpleexpressionmodel.DummySimpleExpressionModel
import gov.nih.niaid.granite.gravel.simpleexpressionmodel.ExpressionModelPanel
import gov.nih.niaid.granite.gravel.simpleexpressionmodel.SimpleExpressionModel
import scala.swing.ComboBox.stringEditor

/** Displays either 1 or 2 expression data panels. If 2, then displays them 
  * side-by-side. This is used to manage Responder/Nonresponder, or Healthy/Sick
  * data sets where you have two closely related data sets under investigation.
  * 
  * @todo There is a lot of sloppiness in managing the housekeeping here,
  * 	  particularly of column widths and multiple expression model views. 
  *       It can be made much cleaner. 
  * 
  * @author Jamie Lawson
  */
class DualExpressionModelPanel(modelL: Option[SimpleExpressionModel], modelR: Option[SimpleExpressionModel]) extends BorderPanel {
  private val leftTagName = new ComboBox(Seq("Responder", "Non-Responder", "Healthy", "Sick", "Unspecified"))
  private val rightTagName = new ComboBox(Seq("Responder", "Non-Responder", "Healthy", "Sick", "Unspecified"))
  private val dualExpressionModelName = new TextField(20)
  
  def leftTag:String = leftTagName.item
  def rightTag:String = rightTagName.item

  //----------------------------------------------------------------------------
  // Note: We have to keep an additional layer of stuff here (expression panels
  // and model panels because of the way we swap stuff out of the different 
  // panels in the update method. If we don't have this additional layer, the
  // "Clear" function can't figure out how to recover. That's part of the ugly
  // housekeeping that goes on here.
  //----------------------------------------------------------------------------
  private val leftExpressionPanel = new ExpressionModelPanel(new DummySimpleExpressionModel) {
    border = titledBorder("Left Expression Model")
    minimumSize = new scala.swing.Dimension(300,300)
    setTitle("")
  }
  private val rightExpressionPanel = new ExpressionModelPanel(new DummySimpleExpressionModel) {
    border = titledBorder("Right Expression Model")
    minimumSize = new scala.swing.Dimension(300,300)
    setTitle("")
  }  
  
  private val leftModelPanel = new BorderPanel { 
    layout(leftExpressionPanel) = Center
    layout(new FlowPanel {
      contents += new Label("Tag Name: ")
      contents += leftTagName
    }) = South
  }
  
  private val rightModelPanel = new BorderPanel { 
    layout(rightExpressionPanel) = Center
    layout(new FlowPanel {
      contents += new Label("Tag Name: ")
      contents += rightTagName
    }) = South
  }  
  
  //////////////////////////////////////////////////////////////////////////////
  // Lay the components out.
  //////////////////////////////////////////////////////////////////////////////
  layout(new FlowPanel {
    contents += new Label("Dual Expression Model Name:")
    contents += dualExpressionModelName
  }) = North
  update(modelL,modelR)
  leftExpressionPanel.setNameEditable(false)
  rightExpressionPanel.setNameEditable(false)
  
  //////////////////////////////////////////////////////////////////////////////
  // Stuff for outsiders to interact with the panel.
  //////////////////////////////////////////////////////////////////////////////
  
  /** Updates the stuff that's in the panels when the underlying models change,
    * for instance, when the p-value changes. 
    * 
    * @param modelL	The model to be displayed in the left panel (as an Option).
    * @param modelR The model to be displayed in the right panel (as an Option).
    */
  def update(modelL: Option[SimpleExpressionModel], modelR: Option[SimpleExpressionModel]) = {   
    modelL match {
      case Some(mL) => modelR match {
                         case Some(mR) => show2(mL,mR)
                         case None     => showLeft(mL)
                       }
      case None     => modelR match {
                         case Some(mR) => showRight(mR)
                         case None     => show0
                       }
    }
  }
  
  /** Accessor for the data model represented by the left panel.
    * 
    * @return The model from the left panel.
    */
  def getLeftModel = leftExpressionPanel.getModel
  
  /** Accessor for the data model represented by the right panel.
    * 
    * @return The model from the right panel.
    */
  def getRightModel = rightExpressionPanel.getModel
  
  /** A view of this panel as a ''DualSimpleExpressionModel''.
    * 
    * @return The ''DualSimpleExpressionModel'' represented by this panel.
    */
  def getModel: DualSimpleExpressionModel = {
    // This is quite ugly
    var left:Option[Pair[SimpleExpressionModel, String]] = None
    var right:Option[Pair[SimpleExpressionModel, String]] = None
    getLeftModel match {
      case Some(leftM) => left = Some(leftM, leftTagName.item)
      case None        => left = None
    }
    getRightModel match {
      case Some(rightM) => right = Some(rightM, rightTagName.item)
      case None         => right = None
    }
    val modelName = if (getModelName.length == 0) "Untitled" else getModelName
    new DualSimpleExpressionModel(modelName, left, right)
  }
  
  /** Returns the name of the overall model consisting of multiple simple 
    * expression models (as opposed to the names of the individual models). 
    * 
    * @return The overall dual-expression model name.
    */
  def getModelName = dualExpressionModelName.text.trim
  
  /** Exposes the clear button on the left panel as an event source for 
    * potential listeners. 
    */
  val clearLeftButton = leftExpressionPanel.clearButton
  
  /** Exposes the clear button on the right panel as an event source for 
    * potential listeners. 
    */  
  val clearRightButton = rightExpressionPanel.clearButton
  
  //////////////////////////////////////////////////////////////////////////////
  // Private helper stuff.
  // This is where most of the sloppiness is. We maintain a couple of vars to
  // keep track of whether the left and right panels have been installed in
  // layouts. Really pretty ugly. Possibly can use some inherent feature of
  // the components, like "showing" or "displayable" to overcome.
  //////////////////////////////////////////////////////////////////////////////
  private def show0 = showLeft(new DummySimpleExpressionModel)
  
  private def showLeft(model: SimpleExpressionModel) {
    layout(leftModelPanel) = Center  
    leftExpressionPanel.update(model)
    leftExpressionPanel.initializeColumnWidths
    if (getModelName == "") dualExpressionModelName.text = model.name
  }
  
  private def showRight(model: SimpleExpressionModel) {
    layout(rightModelPanel) = Center  
    rightExpressionPanel.update(model)
    rightExpressionPanel.initializeColumnWidths
    if (getModelName == "") dualExpressionModelName.text = model.name
  }  
  
  private def show2(modelL: SimpleExpressionModel, modelR: SimpleExpressionModel) {
    layout(new SplitPane(Orientation.Vertical) {
      leftExpressionPanel.update(modelL)
      leftComponent = leftModelPanel      
      rightExpressionPanel.update(modelR)
      rightComponent = rightModelPanel      
    }) = Center
    leftExpressionPanel.initializeColumnWidths
    rightExpressionPanel.initializeColumnWidths
    // Because of the additional layer of the split pane, we need to revalidate
    // or the window does not properly reflect the current models until a resize
    // or similar event. Revalidate forces the right thing to happen.
    revalidate
  }
}
