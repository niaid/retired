package gov.nih.niaid.granite.gravel

import java.util.UUID
import java.io.{ObjectInputStream,BufferedInputStream,FileInputStream}
import swing._
import scala.collection.mutable.HashMap
import scala.swing.BorderPanel.Position._
import scala.swing.event._
import scala.swing.TabbedPane.Page
import javax.swing.JOptionPane
import javax.swing.filechooser.FileNameExtensionFilter
import java.io.File
import gov.nih.niaid.granite.core.model.{RectangleModel, RectangleModelFromCSV}
import event._
import menus._
import log._
import rectanglemodel._
import simpleexpressionmodel._
import dualsimpleexpressionmodel.DualSimpleExpressionModel
import rawdata._
import networkconstruction._
      
/** The main UI program object for Gravel. This class just binds together all
  * of the classes that make up the Gravel UI as a whole, and provides a menu
  * for users to get started.
  * 
  * @author Jamie Lawson
  */
object Gravel extends SimpleSwingApplication {  
  private val mainCanvas = new TabbedPane
  
  private val tabManager = new TabManager(mainCanvas)
  tabManager.setMenuManagementInfo(Map(("File", MenuInfo(fileMenu,2)), 
                                       ("Edit", MenuInfo(editMenu,1)),
                                       ("Help", MenuInfo(helpMenu,1))))                                     
  def top = new MainFrame {
    title = "GRANITE Gravel"
    minimumSize = applicationMinimumSize
    menuBar = makeMenuBar 
    contents = new BorderPanel {
      layout(mainCanvas) = Center      
      layout(new BoxPanel(Orientation.Horizontal) {
         border = javax.swing.BorderFactory.createLoweredBevelBorder
         contents += new Label("Status:") {
           enabled = false
         }
      } ) = South
    }
  }
  
      
  def notifyUserOfFileOpenError = {
    val optionPane = new JOptionPane("File could not be opened", JOptionPane.ERROR_MESSAGE)    
    val dialog = optionPane.createDialog("Error")
    dialog.setAlwaysOnTop(true)
    dialog.setVisible(true)
  }    

  //////////////////////////////////////////////////////////////////////////////
  // Define the menus. That is the main job of the top level application object.
  //////////////////////////////////////////////////////////////////////////////
  private lazy val fileMenu = new Menu("File") {
    name = "File"
    /*
    contents += new MenuItem(Action("New...") {
    })
    */
    contents += new MenuItem(Action("Open...") {
      val startDir = new File(getProperty("startDir"))
      val fileChooser = new FileChooser(startDir) {
        title = "Select File to Open"
        fileFilter = new FileNameExtensionFilter("Granite Files", "csv", "sem", "dem")
      }
      fileChooser.showOpenDialog(this) match {
        case FileChooser.Result.Approve =>
          val filename = fileChooser.selectedFile.toString
          if (filename.endsWith(".csv")) {
            try {
              val rawDataModel = RectangleModelFromCSV(fileChooser.selectedFile, fileChooser.selectedFile.toString, true)
              val panel = new RawDataPanel(rawDataModel.name, rawDataModel)
              panel.name = getShortLocalFileName(panel.name)
              tabManager.addTab(panel.uuid, panel)
            } catch {
              case t:Throwable => notifyUserOfFileOpenError              
            }
          } else if (filename.endsWith(".sem")) {
            try {
              val simpleExpressionModel = new ObjectInputStream(
                                              new BufferedInputStream(
                                                  new FileInputStream(fileChooser.selectedFile))).
                                                  readObject.asInstanceOf[SimpleExpressionModel]
              val panel = new NetworkConstructionPanel(simpleExpressionModel.name, Some(simpleExpressionModel), None)
              tabManager.addTab(panel.uuid, panel)
            } catch {
              case t:Throwable => 
            }
          } else if (filename.endsWith(".dem")) {
            println("DEM")
            try {
              val dualExpressionModel = new ObjectInputStream(
                                            new BufferedInputStream(
                                                new FileInputStream(fileChooser.selectedFile))).
                                                readObject.asInstanceOf[DualSimpleExpressionModel]
              val model1 = dualExpressionModel(1)
              val model2 = dualExpressionModel(2)
              val panel = new NetworkConstructionPanel(dualExpressionModel.name, dualExpressionModel(1), dualExpressionModel(2))
              tabManager.addTab(panel.uuid, panel)              
            } catch {
              case t:Throwable => t.printStackTrace; notifyUserOfFileOpenError
            }
          } else {
        	notifyUserOfFileOpenError
          }
        case _ =>
      }
    })
    contents += new MenuItem(Action("Import Raw Expression Data") {
      val startDir = new File(getProperty("startDir"))
      val fileChooser = new FileChooser(startDir) {
        title = "Select File to Open"
        fileFilter = new FileNameExtensionFilter("Gene Expression Comma Separated Variable", "csv")
      }
      if (fileChooser.showOpenDialog(this) == FileChooser.Result.Approve) {
        try {
          val rawDataModel = RectangleModelFromCSV(fileChooser.selectedFile, fileChooser.selectedFile.toString, true)
          val panel = new RawDataPanel(rawDataModel.name, rawDataModel)
          panel.name = getShortLocalFileName(panel.name)
          tabManager.addTab(panel.uuid, panel)
        } catch {
          case t:Throwable => notifyUserOfFileOpenError
        }
      }
    })
    contents += new Separator
    contents += new MenuItem(Action("Exit") {
      sys.exit(0)
    })
  }
  
  private lazy val editMenu = new Menu("Edit") {
    name = "Edit"
    contents += new MenuItem(Action("Copy") {
        enabled = false
    })
  }
  
  private lazy val helpMenu = new Menu("Help") {
    name = "Help"
    contents += new MenuItem(Action("About Gravel") {
        
    })
  }
   
  private def makeMenuBar = new MenuBar {
    contents += fileMenu 
    contents += editMenu
    contents += helpMenu
  }  
}
