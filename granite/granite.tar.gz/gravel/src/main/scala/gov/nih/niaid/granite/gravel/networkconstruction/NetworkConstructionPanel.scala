package gov.nih.niaid.granite.gravel.networkconstruction

import java.util.UUID
import java.awt.Cursor
import swing._
import scala.swing.TabbedPane.Page
import scala.collection.mutable.{HashMap,TreeSet,ListBuffer}
import scala.util.Sorting._
import javax.swing.table.DefaultTableModel
import scala.swing.BorderPanel.Position._
import scala.swing.event._
import javax.swing.filechooser.FileNameExtensionFilter
import java.io.{File,FileOutputStream,ObjectOutputStream,BufferedOutputStream,
       FileInputStream,ObjectInputStream,BufferedInputStream,FileWriter,
       FileReader,BufferedWriter,BufferedReader}
import it.uniroma1.dis.wsngroup.gexf4j.core.Node
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.gravel.log._
import gov.nih.niaid.granite.gravel.simpleexpressionmodel._
import gov.nih.niaid.granite.gravel.menus._
import gov.nih.niaid.granite.gravel.simpleexpressionmodel._
import gov.nih.niaid.granite.gravel.event._
import gov.nih.niaid.granite.gravel.significance._
import gov.nih.niaid.granite.tools.targetscan.{MirnaGraph, MirnaGraphBuilder, TargetScanReader}
import gov.nih.niaid.granite.gravel.graphpanel.MirnaNetworkPanel
import gov.nih.niaid.granite.gravel.degreeranktable._
import gov.nih.niaid.granite.gravel.dualsimpleexpressionmodel.DualExpressionModelPanel
import gov.nih.niaid.granite.gravel.dualsimpleexpressionmodel.DualSimpleExpressionModel

/** A composite panel that allows the user to construct a network from 
  * ''SimpleExpressionModels''. The top level panel also behaves as a ''Log'' 
  * so that it can write to a Gravel logging window (included in this panel).
  * 
  * @author Jamie Lawson
  * 
  * @param panelName	The name of this panel, typically used for tab titles.
  * @param model1		A ''SimpleExpressionModel'' with processed data from an
  *                 	experiment. If a model is not provided, a "dummy" model,
  *                 	with no data, will be substituted.
  * @param model2   	A second expression model.
  */
class NetworkConstructionPanel(panelName: String,
							   model1: Option[SimpleExpressionModel], 
                               model2: Option[SimpleExpressionModel]) 
    extends SplitPane(Orientation.Horizontal) with Log with MenuProvider {
  name = panelName
  private var mL:Option[SimpleExpressionModel] = None
  private var mR:Option[SimpleExpressionModel] = None
  
  //////////////////////////////////////////////////////////////////////////////
  // Define all the components of the panel and lay them out.
  //////////////////////////////////////////////////////////////////////////////
  private val dualExpressionModelPanel = new DualExpressionModelPanel(None, None)
  private val logPanel = new LogPanel
  private val significanceFilterPanel = new SignificanceFilterPanel
  private val databasePanel = new DatabasePanel
  private val expressionDataTypePanel = new ExpressionDataTypePanel
  
  private val saveDualExpressionModelMenuItem = new MenuItem(Action("Save Dual-Expression Model") {
    val model = dualExpressionModelPanel.getModel
    if (model(1) == None && model(2) == None) {
      log("No dual-expression model to save")
    } else {
      saveModel(model) match {
        case Some(file) => log("Successfully saved Dual-Expression model " + file.toString)
        case None       => log("Unknown failure while saving Dual-Expression model")
      }
    }                                                         			  
  })
  
  /** Used for doing degree rank comparisons.
    */
  private object DegreeRankOrdering extends Ordering[VertexDegree] {
    def compare(a:VertexDegree, b:VertexDegree) = a.degree compare b.degree
  }
  
  private def makeDegreeRankPanel(graph: MirnaGraph, mirnas:Boolean): DegreeRankModelPanel = {
    val nodeRanks = new ListBuffer[VertexDegree]
    if (mirnas) {
      graph.miRNAset.foreach(nodeName => {
        graph.mRNAs(nodeName) match {
          case Some(nodes) => nodeRanks += VertexDegree(nodeName, nodes.size)              
          case None => 
        }
      })      
    } else {
      graph.mRNAset.foreach(nodeName => {
        graph.miRNAs(nodeName) match {
          case Some(nodes) => nodeRanks += VertexDegree(nodeName, nodes.size)              
          case None => 
        }
      })
    }
    val sortedByRank = nodeRanks.toArray[VertexDegree]
	quickSort[VertexDegree](sortedByRank)(DegreeRankOrdering)
	val rankModel = new DegreeRankModel(dualExpressionModelPanel.leftTag, sortedByRank.toSeq)
	new DegreeRankModelPanel(new DegreeRankTableModel(rankModel)) {
      border = titledBorder((if (mirnas) "miRNA" else "mRNA") + " Degree Ranks")
    }
  }
  
  private val degreeRankMeasuresMenuItem = new MenuItem(Action("Develop Rank Measures") {   
    val cursorToRestore = cursor
    cursor = Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR)    
    makeLeftGraph match {
      case Some(graph) =>
        val mRnaDegreePanel = makeDegreeRankPanel(graph, false)
        val miRnaDegreePanel = makeDegreeRankPanel(graph,true)
        ranks.pages += new Page(dualExpressionModelPanel.leftTag, 
        					    new SplitPane(Orientation.Vertical) {
                                  leftComponent = mRnaDegreePanel
                                  rightComponent = miRnaDegreePanel
                                  dividerLocation = 255
        				   })
      case None =>        
    }
    makeRightGraph match {
      case Some(graph) =>
        val mRnaDegreePanel = makeDegreeRankPanel(graph, false)
        val miRnaDegreePanel = makeDegreeRankPanel(graph,true)
        ranks.pages += new Page(dualExpressionModelPanel.rightTag, 
        					    new SplitPane(Orientation.Vertical) {
                                  leftComponent = mRnaDegreePanel
                                  rightComponent = miRnaDegreePanel
                                  dividerLocation = 255
        				   })        
      case None =>
    }    
    cursor = cursorToRestore    
  })
  
  private val loadLeftModelMenuItem = new MenuItem(Action("Load Left Model") {
    val startDir = new File(getProperty("startDir"))
    val fileChooser = new FileChooser(startDir) {
      title = "Select File to Open"
      fileFilter = new FileNameExtensionFilter("Simple Expression Model", "sem")
    }
    if (fileChooser.showOpenDialog(this) == FileChooser.Result.Approve) {
      val input = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileChooser.selectedFile)))
      setLeftModel(Some((input.readObject).asInstanceOf[SimpleExpressionModel]))
      log("Loaded Left Expression Model from file " + getShortLocalFileName(fileChooser.selectedFile.toString))         
    } else log("Loading new Left Expression Model aborted")                     			  
  })
  
  private val loadRightModelMenuItem = new MenuItem(Action("Load Right Model") {
    val startDir = new File(getProperty("startDir"))
    val fileChooser = new FileChooser(startDir) {
      title = "Select File to Open"
      fileFilter = new FileNameExtensionFilter("Simple Expression Model", "sem")
    }
    if (fileChooser.showOpenDialog(this) == FileChooser.Result.Approve) {
      val input = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileChooser.selectedFile)))
      setRightModel(Some((input.readObject).asInstanceOf[SimpleExpressionModel]))
      log("Loaded Right Expression Model from file " + getShortLocalFileName(fileChooser.selectedFile.toString))         
    } else log("Loading new Right Expression Model aborted")                  			  
  })
  
  private val saveGraphMenuItem = new MenuItem(Action("Save Graph as Gexf.."){
    dualExpressionModelPanel.getLeftModel match {
      case Some(model) => 
        val startDir = new File(getProperty("startDir"))
        val fileChooser = new FileChooser(startDir) {
          title = "Select File Save Location"
          fileFilter = new FileNameExtensionFilter("Graph EXperts Format", "gexf")
          selectedFile = new File(dualExpressionModelPanel.getModel.name)
        }
        fileChooser.showSaveDialog(this) match {
          case FileChooser.Result.Approve =>
            val cursorToRestore = cursor
            cursor = Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR)
            log("Exporting Dual-Expression Model to Gexf file")            
            var fn = fileChooser.selectedFile.toString
    	    if (!fn.endsWith(".gexf")) fn = fn+".gexf"
    	    val file = new File(fn)
            val start = System.currentTimeMillis
            saveGexf(file) match {
              case Some(mirnaGraph) =>
                //val graphFile = new File(getProperty("startDir") + "/x__graph.gexf")
                //publish(new AddTab(new MirnaNetworkPanel(model.name, graphFile)))
                log("Graph file has " + mirnaGraph.vertices + " nodes and " + mirnaGraph.edges + " edges")
                log("Graph file construction complete, requiring " + ((System.currentTimeMillis-start)/1000) + " seconds")
              case None =>
                log("Unknown failure occurred while constructing graph file")
            }
            cursor = cursorToRestore
          case _ =>
            log("File save aborted")
        }
      case None =>
        log("No model to save as a graph")
    }    
  })
  
  private val exportToGraphMenuItem = new MenuItem(Action("Export to Graph") {
    dualExpressionModelPanel.getLeftModel match {
      case Some(model) => 
        val cursorToRestore = cursor
        cursor = Cursor.getPredefinedCursor(java.awt.Cursor.WAIT_CURSOR)
        log("Exporting Dual-Expression Model to graph view")
        val start = System.currentTimeMillis
        saveGexf(new File(getProperty("startDir") + "/x__graph.gexf")) match {
          case Some(mirnaGraph) =>
            val graphFile = new File(getProperty("startDir") + "/x__graph.gexf")
            publish(new AddTab(new MirnaNetworkPanel(model.name, graphFile)))
            log("Resulting graph has " + mirnaGraph.vertices + " nodes and " + mirnaGraph.edges + " edges")
            log("Export of Dual-Expression Model complete, requiring " + ((System.currentTimeMillis-start)/1000) + " seconds")
          case None =>
            log("Unknown failure occurred while exportint the graph")
        }
        cursor = cursorToRestore
    }
  })
  
  private def makeLeftGraph: Option[MirnaGraph] = {
    val edgeDB = databasePanel.edgeDatabase
    dualExpressionModelPanel.getLeftModel match {
      case Some(model) => val geneSymbols = model.geneSymbols		// Gather up all of the selected gene symbols and create the MirnaGraph.
        if (expressionDataTypePanel.isGene)       Some(edgeDB.filterByGene(geneSymbols))
        else if (expressionDataTypePanel.isMirna) Some(edgeDB.filterByMirna(geneSymbols))
        else                                      None
      case None =>                                None 
    }
  }
  
  private def makeRightGraph: Option[MirnaGraph] = {
    val edgeDB = databasePanel.edgeDatabase
    dualExpressionModelPanel.getRightModel match {
      case Some(model) => val geneSymbols = model.geneSymbols		// Gather up all of the selected gene symbols and create the MirnaGraph.
        if (expressionDataTypePanel.isGene)       Some(edgeDB.filterByGene(geneSymbols))
        else if (expressionDataTypePanel.isMirna) Some(edgeDB.filterByMirna(geneSymbols))
        else                                      None
      case None =>                                None 
    }
  }
  
  private def saveGexf(file: File): Option[MirnaGraph] = {
    val edgeDB = databasePanel.edgeDatabase
    dualExpressionModelPanel.getLeftModel match {
      case Some(model) => val geneSymbols = model.geneSymbols		// Gather up all of the selected gene symbols.
        log("exporting " + geneSymbols.size + " symbols ")
        val mirnaGraph = edgeDB.filterByGene(geneSymbols)			// Create the raw miRNA graph.
        val gexfBuilder = new GexfGraphObj                          // Now we need to export that graph to Gephi as a Gexf
        val map = new HashMap[String, Node]                         // Use this map to store the Gefx Nodes as we create them.
        mirnaGraph.miRNAset.foreach(miRNA => {					    // Create a node for each miRNA vertex in the raw graph.
          map += Pair(miRNA, gexfBuilder.addNode(miRNA, true, false))
        })
        mirnaGraph.mRNAset.foreach(mRNA => {						// Create a node for each mRNA vertex in the raw graph.
          map += Pair(mRNA, gexfBuilder.addNode(mRNA, true, false))
        })
        if (expressionDataTypePanel.isGene) {                       // The expression data is gene/messengerRNA expression data...
          mirnaGraph.miRNAset.foreach(miRNA => {       				// Get the names of the miRNAs 
		    map.get(miRNA) match {                    				// Find the Gexf node associated with it.
		      case Some(miRnaSrc) =>
		        mirnaGraph.mRNAs(miRNA) match {        				// See if there are any mRNA's associated with it in the raw graph.
		          case Some(mRNAs) => mRNAs.foreach(mRNA => {   	// If there are, find the destination vertices, 
		            map.get(mRNA) match {                  		    // as Gexf Nodes
   		              case Some(mRnaDest) =>                        // If you find the mRNA node, add the edge to the Gexf graph.
		                gexfBuilder.addEdge(miRnaSrc, mRnaDest)
  	                  case None =>
		            }
		          })
		          case None =>
		        } 
		      case None =>
	  	    }
          })
        } else {                                                    // The expression data is micro-RNA expression data... 
          mirnaGraph.mRNAset.foreach(mRNA => {       				// Get the names of the messenger RNAs 
		    map.get(mRNA) match {                    				// Find the Gexf node associated with it.
		      case Some(mRnaSrc) =>
		        mirnaGraph.miRNAs(mRNA) match {        				// See if there are any miRNA's associated with it in the raw graph.
		          case Some(miRNAs) => miRNAs.foreach(miRNA => {   	// If there are, find the destination vertices, 
		            map.get(miRNA) match {                  		// as Gexf Nodes
   		              case Some(miRnaDest) =>                       // If you find the miRNA node, add the edge to the Gexf graph.
		                gexfBuilder.addEdge(mRnaSrc, miRnaDest)
  	                  case None =>
		            }
		          })
		          case None =>
		        } 
		      case None =>
	  	    }
          })          
        }
        val strWriter = new BufferedWriter(new FileWriter(file))
        gexfBuilder.writeGexf(strWriter)
        strWriter.close
        Some(mirnaGraph)
      case None =>
        None
    }
  }
  
  val ranks = new TabbedPane
  
  topComponent = new SplitPane(Orientation.Vertical) {
    leftComponent = dualExpressionModelPanel
    rightComponent = new BorderPanel {
      layout(significanceFilterPanel) = North
      layout(new BorderPanel {
        layout (databasePanel) = North
        layout(new BorderPanel {
          layout(expressionDataTypePanel) = North
          layout(ranks) = Center
        }) = Center
      }) = Center
    }
  }
  
  bottomComponent = logPanel
  setLeftModel(model1)
  setRightModel(model2)
  
  //////////////////////////////////////////////////////////////////////////////
  // Now deal with all of the event handling.
  //////////////////////////////////////////////////////////////////////////////
  listenTo(significanceFilterPanel.foldChangeSelector)
  listenTo(significanceFilterPanel.pValueSelector)
  listenTo(significanceFilterPanel.fr11)
  listenTo(significanceFilterPanel.fr12)
  listenTo(significanceFilterPanel.fr15)
  listenTo(significanceFilterPanel.p001)
  listenTo(significanceFilterPanel.p01)
  listenTo(significanceFilterPanel.p05)
  reactions += {
    case ButtonClicked(component) if component == significanceFilterPanel.foldChangeSelector =>
      updateExpressionModels
      if (significanceFilterPanel.foldChangeSelector.selected) log("Fold change added to filter criteria")
      else log("Fold change removed from filter criteria")
    case ButtonClicked(component) if component == significanceFilterPanel.pValueSelector =>
      updateExpressionModels
      if (significanceFilterPanel.pValueSelector.selected) log("P-value added to filter criteria")
      else log("P-value removed from filter criteria")
    case ButtonClicked(component) if component == significanceFilterPanel.fr11 =>
      if (significanceFilterPanel.foldChangeSelector.selected) {
        updateExpressionModels
        log("Fold ratio threshold changed to 1.1") 
      }
    case ButtonClicked(component) if component == significanceFilterPanel.fr12 =>
      if (significanceFilterPanel.foldChangeSelector.selected) {
        updateExpressionModels
        log("Fold ratio threshold changed to 1.2") 
      }
    case ButtonClicked(component) if component == significanceFilterPanel.fr15 =>
      if (significanceFilterPanel.foldChangeSelector.selected) {
        updateExpressionModels
        log("Fold ratio threshold changed to 1.5") 
      }
    case ButtonClicked(component) if component == significanceFilterPanel.p001 =>
      if (significanceFilterPanel.pValueSelector.selected) {
        updateExpressionModels
        log("P-value threshold changed to 0.001") 
      }
    case ButtonClicked(component) if component == significanceFilterPanel.p01 =>
      if (significanceFilterPanel.pValueSelector.selected) {
        updateExpressionModels
        log("P-value threshold changed to 0.01") 
      }
    case ButtonClicked(component) if component == significanceFilterPanel.p05 =>
      if (significanceFilterPanel.pValueSelector.selected) {
        updateExpressionModels
        log("P-value threshold changed to 0.05") 
      }
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // These two methods need to be the only place where mL and mR are assigned!!
  // Note that whenever we change models, we blow away any existing rank
  // information.
  //////////////////////////////////////////////////////////////////////////////
  private def setLeftModel(leftModel: Option[SimpleExpressionModel]) {
    mL = leftModel
    ranks.pages.remove(0, ranks.pages.size)    
    updateExpressionModels    
  }
  
  private def setRightModel(rightModel: Option[SimpleExpressionModel]) {
    mR = rightModel
    ranks.pages.remove(0, ranks.pages.size)    
    updateExpressionModels
  }
  
  private def updateExpressionModels = {    
    /*
    leftModel match {
      case Some(model) => log("Opened an expression model \" " + model.name + "\" on the left")
      case None        => 
    }
    rightModel match {
      case Some(model) => log("Opened an expression model \" " + model.name + "\" on the right")
      case None        => 
    }
    */
    //--TODO:-------------------------------------------------------------------
    // This stuff is pretty ugly. The idea is to filter the datasets without
    // disturbing the original. It would be a lot nicer if we could simply pass
    // a predicate to the filter method. We wouldn't need the vars.
    //--------------------------------------------------------------------------
    var filteredML = mL
    var filteredMR = mR
    significanceFilterPanel.pValue match {
      case Some(pValue) => 
        filteredML match {
          case Some(expressionModel) => filteredML = Some(expressionModel.filterByPValue(pValue))
          case None =>
        }
        filteredMR match {
          case Some(expressionModel) => filteredMR = Some(expressionModel.filterByPValue(pValue))
          case None =>
        }
      case None =>
    }
    significanceFilterPanel.foldChange match {
      case Some(foldChange) => 
        filteredML match {
          case Some(expressionModel) => filteredML = Some(expressionModel.filterByFoldChange(foldChange))
          case None =>
        }
        filteredMR match {
          case Some(expressionModel) => filteredMR = Some(expressionModel.filterByFoldChange(foldChange))
          case None =>
        }
      case None =>
    }
    dualExpressionModelPanel.update(filteredML, filteredMR)
  }
  
  
  //////////////////////////////////////////////////////////////////////////////
  // Define all of the MenuProvider stuff.
  //////////////////////////////////////////////////////////////////////////////  
  /** Menus specific to this panel. Satisfies the ''MenuProvider'' trait.
    */  
  def menus = Seq( ("File", Seq(  loadLeftModelMenuItem,
		  						  loadRightModelMenuItem,
                    			  saveDualExpressionModelMenuItem,
                    			  saveGraphMenuItem,
                                  exportToGraphMenuItem,
                                  degreeRankMeasuresMenuItem,
          			              new MenuItem(Action("Close") {
          			                 publish(new TabClosing(this))
	  							     log("Closing file")
  								  })
                  			   )),
                   ("Edit", Seq( new MenuItem(Action("Clear Log") {
                      			   logPanel.clear                     			  
                    			 })
          			           ))
                 )
  /** The identifier that the tab manager uses to identify this content panel.
    * 
    * @return the unique id.
    */
  lazy val uuid = UUID.randomUUID                 

  /** Save the current model as an "dem" file.
    *   
    * @param model	The model to save.
    */
  private def saveModel(model: DualSimpleExpressionModel): Option[File] = {
    val startDir = new File(getProperty("startDir"))
    val fileChooser = new FileChooser(startDir) {
      title = "Select File Save Location"
      fileFilter = new FileNameExtensionFilter("Dual Expression Model", "dem")
      selectedFile = new File(model.name)
    }
    fileChooser.showSaveDialog(this) match {
      case FileChooser.Result.Approve => var fn = fileChooser.selectedFile.toString
    		  							 if (!fn.endsWith(".dem")) fn = fn+".dem"
    		  							 val file = new File(fn)
    		  							 val outStream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)))
                                         outStream.writeObject(model)
                                         outStream.close
         								 Some(file)
      case _                          => None
    }
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Define all of the reactive event handling for the panel.
  //////////////////////////////////////////////////////////////////////////////
  listenTo(dualExpressionModelPanel.clearLeftButton)
  listenTo(dualExpressionModelPanel.clearRightButton)
  reactions += {
    case ButtonClicked(component) if component == dualExpressionModelPanel.clearLeftButton =>
      setLeftModel(None)      
    case ButtonClicked(component) if component == dualExpressionModelPanel.clearRightButton =>
      setRightModel(None)
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Implement the Log trait, and use it to log an initial message.
  //////////////////////////////////////////////////////////////////////////////
  def log(message: String) = logPanel.log(message)
  
  //////////////////////////////////////////////////////////////////////////////
  // Support methods.
  //////////////////////////////////////////////////////////////////////////////
}

/** A small panel for selecting (from a combo box) which database to build the
  * network against.
  *  
  * @author Jamie Lawson 
  */
private class DatabasePanel extends BorderPanel {
  border = titledBorder("Database")
  val selector = new ComboBox(Seq("TargetScan Predicted"))
  layout(selector) = North

  def edgeDatabase: MirnaGraph = {
    val homeDir = getProperty("startDir") + "/target_scan"
    val filenameBase = "/pairssplit-conserved-family-info."
    val filenames = List("aa.csv", "ab.csv", "ac.csv", "ad.csv", "ae.csv", "af.csv", "ag.csv", "ah.csv", "ai.csv", "aj.csv", "ak.csv", "al.csv", "am.csv", "an.csv", "ao.csv")
    TargetScanReader(filenames.map(homeDir+filenameBase+_))
  }
}

/** A small panel for selecting whether the expression data in the network
  * construction panel is gene expression data or miRNA expression data. The
  * default is gene expression data. 
  * 
  * @author Jamie Lawson
  */
private class ExpressionDataTypePanel extends BoxPanel(Orientation.Horizontal) {
  border = titledBorder("Source of Expression Data")  
  private val mirnaButton = new RadioButton("micro-RNA")
  private val geneButton = new RadioButton("Gene/mRNA   ")
  private val expressionTypeGroup = new ButtonGroup(mirnaButton, geneButton)
  expressionTypeGroup.select(geneButton)
  contents += geneButton
  contents += mirnaButton
  
  /** Whether or not the expression data is miRNA expression data.
    *  
    * @return True if the expression data is miRNA expression data, false if
    *         the expression data is gene expression data. 
    */
  def isMirna = mirnaButton.selected
  
  /** Whether or not the expression data is gene expression data.
    * 
    * @return True if the expression data is gene expression data, false if the
    *         expression data is miRNA expression data.
    */
  def isGene = geneButton.selected
}

