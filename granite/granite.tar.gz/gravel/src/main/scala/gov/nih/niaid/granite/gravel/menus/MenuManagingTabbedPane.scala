package gov.nih.niaid.granite.gravel.menus

import scala.swing.{TabbedPane,MenuItem}
import javax.swing.JTabbedPane
import javax.swing.event.{ChangeEvent,ChangeListener}
import gov.nih.niaid.granite.gravel.event.{TabActivated,AllTabsRemoved}

/** Supports making changes to the main application's menu bar when the 
  * currently selected tab changes. It is often extremely useful to modify the 
  * menus on an application's menu bar when a new tab becomes active. Instances
  * of this class are ''TabbedPanes'' that notify the main applications (or
  * frames or whatever) that they support when the active tab changes. That way,
  * the main application can augment its menus to support the new pane, and of
  * course get rid of the menus that were associated with the other pane.
  * 
  * To use this, the main application will have to ''listenTo'' this object and
  * "react" to events of type ''TabActivated''. In addition, to hook everything
  * together, the application needs to establish which top level menus are
  * able to be augmented, and where to insert new menu items in those existing
  * top level menus. That is done by calling ''setMenuManagementInfo'', which
  * accepts a ''Map[String,MenuInfo]''. The ''String'' keys of that map give the
  * name of the menu that can be augmented, and the ''MenuInfo'' gives the 
  * actual menu and the index at which it can be augmented.
  * 
  * The following piece of code provides
  * an example:
  * 
  * {{{
  *   object MyApp extends SimpleSwingApplication {
  *     private val mainCanvas = new MenuManagingTabbedPane
  *     contents = mainCanvas
  *     listenTo(mainCanvas)
  *     reactions += {
  *       case TabActivated(component:MenuProvider) => 
  *         removeTabSpecificMenus
  *         addTabSpecificMenus(component)
  *     }
  *     val fileMenu = new Menu("File") { ... }
  *     val editMenu = new Menu("Edit") { ... }
  *     mainCanvas.setMenuManagementInfo(Map(("File", MenuInfo(fileMenu,3)), 
  *                                          ("Edit", MenuInfo(editMenu,1))))
  *   }
  * }}}
  * 
  * @author Jamie Lawson 
  * 
  * @todo Make this support adding whole menus (not just menu items) to the
  *       menu bar.
  */
class MenuManagingTabbedPane extends TabbedPane {
  peer.addChangeListener(new ChangeListener {
      def stateChanged(changeEvent: ChangeEvent) {
        val sourceTabbedPane = changeEvent.getSource.asInstanceOf[JTabbedPane] 
        sourceTabbedPane.getSelectedIndex match {
          case i if i < 0  => publish(new AllTabsRemoved)
          case i if i >= 0 => publish(new TabActivated(pages(i).content))
        }       
      }
    }
  )
  
  private def removeTabSpecificMenus(menuInfo: MenuInfo) {
    if (menuInfo.currentNumberOfComponentSpecificMenus > 0) {
      // Start from 0 to remove the separator. End with #menus to remove all of the menus.
      for (i <- 0 to menuInfo.currentNumberOfComponentSpecificMenus) menuInfo.menu.peer.remove(menuInfo.insertionPoint)
    }
  }
  
  private def addTabSpecificMenus(menuInfo:MenuInfo, newMenus:Seq[MenuItem]) = {
    if (newMenus.length > 0) {
      // We add each item to the same location in the menu, pushing the 
      // previously added item down. By reversing the sequence of menu items,
      // the resulting menu will have the new items in the same order as the
      // original sequence.      
      newMenus.reverse foreach {menuItem =>
        menuInfo.menu.peer.insert(menuItem.peer, menuInfo.insertionPoint)  
      }
      menuInfo.menu.peer.insertSeparator(menuInfo.insertionPoint)
    }    
  }
  
  private var menuMgtInfo: Map[String,MenuInfo] = null
  
  /** Used to tell the application which menus are eligible for augmenting by
    * the individual components.  
    * 
    * @param menuManagementInfo		A ''Map'' with ''Strings'' as keys and 
    *                               ''MenuInfo'' elements as values, describing
    *                               which menu items can be augmented and where
    *                               in those menu items to insert the new,
    *                               component-specific menu items.
    */
  def setMenuManagementInfo(menuManagementInfo: Map[String,MenuInfo]) = menuMgtInfo = menuManagementInfo

  /** Called by the subclass in its reactor to remove all of the 
    * component-specific menu items.
    * 
    */
  def removeTabSpecificMenus() {
     menuMgtInfo.keys.foreach { menuName => menuMgtInfo.get(menuName) match {
        case Some(menuInfo) => removeTabSpecificMenus(menuInfo)
                               menuInfo.setCurrentNumberOfComponentSpecificMenus(0)
        case None           => println("TODO: Make this add and remove top level menus too")                               
      }
    }
  }
  
  def addTabSpecificMenus(menuProvider:MenuProvider) {
    menuProvider.menus.foreach(menuSeq => {
      // menuSeq._1 is the name, menuSeq._2 is the sequence of menuItems
      menuMgtInfo.get(menuSeq._1) match {
        case Some(menuInfo) => addTabSpecificMenus(menuInfo, menuSeq._2)
                               menuInfo.setCurrentNumberOfComponentSpecificMenus(menuSeq._2.length)
        case None           => println("TODO: Make this add and remove top level menus too")
      }
    })
  }
}