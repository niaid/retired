package gov.nih.niaid.granite.gravel.menus

import scala.swing.Menu

/** A small case class that ties together:
  *   
  *  - A menu item, say, on a menu bar.
  *  - An insertion point on that menu item where component specific menu items
  *    can be inserted when that component is selected.
  *  - The number of those component-specific menu items that are 
  *    (temporarily) in the main menu.
  *     
  * @author Jamie Lawson
  * 
  * @param menu					The menu (in the main menu bar).
  * @param insertionPoint		The index in the menu (nominally, before any
  *                             components have inserted component-specific menu 
  *                             items) where new menu content should be 
  *                             inserted.
  */
case class MenuInfo(val menu: Menu, val insertionPoint: Int) {
  if (menu == null) println("WAAY BACK!!!!!")
  var currentNumberOfComponentSpecificMenus = 0
  def setCurrentNumberOfComponentSpecificMenus(newCount: Int) = currentNumberOfComponentSpecificMenus = newCount
}