package gov.nih.niaid.granite.gravel
import it.uniroma1.dis.wsngroup.gexf4j.core.EdgeType;
import it.uniroma1.dis.wsngroup.gexf4j.core.Gexf;
import it.uniroma1.dis.wsngroup.gexf4j.core.Graph;
import it.uniroma1.dis.wsngroup.gexf4j.core.Mode;
import it.uniroma1.dis.wsngroup.gexf4j.core.Node;
import it.uniroma1.dis.wsngroup.gexf4j.core.data.Attribute;
import it.uniroma1.dis.wsngroup.gexf4j.core.data.AttributeClass;
import it.uniroma1.dis.wsngroup.gexf4j.core.data.AttributeList;
import it.uniroma1.dis.wsngroup.gexf4j.core.data.AttributeType;
import it.uniroma1.dis.wsngroup.gexf4j.core.impl.GexfImpl;
import it.uniroma1.dis.wsngroup.gexf4j.core.impl.StaxGraphWriter;
import it.uniroma1.dis.wsngroup.gexf4j.core.impl.data.AttributeListImpl;
import it.uniroma1.dis.wsngroup.gexf4j.core.viz.NodeShape;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Calendar;


object StaticGexfGraph {
  def main(args: Array[String]) = {
	val gexf:Gexf = new GexfImpl
	val date = Calendar.getInstance();
		
	gexf.getMetadata
		.setLastModified(date.getTime)
		.setCreator("Gephi.org")
		.setDescription("A Web network")
	gexf.setVisualization(true)

    val graph:Graph = gexf.getGraph
	graph.setDefaultEdgeType(EdgeType.UNDIRECTED).setMode(Mode.STATIC)
		
	val attrList:AttributeList = new AttributeListImpl(AttributeClass.NODE)
	graph.getAttributeLists().add(attrList);
		
	val attUrl:Attribute = attrList.createAttribute("0", AttributeType.STRING, "url")
	val attIndegree:Attribute = attrList.createAttribute("1", AttributeType.FLOAT, "indegree")
    val attFrog:Attribute = attrList.createAttribute("2", AttributeType.BOOLEAN, "frog").setDefaultValue("true")
		
	val gephi:Node = graph.createNode("0")
	gephi.setLabel("Gephi").setSize(20).getAttributeValues
	    .addValue(attUrl, "http://gephi.org")
		.addValue(attIndegree, "1");
	gephi.getShapeEntity.setNodeShape(NodeShape.DIAMOND).setUri("GephiURI")
		
	val webatlas:Node = graph.createNode("1");
	webatlas.setLabel("Webatlas").getAttributeValues
		.addValue(attUrl, "http://webatlas.fr")
		.addValue(attIndegree, "2")
		
	val rtgi:Node = graph.createNode("2")
	rtgi.setLabel("RTGI").getAttributeValues
		.addValue(attUrl, "http://rtgi.fr")
		.addValue(attIndegree, "1")
		
	val blab:Node = graph.createNode("3")
	blab.setLabel("BarabasiLab").getAttributeValues
		.addValue(attUrl, "http://barabasilab.com")
		.addValue(attIndegree, "1")
		.addValue(attFrog, "false")
		
	gephi.connectTo("0", webatlas)
	gephi.connectTo("1", rtgi)
	webatlas.connectTo("2", gephi)
	rtgi.connectTo("3", webatlas)
	gephi.connectTo("4", blab)

	val graphWriter:StaxGraphWriter = new StaxGraphWriter
	val f = new File("static_graph_sample.gexf")
	var out:Writer = null
	try {
	  out =  new FileWriter(f, false)
	  graphWriter.writeToStream(gexf, out, "UTF-8");
	  System.out.println(f.getAbsolutePath());
	} catch {
	  case e:IOException => e.printStackTrace
	}
  }
}