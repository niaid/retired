package gov.nih.niaid.granite.gravel.degreeranktable

import java.util.Comparator
import javax.swing.JTable
import javax.swing.table.TableRowSorter
import scala.swing._
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.gravel.degreeranktable.DegreeRankTableModel._

/** It is extremely useful for Gravel users to be able to sort the simple 
  * expression tables by picking a column and sorting the rows by that column.
  * This is useful: to find a gene or miRNA, to see which are the 
  * most or least significant by p-value or fold ratio, etc. Swing JTables 
  * have good support for sorting by row by assigning a ''TableRowSorter''
  * to the table. Unfortunately, that capability is "commented out" of the
  * ''scala.swing.Table'' class. It is not exactly clear why this is. There is
  * some traffic in the Scala Github logs about this being a bug and it being
  * fixed in 2011. But there are lots of discussions in StackOverflow.com and
  * other sources up through this writing, Feb-2014 indicating that whatever fix
  * was made is not in the codebase. As a consequence, the "standard" work 
  * around for those requiring sorting in their tables is to create a new
  * component that wraps the JTable and provides a peer. It's a bit odd, and we
  * expect this to be fixed at last in Scala 2.11. In the interim, this class
  * provides such a wrapper for ''SimpleExpressionModelTables''. When the bug
  * in the standard Scala distribution is fixed, we will refactor this code out.
  * It has been designed so that only a couple lines of code change. 
  * 
  * @author Jamie Lawson
  */
private class MyTable(tableModel: DegreeRankTableModel) extends Component {
  override lazy val peer = new JTable(tableModel)
  peer.setRowSelectionAllowed(true)
  peer.setColumnSelectionAllowed(true)
  setSorter(tableModel)
  
  private object IntComparator extends Comparator[Int] {
    def compare(i1: Int, i2: Int): Int = i1.compareTo(i2)
  }
  private object StringComparator extends Comparator[String] {
    def compare(s1: String, s2: String): Int = s1.compareTo(s2)
  }
  
  def model_=(newModel: DegreeRankTableModel) = {
    peer.setModel(newModel)
  }
  
  private def setSorter(tableModel: DegreeRankTableModel) = {
    val sorter = new TableRowSorter[DegreeRankTableModel](tableModel)
    sorter.setComparator(RowNumberColumn, IntComparator)
    sorter.setComparator(GeneSymbolColumn, StringComparator)
    sorter.setComparator(DegreeColumn, IntComparator)
    peer.setRowSorter(sorter)    
  }
  
  def model: DegreeRankTableModel = peer.getModel.asInstanceOf[DegreeRankTableModel]
}

/** This panel provides a table view of a ''SimpleExpressionModel'' for use in 
  * user interfaces. 
  * 
  * @author Jamie Lawson
  */
class DegreeRankModelPanel(tableModel: DegreeRankTableModel) extends ScrollPane {
  def this() = this(new DegreeRankTableModel)
  def this(dataModel: DegreeRankModel) = this(new DegreeRankTableModel(dataModel))
  
  border = titledBorder("Node Rank By Degree")
  /* This is the part that changes when we get the Scala.swing.Table working 
   * again, hopefully in Scala 2.11. We also have to remember to set up the 
   * TableRowSorter, as we do in the MyTable thing above.
  private val table = new Table {
    model = tableModel
    peer.setRowSelectionAllowed(true)
    peer.setColumnSelectionAllowed(true)
  }
  */
  private val table = new MyTable(tableModel)
  contents = table
  initializeColumnWidths
  
  //////////////////////////////////////////////////////////////////////////////
  // Methods for external interaction.
  //////////////////////////////////////////////////////////////////////////////
  
  /** Sets the table model for the display table to a new model.
    *  
    * @param newModel The new table model to push into the display table.      
    */
  def setModel(newModel: DegreeRankTableModel) = {
    // First we need to get all of the current column widths. 
    val width = new Array[Int](7)
    for (col <- 0 to 2) width(col) = table.peer.getColumnModel.getColumn(col).getWidth()
    // Then we set the new table.
    table.model=newModel
    // Then we restore the column widths.
    for (col <- 0 to 2) setPreferredColumnWidth(col, width(col))
  }
  
  /** The degree rank model represented by this panel (as an ''Option'').
    * 
    * @return A degree rank model equivalent to the one represented in this 
    *         panel.
    */
  def toDegreeRankModel(newName: String): Option[DegreeRankModel] = {
    table.model match {
      case model: DegreeRankTableModel => model.toDegreeRankModel(newName)
      case _ => None
    }
  }
  
  def setPreferredColumnWidth(column: Int, preferredWidth:Int) = {
    table.peer.getColumnModel.getColumn(column).setPreferredWidth(preferredWidth)
  }
  /** This may need to be called if you create your table before installing it
    * in a layout manager. 
    */
  def initializeColumnWidths = {
    setPreferredColumnWidth(RowNumberColumn,rowNumberColumnWidth-5)
    setPreferredColumnWidth(GeneSymbolColumn,110)
    setPreferredColumnWidth(DegreeColumn,65)
  }  
}