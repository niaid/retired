package gov.nih.niaid.granite.gravel.significance

import scala.swing._
import gov.nih.niaid.granite.gravel._

/** This panel provides a way for users to specify significance criteria, like
  * what p-value and fold change thresholds they want to use for selection. 
  * Here, the p-value and fold change are restricted to 3 values each, selecting
  * values that are standard for peer review:
  * 
  *   - ''P-value:'' 0.05, 0.01, and 0.001
  *   - ''Fold Change:'' 1.5, 1.2, and 1.1
  *   
  * The initial defaults are p-value=0.05 and fold-change=1.2.
  * 
  * Associated with both the p-value and fold change are selectors so that you
  * can choose to filter by p-value only, fold change only, both, or neither.
  * The default value is to select by p-value.
  *  
  * @author Jamie Lawson
  */
class SignificanceFilterPanel extends GridPanel(2,1) {
  border = titledBorder("Significance Filter")
  //////////////////////////////////////////////////////////////////////////////
  // Establish the stuff that can be listened to (there's a bunch of it).
  //////////////////////////////////////////////////////////////////////////////
  val pValueSelector =     new CheckBox("P-Value         ") {
    selected = true
  }
  val foldChangeSelector = new CheckBox("Fold Change")
  val p05 = new RadioButton("0.05")
  val p01 = new RadioButton("0.01")
  val p001 = new RadioButton("0.001")
  private val pValueGroup = new ButtonGroup(p05, p01, p001) {
    select(p05)
  }
  val fr11 = new RadioButton("1.1  ")
  val fr12 = new RadioButton("1.2  ")
  val fr15 = new RadioButton("1.5  ")  
  private val foldChangeGroup = new ButtonGroup(fr15, fr12, fr11) {
    select(fr12)
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Layout all of the components.
  //////////////////////////////////////////////////////////////////////////////
  contents += new BoxPanel(Orientation.Horizontal) {
    contents += pValueSelector
    contents += p05
    contents += p01
    contents += p001
  }
  contents += new BoxPanel(Orientation.Horizontal) {
    contents += foldChangeSelector
    contents += fr15
    contents += fr12
    contents += fr11
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Methods for external query and interaction with the panel.
  //////////////////////////////////////////////////////////////////////////////
  
  /** Supplies the fold change as an ''Option'' on a ''Double'' because it could
    * be (and often is) that the fold change isn't tracked and is ''None''. 
    * 
    * @return	The fold change value.
    */
  def foldChange: Option[Double] = {
    if (!foldChangeSelector.selected) None
    else foldChangeGroup.selected match {
      case Some(button) if button == fr11 => Some(1.1)
      case Some(button) if button == fr12 => Some(1.2)
      case Some(button) if button == fr15 => Some(1.5)
      case _ => None
    }
  }
  
  /** Supplies the p-value as an ''Option'' on a ''Double'' because it could be
    * (and often is) that the fold change isn't tracked and is ''None''.
    * 
    * @return The p-value.
    */
  def pValue: Option[Double] = {
    if (!pValueSelector.selected) None
    else pValueGroup.selected match {
      case Some(button) if button == p05 => Some(0.05)
      case Some(button) if button == p01 => Some(0.01)
      case Some(button) if button == p001 => Some(0.001)
      case _ => None
    }
  }
}