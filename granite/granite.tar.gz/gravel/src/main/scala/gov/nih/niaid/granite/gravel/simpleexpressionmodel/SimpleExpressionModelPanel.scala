package gov.nih.niaid.granite.gravel.simpleexpressionmodel

import java.util.Comparator
import javax.swing.table.TableRowSorter
import scala.swing._
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.gravel.simpleexpressionmodel._
import gov.nih.niaid.granite.gravel.simpleexpressionmodel.SimpleExpressionModelTableModel._

import javax.swing.JTable

/** It is extremely useful for Gravel users to be able to sort the simple 
  * expression tables by picking a column and sorting the rows by that column.
  * This is useful: to find a gene or miRNA, to see which are the 
  * most or least significant by p-value or fold ratio, etc. Swing JTables 
  * have good support for sorting by row by assigning a ''TableRowSorter''
  * to the table. Unfortunately, that capability is "commented out" of the
  * ''scala.swing.Table'' class. It is not exactly clear why this is. There is
  * some traffic in the Scala Github logs about this being a bug and it being
  * fixed in 2011. But there are lots of discussions in StackOverflow.com and
  * other sources up through this writing, Feb-2014 indicating that whatever fix
  * was made is not in the codebase. As a consequence, the "standard" work 
  * around for those requiring sorting in their tables is to create a new
  * component that wraps the JTable and provides a peer. It's a bit odd, and we
  * expect this to be fixed at last in Scala 2.11. In the interim, this class
  * provides such a wrapper for ''SimpleExpressionModelTables''. When the bug
  * in the standard Scala distribution is fixed, we will refactor this code out.
  * It has been designed so that only a couple lines of code change. 
  * 
  * @author Jamie Lawson 
  */
private class MyTable(tableModel: SimpleExpressionModelTableModel) extends Component {
  override lazy val peer = new JTable(tableModel)
  peer.setAutoResizeMode(JTable.AUTO_RESIZE_OFF)
  setSorter(tableModel)
  val sorter = new TableRowSorter[SimpleExpressionModelTableModel](tableModel)
  peer.setRowSorter(sorter)
  
  private object IntComparator extends Comparator[Int] {
    def compare(i1: Int, i2: Int): Int = i1.compareTo(i2)
  }
  private object StringComparator extends Comparator[String] {
    def compare(s1: String, s2: String): Int = s1.compareTo(s2)
  }
  
  private object DoubleComparator extends Comparator[Double] {
    def compare(d1: Double, d2: Double): Int = d1.compareTo(d2)
  }
  
  def model_=(newModel: SimpleExpressionModelTableModel) = {
    peer.setModel(newModel)
    setSorter(newModel)
  }
  
  private def setSorter(tableModel: SimpleExpressionModelTableModel) = {
    val sorter = new TableRowSorter[SimpleExpressionModelTableModel](tableModel)
    sorter.setComparator(RowNumberColumn, IntComparator)
    sorter.setComparator(GeneSymbolColumn, StringComparator)
    sorter.setComparator(PValueColumn, DoubleComparator)
    sorter.setComparator(FoldChangeColumn, DoubleComparator)
    sorter.setComparator(FoldDescriptionColumn, StringComparator)
    sorter.setComparator(ColumnNoColumn, IntComparator)
    sorter.setComparator(TranscriptIdColumn, StringComparator)
    peer.setRowSorter(sorter)    
  }
  
  def model: SimpleExpressionModelTableModel = peer.getModel().asInstanceOf[SimpleExpressionModelTableModel]
}

/** This panel provides a table view of a ''SimpleExpressionModel'' for use in 
  * user interfaces. 
  * 
  * @author Jamie Lawson
  */
class SimpleExpressionModelPanel(tableModel: SimpleExpressionModelTableModel) extends ScrollPane {
  def this() = this(new SimpleExpressionModelTableModel)
  def this(dataModel: SimpleExpressionModel) = this(new SimpleExpressionModelTableModel(dataModel))
  
  border = titledBorder("Expression Model")
  /*****************************************************************************
  This is what changes when we get a Scala Swing Table back and functioning.
  We also need to setup the TableRowSorter just like the MyTable above.
  private val table = new Table {
    model = tableModel
    autoResizeMode = scala.swing.Table.AutoResizeMode.Off
  }
  *****************************************************************************/
  private val table = new MyTable(tableModel)
  contents = table
  initializeColumnWidths
  
  //////////////////////////////////////////////////////////////////////////////
  // Methods for external interaction.
  //////////////////////////////////////////////////////////////////////////////
  
  /** Sets the table model for the display table to a new model.
    *  
    * @param newModel The new table model to push into the display table.      
    */
  def setModel(newModel: SimpleExpressionModelTableModel) = {
    // First we need to get all of the current column widths. 
    val width = new Array[Int](7)
    for (col <- 0 to 6) width(col) = table.peer.getColumnModel.getColumn(col).getWidth()
    // Then we set the new table.    
    table.model = newModel
    // Then we restore the column widths.
    for (col <- 0 to 6) setPreferredColumnWidth(col, width(col))
  }
  
  /** The simple expression model represented by this panel (as an ''Option'').
    * 
    * @return An expression model equivalent to the one represented in this 
    *         panel.
    */
  def toSimpleExpressionModel(newName: String): Option[SimpleExpressionModel] = {
    table.model match {
      case model: SimpleExpressionModelTableModel => model.toSimpleExpressionModel(newName)
      case _ => None
    }
  }
  
  def setPreferredColumnWidth(column: Int, preferredWidth:Int) = {
    table.peer.getColumnModel.getColumn(column).setPreferredWidth(preferredWidth)
  }
  /** This may need to be called if you create your table before installing it
    * in a layout manager. 
    */
  def initializeColumnWidths = {
    setPreferredColumnWidth(RowNumberColumn,rowNumberColumnWidth)
    setPreferredColumnWidth(GeneSymbolColumn,125)
    setPreferredColumnWidth(FoldChangeColumn,100)
    setPreferredColumnWidth(FoldDescriptionColumn,200)
  }  
}