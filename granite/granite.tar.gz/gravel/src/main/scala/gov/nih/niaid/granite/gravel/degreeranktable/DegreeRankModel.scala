package gov.nih.niaid.granite.gravel.degreeranktable

import gov.nih.niaid.granite.core.model.RowDataModel

/** A simple class representing the degree of a named vertex in a 
  * ''MirnaGraph''.
  * 
  * @author Jamie Lawson
  * 
  * @param geneSymbol	The name associated with the node. Might be a gene or
  * 					messenger RNA, or might be a miRNA name.
  * @param degree       The degree of that vertex. 
  */
case class VertexDegree(geneSymbol: String, degree: Int)

/** A data model describing the degrees of some vertices of a ''MirnaGraph''. In
  * most cases, there will be two of these models associated with each graph.
  * One will be associated with the miRNA nodes of the graph and another will
  * be associated with the genes or messenger RNA nodes of the graph.
  * 
  * @author Jamie Lawson  
  */
class DegreeRankModel(modelName: String, dataSeq: Seq[VertexDegree]) extends RowDataModel[VertexDegree] {
  def rows = dataSeq.length
  def apply(row: Int) = if (isValidLocation(row)) Some(dataSeq(row)) else None
  def name = modelName
}