package gov.nih.niaid.granite.gravel.event

import swing.Component
import swing.event.ActionEvent

/** An event class for signifying that there are no tabs left in the associated
  * ''TabbedPane''. 
  * 
  * @author Jamie Lawson
  */
class AllTabsRemoved extends ActionEvent(NoComponentSelected())

/** In order for the publication stuff to work properly, the event classes need
  * an extractor. This is the extractor.
  * 
  * @author Jamie Lawson
  */ 
object AllTabsRemoved {
  def unapply(t: AllTabsRemoved): Option[Component] = Some(t.source)
}

/** Instances of this class are sentinel objects that indicate that no tab is 
  * selected. This is useful, for instance, if you remove the last tab. The
  * menu manager wants to update the menus for the currently selected tab. But
  * there is none because there is no tab to select. This tells the menu manager
  * that it's okay to stop looking for an active tab.
  */
class NoComponentSelected extends Component

object NoComponentSelected {
  val nc = new NoComponentSelected
  def apply() = nc
}