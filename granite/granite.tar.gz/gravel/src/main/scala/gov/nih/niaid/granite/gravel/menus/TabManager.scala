package gov.nih.niaid.granite.gravel.menus

import java.util.UUID
import scala.collection.mutable.HashMap
import scala.swing._
import scala.swing.TabbedPane.Page
import javax.swing.JTabbedPane
import javax.swing.event.{ChangeEvent,ChangeListener}
import gov.nih.niaid.granite.gravel.event.{TabActivated,AllTabsRemoved,TabClosing,AddTab}

/** Provides housekeeping for applications that use tabs and offloads much busy
  * work. Allows you to make changes to the main application's menu bar when 
  * the currently selected tab changes. It is often extremely useful to modify 
  * the menus on an application's menu bar when a new tab becomes active.
  * Also allows you to conveniently close a tab from the menu, and all of the
  * menus are cleaned up appropriately. To use this class, you need to 
  * 
  *   1. Configure it appropriately.
  *   1. Make the tab contents instances of ''MenuProvider''. The 
  *      ''MenuProvider'' trait exposes a set of menus that the tab manager
  *      will add to the menu bar when the tab is activated, and remove from
  *      the menu bar when the tab is de-activated. The ''MenuProvider'' also
  *      has a unique identifier that the tab manager uses to find it.
  *   1. The tab panels need to truly own the menus items that they will augment 
  *      the main menu with. For instance, if you want a "Close current tab"
  *      menu item, that should be part of the tab panel. Every tab panel may
  *      have a "Close current tab" menu item, so that whenever you look at the
  *      menu you see the item, but it's really different "Close current tab"
  *      menu items, one for each tab, and it closes that specific tab. 
  *   1. Hand over your tabs to it for management.
  *   
  * As for configuration, consider the code fragment below:
  *
  * {{{ 
  *  object MyApplication extends SimpleSwingApplication {  
  *    private val mainCanvas = new TabbedPane
  *    private val tabManager = new TabManager(mainCanvas)
  *    
  *    val fileMenu = new Menu("File") {
  *      contents += new MenuItem(Action("New") { 
  *        ..
  *        val panel = new MyPanel(uuid)  // MyPanel should extend MenuProvider.
  *        tabManager.addTab(panel.uuid, new Page("Untitled", panel)) 
  *      })
  *      contents += new MenuItem(Action("Open") { .. })
  *      contents += new MenuItem(Action("Save") { .. })
  *      contents += new MenuItem(Action("Exit") { .. })
  *    }
  *    val editMenu = new Menu("Edit") {
  *      contents += new MenuItem(Action("Copy") { .. })
  *    }
  *    
  *    tabManager.setMenuManagementInfo(Map(("File", MenuInfo(fileMenu,3)), 
  *                                         ("Edit", MenuInfo(editMenu,1))))                                 
  *    def top = new MainFrame {
  *      ...
  *      contents = new BorderPanel {
  *        layout(mainCanvas) = Center
  *      }
  *    }
  *  }
  * }}}
  * 
  * This creates the tabbed pane, then gives it to the tab manager. Then the
  * menus are created, before configuring the tab manager for menu augmentation.
  * Menu creation could be deferred, in the code, until after the call to
  * ''setMenuManagementInfo'', __if__ the ''fileMenu'' and ''editMenu'' are
  * declared as ''lazy val''. Otherwise a ''NullPointerException'' will be
  * thrown. The ''setMenuManagementInfo'' call configures the tab manager so 
  * that new menu items can be added to the "File" menu, starting after the 3rd 
  * position on the "File" menu (after "Save"), and new menu items can be added 
  * to the "Edit" menu right after the first item (right after "Copy"). 
  * 
  * We have elaborated the "File-Open" menu item a bit because that is where we
  * will be creating a new tab pane, and there we show how to hand the 
  * management of that tab pane off to the tab manager. 
  * 
  * So now ''MyPanel'' still needs to do its part in this. It needs to implement
  * ''MenuProvider'', and implement its tab-specific menus. Here is how 
  * ''MyPanel'' goes about that:
  * 
  * {{{
  *  class MyPanel extends Panel with MenuProvider {
  *    lazy val uuid = java.util.UUID.randomUUID
  *    def menus = Seq( ("File", Seq(new MenuItem(Action("Close") {
  *        			                 publish(new TabClosing(this))
  *								  })
  *                			   ))
  *                   )
  * }}} 
  * 
  * The ''menus'' method says that this tab panel adds one new menu item, called 
  * "Close" to the "File" menu, and that the closing of the window relies on
  * the ''TabClosing'' event. The tab manager picks up the ''TabClosing'' event
  * and closes the tab and does all necessary housekeeping. The result type of
  * the ''menus'' method is slightly awkward, but actually makes sense. It is 
  * a sequence of pairs. Each of those pairs is the name of the main application
  * menu (same as the keys in the first code snippet) and a sequence of menu
  * items to add to that main menu.
  * 
  * @author Jamie Lawson 
  * 
  * @todo Make this support adding whole menus (not just menu items) to the
  *       menu bar.
  */
class TabManager(tabbedPane: TabbedPane) extends Component {
  tabbedPane.peer.addChangeListener(new ChangeListener {
      def stateChanged(changeEvent: ChangeEvent) {
        //  If this sourceTabbedPane and our tabbedPane are different, there
        //  will be a problem...
        val sourceTabbedPane = changeEvent.getSource.asInstanceOf[JTabbedPane]
        sourceTabbedPane.getSelectedIndex match {
          case i if i < 0  => tabbedPane.publish(new AllTabsRemoved)
          case i if i >= 0 => tabbedPane.publish(new TabActivated(tabbedPane.pages(i).content))
        }
      }
    }
  )
  listenTo(tabbedPane)
  reactions += {
    case TabActivated(component) => 
      removeTabSpecificMenus  
      component match {
        case menuProvider:MenuProvider => addTabSpecificMenus(menuProvider)
      }
    case AllTabsRemoved(component) =>
      removeTabSpecificMenus
    case TabClosing(component) =>      
      component match {
        case menuProvider:MenuProvider => removeTab(menuProvider.uuid)
      }
    case AddTab(component) =>
      component match {
        case menuProvider:MenuProvider => addTab(menuProvider.uuid, component) 
      }
  }
  
  /** Given a "proposed" name for a new tab, returns an "offered" name. This
    * takes account of issues like duplicate names. If you propose the name 
    * "Foo", but there is already a tab named "Foo" in the tabbed pane, this
    * method will offer "Foo(1)" as a tab name. If there is already a tab named
    * "Foo(1)", it will offer "Foo(2)" and so on and so forth.
    * 
    * @param proposedName	The name the caller proposes for the new tab.
    * 
    * @return The offered name ultimately decided on for the new tab.  
    */
  def tabName(proposedName: String): String = {
    // Maintenance Note:
    // There is some rather ugly stuff here dealing with the loop that goes 
    // through potential tab names. The loop should never be infinite. In fact,
    // it should bottom out pretty quickly, i.e. if we see 64 tabs with the same
    // root name. But it's something to keep an eye on.
    if (tabbedPane.peer.indexOfTab(proposedName) == -1) return proposedName	//  If the proposed name is available, offer it back to the caller.
    var i = 1
    do {
      if (tabbedPane.peer.indexOfTab(proposedName+"("+i+")") == -1) return proposedName+"("+i+")"
      else i+=1
      if (i == 64) throw new AssertionError("Too many tabs named \"" + proposedName + "\"")
    } while (true)
    throw new AssertionError("Could not find an acceptable tab name. This should never happen.")
  }
  
  /** This is a dictionary used to find a tab (that you want to remove).
    * 
    */
  private val tabs = new HashMap[UUID, Page]
  
  /** Places the tab component under the management of this menu manager. 
    * 
    * @param key	The unique tag for the tab that can be used to identify it.
    * @param tab	The tab component to be managed.
    */
  def addTab(key: UUID, tab: Component) = {
    val page = new Page(tabName(tab.name), tab)
    tabbedPane.pages += page				   
    tabbedPane.peer.setSelectedIndex(page.index)    
    tabs += Pair(key,page)                      
                                                
    listenTo(page.content)                      
  } 
  
  /** Removes the tab from the application and releases it from the management
    * of this menu manager. 
    * 
    * @param key	The unique tag on the tab that can be used to identify it.
    */
  def removeTab(key: UUID) = {
    tabs.get(key) match {
      case Some(tab) => tabbedPane.pages -= tab
                        deafTo(tab.content)
      case None => println("Couldn't find the page to remove")
    }
    tabs.remove(key)
  }
  
  private def removeTabSpecificMenus(menuInfo: MenuInfo) {
    if (menuInfo.currentNumberOfComponentSpecificMenus > 0) {
      // Start from 0 to remove the separator. End with #menus to remove all of the menus.
      for (i <- 0 to menuInfo.currentNumberOfComponentSpecificMenus) menuInfo.menu.peer.remove(menuInfo.insertionPoint)
    }
  }
  
  private def addTabSpecificMenus(menuInfo:MenuInfo, newMenus:Seq[MenuItem]) = {
    if (newMenus.length > 0) {
      // We add each item to the same location in the menu, pushing the 
      // previously added item down. By reversing the sequence of menu items,
      // the resulting menu will have the new items in the same order as the
      // original sequence.      
      newMenus.reverse foreach {menuItem =>
        menuInfo.menu.peer.insert(menuItem.peer, menuInfo.insertionPoint)  
      }
      menuInfo.menu.peer.insertSeparator(menuInfo.insertionPoint)
    }    
  }
  
  private var menuMgtInfo: Map[String,MenuInfo] = null
  
  /** Used to tell the application which menus are eligible for augmenting by
    * the individual components.  
    * 
    * @param menuManagementInfo		A ''Map'' with ''Strings'' as keys and 
    *                               ''MenuInfo'' elements as values, describing
    *                               which menu items can be augmented and where
    *                               in those menu items to insert the new,
    *                               component-specific menu items.
    */
  def setMenuManagementInfo(menuManagementInfo: Map[String,MenuInfo]) = {
    menuMgtInfo = menuManagementInfo
  }

  private def removeTabSpecificMenus() {
    menuMgtInfo.keys.foreach { menuName => menuMgtInfo.get(menuName) match {
        case Some(menuInfo) => removeTabSpecificMenus(menuInfo)
                               menuInfo.setCurrentNumberOfComponentSpecificMenus(0)
        case None           => println("TODO: Make this add and remove top level menus too")                               
      }
    }
  }
  
  private def addTabSpecificMenus(menuProvider:MenuProvider) {
    menuProvider.menus.foreach(menuSeq => {
      // menuSeq._1 is the name, menuSeq._2 is the sequence of menuItems
      menuMgtInfo.get(menuSeq._1) match {
        case Some(menuInfo) => addTabSpecificMenus(menuInfo, menuSeq._2)
                               menuInfo.setCurrentNumberOfComponentSpecificMenus(menuSeq._2.length)
        case None           => println("TODO: Make this add and remove top level menus too")
      }
    })
  }
}

