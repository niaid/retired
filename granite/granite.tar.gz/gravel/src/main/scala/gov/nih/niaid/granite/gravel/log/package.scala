package gov.nih.niaid.granite.gravel

/** Supplies a trait (''Log'') as a general contract for things that can manage
  * logs of information, and a panel (''LogPanel'') for displaying logged
  * information.
  * 
  * @author Jamie Lawson 
  */ 
package object log {
}