package gov.nih.niaid.granite.gravel

import it.uniroma1.dis.wsngroup.gexf4j.core.{EdgeType,Gexf,Graph,Mode,Node}
import it.uniroma1.dis.wsngroup.gexf4j.core.data.{Attribute,AttributeClass,AttributeList,AttributeType}
import it.uniroma1.dis.wsngroup.gexf4j.core.impl.{GexfImpl,StaxGraphWriter}
import it.uniroma1.dis.wsngroup.gexf4j.core.impl.data.AttributeListImpl;
import it.uniroma1.dis.wsngroup.gexf4j.core.viz.NodeShape;
import java.io.{File,FileWriter,IOException,Writer}
import java.util.Calendar;

object GexfGraphObj {
  val gexf:Gexf = new GexfImpl  
  val date = Calendar.getInstance
  gexf.getMetadata
	.setLastModified(date.getTime)
	.setCreator("Gephi.org")
	.setDescription("A Web network")
  gexf.setVisualization(true)
  val attrList:AttributeList = new AttributeListImpl(AttributeClass.NODE)
  val attR:Attribute = attrList.createAttribute("R", AttributeType.BOOLEAN, "R").setDefaultValue("false")
  val attN:Attribute = attrList.createAttribute("N", AttributeType.BOOLEAN, "N").setDefaultValue("false")	
  val attRO:Attribute = attrList.createAttribute("RO", AttributeType.BOOLEAN, "RO").setDefaultValue("false")
  val attNO:Attribute = attrList.createAttribute("NO", AttributeType.BOOLEAN, "NO").setDefaultValue("false")
  val attC:Attribute = attrList.createAttribute("C", AttributeType.BOOLEAN, "C").setDefaultValue("false")  
}
import GexfGraphObj._
class GexfGraphObj {
  var nodeNo = 0
  var edgeNo = 0
  val graph: Graph = gexf.getGraph
  graph.setDefaultEdgeType(EdgeType.UNDIRECTED).setMode(Mode.STATIC)
  graph.getAttributeLists().add(attrList)
  
  def addNode(label: String, isR:Boolean, isN: Boolean): Node = {
    val node = graph.createNode(nodeNo.toString)
    nodeNo += 1
    node.setLabel(label)
    if (isR && !isN) node.getAttributeValues.addValue(attR,"true").addValue(attRO,"true")
    if (!isR && isN) node.getAttributeValues.addValue(attN,"true").addValue(attNO,"true")
    if (isR && isN) node.getAttributeValues.addValue(attR,"true").addValue(attN,"true").addValue(attC,"true")
    node
  }
  
  def addEdge(source: Node, dest: Node) = {
    source.connectTo(edgeNo.toString, dest)
    edgeNo += 1
    this
  }
  
  def writeGexf(writer: Writer): Writer = {
	val graphWriter = new StaxGraphWriter
	graphWriter.writeToStream(gexf, writer, "UTF-8")
	writer
  }
  
  def vertices = nodeNo 
  def edges = edgeNo
}

object MoreReasonableGefxWriter {
  def main(args: Array[String]) = {	
    val myGraph = new GexfGraphObj
    val mir1 = myGraph.addNode("mir1", true, false)
    val mir2 = myGraph.addNode("mir2", false, true)
    val pro1 = myGraph.addNode("pro1", true, true)
    val pro2 = myGraph.addNode("pro2", true, true)

    myGraph.addEdge(mir1, pro1)
	myGraph.addEdge(mir2, pro1)
	myGraph.addEdge(mir2, pro2)

	try {  
	  myGraph.writeGexf(new FileWriter(new File("static_graph_sample_mirna.gexf"), false))
	} catch {
	  case e:IOException => e.printStackTrace
	}
  }
}