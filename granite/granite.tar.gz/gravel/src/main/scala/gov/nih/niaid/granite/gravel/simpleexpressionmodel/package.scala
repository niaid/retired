package gov.nih.niaid.granite.gravel

/** This package deals with things that are specific to the simplified 
  * expression models, which are effectively a collection of records, each of
  * which has:
  * 
  *   1. A Gene Symbol.
  *   1. A P-Value.
  *   1. A Fold-Ratio.
  *   1. Memos for housekeeping.
  *  
  * @author Jamie Lawson 
  */
package object simpleexpressionmodel {
  def maximumValidationErrors = 100
  def foldRatioSuspicionThreshold = 4.0
}