package gov.nih.niaid.granite.gravel.menus

import java.util.UUID
import scala.swing.MenuItem

/** A ''MenuProvider'' is a thing (typically a ''Component'') that offers a 
  * frame or application a set of menus to display. The ''MenuProvider'' exposes
  * a sequence of menu changes. Each of those changes is described by a ''Pair''
  * that contains a name (the name of the menu to be augmented), and a sequence
  * of new menu items to add to that menu.
  * 
  * This is intended to work either with existing top level menus, or to add a
  * new top level menu if there is none of the given name. Currently it works
  * only with the existing top level menus.
  * 
  * @author Jamie Lawson 
  */ 
trait MenuProvider {
  /** Provides a view of the menu items specific to a particular component.
    * 
    * @return A set of menus to add to a top level menu bar.
    */
  def menus: Seq[Pair[String,Seq[MenuItem]]]
  
  /** Provides a key for menu managers to manage the menu provider.
    * 
    */
  def uuid: UUID
}