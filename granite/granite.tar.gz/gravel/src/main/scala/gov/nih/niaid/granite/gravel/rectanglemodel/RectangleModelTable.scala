package gov.nih.niaid.granite.gravel.rectanglemodel

import scala.swing._
import scala.swing.BorderPanel.Position._
import gov.nih.niaid.granite.core.model.RectangleModel
import gov.nih.niaid.granite.gravel._

/** This panel displays the raw data from a ''RectangleModel[String]]'' in a 
  * table using a ''RectangleModelTableModel'' as the model for the ''Table'' 
  * control.
  *
  * @author Jamie Lawson  
  */
class RectangleModelPanel(rawDataModel: RectangleModel[String]) extends BorderPanel {
  border = titledBorder("Raw Data")
  minimumSize = new Dimension(300,100)  
  private val tableModel = new RectangleModelTableModel(rawDataModel)  
  private val table = new Table() {
     model = tableModel
     autoResizeMode = scala.swing.Table.AutoResizeMode.Off
  }
  def setPreferredColumnWidth(column: Int, preferredWidth:Int) = {
    table.peer.getColumnModel.getColumn(column).setPreferredWidth(preferredWidth)
  }
  setPreferredColumnWidth(0,rowNumberColumnWidth)
  for (col <- 1 to rawDataModel.columns) setPreferredColumnWidth(col, incidentalColumnPreferredWidth)
  layout { 
    new ScrollPane {    
      contents = table 
    }
  } = Center
}
