package gov.nih.niaid.granite.gravel

/** Supplies event types that are specific to Gravel. These are the kinds of 
  * things that go into ''reactions'' blocks in the code, as in the following
  * code sample:
  * 
  *  {{{
  *    object MyApplication extends SimpleSwingApplication {
  *      private val mainCanvas = new MenuManagingTabbedPane
  *      ...
  *      listenTo(mainCanvas)
  *      reactions += {
  *        case TabActivated(component:MenuProvider) => 
  *          mainCanvas.removeTabSpecificMenus
  *          component match {
  *            case menuProvider:MenuProvider => 
  *              mainCanvas.addTabSpecificMenus(menuProvider)
  *          }
  *      }
  *    }     
  *  }}}  
  * 
  * @author Jamie Lawson
  */
package object event {
}