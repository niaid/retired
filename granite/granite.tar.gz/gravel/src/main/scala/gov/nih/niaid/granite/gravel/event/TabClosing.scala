package gov.nih.niaid.granite.gravel.event

import swing.Component
import swing.event.ActionEvent

/** An event class for signifying that a tab in a ''TabbedPane'' is being
  * closed. 
  * 
  * @author Jamie Lawson
  */
class TabClosing(component: Component) extends ActionEvent(component)

/** In order for the publication stuff to work properly, the event classes need
  * an extractor. This is the extractor.
  * 
  * @author Jamie Lawson
  */ 
object TabClosing {
  def unapply(t: TabClosing): Option[Component] = Some(t.source)
}