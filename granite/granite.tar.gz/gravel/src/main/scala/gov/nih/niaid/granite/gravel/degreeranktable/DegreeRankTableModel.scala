package gov.nih.niaid.granite.gravel.degreeranktable

import javax.swing.table.DefaultTableModel
import scala.collection.mutable.ListBuffer
import gov.nih.niaid.granite.core.model.RowDataModel
import gov.nih.niaid.granite.tools.significance.GeneSignificance

/** Companion object for ''DegreeRankTableModel''. Gives convenient access to
  * constants like column numbers and column headings
  * 
  * @author Jamie Lawson
  */
object DegreeRankTableModel {
  val RowNumberColumn = 0
  val GeneSymbolColumn = 1 
  val DegreeColumn = 2
  val ColumnTitles = Array[Object]("Row#", "Gene Symbol", "Degree")
}
import DegreeRankTableModel._

/** A table model appropriate for the display and management of a degree 
  * ranking list.
  * 
  * @note Cells in a ''DegreeRankTableModel'' are not editable. The degrees are
  *       fixed.
  *  
  * @param dataModel	The model to represent in a table.
  * 
  * @author Jamie Lawson
  */
class DegreeRankTableModel(dataModel: DegreeRankModel) extends DefaultTableModel(dataModel.rows, 3) {
  /** Alternative constructor for when you don't have an actual data model
    * yet, but you want a TableModel to put into a display. This builds the
    * ''DegreeRankTableModel'' with a ''DummyDegreeRankModel''. 
    */
  def this() = this(new DummyDegreeRankModel())  
  
  setColumnIdentifiers(ColumnTitles)
  for (row <- 0 to dataModel.rows-1) {
    setValueAt((row+1), row, 0)
    dataModel(row) match {
      case Some(vertex) => setValueAt(vertex.geneSymbol, row, GeneSymbolColumn)
    		  			   setValueAt(vertex.degree, row, DegreeColumn)
      case None => 			for (col <- 1 to 3) setValueAt("", row, col)
    }
  }  
  
  override def isCellEditable(row: Int, column: Int): Boolean = false
  
  /** Provides a view of the data table as a ''SimpleExpressionModel''. The 
    * purpose of this is to provide persistence for the table.  
    * 
    * @param modelName 	The name to assign to the model (default is "Unnamed").
    * 
    * @return  A ''DegreeRankModel'', in an ''Option'' with data equivalent 
    *          to what is in this table model. 
    */
  def toDegreeRankModel(modelName: String="Unnamed"): Option[DegreeRankModel] = {
    dataModel match {
      case model:DummyDegreeRankModel => None
      case _ => 
        val buffer = new ListBuffer[VertexDegree]    
        for (row <- 0 to getRowCount-1) {
          buffer += VertexDegree(getValueAt(row, GeneSymbolColumn).asInstanceOf[String],
                                 getValueAt(row, DegreeColumn).toString.toInt)
        }
        Some(new DegreeRankModel(modelName, buffer.toSeq))
    }
  }
}

/** A "dummy" degree rank model used for populating empty tables. It has
  * as many rows as you specify, but the ''apply(row)'' method returns ''None''
  * for any input.
  * 
  * @author Jamie Lawson   
  * 
  * @param dummyRows	The number of empty rows to give this table. Defaults
  * 					to 20.
  */
class DummyDegreeRankModel(dummyRows: Int = 20, name:String = "") extends DegreeRankModel(name, Seq[VertexDegree]()) {
  override def rows = dummyRows
  override def apply(row: Int) = None  
}
