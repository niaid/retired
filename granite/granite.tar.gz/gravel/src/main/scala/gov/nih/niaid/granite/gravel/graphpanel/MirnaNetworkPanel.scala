package gov.nih.niaid.granite.gravel.graphpanel

import java.io.IOException
import swing._
import scala.swing.BorderPanel.Position._
import javax.swing.border._
import javax.swing.filechooser.FileNameExtensionFilter
import javax.swing.JOptionPane
import scala.swing.Orientation
import scala.swing.event._
import java.io.File
import java.util.UUID
import java.text.DecimalFormat
import gov.nih.niaid.graphview.{PreviewPanel,GraphPreviewController,TimeBasedStopper, InterruptableTimeBasedStopper}
import gov.nih.niaid.granite.gravel._
import gov.nih.niaid.granite.gravel.menus.MenuProvider
import gov.nih.niaid.granite.gravel.event._

/** A compound widget for visualizing miRNA networks. It puts a graph view on
  * the right side, and a whole bunch of controls for manipulating that view
  * on the left side.
  *  
  * @param file	The file (GEFX format) to read in and display.  
  * 
  * @author Jamie Lawson
  */
class MirnaNetworkPanel(panelName: String, file: File) extends SplitPane(Orientation.Vertical) with MenuProvider {

  //////////////////////////////////////////////////////////////////////////////
  // Define all of the MenuProvider stuff.
  //////////////////////////////////////////////////////////////////////////////
  name = panelName
  
  /** Menus specific to this panel. Satisfies the ''MenuProvider'' trait.
    */  
  def menus = Seq( ("File", Seq(closeMenuItem,
                                saveVisibleGraphAsPngMenuItem,
                                exportVisibleGraphToGexfMenuItem
                  			   ))
                 )
    
  private val closeMenuItem = new MenuItem(Action("Close") {
	publish(new TabClosing(this))
  })
  
  private val exportVisibleGraphToGexfMenuItem = new MenuItem(Action("Export Visible Graph to Gexf") {  
    val startDir = new File(getProperty("startDir"))
    val fileChooser = new FileChooser(startDir) {
      title = "Select File Save Location"
      fileFilter = new FileNameExtensionFilter("Graph EXperts Format", "gexf")
      selectedFile = new File(panelName)
    }
    fileChooser.showSaveDialog(this) match {
      case FileChooser.Result.Approve =>
        try {
          val fn = if (fileChooser.selectedFile.toString.endsWith(".gexf")) fileChooser.selectedFile.toString
                   else fileChooser.selectedFile.toString + ".gexf"
          controller.exportVisibleToGexf(new File(fn))
        } catch {
          case ex:Throwable   => ex.printStackTrace
                                 val optionPane = new JOptionPane("File could not be saved", JOptionPane.ERROR_MESSAGE)    
                                 val dialog = optionPane.createDialog("Error")
                                 dialog.setAlwaysOnTop(true)
                                 dialog.setVisible(true)
        }
    }
  })
  
  private val saveVisibleGraphAsPngMenuItem = new MenuItem(Action("Save Visible Graph as PNG") {  
    val startDir = new File(getProperty("startDir"))
    val fileChooser = new FileChooser(startDir) {
      title = "Select File Save Location"
      fileFilter = new FileNameExtensionFilter("PNG Format", "png")
      selectedFile = new File(panelName)
    }
    fileChooser.showSaveDialog(this) match {
      case FileChooser.Result.Approve =>
        try {
          val fn = if (fileChooser.selectedFile.toString.endsWith(".png")) fileChooser.selectedFile.toString
                   else fileChooser.selectedFile.toString + ".png"
          controller.exportVisibleToPNG(new File(fn))
        } catch {
          case ex:Throwable   => ex.printStackTrace
                                 val optionPane = new JOptionPane("File could not be saved", JOptionPane.ERROR_MESSAGE)    
                                 val dialog = optionPane.createDialog("Error")
                                 dialog.setAlwaysOnTop(true)
                                 dialog.setVisible(true)
        }
    }
  })
  
  /** The identifier that the tab manager uses to identify this content panel.
    * 
    * @return the unique id.
    */
  lazy val uuid = UUID.randomUUID
  
  /** The controller is where all of the underlying manipulation takes place.
    * 
    * @return The graph preview controller.
    */
  private lazy val controller = new GraphPreviewController(file)
  
  /** The visualization (right side of screen).
    *  
    */
  private val previewPanel = new PreviewPanel(controller)
  rightComponent = previewPanel
  
  /** The controls for the visualization (left side of screen).
    *  
    */
  private val controlPane = new MirnaNetworkVisualizationControlPane(previewPanel)
  leftComponent = controlPane
}

/** A panel for manipulating the visualization of a miRNA graph. It has four
  * parts:
  * 
  *  1. Summary features/measures of the graph.
  *  1. Graph viewing options.
  *  1. Graph filtering options.
  *  1. Graph layout control. 
  * 
  * @author Jamie Lawson
  */
private class MirnaNetworkVisualizationControlPane(preview: PreviewPanel) extends BoxPanel(Orientation.Vertical) {
  contents += new GraphMeasuresPanel(preview)
  contents += new GraphViewOptionsPanel(preview)
  contents += new GraphFilterPanel(preview)
  contents += new LayoutControlPanel(preview)
}

/** A panel for showing some simple measures of the graph.
  * 
  * @author Jamie Lawson
  */
private class GraphMeasuresPanel(preview: PreviewPanel) extends BorderPanel {
  border = titledBorder("Basic Graph Measures")
  val formatter = new DecimalFormat("0.###");
  val nodes = preview.getNodeCount
  val edges = preview.getEdgeCount
  val density = 2.0 * edges / (nodes*(nodes-1))
  val content = "Node Count = " + nodes + "\n" + 
                "Edge Count = " + edges + "\n" +
                "Average Degree = " + formatter.format(edges.asInstanceOf[Double] / nodes) + "\n" +
                "Density = " + formatter.format(density)
  layout(new TextArea(content) {
    editable = false
    background = uneditableTextAreaBackgroundColor
  }) = Center
}

/** A panel that displays basic viewing options like whether to show the node
  * labels.
  * 
  * @author Jamie Lawson 
  * 
  * @param preview	The preview panel that holds the visualization being
  * 				manipulated.
  */
private class GraphViewOptionsPanel(preview: PreviewPanel) extends BorderPanel {
  border = titledBorder("Graph View Options")
  val showLabels = new CheckBox {
      action = Action("Show Node Labels") {
        if (selected) preview.showLabels
        else preview.hideLabels
      }
    }
  val curvedEdges = new CheckBox {
      action = Action("Use Curved Edges") {
        if (selected) preview.useCurvedEdges
        else preview.useStraightEdges
      }
    }
  val useHeatMap = new CheckBox {
      action = Action("Use Heat Map Display") {
        if (selected) preview.useHeatMap
        else preview.useDefaultColors
      }
    }
  layout {
    new GridPanel(3,1) {
      contents += showLabels
      contents += curvedEdges
      contents += useHeatMap   
    }
  } = North
}

/** A widget that allows you to filter the graph visualization, meaning pick a
  * vertex and see just the part of the graph incident on that vertex.
  * 
  * @author Jamie Lawson
  * 
  * @param preview	The graph visualization to be filtered.  
  */
private class GraphFilterPanel(preview: PreviewPanel) extends BoxPanel(Orientation.Vertical) {
  border = titledBorder("Graph Filter")
  private val nodeName = new TextField(15)
  private val filterDepth = new Slider {
    min = 0
    max = 6
    majorTickSpacing = 3
    minorTickSpacing = 1
    paintLabels = true
    paintTicks = true
    value = 1
    name = "Filter Depth"
  }
  private val rButton = new RadioButton("R") {
    enabled = false
  }
  private val roButton = new RadioButton("RO") {
    enabled = false
  }
  private val nButton = new RadioButton("N") {
    enabled = false
  }
  private val noButton = new RadioButton("NO") {
    enabled = false
  }
  private val intersectionButton = new RadioButton("RᴖN") {
    enabled = false
  }
  private val unionButton = new RadioButton("RᴗN") {
    selected = true
    enabled = false
  }
  private val graphSetGroup = new ButtonGroup(rButton,roButton,nButton,noButton,intersectionButton, unionButton)

  private val filterButton = new Button("Filter Graph By Node Name")
  private val clearFiltersButton = new Button("Clear Filters")
  contents += new FlowPanel {
    contents += new Label("Node:")
    contents += nodeName
  }
  contents += new FlowPanel {
    border = titledBorder("Filter Depth")
    contents += filterDepth
  }
  contents += new FlowPanel {
    contents ++= Seq(rButton,roButton,nButton,noButton,intersectionButton,unionButton)
  }
  contents += new BorderPanel {
    layout {
      new GridPanel(2,1) {
        contents += filterButton
        contents += clearFiltersButton
      }
    } = North
  }  
  listenTo(filterButton)
  listenTo(clearFiltersButton)
  reactions += {
    case ButtonClicked(component) if component == filterButton =>
      if (nodeName.text.length > 0) {
        // We need to clear the filters first because if there is an existing
        // filter, a new filter over the top of it won't work.
        preview.clearFilters        
        preview.filterGraphByNodeName(nodeName.text, filterDepth.value)
      }
    case ButtonClicked(component) if component == clearFiltersButton =>     
      preview.clearFilters      
  }
}

/** This very small trait is used to add a method to the layout radio buttons
  * in the LayoutControlPane for purposes of callback. It is very narrow in 
  * purpose, hence private.
  * 
  * @author Jamie Lawson
  */
private trait LayerOuter {
  def layoutGraph
}

/** A compound widget that controls the layout of the graph visualization. At 
  * the moment it supports:
  * 
  *  1. ''Fruchterman-Reingold layout algorithm:'' Good choice for miRNA 
  *     networks though perhaps a bit slow.
  *  1. ''Yifan Hu layout algorithm:'' Good general choice for laying out
  *     medium-to-large graphs. Relatively efficient.
  *  1. ''Force Atlas layout algorithm:'' Emerging as a pretty good layout
  *     algorithm for small-to-medium sized graphs.
  *  1. ''OpenOrd layout algorithm:'' A layout algorithm that is good for very
  *     large graphs, but not so good for graphs with, say, a few hundred
  *     vertices.
  *  
  * @author Jamie Lawson
  * 
  * @param preview	The graph visualization to apply the layout algorithm to.
  */
class LayoutControlPanel(preview: PreviewPanel) extends BorderPanel {
  border = titledBorder("Graph Layout")
  
  /** This method basically takes a layout method and turns it into a background
    * process for laying out the graph. It takes the function to do the layout
    * as a parameter and returns a ''BackgroundProcess'' that wraps it. This
    * can then be passed to a ''WaitDialog''.
    * 
    * @param f	The function (which itself takes a ''Stopper'' as a parameter)
    * 			that lays out the graph.
    *    
    * @return A ''BackgroundProcess'' that wraps the layout function.
    */
  private def makeBackgroundLayoutProcess(f:(InterruptableTimeBasedStopper=>Unit)) = {
    new BackgroundProcess {
      val stopper = new InterruptableTimeBasedStopper(layoutTime)
      val progressBar = new ProgressBar {
        min = 0
        max = 100
        value = 0
        labelPainted = true
      }
      def run = f(stopper)
    }    
  }
  
  private val fruchtermanReingoldButton = new RadioButton("Fruchterman-Reingold") with LayerOuter {    
    def layoutGraph = new WaitDialog(makeBackgroundLayoutProcess(preview.useFruchtermanReingoldLayout)).open
  }
  
  private val yifanHuButton = new RadioButton("Yifan Hu") with LayerOuter {
    def layoutGraph = new WaitDialog(makeBackgroundLayoutProcess(preview.useYifanHuLayout)).open
  }
  private val forceAtlasButton = new RadioButton("Force Atlas") with LayerOuter {
    def layoutGraph = new WaitDialog(makeBackgroundLayoutProcess(preview.useForceAtlasLayout)).open
  }
  private val openOrdButton = new RadioButton("OpenOrd") with LayerOuter {
    def layoutGraph = new WaitDialog(makeBackgroundLayoutProcess(preview.useOpenOrdLayout)).open // Fix this.
  }
  // OpenOrd layout is currently not supported.
  //openOrdButton.enabled = false
  
  private val graphLayoutGroup = new ButtonGroup(fruchtermanReingoldButton, yifanHuButton,forceAtlasButton, openOrdButton)
  private val layoutButton = new Button("Layout Graph")
  private val maxTime = new Slider {
    min = 0
    max = 300
    majorTickSpacing = 60
    minorTickSpacing = 10
    paintLabels = true
    paintTicks = true
    value = 10
    name = "Layout Time (secs)"
  }
  graphLayoutGroup.select(fruchtermanReingoldButton)
  
  private lazy val oneXButton = new RadioButton("1x")
  private lazy val tenXButton = new RadioButton("10x")
  private lazy val cXButton = new RadioButton("100x")
  private lazy val layoutTimeMultiplierGroup = new ButtonGroup(oneXButton, tenXButton, cXButton)
  layoutTimeMultiplierGroup.select(oneXButton)
  
  private def layoutTime: Int = {
    if (layoutTimeMultiplierGroup == null) println("THE GROUP ITSELF IS NULL")
    if (layoutTimeMultiplierGroup.selected == null) println("THE SELECTED ELEMENT IS NULL")
    val mult = layoutTimeMultiplierGroup.selected match {
      case Some(button) if button == oneXButton => 1
      case Some(button) if button == tenXButton => 10
      case Some(button) if button == cXButton   => 100
      case _                                    => 1
    }
    maxTime.value * mult * 1000
  }
  
  //  Now lay all of these things out.
  layout {
    new GridPanel(4,1) {
      contents += fruchtermanReingoldButton
      contents += yifanHuButton
      contents += forceAtlasButton
      contents += openOrdButton
    }
  } = North
  layout {
    new BoxPanel(Orientation.Vertical) {
      border = titledBorder("Layout Time (secs)")
      contents += maxTime
      contents += new FlowPanel {
        contents += oneXButton
        contents += tenXButton
        contents += cXButton
      }
    }
  } = Center
  layout(new GridPanel(1,1) {
      //contents += layoutButton 
      contents += new BorderPanel {
        layout(layoutButton) = South
      }
    }) = South
    
  // In this panel, the only thing that causes outside change is a press of the
  // "Layout Graph" button. So that's what we listen to, and react accordingly. 
  listenTo(layoutButton)
  reactions += {
    case ButtonClicked(component) if component == layoutButton =>
      graphLayoutGroup.selected match {
        case Some(layerOuter:LayerOuter) => layerOuter.layoutGraph
        case Some(other)                 => 
        case None                        =>
      }
  }    
}

/** A process that runs as a ''Future'' under a ''WaitDialog''. It has a
  * progress bar so that we can update the user as to actual progress, and
  * an ''InterruptableTimeBasedStopper'' that tells us how long to expect this
  * background process to take. 
  * 
  * @author Jamie Lawson
  */
private abstract class BackgroundProcess extends Runnable {
  def progressBar: ProgressBar
  def stopper: InterruptableTimeBasedStopper
}

import scala.concurrent._
import ExecutionContext.Implicits.global

/** A "Please wait until this long running process is done" modal dialog that is
  * used during the long process of laying out a graph. The dialog box has a 
  * progress bar (that it gets from the background process), to show the user
  * where in the process we are, and a "Cancel" button that lets the user short
  * circuit the process. The "Cancel" button interrupts an 
  * ''InterruptableTimeBasedStopper'' that is also provided as part of the 
  * background process.   
  * 
  * @author Jamie Lawson
  * 
  * @param backgroundProcess 	The background process (a layout algorithm 
  * 							typically) that we will be waiting on.
  * 
  */
private class WaitDialog(backgroundProcess:BackgroundProcess) extends Dialog {
  modal = true
  minimumSize = new scala.swing.Dimension(400,200)
  // Lay out the dialog box.
  contents = new BorderPanel {
    border = titledBorder("Performing Graph Layout")
    layout (new Label(" ")) = North
    layout (new BorderPanel {
      layout(backgroundProcess.progressBar) = North
    }) = Center
    layout (new FlowPanel {
      contents += new Button(Action("Cancel") {
        // We interrupt the background process but we don't need to close here
        // because the stopper will cause the background process to exit 
        // successfully
        backgroundProcess.stopper.interrupt
      })
    }) = South
    layout (new Label("   ")) = East
    layout (new Label("   ")) = West
  }
  
  // This is a little helper thread that basically has a watch, and every time
  // the big hand is in the right place, it updates the progress bar.
  new Thread {
    override def run:Unit = {
      val timeDivisions = 20
      val delay = backgroundProcess.stopper.duration / timeDivisions
      for (i <- 1 to timeDivisions) {
        // If the background process is done, we are (possibly unexpectedly)
        // done and need to bail out of this thread immediately.
        if (!backgroundProcess.stopper.continue) return
        Thread.sleep(delay)
        backgroundProcess.progressBar.value = i*5 
      }
    }
  }.start
  // Run the background process. When the background process has completed,
  // close this dialog box immediately.
  val myFuture = future {
    backgroundProcess.run
  }
  myFuture onSuccess {
    case _ => Swing.onEDT {
      close
    }
  }
  
  /** In case the user closes this dialog with the little "X", we want to make
    * sure that the background process is stopped. Other than that, this method
    * does exactly what the parent class does with this method. 
    */
  override def closeOperation = {
    backgroundProcess.stopper.interrupt
    super.closeOperation
  }
}