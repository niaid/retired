package gov.nih.niaid.granite.gravel

/** Supplies a composite panel (at the top level, one that goes into a
  * ''TabbedPane'') for viewing large graphs and manipulating those views.
  * 
  * @author Jamie Lawson 
  */
package object graphpanel {
}