package gov.nih.niaid.granite.gravel.simpleexpressionmodel

import gov.nih.niaid.granite.gravel._
import scala.swing._
import scala.swing.BorderPanel.Position._

/** Provides a combination of a table view of the expression data along with a
  * brief overview.
  * 
  * @author Jamie Lawson 
  */
class ExpressionModelPanel(expressionModel: SimpleExpressionModel) extends BorderPanel {
  val table = new SimpleExpressionModelPanel(expressionModel) {
    border = titledBorder("")
  }
  def this() = this(new DummySimpleExpressionModel)
  
  //////////////////////////////////////////////////////////////////////////////
  //  Layout the components.
  //////////////////////////////////////////////////////////////////////////////
  private val outputPanel = new ModelOutputPanel(expressionModel)
  
  layout(new BoxPanel(Orientation.Vertical) {
    contents += outputPanel 
  }) = North
  layout(table) = Center
  
  def update(newModel: SimpleExpressionModel) = {
    table.setModel(new SimpleExpressionModelTableModel(newModel))
    outputPanel.update(newModel)
  }
  
  /** Gets the simple expression model represented by this panel.
    * 
    * @return An expression model equivalent to the one embodied in this panel, 
    *         as an ''Option'', because there might be none.
    */
  def getModel: Option[SimpleExpressionModel] = {
    table.toSimpleExpressionModel(outputPanel.getName)
  }
  
  /** Since external observers will want to process events from the clear
    * button in the subpanel, we expose it to them. 
    * 
    */
  val clearButton = outputPanel.clearButton
  
  /** Puts a new title at the top of the panel.
    * 
    */
  def setTitle(newTitle: String) = outputPanel.border = titledBorder(newTitle)
  
  /** May have to be called if this panel is constructed before installing in
    * a layout. 
    */
  def initializeColumnWidths = table.initializeColumnWidths
  
  /** Sets whether or not the name field that is displayed is user editable.
    * 
    * @param isNameEditable	Whether the name field is to be editable or not.
    */
  def setNameEditable(isNameEditable: Boolean) = outputPanel.setNameEditable(isNameEditable)
}

/** This panel provides user control to accept the processed expression model
  * and record it. 
  * 
  * @author Jamie Lawson
  */
private class ModelOutputPanel(expressionModel: SimpleExpressionModel) extends GridPanel(2,1) {
  border = titledBorder("Model Output")
  //////////////////////////////////////////////////////////////////////////////
  // Instantiate and name all of the things that might get manipulated.
  //////////////////////////////////////////////////////////////////////////////
  val text = new TextArea {
    editable = false
    background = uneditableTextAreaBackgroundColor
  }
  val nameLabel = new Label("Model Name:")
  val nameField = new TextField(20)
  val clearButton = new Button("Clear") {
    maximumSize = new scala.swing.Dimension(100,30)
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // Layout all of the components.
  //////////////////////////////////////////////////////////////////////////////
  contents += text
  contents += new BorderPanel {
    layout(new FlowPanel {
      contents += nameLabel
      contents += nameField
    }) = West
    layout(new BoxPanel(Orientation.Vertical) {
       contents += clearButton
    }) = Center
  }
  update(expressionModel)

  //////////////////////////////////////////////////////////////////////////////
  // Methods that do some manipulation or provide status.
  //////////////////////////////////////////////////////////////////////////////
  
  /** Update this display to account for a new expression model.
    *
    * @param model	The new expression model to display. 
    */
  def update(model: SimpleExpressionModel) = {
    model match {
      case dummy: DummySimpleExpressionModel => clearOutput
    	   									    disableName
    	   									    setName("")
      case _ 								 => updateRecords(model.rows)
                                                enableName
                                                setName(model.name)
    }
  }
  def setName(modelName: String) = nameField.text = modelName
  def getName = nameField.text.trim
  def setNameEditable(isNameEditable: Boolean) = nameField.editable = isNameEditable
  
  //////////////////////////////////////////////////////////////////////////////
  // Private helpers.
  //////////////////////////////////////////////////////////////////////////////
  private def clearOutput = {
    text.text = "No current expression model has been computed"
  }
  private def updateRecords(records: Int) = {
    text.text = "Number of Processed Records: " + records
  }
  private def enableName = {
    nameLabel.enabled = true
    nameField.enabled = true
  }
  private def disableName = {
    nameLabel.enabled = false
    nameField.enabled = false
  }
}
