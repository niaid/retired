package gov.nih.niaid.granite.gravel.log

import scala.swing._
import scala.swing.BorderPanel.Position._
import gov.nih.niaid.granite.gravel._

/** This panel provides a place to write log information.
  * 
  * @author Jamie Lawson
  */
class LogPanel extends ScrollPane with Log {
  border = titledBorder("Log")  
  val logArea = new TextArea {
    editable = false
    background = uneditableTextAreaBackgroundColor
  }
  contents = new BorderPanel {
    layout(logArea) = Center
  }
  
  /** Appends a message to the current log text.
    * 
    */
  def log(message: String) = logArea.text = logArea.text + "LOG> " + message + "\n"
  
  /** Clears the log area.
    * 
    */
  def clear() = {
    logArea.text = ""     
  }
}