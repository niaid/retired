package gov.nih.niaid.granite

import java.io.{File,FileInputStream,FileWriter,FileNotFoundException}
import java.util.Properties
import java.awt.{Dimension,Color}
import javax.swing.border.TitledBorder._
import javax.swing.border._
import gov.nih.niaid.granite.core.model.RectangleModel

/** Gravel is the GRANITE user interface.
  *  
  * The package object defines general properties and styles that we want to be
  * applied across the user interface: colors, borders, etc.  
  * 
  * @author Jamie Lawson
  */
package object gravel {
  def titledBorder(title: String) = new TitledBorder(new EtchedBorder, title, DEFAULT_JUSTIFICATION, DEFAULT_POSITION)
  def uneditableTextAreaBackgroundColor = new java.awt.Color(0xF0F0F0)
  def candidateColumnPreferredWidth = 100
  def rowNumberColumnWidth = 50
  def incidentalColumnPreferredWidth = 60
  def applicationMinimumSize = new Dimension(1024,768)
  
  //////////////////////////////////////////////////////////////////////////////
  //  Deal with the initial user configuration properties for the application.
  //    1) Create the properties object.
  //    2) Set the default properties.
  //    3) Read the user's override properties from an XML file.
  //////////////////////////////////////////////////////////////////////////////
  private val properties = new Properties
  properties.setProperty("startDir", System.getProperty("user.home"))
  properties.setProperty("imagesDir", System.getProperty("user.home"))
  val gravelDirName = System.getProperty("user.home") + "/.gravel"
  val gravelConfigFileName = gravelDirName + "/gravel.ini"  
  try {
    val in = new FileInputStream(gravelConfigFileName)
    properties.loadFromXML(in)
    in.close
  } catch {
    case fnfe: FileNotFoundException =>
      println("Gravel configuration file not found. Attempting to create one")
      // Chances are that if the configuration file doesn't exist, the Gravel
      // directory doesn't exist either, so let's make sure it is there.
      val theDir = new File(gravelDirName)
      if (!theDir.exists) {
        println("Gravel settings directory " + gravelDirName + " doesn't exist so Gravel is creating one")          
        if (!theDir.mkdir) {
          println("Gravel settings directory " + gravelDirName + " doesn't exist and can't be created. Possible permissions problem.")
          println("Exiting with an error")
          System.exit(1)
        }
      }
      // Now try to create the configuration file.
      try {
        val writer = new FileWriter(gravelConfigFileName)
        writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        writer.write("<!DOCTYPE properties SYSTEM \"http://java.sun.com/dtd/properties.dtd\">\n")
        writer.write("<properties>\n")
        writer.write("  <comment>Gravel startup configuration properties</comment>\n")
        writer.write("  <entry key=\"startDir\">" + properties.getProperty("startDir") + "</entry>\n")
        writer.write("  <entry key=\"imagesDir\">" + properties.getProperty("imagesDir") + "</entry>\n")
        writer.write("</properties>\n")
        writer.close
      } catch {
        case t:Throwable => 
          println("Could not create Gravel configuration file " + gravelConfigFileName + ". Possible permissions problem.")
          println("Exiting with an error")
          System.exit(2)
      }
  }
  		  		  
  def getProperty(name:String) = properties.getProperty(name).trim
  
  def getLikelyColumn(rawDataModel: RectangleModel[String], comp: String => Boolean): Option[Int] = {
    for (col <- 0 to rawDataModel.columns-1) {
      rawDataModel(0,col) match {
        case Some(value) => if (comp(value.toUpperCase)) return Some(col+1)  
        case None        =>
      } 
    }
    None
  }
  
  def getFoldRatioLikelyColumn(rawDataModel: RectangleModel[String]): Option[Int] = {
    getLikelyColumn(rawDataModel, {string:String => {
        if (string.contains("FOLD") && string.contains("RATIO")) true
        else if (string.contains("FOLD") && string.contains("CHANGE")) true
        else false
      }
    })
  }
  
  def getGeneSymbolLikelyColumn(rawDataModel: RectangleModel[String]): Option[Int] = {
    getLikelyColumn(rawDataModel, {string: String => {
        if (string.contains("GENE") && string.contains("SYMBOL")) true
        else false
      }
    })
  }
  
  def getPValueLikelyColumn(rawDataModel: RectangleModel[String]): Option[Int] = {
    getLikelyColumn(rawDataModel, {string: String => {
        if (string.contains("PVAL") || string.contains("P-VAL")) true
        else false
      }
    })
  }
  
  def getColumnNumberLikelyColumn(rawDataModel: RectangleModel[String]): Option[Int] = {
    getLikelyColumn(rawDataModel, {string: String => {
        if (string.contains("COLUMN")) true
        else false
      }
    })
  }  
  
  def getFoldChangeDescriptionLikelyColumn(rawDataModel: RectangleModel[String]): Option[Int] = {
    getLikelyColumn(rawDataModel, {string: String => {
        if (string.contains("FOLD") && string.contains("DESC")) true
        else false
      }
    })
  }
  
  def getTranscriptIdLikelyColumn(rawDataModel: RectangleModel[String]): Option[Int] = {
    getLikelyColumn(rawDataModel, {string: String => {
        if (string.contains("TRANSCRIPT") && string.contains("ID")) true
        else false
      }
    })
  }
  
  
  //////////////////////////////////////////////////////////////////////////////
  
  
  def getLocalFileName(fn: String): String = {
    val splitPointUnix = fn.lastIndexOf('/')
    val splitPointWindows = fn.lastIndexOf('\\')
    val splitPoint = Math.max(splitPointUnix, splitPointWindows)
    fn.substring(splitPoint+1)
  }
  def getShortLocalFileName(fn: String): String = {
    val sfn = getLocalFileName(fn)
    val splitPoint = sfn.lastIndexOf(".")
    sfn.substring(0,splitPoint)
  }
}