#!/bin/bash

chmod a+x ./*.pl

./remove_extra_dot.pl *pdb

ls *.pdb >pdblist

java -cp . gov.nih.niaid.bcbb.nglycpred.GlycSelPdbs_Singlechain pdblist 1 $1 pdbs_glyc.out 5

./pdbs_glyc.out_tolist.pl pdbs_glyc.out >list_input

for i in `cat pdblist `;do ../../../dssp/bin/dssp-2-linux-i386 $i >$i.dssp;done

for i in `cat pdblist `;do ../../../bin/naccess -p 3.0 $i;done

./get_3d_env_co_seq.pl list_input ./ 5 0 5 6 >localseq_3d_env_co

./get_dssp_window.pl list_input ./ 5 >list_input_dssp

./get_sa_naccess.pl list_input ./ 0 >list_input_sa_naccess

./get_test_arff_v4.pl list_input localseq_3d_env_co list_input_sa_naccess list_input_dssp  >input.arff

java -Xmx2500m -cp . weka.classifiers.trees.RandomForest -t sa_Nacess_t3.7_dssp_position_0_dssp_position_5_contact_order_w5_t0.25_pattern_11_THR_pattern_9_GLY_pattern_10_LEU_pattern_7_TRP.arff -T input.arff -I 1000 -K 0 -S 1 -p 0 >weka_predictions

./get_predicted_probabilities.pl list_input weka_predictions >output

 echo "NGLYCPRED-OUTPUT-START--"; cat output; echo "--NGLYCPRED-OUTPUT-END"
