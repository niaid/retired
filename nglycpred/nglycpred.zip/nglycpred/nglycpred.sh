#!/bin/bash

trap 'stop' SIGINT

function errdie() {
  echo -e "\n\n${1}"
  exit 1
}

# This script is the entrypoint for starting the Abctransporter  application in a running container.
# It's split into three phases; pre-start, start, and post-start to split up tasks that
# should run at those different stages of starting the application

#
# Pre-start
#

prestart(){
    echo "[Nglycpred][info] - Running pre-start steps..."
    echo ""
    
    echo "[Nglycpred][info] - Finished pre-start steps."
}


#
# Start
#

start(){
  echo "[Nglycpred][info] - Configuring database connection..."
  #db_props=/usr/local/tomcat/webapps/abctransporter/WEB-INF/hosts/jdbc.properties
  #export CATALINA_OPTS="$CATALINA_OPTS -Dibm.worklight.jndi.file=${db_props} -DDB_HOST=${DB_HOST} -DDB_NAME=${DB_NAME} -DDB_USER=${DB_USER} -DDB_PASS=${DB_PASS}"
  echo "[Nglycpred][info] - Starting Tomcat..."
  nohup catalina.sh run &
  echo "[Nglycpred][info] - Finished start steps."
}


#
# Post-start
#

poststart(){
    echo "[Nglycpred][info] - Running post-start steps..."
    # Run any scripts or commands here that should happen after the Apache has started.

   #Installing naccess
    #echo "[Nglycpred][info] - Installing naccess ..."
    #cd /usr/local/naccess-2.1.1
    #csh install.scr
    #creating symbolic link
    #ln -s /usr/local/naccess-2.1.1/naccess /usr/local/bin/
    #echo "[Nglycpred][info] - Created symbolic links ..."
    if [[ $RUN_RSYNC == "true" ]]
      then
        rsync -avz rsync://rsync.cmbi.ru.nl/dssp/ /mnt/data
    fi
    
   

   echo "[Nglycpred][info] - Data syncing completed ..."

   ln -s /mnt/data /usr/local/dssp/data

   echo "[Nglycpred][info] - Created symbolic links ..."



    printf "[Nglycpred][info] - HTTP GET returns: "
    curl -sL -w "%{http_code}" "http://localhost:8888" -o /dev/null

    echo "[Nglycpred][info] - Finished post-start steps."
}

#
# Stop
#

stop(){
    echo "[Nglycpred][info] - Stopping application..."
    exit 0
}

# entrypoint

echo "[Nglycpred][info] - Begining controlled startup..."
prestart
start
poststart
echo "[Nglycpred][info] - Controlled startup finished!"

#
# run indefinitely, until error, or SIGINT
#
while true
do
    # nothing..
    sleep 100
done


