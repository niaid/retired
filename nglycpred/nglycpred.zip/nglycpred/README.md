NGlycPred Server: N-linked Glycosylation Prediction Server Incorporating Structural Information and Patterns

This repository contains war file from exon server.

Docker
======
The Dockerfile in this application repository defines the state of a Docker image capable of running this application and is based on a NIAID OEB nodejs-4.4.x image hosted in our registry. This Dockerfile will make it possible to setup automatic CI build processes and enables the potential for CD to QA/Prod application servers.

Once a build process is in place, an image will be available to pull and run with the proper crednetials. To build and run the docker image in a container locally the following prerequisites must be met:

  - Docker for your platform must be installed: [Docker can now be installed natively most popular platforms](https://www.docker.com/products/overview#/install_the_platform)! 
  - NIAID docker registry account to pull the base nodejs-4.4.x image which is used to build the app image

Setup
-----

CD to your favoriate place to clone apps locally, clone this repo, and cd into the cloned repo. (No need to run and node commands or do an `npm install`, in fact, you do not need node installed on the machine for this process to work. Nifty huh?)

Make sure your Docker service is running.

Building
--------

Building your application image takes the base image specified in your `Dockerfile` and adds everything necessary to run your application to the image and saves it locally.

*(Note: Make sure the NAME is in lowercase.)*

```bash
 $ docker build -t nbp .
```
The Dockerfile also specifies a default `CMD` to run when nothing is passed on the CLI to override this. In the case of this app, the `CMD` is `npm start`. There is an associated `start` script in the `package.json` file that simple runs `node app.js` however this can be changed to whatever is necessary to get the app running. (Furthermore, the `CMD` in the Dockerfile can also be changed if necessary. Whatever it takes to get the app running!) This `CMD` is added to the image but the image is not running so neither is the application.

Running
-------

Running envolves instantiating a container based on a specific image. An image can have several containers created from it but a container can only be built from a single parent image. (Of course, that image could have been built on another image, as is the case with this app.)

```bash
 $ docker run --expose=3000 -p 3000:3000 --name nbp nbp:latest & 
```

Notice the `--expose` and the `-p` optargs. These ensure that the internal port is exposed to Docker and that Docker maps the internal port to the external port. Keep in mind, if you already have an app bound to the port above, you should use a different one.

An environment file can/will be generated automatically and populated with configuration information in the NIAID GoCD CI/CD pipeline. The same process can be imitated locally by creating an environment file (essentially just a shell script to set environment variables) which can be passed to Docker at runtime to configure your running application within the container!

Here's an example:

```bash
CHEMOKINEDB_VER=1.0.0
CHEMOKINEDB_LISTEN_PORT=3000
CHEMOKINEDB_DB_PROTOCOL=http
CHEMOKINEDB_DB_URL=ai-exondbdev1.niaid.nih.gov
CHEMOKINEDB_DB_PORT=7474
CHEMOKINEDB_DB_USER=neo4j
CHEMOKINEDB_DB_PASS=*************
```

*(Note: This will not currently work but should be on the future todo list for this application as configuration in this manner is simple and clean.)*

With this environment file create, simply add the following optarg pointing to environment file to the `docker run` command above:

```bash
  --env-file </path/to/environment/file.env>
```

Stopping
--------

The ` &` on the end of the run statement will get your contianer running and return to your thread so that you can run subsequent commands. 

**Check the running containers**
```bash
    $ docker ps
```

(Add -a to check for non-running containers.)

**Stop running containers**
```bash
    $ docker stop <container_id>
```
To get container_id type: $ docker ps

Cleaning Up
-----------

To clean up contianers (must occur first):
```bash
   $ docker rm <container_id>
```
To clean up images (must occur after all associated containers no longer exist):
```bash
   $ docker rmi <image_id>
```
P.S. **container_id** is different from **image_id** to obtain the image_id you should type this:

```bash
$ docker images
```
