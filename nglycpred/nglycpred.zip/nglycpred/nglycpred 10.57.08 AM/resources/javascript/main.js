

var tabHoverClass="TabbedPanelsTabHover";
var tabFocusedClass="TabbedPanelsTabSelected";

// Disabled 10/16/2009 - JLN: Using jQuery plugin to rotate live
/*
window.onload=function(){
		decorate();
		Nifty("div#box", "big");
		if(document.exonspice!=null){
			var select = new Array();
			var count = 0;
			select[count++] = "SPICE-Ad.png"
	//	select[count++] = "SPICE-Thumb.png"
	//	select[count++] = "ajax-loader.gif"
	//	select[count++] = "DRA-Thumb.png"
	//	select[count++] = "exon.jpg"
	//	select[count++] = "ncbi.gif"

			var image = Math.floor(Math.random()*count);
			var randomImg = "resources/images/" + select[image];
			document.exonspice.src = randomImg;
			}
}
*/

function linkTo(title){
	window.location=title;
	
}

function openTo(title){
	window.open(title);
}

function setMO(ele){
	return addClassName(ele, tabHoverClass);	
}

function setOO(ele){
	return removeClassName(ele, tabHoverClass);
	
}

function decorate(){
	//function to decorate the tab. 
	//get the document name, 
	var titleString=window.location.toString();
	var toSelect="";
	if(titleString.indexOf('applications')>0) toSelect="downloadsTab";
	else if(titleString.indexOf('support')>0 || titleString.indexOf('Send')>0) toSelect="supportTab";
	else if(titleString.indexOf('about')>0) toSelect="aboutTab";
	else if(titleString.indexOf('transcriptome')>0) toSelect="transcriptomeTab";
	else if(titleString.indexOf('links')>0) toSelect="linksTab";
	else if(titleString.indexOf('index')>0 || titleString.substring(titleString.length-1, titleString.length)=="/") toSelect="indexTab";
	
	return decorateOn(toSelect);
	
}

function decorateOn(eleString){
	var ele=document.getElementById(eleString);	
	return addClassName(ele, tabFocusedClass);
}

function addClassName(ele, className){
	if (!ele || !className || (ele.className && ele.className.search(new RegExp("\\b" + className + "\\b")) != -1))
		return;
	ele.className += (ele.className ? " " : "") + className;
}

function removeClassName(ele, className){
	if (!ele || !className || (ele.className && ele.className.search(new RegExp("\\b" + className + "\\b")) == -1))
		return;
	ele.className = ele.className.replace(new RegExp("\\s*\\b" + className + "\\b", "g"), "");	
}