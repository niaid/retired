#!/bin/bash

# requires dssp binaries    http://swift.cmbi.ru.nl/gv/dssp/
# requires naccess binaries http://www.bioinf.manchester.ac.uk/naccess/
# expects environment variables named 'naccess' and 'dssp' set to respective binary paths
# for example:
# NACCESS=/usr/local/bin/naccess
# DSSP=/export/.rhel6_sw/usrlocal/dssp/bin/dssp-2-linux-i386
# NGlycPred server process uses '/WEB-INF/sh/environment.properties' to determine these values

chmod a+x ./*.pl

./remove_extra_dot.pl *pdb 2>/dev/null

# append .upload extension to uploaded pdb files ( fileABC.pdb -> fileABC.pdb.upload )
# run Perl script with results saved as original filename ( -> fileABC.pdb )
for fpdb in $( ls *.pdb ); do mv $fpdb "$fpdb".upload && ./removeH.pl "$fpdb".upload >$fpdb; done


ls *.pdb >pdblist
java -cp NGlycPredCore.jar gov.nih.niaid.bcbb.nglycpred.GlycSelPdbs_Singlechain pdblist 1 $1 pdbs_glyc.out 5 
./pdbs_glyc.out_tolist.pl pdbs_glyc.out >list_input
for i in `cat pdblist `;do $DSSP $i >$i.dssp;done
for i in `cat pdblist `;do $NACCESS -p 3.0 $i;done
./get_3d_env_co_seq.pl list_input ./ 5 0 5 6 >localseq_3d_env_co 
./get_dssp_window.pl list_input ./ 5 >list_input_dssp
./get_sa_naccess.pl list_input ./ 0 >list_input_sa_naccess
./get_test_arff_structure_sequence_grouped.pl list_input localseq_3d_env_co list_input_sa_naccess list_input_dssp  >input.arff
java -Xmx2500m -cp weka.jar weka.classifiers.trees.RandomForest -t sa_Nacess_t3.7_grouped_data_t5.0_dssp_position_0_dssp_position_6_seq_encoding_1_w2.arff -T input.arff -I 1000 -K 0 -S 1 -p 0 >weka_predictions
./get_predicted_probabilities.pl list_input weka_predictions >output
