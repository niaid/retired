#!/usr/bin/perl -w

if(@ARGV<4)
{
print "list_input localseq_3d_env_sidechain list_sa list_dssp\n";
exit;
}

$list=shift;
$local_3d=shift;
$rsa=shift;
$dssp=shift;

print "\@relation local_sequence_only
\@attribute sa {g3.7,l3.7}
\@attribute proline real
\@attribute hfb real
\@attribute GA real
\@attribute large_hydrophobic real
\@attribute negative_charge real
\@attribute positive_charge real
\@attribute polar_O real
\@attribute polar_N real
\@attribute dssp_position_0 {H,B,E,G,I,T,S,L}
\@attribute dssp_position_5 {H,B,E,G,I,T,S,L}
\@attribute contact_order_t0.3 {g0.3,l0.3}
\@attribute flag {1,0}
\@data
";
open(LIST, "<$list") or die;
@llines=<LIST>;
close(LIST);

$n=@llines;

open(L3D, "<$local_3d") or die;
@l3dlines=<L3D>;
close(L3D);

open(SA, "<$rsa") or die;
@salines=<SA>;
close(SA);

open(DSSP, "<$dssp") or die;
@dssplines=<DSSP>;
close(DSSP);

for($i=0;$i<$n;$i++)
{
@sdata=split(/:/,$salines[$i]);
@dsspdata=split(/:/,$dssplines[$i]);
$sa=$sdata[2];
chomp($sa);
if($sa>=3.7)
{
$safinal="g3.7";
}
else
{
$safinal="l3.7";
}
@data=split(/,/,$l3dlines[$i]);

chomp($l3dlines[$i]);
print "$safinal,";


$pro=$data[13];
$hfb=$data[10]+$data[23]+$data[24]+$data[25]+$data[26];
$ga=$data[14]+$data[15];
$aromatic=$data[27]+$data[28]+$data[29];
$nc=$data[17]+$data[18];
$pc=$data[21]+$data[22]+$data[23];
$polarO=$data[11]+$data[12];
$polarN=$data[16]+$data[19];

print  "$pro,$hfb,$ga,$aromatic,$nc,$pc,$polarO,$polarN,";



#for($j=14;$j<34;$j++)
#{
#print "$data[$j],";
#}
print "$dsspdata[2],$dsspdata[7],";
$co=$data[30];
chomp($co);
if($co>=0.3)
{
print "g0.3,"; 
}
else
{
print "l0.3,";
}

#get_pattern





print "1\n";







}
