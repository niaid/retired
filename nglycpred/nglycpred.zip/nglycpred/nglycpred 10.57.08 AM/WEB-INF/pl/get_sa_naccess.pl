#!/usr/bin/perl -w

if(@ARGV<2)
{
print "usage:$0 list pdb_dir window\n";
exit;
}

$list=shift;
$pdb_dir=shift;
$window=shift;

if(!$window)
{
$window=0;
}

%amino=("GLY", "G", "ALA","A", "PRO", "P", "VAL", "V", "LEU", "L", "ILE", "I", "MET", "M", "PHE", "F", "TYR", "Y", "TRP", "W", "SER", "S", "THR", "T", "CYS", "C", "ASN", "N", "GLN", "Q", "LYS", "K", "HIS", "H", "ARG", "R", "ASP", "D", "GLU", "E", "HEM", "Heme");
%sanorm=("A", 110.2, "D", 144.1, "C", 140.4, "E", 174.7, "F", 200.7, "G", 78.7, "H", 181.9, "I", 185.0, "K", 205.7, "L", 183.1, "M", 200.1, "N", 146.4, "P", 141.9, "Q", 178.6, "R", 229.0, "S", 117.2, "T", 138.7, "V", 153.7, "W" , 240.5, "Y", 213.7);

open(FILE, "<$list") or die;
@lines=<FILE>;
close(FILE);


foreach(@lines)
{
$origline=$_;
chomp($origline);
@data=split(/\s+/,$_);
$pdb=$data[0];
$l=length($pdb);
$chain=substr($data[2],0,1);
$tail=substr($_,6+$l,12);
chomp($tail);
@t=split(':',$tail);
@d=split(':',$_);
$res=substr($d[0],1+$l,10);
$res=~s/\s+$//g;
$resi=$t[0];
$flag=$t[1];
$flag=~s/\s+//g;
$resi=~s/\s+//g;
$occupancy=$t[1];
$occupancy=~s/\s+//g;
$file="$pdb_dir/$pdb.rsa";

$lock=1;
open(FILE, "<$file") or die;
@flines=<FILE>;
close(FILE);

open(FILE, "<$file") or die;

$i=0;
while($s=<FILE>)
{
if($s=~/ABS   REL/)
{
$i=$i+1;	
while($s=<FILE>)
{
$dresi=substr($s,9,5);
$dresi=~s/\s+//g;
$dchain=substr($s,8,1);
#$daa=substr($s,13,1);
#$dssp=substr($s,16,1);	

if($dresi eq $resi && $chain eq $dchain)
{
	print "$origline";
	for($j=0;$j<$window*2+1;$j++)
	{
	$sa=substr($flines[$i+$j-$window],28,6);
	print ":$sa";
	}
	print "\n";
	$lock=0;
	last;
}

$i=$i+1;
}

if($lock==0)
{
close(FILE);
last;
}

}
$i=$i+1;
}

}
