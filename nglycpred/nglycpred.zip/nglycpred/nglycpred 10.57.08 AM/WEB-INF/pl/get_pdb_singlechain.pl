#!/usr/bin/perl -w

if(@ARGV<1)
{
print "list\n";
exit;
}
$list=shift;
open(L, "<$list") or die;
@llines=<L>;
close(L);

foreach(@llines)
{
@ld=split(/\s+/,$_);
$chain=substr($ld[2],0,1);
$pdb=$ld[0];

open(FILE, "<$pdb.pdb") or die "no $pdb.pdb";
open(OUT, ">$pdb.$chain.pdb") or die;
while($s=<FILE>)
{
if($s=~/^ATOM/ && substr($s,21,1) eq $chain)
{
print OUT $s;

}
}
close(OUT);
close(FILE);

}
