#!/usr/bin/perl -w

if(@ARGV<1)
{
print "usage: file\n";
exit;
}

$file=shift;

@d=split(/\./,$file);

$num=@d;
$num=$num-2;
$newfile=$file;
for($i=0;$i<$num;$i++)
{
$newfile=~s/\./_/;
}
system "mv $file  $newfile";
