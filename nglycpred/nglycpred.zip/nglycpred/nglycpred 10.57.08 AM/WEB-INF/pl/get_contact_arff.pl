#!/usr/bin/perl -w

if(@ARGV<3)
{
print "usage:$0 list pdb_dir\n window threshold\n";
exit;
}

$list=shift;
$pdb_dir=shift;
$window=shift;
$threshold=shift;
#print headers

print "\@relation local_sequence_onlyl\n";
print "\@attribute contact_order real\n";


print "\@attribute flag {1,0}\n";

print "\n\@data\n";



open(FILE, "<$list") or die;
@lines=<FILE>;
close(FILE);

foreach(@lines)
{
@data=split(/\s+/,$_);
$pdb=$data[0];
$l=length($pdb);
$chain=substr($data[2],0,1);
$tail=substr($_,10,12);
chomp($tail);
@t=split(':',$tail);
@d=split(':',$_);
$res=substr($d[0],1+$l,10);

$res=~s/\s+$//g;
$resi=$t[0];
$flag=$t[1];
$flag=~s/\s+//g;
$resi=~s/\s+//g;
$occupancy=$t[1];
$occupancy=~s/\s+//g;
#print "$pdb $chain $t[0]\n";
$file="$pdb_dir/$pdb.$chain.pdb";

print "java nglycpred.contact_order $file $chain '$res' $window $threshold";
$sequence=`java nglycpred.contact_order $file $chain '$res' $window $threshold`;

chomp($sequence);
$sequence=~s/,//;
$seqfinal=sprintf("%.3f",$sequence);
$output=$seqfinal.",".$flag;
print "$output\n";
}
