#!/usr/bin/perl -w

if(@ARGV<2)
{
print "list_input localseq_3d_env_sidechain\n";
exit;
}

$list=shift;
$local_3d=shift;
@aa=("CYS","SER","THR","PRO","ALA","GLY","ASN","ASP","GLU","GLN","HIS","ARG","LYS","MET","ILE","LEU","VAL","PHE","TYR","TRP");
print "\@relation local_sequence_only
\@attribute pattern_11_THR {1,0}
\@attribute pattern_9_GLY {1,0}
\@attribute pattern_9_VAL {1,0}
\@attribute pattern_7_TRP {1,0}
\@attribute pattern_8_GLU {1,0}
\@attribute flag {1,0}
\@data
";
open(LIST, "<$list") or die;
@llines=<LIST>;
close(LIST);

$n=@llines;

open(L3D, "<$local_3d") or die;
@l3dlines=<L3D>;
close(L3D);


for($i=0;$i<$n;$i++)
{
@data=split(/,/,$l3dlines[$i]);

chomp($l3dlines[$i]);

#get_pattern

if($data[6] eq "THR")
{
print "1,";
}
else
{
print "0,";
}

if($data[4] eq "GLY")
{
print "1,";
}
else
{
print "0,";
}

if($data[4] eq "VAL")
{
print "1,";
}
else
{
print "0,";
}

if($data[2] eq "TRP")
{
print "1,";
}
else
{
print "0,";
}

if($data[3] eq "GLU")
{
print "1,";
}
else
{
print "0,";
}

print "1\n";







}
