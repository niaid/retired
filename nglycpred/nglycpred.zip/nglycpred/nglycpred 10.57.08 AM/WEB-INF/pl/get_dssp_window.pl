#!/usr/bin/perl -w

if(@ARGV<2)
{
print "udsspge:$0 list pdb_dir window\n";
exit;
}

$list=shift;
$pdb_dir=shift;
$window=shift;

if(!$window)
{
$window=0;
}

%amino=("GLY", "G", "ALA","A", "PRO", "P", "VAL", "V", "LEU", "L", "ILE", "I", "MET", "M", "PHE", "F", "TYR", "Y", "TRP", "W", "SER", "S", "THR", "T", "CYS", "C", "ASN", "N", "GLN", "Q", "LYS", "K", "HIS", "H", "ARG", "R", "ASP", "D", "GLU", "E", "HEM", "Heme");

open(FILE, "<$list") or die;
@lines=<FILE>;
close(FILE);


foreach(@lines)
{
$origline=$_;
chomp($origline);
@data=split(/\s+/,$_);
$pdb=$data[0];
$l=length($pdb);
$chain=substr($data[2],0,1);
$tail=substr($_,6+$l,12);
chomp($tail);
@t=split(':',$tail);
@d=split(':',$_);
$res=substr($d[0],1+$l,10);
$res=~s/\s+$//g;
$resi=$t[0];
$flag=$t[1];
$flag=~s/\s+//g;
$resi=~s/\s+//g;
$occupancy=$t[1];
$occupancy=~s/\s+//g;
$file="$pdb_dir/$pdb.pdb.dssp";

$lock=1;
open(FILE, "<$file") or die;
@flines=<FILE>;
close(FILE);

open(FILE, "<$file") or die;

$i=0;
while($s=<FILE>)
{
if($s=~/RESIDUE AA/)
{
$i=$i+1;	
while($s=<FILE>)
{
$dresi=substr($s,5,6);
$dresi=~s/\s+//g;
$dchain=substr($s,11,1);
#$daa=substr($s,13,1);
#$dssp=substr($s,16,1);	

if($dresi eq $resi && $chain eq $dchain)
{
	print "$origline";
	for($j=0;$j<$window*2+1;$j++)
	{
	$dssp=substr($flines[$i+$j-$window],16,1);
	$aa=substr($flines[$i+$j-$window],13,1);
	
	if($dssp eq " ")
{
$dssp="L";
}


	print ":$dssp";
	}
	print "\n";
	$lock=0;
	last;
}

$i=$i+1;
}

if($lock==0)
{
close(FILE);
last;
}

}
$i=$i+1;
}

}
