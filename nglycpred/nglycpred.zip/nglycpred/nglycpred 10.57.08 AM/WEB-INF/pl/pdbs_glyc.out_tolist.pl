#!/usr/bin/perl -w

if(@ARGV<1)
{
print "$0 file\n";
exit;
}

$file=shift;

open(FILE, "<$file") or die;

while($s=<FILE>)
{
if($s=~/pdb: (\S+).pdb/)
{
$header=$1;
}

if($s=~/ASN /)
{
#$h=substr($header,0,4);
print "$header\t$s";
}


}


close(FILE);
