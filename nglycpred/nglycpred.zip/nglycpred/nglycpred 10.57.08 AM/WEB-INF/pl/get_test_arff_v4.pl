#!/usr/bin/perl -w

if(@ARGV<4)
{
print "list_input localseq_3d_env_sidechain list_sa list_dssp\n";
exit;
}

$list=shift;
$local_3d=shift;
$rsa=shift;
$dssp=shift;

print "\@relation local_sequence_only
\@attribute sa {g3.7,l3.7}
\@attribute dssp_position_0 {H,B,E,G,I,T,S,L}
\@attribute dssp_position_5 {H,B,E,G,I,T,S,L}
\@attribute contact_order_t0.25 {g0.25,l0.25}
\@attribute pattern_11_THR {1,0}
\@attribute pattern_9_GLY {1,0}
\@attribute pattern_10_LEU {1,0}
\@attribute pattern_7_TRP {1,0}
\@attribute flag {1,0}
\@data
";
open(LIST, "<$list") or die;
@llines=<LIST>;
close(LIST);

$n=@llines;

open(L3D, "<$local_3d") or die;
@l3dlines=<L3D>;
close(L3D);

open(SA, "<$rsa") or die;
@salines=<SA>;
close(SA);

open(DSSP, "<$dssp") or die;
@dssplines=<DSSP>;
close(DSSP);

for($i=0;$i<$n;$i++)
{
@sdata=split(/:/,$salines[$i]);
@dsspdata=split(/:/,$dssplines[$i]);
$sa=$sdata[2];
chomp($sa);
if($sa>=3.7)
{
$safinal="g3.7";
}
else
{
$safinal="l3.7";
}
@data=split(/,/,$l3dlines[$i]);

chomp($l3dlines[$i]);
print "$safinal,";
#for($j=14;$j<34;$j++)
#{
#print "$data[$j],";
#}
print "$dsspdata[2],$dsspdata[7],";
$co=$data[30];
chomp($co);
if($co>=0.25)
{
print "g0.25,"; 
}
else
{
print "l0.25,";
}

#get_pattern

if($data[6] eq "THR")
{
print "1,";
}
else
{
print "0,";
}

if($data[4] eq "GLY")
{
print "1,";
}
else
{
print "0,";
}

if($data[5] eq "LEU")
{
print "1,";
}
else
{
print "0,";
}

if($data[2] eq "TRP")
{
print "1,";
}
else
{
print "0,";
}





print "1\n";







}
