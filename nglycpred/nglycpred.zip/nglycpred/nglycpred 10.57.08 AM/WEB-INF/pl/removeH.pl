#!/usr/bin/perl -w

if(@ARGV<1)
{
print "$0 file\n";
exit;
}

$file=shift;
open(FILE, "<$file") or die;
@l=<FILE>;
close(FILE);
foreach(@l)
{
if($_=~/^ATOM/||$_=~/^HETATM/)
{
$atomn=substr($_,12,4);
$atomn=~s/\s+//g;
if(substr($atomn,0,1) ne "H")
{
print $_
}


}
else
{
print $_;
}



}
