#!/usr/bin/perl -w

if(@ARGV<3)
{
print "usage:$0 list pdb_dir\n window encoding_mode threshold\n";
exit;
}

$list=shift;
$pdb_dir=shift;
$window=shift;
$encoding=shift;
$threshold_3d=shift;
$threshold_co=shift;
#print headers
#@aa=("CYS","SER","THR","PRO","ALA","GLY","ASN","ASP","GLU","GLN","HIS","ARG","LYS","MET","ILE","LEU","VAL","PHE","TYR","TRP");
#print "\@relation local_sequence_only\n\n";


for($j=0;$j<20;$j++)
{
#print "\@attribute surrounding_$aa[$j] real\n";
}


#print "\@attribute flag {1,0}\n";

#print "\n\@data\n";



open(FILE, "<$list") or die;
@lines=<FILE>;
close(FILE);
$n=@lines;
$c=0;
$cmd="";
foreach(@lines)
{
@data=split(/\s+/,$_);
$pdb=$data[0];
$l=length($pdb);
$chain=substr($data[2],0,1);
$tail=substr($_,10,12);
chomp($tail);
@t=split(':',$tail);
@d=split(':',$_);
$res=substr($d[0],1+$l,10);
$res=~s/\s+$//g;
$resi=$t[0];
$flag=$t[1];
$flag=~s/\s+//g;
$resi=~s/\s+//g;
$occupancy=$t[1];
$occupancy=~s/\s+//g;
#print "$pdb $chain $t[0]\n";
$file="$pdb_dir/$pdb.pdb";
#print "java gov.nih.niaid.bcbb.nglycpred.LocalSequence $file $chain $resi $window encoding";
#system "java gov.nih.niaid.bcbb.nglycpred.LocalSequence $file $chain $resi $window encoding";
if($c==0)
{
$cmd=$cmd."java gov.nih.niaid.bcbb.nglycpred.LocalSequence_Three_d_env_sidechain_contact_order_pattern_MultiResidues $file $window $encoding $threshold_3d $threshold_co $n $chain '$res' "
}else
{
$cmd=$cmd."$chain '$res' ";
}
$c=$c+1;
}

system($cmd);
