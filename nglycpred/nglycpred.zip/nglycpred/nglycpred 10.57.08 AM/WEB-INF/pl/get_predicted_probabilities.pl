#!/usr/bin/perl -w

if(@ARGV<2)
{
print "usage: list_input weka_predictions\n"; 
exit;
}

$list=shift;
$weka=shift;

open(LIST, "<$list") or die;
@llines=<LIST>;
close(LIST);

$n=@llines;

open(WEKA, "<$weka") or die;
@wlines=<WEKA>;
close(WEKA);

for($i=0;$i<$n;$i++)
{
@dl=split(/:/,$llines[$i]);
if(substr($wlines[$i+5],31,1) eq "+")
{
$p=1-substr($wlines[$i+5],35,5);
}
else
{
$p=substr($wlines[$i+5],35,5);
}

chomp($p);
if($p>=0.5)
{
print "$dl[0]\t$p\t+\n";
}
else
{
print "$dl[0]\t$p\t-\n";
}
}
