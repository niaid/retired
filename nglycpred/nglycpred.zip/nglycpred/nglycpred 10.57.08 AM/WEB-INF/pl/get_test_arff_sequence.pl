#!/usr/bin/perl -w

if(@ARGV<2)
{
print "list_input localseq_3d_env_sidechain\n";
exit;
}

$list=shift;
$local_3d=shift;
@aa=("CYS","SER","THR","PRO","ALA","GLY","ASN","ASP","GLU","GLN","HIS","ARG","LYS","MET","ILE","LEU","VAL","PHE","TYR","TRP");
print "\@relation local_sequence_only
\@attribute seq_pre_3_CYS {1,0}
\@attribute seq_pre_3_SER {1,0}
\@attribute seq_pre_3_THR {1,0}
\@attribute seq_pre_3_PRO {1,0}
\@attribute seq_pre_3_ALA {1,0}
\@attribute seq_pre_3_GLY {1,0}
\@attribute seq_pre_3_ASN {1,0}
\@attribute seq_pre_3_ASP {1,0}
\@attribute seq_pre_3_GLU {1,0}
\@attribute seq_pre_3_GLN {1,0}
\@attribute seq_pre_3_HIS {1,0}
\@attribute seq_pre_3_ARG {1,0}
\@attribute seq_pre_3_LYS {1,0}
\@attribute seq_pre_3_MET {1,0}
\@attribute seq_pre_3_ILE {1,0}
\@attribute seq_pre_3_LEU {1,0}
\@attribute seq_pre_3_VAL {1,0}
\@attribute seq_pre_3_PHE {1,0}
\@attribute seq_pre_3_TYR {1,0}
\@attribute seq_pre_3_TRP {1,0}
\@attribute seq_pre_2_CYS {1,0}
\@attribute seq_pre_2_SER {1,0}
\@attribute seq_pre_2_THR {1,0}
\@attribute seq_pre_2_PRO {1,0}
\@attribute seq_pre_2_ALA {1,0}
\@attribute seq_pre_2_GLY {1,0}
\@attribute seq_pre_2_ASN {1,0}
\@attribute seq_pre_2_ASP {1,0}
\@attribute seq_pre_2_GLU {1,0}
\@attribute seq_pre_2_GLN {1,0}
\@attribute seq_pre_2_HIS {1,0}
\@attribute seq_pre_2_ARG {1,0}
\@attribute seq_pre_2_LYS {1,0}
\@attribute seq_pre_2_MET {1,0}
\@attribute seq_pre_2_ILE {1,0}
\@attribute seq_pre_2_LEU {1,0}
\@attribute seq_pre_2_VAL {1,0}
\@attribute seq_pre_2_PHE {1,0}
\@attribute seq_pre_2_TYR {1,0}
\@attribute seq_pre_2_TRP {1,0}
\@attribute seq_pre_1_CYS {1,0}
\@attribute seq_pre_1_SER {1,0}
\@attribute seq_pre_1_THR {1,0}
\@attribute seq_pre_1_PRO {1,0}
\@attribute seq_pre_1_ALA {1,0}
\@attribute seq_pre_1_GLY {1,0}
\@attribute seq_pre_1_ASN {1,0}
\@attribute seq_pre_1_ASP {1,0}
\@attribute seq_pre_1_GLU {1,0}
\@attribute seq_pre_1_GLN {1,0}
\@attribute seq_pre_1_HIS {1,0}
\@attribute seq_pre_1_ARG {1,0}
\@attribute seq_pre_1_LYS {1,0}
\@attribute seq_pre_1_MET {1,0}
\@attribute seq_pre_1_ILE {1,0}
\@attribute seq_pre_1_LEU {1,0}
\@attribute seq_pre_1_VAL {1,0}
\@attribute seq_pre_1_PHE {1,0}
\@attribute seq_pre_1_TYR {1,0}
\@attribute seq_pre_1_TRP {1,0}
\@attribute seq_post_1_CYS {1,0}
\@attribute seq_post_1_SER {1,0}
\@attribute seq_post_1_THR {1,0}
\@attribute seq_post_1_PRO {1,0}
\@attribute seq_post_1_ALA {1,0}
\@attribute seq_post_1_GLY {1,0}
\@attribute seq_post_1_ASN {1,0}
\@attribute seq_post_1_ASP {1,0}
\@attribute seq_post_1_GLU {1,0}
\@attribute seq_post_1_GLN {1,0}
\@attribute seq_post_1_HIS {1,0}
\@attribute seq_post_1_ARG {1,0}
\@attribute seq_post_1_LYS {1,0}
\@attribute seq_post_1_MET {1,0}
\@attribute seq_post_1_ILE {1,0}
\@attribute seq_post_1_LEU {1,0}
\@attribute seq_post_1_VAL {1,0}
\@attribute seq_post_1_PHE {1,0}
\@attribute seq_post_1_TYR {1,0}
\@attribute seq_post_1_TRP {1,0}
\@attribute seq_post_2_CYS {1,0}
\@attribute seq_post_2_SER {1,0}
\@attribute seq_post_2_THR {1,0}
\@attribute seq_post_2_PRO {1,0}
\@attribute seq_post_2_ALA {1,0}
\@attribute seq_post_2_GLY {1,0}
\@attribute seq_post_2_ASN {1,0}
\@attribute seq_post_2_ASP {1,0}
\@attribute seq_post_2_GLU {1,0}
\@attribute seq_post_2_GLN {1,0}
\@attribute seq_post_2_HIS {1,0}
\@attribute seq_post_2_ARG {1,0}
\@attribute seq_post_2_LYS {1,0}
\@attribute seq_post_2_MET {1,0}
\@attribute seq_post_2_ILE {1,0}
\@attribute seq_post_2_LEU {1,0}
\@attribute seq_post_2_VAL {1,0}
\@attribute seq_post_2_PHE {1,0}
\@attribute seq_post_2_TYR {1,0}
\@attribute seq_post_2_TRP {1,0}
\@attribute seq_post_3_CYS {1,0}
\@attribute seq_post_3_SER {1,0}
\@attribute seq_post_3_THR {1,0}
\@attribute seq_post_3_PRO {1,0}
\@attribute seq_post_3_ALA {1,0}
\@attribute seq_post_3_GLY {1,0}
\@attribute seq_post_3_ASN {1,0}
\@attribute seq_post_3_ASP {1,0}
\@attribute seq_post_3_GLU {1,0}
\@attribute seq_post_3_GLN {1,0}
\@attribute seq_post_3_HIS {1,0}
\@attribute seq_post_3_ARG {1,0}
\@attribute seq_post_3_LYS {1,0}
\@attribute seq_post_3_MET {1,0}
\@attribute seq_post_3_ILE {1,0}
\@attribute seq_post_3_LEU {1,0}
\@attribute seq_post_3_VAL {1,0}
\@attribute seq_post_3_PHE {1,0}
\@attribute seq_post_3_TYR {1,0}
\@attribute seq_post_3_TRP {1,0}
\@attribute flag {1,0}
\@data
";
open(LIST, "<$list") or die;
@llines=<LIST>;
close(LIST);

$n=@llines;

open(L3D, "<$local_3d") or die;
@l3dlines=<L3D>;
close(L3D);


for($i=0;$i<$n;$i++)
{
@data=split(/,/,$l3dlines[$i]);

chomp($l3dlines[$i]);

#get sequence
for($j=0;$j<20;$j++)
{
if($aa[$j] eq $data[2])
{
print "1,";
}
else
{
print "0,";
}
}


for($j=0;$j<20;$j++)
{
if($aa[$j] eq $data[3])
{
print "1,";
}
else
{
print "0,";
}
}


for($j=0;$j<20;$j++)
{
if($aa[$j] eq $data[4])
{
print "1,";
}
else
{
print "0,";
}
}

for($j=0;$j<20;$j++)
{
if($aa[$j] eq $data[5])
{
print "1,";
}
else
{
print "0,";
}
}

for($j=0;$j<20;$j++)
{
if($aa[$j] eq $data[6])
{
print "1,";
}
else
{
print "0,";
}
}

for($j=0;$j<20;$j++)
{
if($aa[$j] eq $data[7])
{
print "1,";
}
else
{
print "0,";
}
}

print "1\n";







}
