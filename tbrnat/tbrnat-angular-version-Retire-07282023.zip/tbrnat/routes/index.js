
"use strict";

var express = require('express');
var router = express.Router();


/* GET Index page. */
router.get('/', function() {
/* functionis empty beucase do not do anything */
});


module.exports = router;