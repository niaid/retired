/*
 * Serve JSON to our AngularJS client
 */

exports.getAllNodes = function(req, res) {
  var searchterm = req.body.id;
  searchterm = '(?i).*'+searchterm+'.*';
  var dbconnectString = 'http://'+ req.app.get('config').db.username + ':' + req.app.get('config').db.password + '@' + req.app.get('config').db.host + ':' + req.app.get('config').db.port;

  var cypher = require('cypher-stream')(dbconnectString);
      var resultdata={};
      var arrayAllNodes=[];
      var transaction = cypher.transaction()
            .on('data', function (result) {
                if(result["source"] != null){
                    item = {};
                    item ["target"] = result["target"];
                    item ["source"] = result["source"];
                    item ["targetGap"] = result["targetGap"];
                    item ["sourceGap"] = result["sourceGap"];
                    item ["targetName"] = result["targetSymbol"];
                    item ["sourceName"] = result["sourceSymbol"];
                    item ["pubmedId"] = result["pubmedId"];
                    item ["totalAssociations"] = result["totalAssociations"];
                    item ["targetGeneId"] = result["targetGeneId"];
                    item ["sourceGeneId"] = result["sourceGeneId"];
                    arrayAllNodes.push(item);

                }
        });
    //Getting Event Information
    transaction.write({
          statement : 'MATCH p=(g1:TbRNAT)<-[r:TBREGNET*1..1]->(g2:TbRNAT) WITH (nodes(p)) as pathNodes, g1, r, g2 where g1.ncbiGeneLocus =~ {term} or g1.ncbiGeneDescription =~ {term} or g1.ncbiGeneSymbol =~{term} unwind pathNodes as allNodes with collect(DISTINCT id(allNodes)) as allIds MATCH (a)-[r1]->(b) WHERE id(a) IN allIds and id(b) IN allIds RETURN DISTINCT r1.totalAssociations as totalAssociations, r1.pmid as pubmedId, b.ncbiGeneLocus as target, b.ncbiGeneLocus as targetGap, b.ncbiGeneSymbol as targetSymbol, b.ncbiGeneId as targetGeneId, a.ncbiGeneLocus as source, a.ncbiGeneLocus as sourceGap, a.ncbiGeneSymbol as sourceSymbol, a.ncbiGeneId as sourceGeneId ',
          parameters : { term: searchterm  }
        });
    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {
        resultdata["arrayAllNodes"] = arrayAllNodes;
        res.json(resultdata);
    });

};

exports.getGraph = function(req, res) {
    var searchterm = req.body.id;
  searchterm = '(?i).*'+searchterm+'.*';
  var dbconnectString = 'http://'+ req.app.get('config').db.username + ':' + req.app.get('config').db.password + '@' + req.app.get('config').db.host + ':' + req.app.get('config').db.port;

  var cypher = require('cypher-stream')(dbconnectString);
      var resultdata={};
      var arrayGraph=[];
      var transaction = cypher.transaction()
            .on('data', function (result) {
                if(result["source"] != null){
                    item = {};
                    item ["target"] = result["target"];
                    item ["source"] = result["source"];
                    arrayGraph.push(item);

                }
        });
    //Getting Event Information
    transaction.write({
      statement : 'MATCH (g1:TbRAT)-[]-(g2) where g1.ncbiGeneLocus =~ {term} or g1.ncbiGeneDescription =~ {term} RETURN g1 as target, g2 as source',
      parameters : { term: searchterm }
    });
    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {
        resultdata["arrayGraph"] = arrayGraph;
        res.json(resultdata);
    });

};

exports.getEvents = function(req, res) {
  var dbconnectString = 'http://'+ req.app.get('config').db.username + ':' + req.app.get('config').db.password + '@' + req.app.get('config').db.host + ':' + req.app.get('config').db.port;

  var cypher = require('cypher-stream')(dbconnectString);
      var resultdata={};
      var arrayEvent=[];
      var monthNames = ["","January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"];
      var weekDays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      var transaction = cypher.transaction()
            .on('data', function (result) {
                if(result["eventtitle"] != null){
                    item = {};
                    item ["eventtitle"] = result["eventtitle"];
                    item ["eventenddate"] = result["eventenddate"];
                    item ["eventstartdate"] = result["eventstartdate"];
                    var startdate = new Date (result["eventstartdate"]);
                    // EVENT DATE = EVENT START DATE
                    item ["eventmonth"] = monthNames[parseInt(result["eventstartdate"].substring(result["eventstartdate"].indexOf("/") + 1).trim().substring(0,2))]; //getting the MONTH from the start date
                    item ["eventday"] = result["eventstartdate"].substring(result["eventstartdate"].lastIndexOf("/") + 1).trim().substring(0,2);// getting the NUMBER DAY from the start date
                    item ["eventweekday"] = weekDays[startdate.getDay()];// getting the WEEK DAY from the date
                    item ["eventyear"] = result["eventstartdate"].substring(0, result["eventstartdate"].indexOf("/")); //getting the YEAR from the start date
                    item ["eventlocation"] = result["eventlocation"];
                    item ["eventtype"] = result["eventtype"];
                    item ["eventurl"] = result["eventurl"];
                    arrayEvent.push(item);
                }
        });
    //Getting Event Information
    transaction.write('MATCH (n:Events) where n.title =~ "(?i).*Tuberculosis.*" RETURN n.endDate as eventenddate, n.title as eventtitle, n.location as eventlocation, n.type as eventtype, n.startDate as eventstartdate, n.url as eventurl');
    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {
        resultdata["arrayEvent"] = arrayEvent;
        res.json(resultdata);
    });

};// end getEvents

exports.getPub = function(req, res) {

  var dbconnectString = 'http://'+ req.app.get('config').db.username + ':' + req.app.get('config').db.password + '@' + req.app.get('config').db.host + ':' + req.app.get('config').db.port;

var cypher = require('cypher-stream')(dbconnectString);
  var resultdata={};
  var arrayPub=[];

  var transaction = cypher.transaction()
        .on('data', function (result) {
            if(result["pubtitle"] != null){
                item = {};
                item ["pubtitle"] = result["pubtitle"];
                item ["pubdate"] = result["pubdate"].substring(0,4);
                item ["pubjournal"] = result["pubjournal"];
                item ["pubmedID"] = result["pubmedID"];
                arrayPub.push(item);
            }
    });
    //Getting Publication Information
    transaction.write('MATCH (n:Publication) where n.title =~ "(?i).*Tuberculosis.*"  RETURN n.journal as pubjournal, n.pm_date as pubdate, n.title as pubtitle, n.pmid as pubmedID ORDER BY n.pm_timestamp DESC');
    transaction.commit();
    transaction.on('error', function(error) {
        console.log(error);
    });
    transaction.on('end', function() {
        resultdata["arrayPub"] = arrayPub;
        res.json(resultdata);
    });

};// end of getPub

exports.getApps = function(req, res) {

    var dbconnectString = 'http://'+ req.app.get('config').db.username + ':' + req.app.get('config').db.password + '@' + req.app.get('config').db.host + ':' + req.app.get('config').db.port;

    var cypher = require('cypher-stream')(dbconnectString);
    var resultdata={};
    var arrayApps=[];

    var transaction = cypher.transaction()
          .on('data', function (result) {
              // Related Application
            if (result["appname"] != null) {
                var item = {};
                item["appname"] = result["appname"];
                item["appdesc"] = result["appdesc"];
                item["appurl"] = result["appurl"];
                  arrayApps.push(item);
              }
      });
      //Getting Application Information
      transaction.write('MATCH (n:Applications) where n.keywords =~ "(?i).*tuberculosis.*" AND n.appName <> "TBRNAT" RETURN n.appName as appname, n.appShortdescription as appdesc, n.appUrl as appurl');
      transaction.commit();
      transaction.on('error', function(error) {
          console.log(error);
      });
      transaction.on('end', function() {
          resultdata["arrayApps"] = arrayApps;
          res.json(resultdata);
      });

  };// end of getApps


