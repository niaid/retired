(function(angular) {
    "use strict";

    angular.module("tbrat", ['ui.bootstrap', 'ngTouch', 'ui.grid', 'ui.grid.pinning', 'ui.grid.exporter', 'ui.grid.selection', 'ui.grid.pagination','ngtweet'])

    .controller('mainController', mainController)
        .component("headerStyle", {
            templateUrl: "view/header.html"
        })
        .component("bodyInfo", {
            templateUrl: "view/bodyinfo.html",
            controller: mainController,
            controllerAs: 'mc'
        })
        .component("footerStyle", {
            templateUrl: "view/footer.html"
        })
        .component("modalTbrat", {
            templateUrl: "view/modaltbrat.html"
        })
        .component("rightColumn", {
            templateUrl: "view/rightcolumn.html",
            controller: mainController,
            controllerAs: 'mc'
        })



    function mainController($scope, $http, $log, $q, $window, $sce) {

        $scope.isCollapsed = true; // TO COLLAPSE CONTENT

        //-------- UPDATE THE WINDOW SIZE TO UPDATE THE GRAPH ------//
        angular.element($window).on('resize', function() {
            $scope.$apply();
        }); //-------- / END OF UPDATE THE WINDOW SIZE ----------------//

        $scope.gridOptions = {
            paginationPageSizes: [25, 50, 75],
            paginationPageSize: 25,
            showGridFooter: true,
            enableGridMenu: true,
            enableSelectAll: true,
            exporterCsvFilename: 'TbRNAT.csv',
            exporterPdfDefaultStyle: { fontSize: 7 },
            exporterPdfTableStyle: { margin: [0, 30, 0, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 7, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: { text: "Tuberculosis Regulatory Network Analysis Tool (TBRNAT)", style: 'headerStyle' },
            exporterPdfFooter: function(currentPage, pageCount) {
                return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function(docDefinition) {
                docDefinition.styles.headerStyle = { margin: [40, 10, 40, 0], fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            onRegisterApi: function(gridApi) {
                $scope.gridApi = gridApi;
            }
        };  // END OF $scope.gridOptions

        //get all the info according with the name $http.get('/api/getAllNodes', Indata)
        $scope.findAll = function() {

        if ($scope.tbname != '' ){
            var Indata = { id: $scope.tbname };

            $scope.gridOptions.columnDefs = [
                { name: 'target', width: 130, pinnedLeft: true, headerTooltip: 'H37Rv genes whose expressions are regulated' },
                { name: 'source', width: 130, pinnedLeft: true, headerTooltip: 'H37Rv genes regulating expression directly or indirectly' },
                { name: 'targetName', width: 130, headerTooltip: 'Name of target gene' },
                { name: 'sourceName', width: 130, headerTooltip: 'Name of source gene' },
                { name: 'targetGeneId', cellTooltip: 'Custom string', displayName: 'Target Gene Id', width: 150, headerTooltip: 'Target Gene Ids',cellTemplate:'<a ng-href="https://www.ncbi.nlm.nih.gov/gene/{{COL_FIELD}}" target="_blank" aria-label="targetGeneId"> {{COL_FIELD}} </a>' },
                { name: 'sourceGeneId', displayName: 'Source Gene Id', width: 150, headerTooltip: 'Source Gene Ids',cellTemplate:'<a ng-href="https://www.ncbi.nlm.nih.gov/gene/{{COL_FIELD}}" target="_blank" aria-label="sourceGeneId"> {{COL_FIELD}} </a>' },
                { name: 'pubmedId', displayName: 'PubMed Id', width: 150, headerTooltip: 'PubMed Ids',cellTemplate:'<a ng-href="https://www.ncbi.nlm.nih.gov/pubmed/{{COL_FIELD}}" target="_blank" aria-label="PubmedID"> {{COL_FIELD}} </a>' },
                { name: 'totalAssociations', width: 180, headerTooltip: 'Number of publications reporting a source-target association' },
                { name: 'targetGap', displayName: 'Target: GAP', width: 130, headerTooltip: 'Go to GAP', cellTemplate:'<a ng-href="https://gap.tbportals.niaid.nih.gov/VariantSearch?term={{COL_FIELD}}" target="_blank" aria-label="target"> {{COL_FIELD}} </a>' },
                { name: 'sourceGap', displayName: 'Source: GAP', width: 130, headerTooltip: 'Go to GAP', cellTemplate:'<a ng-href="https://gap.tbportals.niaid.nih.gov/VariantSearch?term={{COL_FIELD}}" target="_blank" aria-label="target"> {{COL_FIELD}} </a>' },
            ];

            $http.post('api/getAllNodes', Indata)
                .success(function(data) {
                    if(data.arrayAllNodes != ''){
                    $scope.gridOptions.data = data.arrayAllNodes;
                    // $log.info('GridOption', $scope.gridOptions.data);
                    }else{
                        window.alert("Enter a new value, Please!")
                    }
                })
                .error(function(data) {
                    window.console.log('Error: ' + data);
                });//------ / END OF getAllNodes for the table----//

            //get all the info according with the name

            $http.post('api/getGraph', Indata)
                .success(function(data) {
                    $scope.iframeID = data.arrayGraph; //Pass the data to the front end using the variable genes.
                    var geneId = [$scope.tbname];
                    // $log.info('GENE ID:',geneId );
                    if( geneId != "" ){
                    var command = "match (g1:TbRNAT)-[r:TBREGNET]-(g2:TbRNAT) where g1.ncbiGeneLocus =~'(?i).*Rv0006.*' OR g1.ncbiGeneDescription =~'(?i).*Rv0006.*' OR g1.ncbiGeneSymbol =~'(?i).*Rv0006.*' return *"
                    command = command.replace(/Rv0006/g, geneId);
                    //$log.info('cypher', command);
                    var iframeElem = document.getElementById("iframeID");
                    iframeElem.contentWindow.postMessage({type:"api",command:command}, "*");
                    }else{
                        window.alert("Gene ORF ID not found!")
                    }
                    //this will not allow the window to scroll down or up when the users are inside the iframe working
                    let graphXRIframe = document.getElementById("iframeID");

                                graphXRIframe.addEventListener('mouseover', function () {

                                    window.document.body.style.overflow = 'hidden';

                                    graphXRIframe.style.overflow = 'auto';

                                });



                                graphXRIframe.addEventListener('mouseout', function () {

                                    window.document.body.style.overflow = 'auto';

                                    graphXRIframe.style.overflow = 'hidden';

                                })

                })
                .error(function(data) {
                    window.console.log('Error: ' + data);
                });//------ / END OF getGraph ----//

            }else{
                window.alert("Gene ORF ID not found")
            }
        }; //---- / END OF findAll() -----//

        $http.post('api/getEvents')
            .success(function(data) {
                $scope.event = data.arrayEvent; //Pass the data to the front end using the variable genes.

            })
            .error(function(data) {
                window.console.log('Error: ' + data);
            }); //------ / END OF getEvents ----//

        $http.post('api/getPub')
            .success(function(data) {
                $scope.pub = data.arrayPub; //Pass the data to the front end using the variable genes.
                // $log.info('PUB DATA:', data.arrayPub);

            })
            .error(function(data) {
                window.console.log('Error: ' + data);
            }); //------ / END OF getPub ----//

        $http.post('api/getApps')
            .success(function(data) {
                $scope.apps = data.arrayApps; //Pass the data to the front end using the variable genes.
                // $log.info('APP DATA:', data.arrayApps);

            })
            .error(function(data) {
                window.console.log('Error: ' + data);
            }); //------ / END OF getApps ----//


        $scope.load = function() {
            // this function is to capture the gene id coming from TB Gap application and displaying the graph and table of that specific gene
            const queryString = window.location.search;
            //For example: queryString = ?term=Rv0006
            const urlParams = new URLSearchParams(queryString);
            //urlParams = term=Rv0006
            const term = urlParams.get('term');
            //term = Rv0006
            if (urlParams.has('term')){
                //if the term exist add it to tbname and passed to the findAll function
                $scope.tbname = term;
                // Wait 10 seconds before run findAll
                setTimeout(()=>$scope.findAll(), 10000);

            }// end of the IF
        };//End of the load function

    } //---- / END OF mainController -----//



})(window.angular);
