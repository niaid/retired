<?php


#Author - Vijay Nagarajan
#Parse old tbrat relations data

#some column data missing, have this to suppress notice about missing objects
error_reporting(E_ALL & ~E_NOTICE);
set_time_limit(0);
ini_set("memory_limit","100000M");
error_reporting(E_ALL & ~E_NOTICE);


#load the xml file as simplexml object
$relations = file('tbrat-old.txt');

foreach($relations as $relation)
	{ 
	
	$data = explode(",",$relation);
	echo $data[0],"\t",$data[1],"\t",$data[2],"\t",$data[7],"\t",$data[4],"\t",$data[6],"\t",$data[5],"\t",$data[11],"\t",$data[8],"\t";
	
	$pmidarray = [];
	
	if($data[3]==1)
		{
		$pmidarray[] = "23823726";
		}
	if($data[9]==1)
		{
		$pmidarray[] = "21818301";
		}
	if($data[10]==1)
		{
		$pmidarray[] = "18985025";
		}
	if($data[12]==1)
		{
		$pmidarray[] = "22808930";
		}
	#print_r($pmidarray);
	$totalpmids =  count($pmidarray);
	
	for($i=0; $i<$totalpmids; $i++)
		{
		echo $pmidarray[$i];
		if($totalpmids==2 && $i<1)
			{
			echo ",";
			}
		if($totalpmids==3 && $i<2)
			{
			echo ",";
			}
		if($totalpmids==4 && $i<3)
			{
			echo ",";
			}
		}
	echo "\n";
	}
?>
