<?php

#Author - Vijay Nagarajan
#Parse NCBI Gene XML file
#Load xml file using simplexml - works in php 5

#some column data missing, have this to suppress notice about missing objects
error_reporting(E_ALL & ~E_NOTICE);

#load the xml file as simplexml object
#the location for this xml file is: BCBB_Share/BIPGraphDatabase/graph2/tbrat
#this xml file does not fit in the GitHub due to its size
$genes = simplexml_load_file('h37rv.xml');

#echo $genes->Entrezgene->{'Entrezgene_track-info'}->{'Gene-track'}->{'Gene-track_geneid'};

foreach($genes->children() as $gene) {
#if the entry is discontinued, skip that gene
	if($gene->{'Entrezgene_track-info'}->{'Gene-track'}->{'Gene-track_status'}['value']!="discontinued")
		{
		echo $gene->{'Entrezgene_track-info'}->{'Gene-track'}->{'Gene-track_geneid'},"\t";
		echo $gene->{'Entrezgene_gene'}->{'Gene-ref'}->{'Gene-ref_locus'},"\t";
		echo $gene->{'Entrezgene_gene'}->{'Gene-ref'}->{'Gene-ref_locus-tag'},"\t";
		echo $gene->{'Entrezgene_prot'}->{'Prot-ref'}->{'Prot-ref_name'}->{'Prot-ref_name_E'};
		echo "\n";
		}
	}
	
#print an attribute -traversing the tree, using xpath
#Entrezgene[1] - gets the firts element //-gets element anywhere under Entrezgene[1]

#$ids = $genes->xpath('/Entrezgene-Set/Entrezgene//Gene-track_geneid|/Entrezgene-Set/Entrezgene//Gene-ref_locus-tag');

#selects all child elements of first Entrezgene[1]
#$ids2 = $genes->xpath('/Entrezgene-Set/Entrezgene[1]/*');
#var_dump($ids);
#	foreach($ids as $id) {
#		#var_dump($ids);
#		echo "$id\t"; }
    

?>
