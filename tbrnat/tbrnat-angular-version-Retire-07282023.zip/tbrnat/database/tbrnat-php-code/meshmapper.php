<?php

#Author - Vijay Nagarajan PhD
#Parse TBRAT data and prepare mapping terms based on NIAID/BCBB/BIP graph model

#some column data missing, have this to suppress notice about missing objects
error_reporting(E_ALL & ~E_NOTICE);
set_time_limit(0);
ini_set("memory_limit","100000M");
error_reporting(E_ALL & ~E_NOTICE);


#load the annotation data
$allgenes = file('h37rv4column.txt');
#load the MRCONSO.RRF.ENG.MSH.aa file
$mrconso = file('MRCONSO.RRF.ENG.MSH.aa');
#var_dump($allgenes);
#open file to write the results
$locustocui = fopen("locustocui.txt","w");


#read each gene entry
foreach($allgenes as $gene)
	{ 
	#open a temp file to write the metamap query text - genename and description
	$tempfile = fopen("temp", "w");
	$genedata = explode("\t",$gene);
	$geneid = $genedata[0];	
	#echo $genedata[0],"\t";

	#store only gene name and description
	$formapping=$genedata[1]." ".$genedata[3];
	echo $formapping,"\n";
	
	#write the input string for metamap to file
	fwrite($tempfile,$formapping);

	#execute metamap with -z term phrase, -N fielded mmi output	 --silent turns off header --nomap blocks certain cuis
	exec('metamap -z -N -R MSH --silent --nomap nomaplist.txt temp');

	#get the metamap output file content as array
	$mapping = file('temp.out');
	var_dump($mapping);

	#extract the highest score, first one
	$firstscore = explode("|",$mapping[0]);
	$firstcuiscore = $firstscore[2];

	#read each concept, compare its score with first score, write if the score is same or higher
	foreach($mapping as $mappedcui)
		{
		#echo $mappedcui;
		$mappedcuilist = explode("|",$mappedcui);
		if($mappedcuilist[2] >= $firstcuiscore)
			{
			#echo $mappedcuilist[2],$mappedcuilist[4];
			echo $cuiandscore,"\n";
			echo $mappedcuilist[4],"\n";

			#mapping msh to umls ids
			$mshtoumlsall = preg_grep("/$mappedcuilist[4]/",$mrconso);
			$mshtoumlsall = array_values($mshtoumlsall);
			var_dump($mshtoumlsall);
	
			
			$umlsentries = explode("|",$mshtoumlsall[0]);
			var_dump($umlsentries);
			echo $umlsentries[9],"\t",$umlsentries[10],"/n";

#Column headers 1-NCBI GeneID, 2-MetaMap Mapping MMI Score, 3-MESH Concept ID, 4-MESH Descriptor ID, 5-UMLS Concept ID, 6-MESH Descriptor Name, 7-NCBI Gene Description and Gene Name

#			$cuiandscore = $geneid."\t".$mappedcuilist[2]."\t".$umlsentries[9]."\t".$umlsentries[10]."\t".$mappedcuilist[4]."\t".$mappedcuilist[3]."\t".$formapping;

			$cuiandscore = $geneid."\t".$mappedcuilist[2]."\t".$umlsentries[9]."\t".$umlsentries[10]."\t".$mappedcuilist[4]."\t".$umlsentries[14]."\t".$formapping;


			fwrite($locustocui,$cuiandscore);
			}
		#var_dump($mappedcuilist);
		}

	fclose($tempfile);

	}
	fclose($locustocui);
?>
