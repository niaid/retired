1-In the folder call "tbrnat-model" you will find a picture of how
should the model looks like in Neo4j and the old and new model for
tbrat. 
2-In the folder call "tbrnat-node" you will find a .txt file to
create the nodes for tbrnat in Neo4j. 
3-In the folder call "tbrnat-php-code" you will find 3 php code to parse
tbrat data and mapping(meshmapper.php), to Parse NCBI Gene XML
file(nodels.php) and to Parse old tbrat relations data (relationship.php)
4-In the folder call "tbrnat-queries" you will find a .txt file with 
the queries to import all the data to Neo4j. 
5-In the folder call "tbrnat-relationship" you
will find a .txt file to create the relationship between the nodes.