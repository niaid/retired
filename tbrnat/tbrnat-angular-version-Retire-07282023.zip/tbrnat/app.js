// Adding required modules
// Set Up ==========================================

"use strict";

var express = require('express');
var bodyParser = require("body-parser");
var app = express();
var api = require('./routes/api');
var config = require('./config');
var path = require('path');
const helmet = require('helmet');


//---debug--------//
if (config.debug) {
  app.use(function(req, res, next) {
    console.log('(%s)[%s] %s', req.ip, req.method, req.path);
    next();
  });
}

// Sets "Strict-Transport-Security: max-age=31536001; includeSubDomains, preload: true".
const sixtyDaysInSeconds = 31536001
app.use(helmet.hsts({
  maxAge: sixtyDaysInSeconds,
  preload: true
}));

// Configuration ====================================
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/public'));
app.set('config', config);


// Adding routes ====================================
//app.use('/', routes); if I use this it will create a loop with the routes and not going anywhere
//
app.use(config.app.wwwroot, express.static(path.resolve('angular')));//go to angular folder and look for index.html and run the angular app.
//
//JSON API

app.post(config.app.wwwroot + 'api/getAllNodes', api.getAllNodes);
app.post(config.app.wwwroot + 'api/getGraph', api.getGraph);
app.post(config.app.wwwroot + 'api/getEvents', api.getEvents);
app.post(config.app.wwwroot + 'api/getPub', api.getPub);
app.post(config.app.wwwroot + 'api/getApps', api.getApps);
app.post(config.app.wwwroot + 'api/getTweets', api.getTweets);

app.get('*', function(req, res) {
 res.status(404).send('Bad Route');
});

// listen (start app with node.js using port 3000)===================
var server = app.listen(config.app.port, function() {
  console.log('Listening on port '+ config.app.port);
});

// error handlers ====================================

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
