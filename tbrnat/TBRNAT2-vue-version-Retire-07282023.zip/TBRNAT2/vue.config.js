module.exports = {
    // if the application is in production the public path will be <root>/tbrnat/
    // if not the public path will be the root '/'
    publicPath: process.env.NODE_ENV === 'production'
    ? '/tbrnat/'
    : '/'
}