<template>
  <div class="home container-fluid" :class="{ hidden: $route.path !== '/' }">
    <div class="row">
      <div class="col-xl-9">
        <SearchGene class="bodyinfo" />
      </div>

      <div class="col-xl-3">
        <RightColumn />
      </div>
    </div>
    <!-- end row-->
  </div>
</template>

<script>
import SearchGene from "@/components/SearchGene.vue";
import RightColumn from "@/components/RightColumn.vue";

export default {
  name: "Home",
  components: {
    SearchGene,
    RightColumn,
  },
};
</script>
<style scoped>
.bodyinfo {
  background-color: #ffffff;
  margin-bottom: 20px;
  padding: 10px;
}
.row {
  margin-left: 0px;
}
</style>
