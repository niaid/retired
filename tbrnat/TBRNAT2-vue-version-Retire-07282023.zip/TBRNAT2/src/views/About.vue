<template>
  <div class="about container" :class="{ hidden: $route.path !== '/about' }">
    <h3 align="left">
      What is the TB<i><b style="color: #20558a">RNAT</b></i
      >?
    </h3>

    <p class="bodytext" align="left">
      <b>TB<i style="color: #20558a">RNAT</i></b> presents all known
      <i>M. tuberculosis</i> transcriptional factors that regulate the
      expression of a gene of interest as an interactive regulatory network
      along with additional data in tabular form.
    </p>

    <hr />

    <h3 align="left">
      Why did we develop TB<i style="color: #20558a">RNAT</i>?
    </h3>
    <p class="bodytext" align="left">
      TB<i style="color: #20558a">RNAT</i> was developed to amalgamate
      information from peer-reviewed publications related to the regulation of
      <i>M. tuberculosis</i> transcription factors on gene expression and
      provide users with an intuitive way to visualize this data.
    </p>
    <hr />
    <h3 align="left">What is a transcription factor?</h3>
    <p class="bodytext" align="left">
      A transcription factor is a sequence-specific, DNA-binding protein that
      controls the rate of transcription of genetic information from DNA to RNA.
    </p>
    <hr />
    <h3 align="left">
      How many entries are in TB<i style="color: #20558a">RNAT</i>?
    </h3>
    <p class="bodytext" align="left">
      Currently, our database contains: Over 61000 entries.
    </p>
    <hr />
    <h3 align="left">
      Who develops and maintains TB<i style="color: #20558a">RNAT</i>?
    </h3>
    <p class="bodytext" align="left">
      TB<i style="color: #20558a">RNAT</i> was developed and is maintained by
      the Bioinformatics and Computational Bioscience Branch (BCBB) at the
      National Institute of Allergy and Infectious Diseases (NIAID) at the
      National Institutes of Health (NIH), Bethesda, MD.
    </p>
    <hr />
    <h3 align="left">Where does the data originate?</h3>
    <p class="bodytext" align="left">
      The data contained within the TB<i style="color: #20558a">RNAT</i>
      databases was obtained by manual curation of peer-reviewed articles in the
      scientific literature.
    </p>
    <hr />
    <h3 align="left">How do I cite TB<i style="color: #20558a">RNAT</i>?</h3>
    <p class="bodytext" align="left">
      TB<i style="color: #20558a">RNAT</i> is a product of the Bioinformatics
      and Computational Bioscience Branch (BCBB) at the National Institute of
      Allergy and Infectious Diseases (NIAID), Bethesda, MD.
    </p>
    <hr />
    <h3 align="left">Questions or comments?</h3>
    <p class="bodytext" align="left">
      If you would like more information about TB<i style="color: #20558a"
        >RNAT</i
      >
      or if you have questions or comments, please contact us at
      <b>tbrnat@niaid.nih.gov</b>
    </p>
    <br />
    <a class="event-link" href="#" role="button"
      ><p class="bodytext" align="left">Back to top</p></a
    >
  </div>
</template>

<script>
export default {
  name: "About",
};
</script>

<style scoped>
.bodytext {
  margin-bottom: 20px;
  font-size: 19px;
  font-weight: 300;
  line-height: 1.4;
}
.event-link:hover,
.event-link:focus {
  text-decoration: none;
  background-color: transparent;
}
</style>
