<template>
  <div id="app">
    <Header />
    <div id="nav">
      <router-link class="btn-contactus" to="/">
        <b>HOME</b>
      </router-link>
      <router-link class="btn-contactus" to="/about">
        <b>ABOUT TB<i>RNAT</i></b>
      </router-link>
    </div>
    <router-view />
    <router-view name="home" />
    <Footer />
  </div>
</template>

<script>
import Header from "./components/partial/Header";
import Footer from "./components/partial/Footer";

export default {
  name: "app",
  components: {
    Header,
    Footer,
  },
};
</script>

<style>
/* Buefy */
@import "https://cdn.jsdelivr.net/npm/@mdi/font@5.8.55/css/materialdesignicons.min.css";
@import "https://use.fontawesome.com/releases/v5.2.0/css/all.css";
.pagination-list {
  margin-bottom: 0 !important;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  background-color: #f1f1f1;
}
.bodytext {
  margin-left: 5px;
}
.btn-contactus {
  border-radius: 26px;
  border-color: #20558a;
  color: #20558a;
  margin-left: 20px;
  padding: 5px 20px 5px 20px;
}
.btn-contactus:hover,
.btn-contactus:active,
.btn-contactus.active {
  background-color: #20558a;
  color: #fff;
  text-decoration: none;
}
#nav {
  padding: 10px;
}
.hidden{
    display: none !important;
}
</style>
