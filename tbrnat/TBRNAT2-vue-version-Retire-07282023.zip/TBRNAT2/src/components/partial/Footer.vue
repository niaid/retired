<template>
    <!-- Site footer -->
    <footer class="main-niaid-footer">
        <div class="container alingment-center-footer">
        <!-- Three columns  -->
      <div class="row">
        <div class="col-sm-4 col-md-4 col-lg-4">
          <h6 class="footer-links-heading">connect</h6>

          <!-- Column One Media lINKS -->
          <ul class="list-group list-group-horizontal list-unstyled  footer-links">
            <li class="flex-fill"><a class="footer-links" href="https://www.facebook.com/niaid.nih" target="_blank" aria-label="Facebook" rel="noopener noreferrer"><i class="fa fa-facebook fa-lg"></i></a></li>
            <li class="flex-fill"><a class="footer-links" href="https://twitter.com/NIAIDBioIT" target="_blank" aria-label="Twitter" rel="noopener noreferrer"><i class="fa fa-twitter fa-lg"></i></a></li>
            <li class="flex-fill"><a class="footer-links" href="https://www.youtube.com/channel/UC4xRg9e4mrYBZQUDUhBHNiQ" target="_blank" aria-label="Youtube" rel="noopener noreferrer"><i class="fa fa-youtube-play fa-lg"></i></a></li>
            <li class="flex-fill"><a class="footer-links" href="https://www.linkedin.com/company/national-institute-of-allergy-and-infectious-diseases-niaid" target="_blank" aria-label="Linkedin" rel="noopener noreferrer"><i class="fa fa-linkedin fa-lg"></i></a></li>
            <li class="flex-fill"><a class="footer-links" href="https://www.pinterest.com/niaid/" target="_blank" aria-label="Pinterest" rel="noopener noreferrer"><i class="fa fa-pinterest-p fa-lg"></i></a></li>
          </ul><!-- Column One Media lINKS -->

          <ul class="list-unstyled footer-links">
            <li><a class="footer-links" href="/about">About TBRNAT</a></li>
          </ul>

        </div><!-- /.col-sm-4 col-md-4 col-lg-4 -->

        <hr class="footer-columns-separator visible-xs">

        <div class="col-sm-4 col-md-4 col-lg-4">
          <h6 class="footer-links-heading">links</h6>

          <ul class="list-unstyled footer-links">

            <li><a class="footer-links" href="https://bioinformatics.niaid.nih.gov"  target="_blank" rel="noopener noreferrer"> bioinformatics @NIAID</a></li><!-- another way to redirect to portal onclick="location.href= '/'; return false;"-->

            <li><a class="footer-links" href="https://www.niaid.nih.gov" target="_blank" rel="noopener noreferrer">NIAID Website</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/global/contact-us" target="_blank" rel="noopener noreferrer">Contact NIAID</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/global/website-help" target="_blank" rel="noopener noreferrer">Help</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/global/web-accessibility" target="_blank" rel="noopener noreferrer">Accessibility</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/privacy" target="_blank" rel="noopener noreferrer">Privacy Policy</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/global/disclaimers" target="_blank" rel="noopener noreferrer">Disclaimer</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/global/website-policies-and-notices" target="_blank" rel="noopener noreferrer">Website Links &amp; Policies</a></li>

            <li><a class="footer-links" href="https://www.niaid.nih.gov/global/freedom-information-act" target="_blank" rel="noopener noreferrer">FOIA</a></li>
          </ul>
        </div><!-- /.col-sm-4 col-md-4 col-lg-4 -->

        <hr class="footer-columns-separator visible-xs">


        <div class="col-sm-4 col-md-4 col-lg-4">
          <h6 class="footer-links-heading">related government sites</h6>

          <ul class="list-unstyled footer-links">
            <li><a class="footer-links" href="http://www.nih.gov" target="_blank">National Institutes of Health</a></li>
            <li><a class="footer-links" href="http://www.hhs.gov" target="_blank">U.S. Department of Health &amp; Human Services</a></li>
            <li><a class="footer-links" href="https://www.usa.gov" target="_blank">USA.gov</a></li>
          </ul>
        </div><!-- /.col-sm-4 col-md-4 col-lg-4 -->
      </div><!-- /.row -->

      <hr class="footer-col-hr">


      <div class="row">
        <div class="col-sm-4 col-md-4 col-lg-4">
          <p class="footer-nih-tagline">National Institutes of Health. . .<br>Turning Discovery Into Health<sup>&reg;</sup></p>
        </div><!-- /.col-sm-4 col-md-4 col-lg-4 -->

        <hr class="footer-columns-separator visible-xs">

        <div class="col-sm-4 col-md-4 col-lg-4">
          <address class="footer-address">
        National Institutes of Health (NIH), 9000 Rockville Pike,<br>
        Bethesda, Maryland 20892
      </address>
        </div><!-- /.col-sm-4 col-md-4 col-lg-4 -->

        <hr class="footer-columns-separator visible-xs">

        <div class="col-sm-4 col-md-4 col-lg-4">
          <ul class="list-group list-group-horizontal list-unstyled">
            <li class="flex-fill"><a class="" href="https://www.usa.gov" target="_blank"><img class="img-responsive" src="../../../public/images/usagov-logo-topbar.png" width="100" height="30.4" alt="USA.gov"><!-- <img class="img-responsive img-usa-footer"  alt="USA logo"> --></a></li>

            <li class="flex-fill"><a class="" href="http://www.hhs.gov" target="_blank"><img class="img-responsive" src="../../../public/images/hhs-logo-topbar.png" width="30" height="36" alt="HHS.gov"><!-- <img class="img-responsive img-hhs-footer"  alt="HHS logo"> --></a></li>

            <li class="flex-fill"><a class="" href="http://www.nih.gov" target="_blank"><img class="img-responsive" src="../../../public/images/nih-logo-topbar.png" width="48" height="30" alt="NIH.gov"><!-- <img class="img-responsive img-nih-footer" alt="NIH logo"> --></a></li>

          </ul>
        </div><!-- /.col-sm-4 col-md-4 col-lg-4 -->
       </div>
       </div>
      </footer>

</template>

<script>
export default {
    name: "Footer"
}
</script>

<style scoped>
/* main niaid footer
------------------------- */
.main-niaid-footer {
	background-color: #20558A;/* fff */
	margin-top: 0px;
	padding-bottom: 100px;
	padding-top: 60px;
	padding-left: 0px;
	padding-right: 0px;
    text-align: center;
}

.footer-links-heading {
	font-weight: bold;
	text-transform: uppercase;
  color: #fff;/*151515*/
}

.footer-nih-tagline{
  font-size: 14px;
  color: #fff;/*151515*/
}

.footer-links {
	font-size: 14px;
	color: #fff;/*151515*/
	line-height: 2;
  opacity: 0.7;
}

.footer-links:hover,
.footer-links:focus {
	color: #fff;
	text-decoration: none;
  opacity: 1;
  font-size: 14px;
	/*background-color: transparent;*/
}

.footer-address {
	font-size: 14px;
	color: #fff;/*151515*/
}

.footer-columns-separator {
	border-top: 1px solid transparent;
	margin-top: 30px;
	margin-bottom: 30px;
}

.sidebar-column-separator {
	border-top: 1px solid #000;
	margin-top: 30px;
	margin-bottom: 30px;
}

.footer-col-hr {
  border-top: 1px dotted #fff;/*939393*/
}

img.img-hhs-footer{
  content: url(../../../public/images/hhs-logo-topbar.png);
  width: 30px;
  height: 36px;
}

img.img-nih-footer{
  content: url(../../../public/images/nih-logo-topbar.png);
  width: 48px;
  height: 30px;
}
img.img-usa-footer{
  content: url(../../../public/images/usagov-logo-topbar.png);
  width: 100px;
  height: 30.4px;
}

.iframe-1{
    border-style: solid;
    border-color: gray;
    border-width: 1px;

}
@media (max-width: 780px) {
  .alingment-center-footer {
   text-align: center;
  }

}
</style>