<template>
<div class="main-niaid-header">
<!-- Topbar with links to other government sites -->
<div class="d-none d-lg-block top-bar ">
    <ul class="list-inline mb-0">
        <li class="list-inline-item mr-4">
            <a class="btn btn-link d-none d-sm-none d-md-none d-lg-none d-xl-block" href="https://www.hhs.gov" target="_blank"><p style="color:white">U.S. Department of Health & Human Services</p></a>

             <button type="button" class="btn btn-link d-block d-sm-block d-md-block d-lg-block d-xl-none"><a href="https://www.hhs.gov" target="_blank"><img class="" src="../../../public/images/hhs-logo-topbar.png" width="24.947" height="25" alt="logo"><!-- <img class="img-hhs" alt="hhs-logo"> --></a></button>
        </li>
        <li class="list-inline-item mr-4">

             <a class="btn btn-link d-none d-sm-none d-md-none d-lg-none d-xl-block" href="https://www.nih.gov" target="_blank"><p style="color:white">National Institutes of Health</p></a>

             <button type="button" class="btn btn-link d-block d-sm-block d-md-block d-lg-block d-xl-none"><a href="https://www.nih.gov" target="_blank"><img class="" src="../../../public/images/nih-logo-topbar.png" width="33.947" height="25" alt="logo"><!-- <img class="img-nih" alt="nih-logo"> --></a></button>
        </li>

        <li class="list-inline-item mr-4">

             <a class="btn btn-link d-none d-sm-none d-md-none d-lg-none d-xl-block" href="https://www.niaid.nih.gov" target="_blank"><p style="color:white">National Institute of Allergy &amp; Infectious Diseases</p></a>

             <button type="button" class="btn btn-link d-block d-sm-block d-md-block d-lg-block d-xl-none"><a href="https://www.niaid.nih.gov" target="_blank"><img class="" src="../../../public/images/white_trans_back.png" width="24.947" height="25" alt="logo"><!-- <img class="img-niaid" alt="niaid-logo"> --></a></button>
        </li>

        <li class="list-inline-item mr-4">
             <a class="btn btn-link d-none d-sm-none d-md-none d-lg-none d-xl-block" href="https://bioinformatics.niaid.nih.gov" target="_blank"><p style="color:white"> bioinformatics @NIAID</p></a>

             <button type="button" class="btn btn-link d-block d-sm-block d-md-block d-lg-block d-xl-none"><a href="https://bioinformatics.niaid.nih.gov" target="_blank"><img class="" src="../../../public/images/white_bioinf_@_niaid.png" width="84.947" height="25" alt="logo"><!-- <img class="img-nbp" alt="nbp-logo"> another way to redirect to the portal onclick="location.href= '/'; return false;" --></a></button>
        </li>
    </ul>
</div>
    <nav class="navbar navbar-default mb-0">

        <div class="navbar-header">

          <a class="navbar-brand d-md-inline" :href="wwwroot"><img class="brand-logo" src="../../../public/images/white_trans_back.png" width="50" height="auto" alt="logo"><!-- <img class="img-brand-logo" alt="brand-logo"> --></a>
          <a class="navbar-brand" :href="wwwroot">
            <address>
              <span class="nephele-logotype">TB<i>RNAT</i></span><br>
              <span><small class="nephele-tagline"><b>Tuberculosis Regulatory Network Analysis Tool</b></small></span>
            </address>
          </a>
        </div>


    </nav>
    </div>
</template>

<script>
import * as config from "../../config.js";
export default {
    name: "Header",
    data() {
    return {
      wwwroot: config.app.wwwroot,
    };
    }
}
</script>
<style scoped>
/* Header and Navbar
------------------------- */
.main-niaid-header {
	background-color: #20558A;/* fff */
	margin-top: 0px;
	padding-left: 0px;
	padding-right: 0px;
}

.brand-logo{
    padding-bottom: 30px;
}

.top-bar {
/* background-color: #212463; */
border: 0;
border-bottom: 1px dotted #fff;

}

.top-bar .btn {
  font-size: 12px;
  letter-spacing: 1px;
  /*color: #323a45;*/
  padding-left: 20px;
  padding-right: 24px;
  padding-top: 6px;
  padding-bottom: 6px;
}

.top-bar .btn-link:hover,
.top-bar .btn-link:focus {
  /*color: #323a45;*/
  text-decoration: none;
  background-color: transparent;
  outline: 0;
  transition: all 0.2s;
}
.navbar {
  position: relative;
  min-height: auto;
  margin-bottom: 0px;
  border: none;
  /* border-bottom: 1px dotted #555; */
  border-radius: 0px;
  /*background-color: #151515; BLACK HEADER */
  background-color: #20558A ; /*005295 #2878C8 BLUE HEADER */
}
.nephele-logotype {
	/* font-size: 18px; */
	font-weight: bold;
	text-transform: uppercase;
	/* color: #ff0000;  RED HEADER */
   color: #ffffff;  /* WHITE NAME */

}

.nephele-tagline {
  font-size: 18px;
  color: #fff;
  opacity: 0.7;
}

.nbp-links {
  margin-top: 10px;
  /*padding-top: 10px;*/
  font-size: 14px;
  color: #ffffff;
  /*line-height: 2;*/
}

.nbp-links:hover,
.nbp-links:focus {
  color: #ffffff;
  text-decoration: none;
  background-color: transparent;
}

img.img-hhs{
  content: url(../../../public/images/hhs-logo-topbar.png);
  width: 24.947px;
  height: 25px;
}

img.img-nih{
  content: url(../../../public/images/nih-logo-topbar.png);
  width: 33.947px;
  height: 25px;
}
img.img-niaid{
  content: url(../../../public/images/white_trans_back.png);
  width: 24.947px;
  height: 25px;
}
img.img-nbp{
  content: url(../../../public/images/white_bioinf_@_niaid.png);
  width: 84.947px;
  height: 25px;
}
img.img-brand-logo{
  content: url(../../../public/images/white_trans_back.png);
  width: 59.694px;
  height: 50px;
}
/* RESPONSIVE CSS
-------------------------------------------------- */
@media (min-width: 768px) {

  .navbar-right {
    float: right!important;
    margin-right: -15px;
    padding-top: 29px;
   }

}

@media (max-width: 625px) {

  .navbar {
  position: relative;
  min-height: auto;
  margin-bottom: 0px;
  border: none;
  /* border-bottom: 1px dotted #555; */
  border-radius: 0px;
  /*background-color: #151515; BLACK HEADER */
  background-color: #005295 ; /* #2878C8 BLUE HEADER */
}
}

@media (max-width: 605px) {
  .nephele-logotype{
    font-size: 16px;
  }
  .nephele-tagline {
      font-size: 13px;

  }
  .brand-logo{
      height: auto;
      width: 30px;
  }
}
@media (max-width: 414px) {
  .nephele-logotype{
    font-size: 12px;
  }
  .nephele-tagline {
      font-size: 10px;

  }
  .brand-logo{
      height: auto;
      width: 40px;
  }
}
@media (max-width: 324px) {
  .brand-logo{
      height: auto;
      width: 30px;
  }
}
@media (max-width: 280px) {
    .nephele-logotype{
    font-size: 10px;
  }
  .nephele-tagline {
      font-size: 8px;

  }
  .brand-logo{
      height: auto;
      width: 35px;
  }
}
</style>
