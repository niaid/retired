<template>
  <div>
    <div v-if="pub">
      <div class="static-header">
        <h5>Related Publications</h5>
      </div>
      <!--  / static-header-->
      <div class="training-event-pub scrollbar-event-pub-training">
        <div class="rows" v-for="(pubs, index) in pub.slice().reverse()" v-bind:key="index">
          <p>
            <a
              class="event-link"
              :href="'https://www.ncbi.nlm.nih.gov/pubmed/' + pubs.pmid"
              target="blank"
              >{{ pubs.title }}</a
            >
          </p>
          <i>({{ pubs.pm_date.substring(0, 4) }}) {{ pubs.journal }}</i>
          <hr />
        </div>
        <!--  / listpub in pub-->
      </div>
      <!-- / training-event-pub scrollbar-event-pub-training -->
    </div>
    <br />
    <div v-if="app">
      <div class="static-header">
        <h5>Related Applications</h5>
      </div>
      <!--  / static-header -->
      <div class="training-event-pub scrollbar-event-pub-training">
        <div class="rows" v-for="(apps, index) in app.slice().reverse()" v-bind:key="index">
          <p>
            <a class="event-link" v-bind:href="apps.appUrl" target="blank">{{
              apps.appName
            }}</a>
          </p>
          <p>{{ apps.appShortdescription }}</p>
          <hr />
        </div>
        <!--  / listapps in apps -->
      </div>
      <!-- / training-event-pub scrollbar-event-pub-training -->
    </div>
    <!-- / Related Applications -->
    <br />
  </div>
</template>

<script>
import graphXR from "../../vendor/graphXR.injection";

export default {
  name: "RightColumn",
  methods: {
    fetchData() {
      let graphXRIframe = document.getElementById("iframeID");
      graphXR.injectionApiCommand('MATCH (n:Applications) where n.keywords =~ "(?i).*tuberculosis.*" AND n.appName <> "TBRNAT" RETURN n', graphXRIframe, {ignoreAppend: true}).then((result) => {
        this.app = [...result.content.nodes];

        graphXR.injectionApiCommand('MATCH (n:Publication) where n.title =~ "(?i).*Tuberculosis.*"  RETURN n ORDER BY n.pm_timestamp DESC', graphXRIframe, {ignoreAppend: true}).then((result) => {
          this.pub = [...result.content.nodes];
        });
      });
    },
  },
  data() {
    return {
      app: "",
      pub: "",
    };
  },
  mounted() {
    graphXR.injectionOn("load", (eventName, res) => {
      if (res === "init") {
        this.fetchData();
      }
    });
  },
};
</script>
<style scoped>
/* events and publications in the right side of the page */
.training-event-pub {
  background-color: #ffffff;
  /*border-radius: 5px 25px;*/
  padding-top: 10px;
  padding-left: 25px;
  padding-right: 25px;
  padding-bottom: 10px;
}
.scrollbar-event-pub-training {
  max-height: 550px;
  overflow-y: scroll;
}
.static-header {
  background-color: #ffffff;
  /*border-radius: 5px 25px;*/
  padding-top: 10px;
  padding-left: 25px;
  padding-right: 25px;
  padding-bottom: 10px;
  margin-bottom: 0px;
  border-bottom: 1px solid #f1f1f1;
}

.rows:hover,
.rows:focus {
  text-decoration: none;
  background-color: #fcf8e4;
}

.event-link:hover,
.event-link:focus {
  text-decoration: none;
  background-color: transparent;
}
</style>