<template>
  <div>
    <div class="geneform">
      <p class="">
        Enter a gene <b>ORF ID</b> below and click on the <b>node</b> to expand
        the relationship
      </p>
      <p>
        <strong><i>Example : Rv0006 or Rv0001 or Rv0028</i></strong>
      </p>

      <form id="search-form" role="search" v-on:submit.prevent="searchGene">
        <div class="input-group">
          <input
            id="input-text"
            v-model="geneId"
            type="text"
            class="form-control exon-searchbox textInput"
            aria-label="Search"
            placeholder="Search"
          />
          <div class="input-group-append">
            <button
              class="btn btn-outline-secondary"
              type="submit"
              aria-label="Search button"
            >
              <i class="fa fa-search fa-lg search-icon"></i>
            </button>
          </div>
        </div>
      </form>
    </div>
    <!-- /geneform  -->
    <hr />
    <div>
      <iframe
        class="iframe-1"
        id="iframeID"
        data="iframeID"
        :src="newiframe"
      >
      </iframe>
    </div>
    <!-- /iframe  -->
    <hr />
    <div>
      <b-table
        v-if="tableData.length > 0"
        striped
        hoverable
        :data="tableData"
        defaultSortDirection="asc"
        :paginated="true"
        pagination-position="both"
        per-page="25"
        sticky-header
        sort-icon="chevron-up"
        narrowed
      >
        <b-table-column field="target" label="Target" sortable v-slot="props">
          {{ props.row.target }}
        </b-table-column>
        <b-table-column field="source" label="Source" sortable v-slot="props">
          {{ props.row.source }}
        </b-table-column>
        <b-table-column
          field="targetName"
          label="Target Name"
          sortable
          v-slot="props"
          >{{ props.row.targetName }}</b-table-column
        >
        <b-table-column
          field="sourceName"
          label="Source Name"
          sortable
          v-slot="props"
          >{{ props.row.sourceName }}</b-table-column
        >
        <b-table-column
          field="targetGeneId"
          label="Target Gene Id"
          sortable
          v-slot="props"
        >
          <a
            :href="
              'https://www.ncbi.nlm.nih.gov/gene/' + props.row.targetGeneId
            "
            target="blank"
            >{{ props.row.targetGeneId }}</a
          >
        </b-table-column>
        <b-table-column
          field="sourceGeneId"
          label="Source Gene Id"
          sortable
          v-slot="props"
        >
          <a
            :href="
              'https://www.ncbi.nlm.nih.gov/gene/' + props.row.sourceGeneId
            "
            target="blank"
            >{{ props.row.sourceGeneId }}</a
          >
        </b-table-column>
        <b-table-column
          field="pubmedId"
          label="PubMed Ids"
          sortable
          v-slot="props"
        >
          <a
            :href="'https://www.ncbi.nlm.nih.gov/pubmed/' + props.row.pubmedId"
            target="blank"
            >{{ props.row.pubmedId }}</a
          >
        </b-table-column>
        <b-table-column
          field="totalAssociations"
          label="Total Associations"
          v-slot="props"
          sortable
          >{{ props.row.totalAssociations }}</b-table-column
        >
        <b-table-column
          field="targetGap"
          label="Target: G-AP"
          sortable
          v-slot="props"
        >
          <a
            :href="
              'https://gap.tbportals.niaid.nih.gov/VariantSearch?term=' +
              props.row.targetGap
            "
            target="blank"
            >{{ props.row.targetGap }}</a
          >
        </b-table-column>
        <b-table-column
          field="sourceGap"
          label="Source: G-AP"
          sortable
          v-slot="props"
        >
          <a
            :href="
              'https://gap.tbportals.niaid.nih.gov/VariantSearch?term=' +
              props.row.sourceGap
            "
            target="blank"
            >{{ props.row.sourceGap }}</a
          >
        </b-table-column>
        <template #bottom-left>
          <div class="buttons">
            <!-- <span class="number-of-rows">Rows: <b>{{tableData.length}}</b></span> -->
            <download-csv
              :data="tableData"
              :fields="Object.keys(columns)"
              :labels="columns"
            >
              <b-button type="is-link is-light">Download CSV</b-button>
            </download-csv>
            <b-button type="is-link is-light" v-on:click="downloadPdf()"
              >Download PDF</b-button
            >
          </div>
        </template>
        <template #top-left>
          <div class="buttons">
            <span class="number-of-rows"
              >Rows: <b>{{ tableData.length }}</b></span
            >
          </div>
        </template>
      </b-table>
    </div>

    <p>
      <b
        >If you have any question or comment
        <a
          class="event-link"
          href="mailto:scienceapps@niaid.nih@@gov"
          onmouseover="this.href=this.href.replace('@@','.')"
          onclick="this.href=this.href.replace('@@','.')"
          >contact us</a
        ></b
      >
    </p>
    <a class="event-link" href="#">
      <p class="bodytext" align="left">Back to top</p>
    </a>
  </div>
</template>

<script>
import graphXR from "../../vendor/graphXR.injection";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import * as config from "../config.js";
export default {
  name: "SearchGene",
  data() {
    return {
      geneId: "",
      nodes: [],
      tableData: [],
      newiframe: config.iframe.link,
      columns: {
        target: "Target",
        source: "Source",
        targetName: "Target Name",
        sourceName: "Source Name",
        targetGeneId: "Target Gene Id",
        sourceGeneId: "Source Gene Id",
        pubmedId: "PubMed Ids",
        totalAssociations: "Total Associations",
        targetGap: "Target G-AP",
        sourceGap: "Source G-AP",
      },
    };
  },
  methods: {
    downloadPdf() {
      const doc = new jsPDF({
        orientation: "landscape",
      });
      doc.autoTable({
        columns: Object.keys(this.columns).map((k) => {
          return { header: this.columns[k], dataKey: k };
        }),
        body: this.tableData,
      });
      doc.save("tbrnat.pdf");
    },
    graphXRToTBRNATListTable({ nodes, edges }) {
      let nodesIdMap = {
        // _GXRID:node
      };

      (nodes || []).forEach((node) => {
        nodesIdMap[node._GXRID] = node;
      });

      return (edges || []).map((edge) => {
        let sourceNode = nodesIdMap[edge.sourceId] || {};
        let targetNode = nodesIdMap[edge.targetId] || {};
        let item = {};
        item["_GXRID"] = edge["_GXRID"];

        item["target"] = targetNode["ncbiGeneLocus"];
        item["targetGap"] = targetNode["ncbiGeneLocus"];
        item["targetName"] = targetNode["ncbiGeneSymbol"];
        item["targetGeneId"] = targetNode["ncbiGeneId"];
        item["_GXRIDTarget"] = targetNode["_GXRID"];

        item["source"] = sourceNode["ncbiGeneLocus"];
        item["sourceGap"] = sourceNode["ncbiGeneLocus"];
        item["sourceName"] = sourceNode["ncbiGeneSymbol"];
        item["sourceGeneId"] = sourceNode["ncbiGeneId"];
        item["_GXRIDSource"] = sourceNode["_GXRID"];

        item["_GXRSelected"] =
          sourceNode["_GXRSelected"] && targetNode["_GXRSelected"];
        item["pubmedId"] = edge["pmid"];
        item["totalAssociations"] = edge["totalAssociations"];

        return item;
      });
    },
    searchGene() {
      console.log("Called searchGene");
      let graphXRIframe = document.getElementById("iframeID");
      if (this.geneId != "") {
        // let command = "match (g1:TbRNAT)-[r:TBREGNET]-(g2:TbRNAT) where g1.ncbiGeneLocus =~'(?i).*Rv0006.*' OR g1.ncbiGeneDescription =~'(?i).*Rv0006.*' OR g1.ncbiGeneSymbol =~'(?i).*Rv0006.*' return *"
        let command =
          "match (g1:TbRNAT) where g1.ncbiGeneLocus =~'(?i).*Rv0006.*' OR g1.ncbiGeneDescription =~'(?i).*Rv0006.*' OR g1.ncbiGeneSymbol =~'(?i).*Rv0006.*' return g1";
        command = command.replace(/Rv0006/g, this.geneId);
        console.log(`Executing ${command}!`);
        graphXR.injectionApiCommand(command, graphXRIframe).then((resData) => {
          if (resData.content.nodes == "") {
            window.alert("Gene ORF ID not found!");
          } else {
            console.log("Retrieved command response!");
            console.log(resData.content.nodes);
            this.nodes = resData.content.nodes;
          }
        });
      } else {
        window.alert("Gene ORF ID not found!");
      }

      //this will not allow the window to scroll down or up when the users are inside the iframe working
      graphXRIframe.addEventListener("mouseover", function () {
        window.document.body.style.overflow = "hidden";
        let html = document.getElementsByTagName('html')[0]
        html.style.overflow = 'hidden'
      });
      graphXRIframe.addEventListener("mouseout", function () {
        window.document.body.style.overflow = "auto";
        let html = document.getElementsByTagName('html')[0]
        html.style.overflow = 'auto'
      });
      console.log("subscribing to iframe changes", graphXRIframe);
    },
    load() {
      console.log("debug: registering load")
      let graphXRIframe = document.getElementById("iframeID");
      const self = this;
      graphXR.injectionOn("load", (eventName, res) => {
          console.log('debug: on load')
          if(res === 'init'){
              console.log("GraphXR iframe already load", res)
              graphXR.injectionOn("change", () => {
                  graphXR.injectionApiCommand(':getLayoutGraph', graphXRIframe)
                      .then((resData) => {
                        self.tableData = self.graphXRToTBRNATListTable(resData.content);
                        console.log("debug: tableData", this.tableData);
                      })
              }, graphXRIframe, "onChange");
          }else{
              console.log("GraphXR Load the view ", res)
          }
      }, graphXRIframe, "onLoad")

      // this function is to capture the gene id coming from TB Gap application and displaying the graph and table of that specific gene
      const queryString = window.location.search;
      //For example: queryString = ?term=Rv0006
      const urlParams = new URLSearchParams(queryString);
      //urlParams = term=Rv0006
      const term = urlParams.get("term");
      //term = Rv0006
      if (urlParams.has("term")) {
        //if the term exist add it to tbname and passed to the findAll function
        this.geneId = term;
        // Wait 10 seconds before run findAll
        setTimeout(() => this.searchGene(), 5000);
      } // end of the IF
    },
  },
  mounted() {
    this.load();
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
/* Body
------------------------- */
.geneform {
  font-size: 19px;
  text-align: center;
}

.textInput {
  height: 44px;
  font-size: 22px;
}

.buttonInput {
  height: 44px;
  font-size: 22px;
}
.iframe-1 {
  width: 100%;
  height: 644px;
  border: 1px solid rgb(0, 0, 0);
}
.b-table {
  margin-bottom: 1rem;
}
.buttons button {
  margin-right: 1rem;
}
.number-of-rows {
  margin-right: 1rem;
}
</style>
