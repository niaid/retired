import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import About from "../views/About.vue";
import { publicPath } from '../../vue.config';

Vue.use(VueRouter)

const routes = [
  {
    path: "/",
    name: "home",
    components: {
      home: Home,
      default: About,
    },
  },
  {
    path: "/about",
    name: "about",
    components: {
      home: Home,
      default: About,
    },
  },
];

const router = new VueRouter({
  mode: 'history',
  base: publicPath,
  linkExactActiveClass: "active",
  routes
})

export default router
