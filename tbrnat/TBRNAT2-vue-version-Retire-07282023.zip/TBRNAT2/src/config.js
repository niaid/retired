// config.js
// Configuration component that sets defaults or uses any configuration
// provided in configuration file or environment variables.

"use strict";

// base config object
var config = {};

// app settings
config.app = {};
// if the application is in production the public path will be <root>/tbrnat/
// if not the public path will be the root '/'
config.app.wwwroot = process.env.NODE_ENV === 'production'
? '/tbrnat/'
: '/';
config.app.port = process.env.CONFIG_APP_PORT;

// iframe
config.iframe = {};
config.iframe.link = process.env.CONFIG_IFRAME;

module.exports = config;