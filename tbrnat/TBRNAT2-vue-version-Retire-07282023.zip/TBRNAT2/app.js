
var path = require('path');
const express = require('express');
var config = require('./src/config');
const routeHistory = require('connect-history-api-fallback');// this is how VUE use the routes with Express.js
// var vueconfig = require('./vue.config')
// var healthcheck = require('./src/healthcheck');

// create server instance
const app = express();
// Single Page Applications (SPA) typically only utilise one index file that is accessible by web browsers: usually index.html.
// Navigation in the application is then commonly handled using JavaScript with the help of the HTML5 History API.
// This results in issues when the user hits the refresh button or is directly accessing a page other than the landing page,
// e.g. /help or /help/online as the web server bypasses the index file to locate the file at this location.
// As your application is a SPA, the web server will fail trying to retrieve the file and return a 404 - Not Found message to the user.
app.use(routeHistory());

// creating logs for debug //
app.use(function(req, res, next) {
  console.log('(%s)[%s] %s', req.ip, req.method, req.path);
  next();
});

// console.log('the wwwroot is:' + ' ' + config.app.wwwroot);
// console.log('the publicPath is:' + ' ' + vueconfig.publicPath);

// to make the application run in https://nbp.niaidawsqa.net/tbrnat/
// do not touch this magic
app.use(express.static(path.resolve('dist')));
app.use(config.app.wwwroot, express.static(path.resolve('dist')));// put the dist folder on <root>/tbrnat/ and run the application

// start the server
app.listen(config.app.port, () => console.log('Listening on port:' + ' ' + config.app.port))

//adding routes
// app.use(config.app.wwwroot, healthcheck);

