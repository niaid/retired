
library(shiny)
library(dplyr)
library(stringr)


#Read in tables
# If you add a table add it here and to the server fucntion
DB1_human_pR <- read.csv("DB1_human_pR.csv")
DB1_human_phospho <- read.csv("DB1_human_phospho.csv")
DB2_human_phospho <- read.csv("DB2_human_phospho.csv")
DB2_human_pR <- read.csv("DB2_human_pR.csv")
DB3_proteins <- read.csv("DB3_proteins.csv")
DB4_proteins <- read.csv("DB4_proteins.csv")
DB4_phospho <- read.csv("DB4_phospho.csv")
DB4_pR <- read.csv("DB4_pR.csv")
DB1_mouse_pRSites <- read.csv("DB1_mouse_pRSites.csv")
DB1_mouse_phospho <- read.csv("DB1_mouse_phospho.csv")
PARP9_IP <- read.csv("PARP9_interactome.csv")
PARP9_IP_phospho <- read.csv("PARP9_IP_phospho.csv")
PARP9_IP_pR <- read.csv("PARP9_IP_pR.csv")
ASK2_IP <- read.csv("ASK2_interactome.csv")
ASK2_IP_phospho <- read.csv("ASK2_IP_phospho.csv")
ASK2_IP_pR <- read.csv("ASK2_IP_pR.csv")
modules <- read.csv("modules.csv")



# This is the UI it contain elements such as sidebarPanel(comments), mainPanel(tabs)
ui <- htmlTemplate("index.html",  

MainPage = bootstrapPage(
  
  sidebarPanel(textInput
               (inputId = "Offical_Gene_Symbol",
                 label = "Search by: Offical Gene Symbol"),
               
               actionButton(inputId = "Show_Data",
                            label = "Show results"),
               tabPanel("Database Description"),
               tags$p(br(),
                      'Welcome to MAPCD!',
                      br(),
                      br(),
                        'Search for a gene of interest to see how the protein product(s) of that gene are regulated in PARPi-treated and/or LPS-stimulated macrophages.',
                      br(),
                      br(),
                      'All data in this database was generated in the Nita-Lazar lab at NIAID, NIH using LPS from Salmonella minnesota (Enzo, Cat # ALX-581-008-L002, Lot # 09141528) from 2015-2020. Please direct questions related to the data to Dr. Casey Daniels (casey.daniels-at-nih.gov)',
                      br(),
                      br(),
                      'The mass spectrometry proteomics data have been deposited to the ProteomeXchange Consortium via the PRIDE partner repository with the dataset identifier PXD016469',
                      br(),
                      br(),
                      'Associated Manuscript:',
                      br(),
'Daniels, C. M.;  Kaplan, P. R.;  Bishof, I.;  Bradfield, C.;  Tucholski, T.;  Nuccio, A. G.;  Manes, N. P.;  Katz, S.;  Fraser, I. D. C.; Nita-Lazar, A., Dynamic ADP-Ribosylome, Phosphoproteome, and Interactome in LPS-Activated Macrophages. Journal of proteome research 2020.',
tags$a(href="http://pubs.acs.org/doi/pdf/10.1021/acs.jproteome.0c00261", "Manuscript link"),
#'http://pubs.acs.org/doi/pdf/10.1021/acs.jproteome.0c00261',
                      br(),
                      br(),
                      
                      'Data Availability:',
                      br(),
                      'RAW files and MaxQuant search results have been deposited to the ProteomeXchange Consortium via the PRIDE partner repository with the data set identifier PXD016469.',
  tags$a(href="https://www.ebi.ac.uk/pride/archive/projects/PXD016469", "RAW files link"),
#'https://www.ebi.ac.uk/pride/archive/projects/PXD016469',
                      br(),
                      br(),
                      br(),
                      'Database Descriptions Below:',
                      br(),
                      br(),
                      'DB1_human_pR- Two different mouse macrophage like cells (bone marrow derived macrophages, or Raw264.7 cells) were stimulated with LPS for a timecourse and analyzed for their PTMs using the method from Daniels et al (JPR 2015). A phosphoribose site (212.01 daltons) represents the ADP-ribosylation PTM that was intact prior to digestion by snake venom phosphodiesterase (SVP).',
                      br(),
                      br(),
                      'DB1_human_phospho- Two different human macrophage like cells types (blood monocyte derived macrophages, or THP1 cells) were stimulated with LPS for a timecourse and analyzed for their PTMs using the method from Daniels et al (JPR 2015).',
                      br(),
                      br(),
                      'DB2_human_phospho- Primary human monocyte derived macrophages from 3 human donors, 2 replicates per donor, were stimulated with LPS over a timecourse (untreated = light/L, 5 minutes = medium/M, 30 minutes = heavy/H) and lysed in urea, dimethyl labeled and combined, and then ADPr monomers & polymers were digested to phosphoribose using SVP (Daniels et al, JPR 2015). Peptides carrying phosphorylation and/or phosphoribosylation were enriched by IMAC and identified by LC-MS/MS.',
                      br(),
                      br(),
                      'DB2_human_pR- Primary human monocyte derived macrophages from 3 human donors, 2 replicates per donor, were stimulated with LPS over a timecourse (untreated = light/L, 5 minutes = medium/M, 30 minutes = heavy/H) and lysed in urea, dimethyl labeled and combined, and then ADPr monomers & polymers were digested to phosphoribose using SVP (Daniels et al, JPR 2015). Peptides carrying phosphorylation and/or phosphoribosylation were enriched by IMAC and identified by LC-MS/MS.',
                      br(),
                      br(),
                      'DB3_proteins- THP1 human cells were lysed in native lysis buffer (Tris pH 7.5, salt, protease inhibitors, phosphatase inhibitors, PARP inhibitor, PARG inhibitor) and fractioned by size exclusion chromatography (SEC). 24 fractions were collected from 2 treatment groups (no LPS or 30 minutes of LPS) and each fraction was lyophilized and reconstituted in 8 M urea. Samples were analyzed by LC-MS/MS',
                      br(),
                      br(),
                      'DB4_proteins- U937 human cells were treated with drug (PJ34) or vehicle (water), then stimulated with LPS (untreated, 5 minutes, or 30 minutes) and lysed in native lysis buffer (Tris pH 7.5, salt, protease inhibitors, phosphatase inhibitors, PARP inhibitor, PARG inhibitor) and fractioned by size exclusion chromatography (SEC). High molecular weight (HMW) or low molecular weight (LMW) fractions were collected and analyzed by LC-MS/MS to identify proteins.',
                      br(),
                      br(),
                      'DB4_phospho- U937 human cells were treated with drug (PJ34) or vehicle (water), then stimulated with LPS (untreated, 5 minutes, or 30 minutes) and lysed in native lysis buffer (Tris pH 7.5, salt, protease inhibitors, phosphatase inhibitors, PARP inhibitor, PARG inhibitor) and fractioned by size exclusion chromatography (SEC). High molecular weight (HMW) or low molecular weight (LMW) fractions were collected and treated with snake venom phosphodiesterase (SVP) to simplify polymeric and monomeric ADP-ribosylated sites to phosphoribose, and phosphopeptides were co-enriched alongside phosphoribosylated peptides using IMAC. Eluted peptides were identified by LC-MS/MS.',
                      br(),
                      br(),
                      'DB4_pR- U937 human cells were treated with drug (PJ34) or vehicle (water), then stimulated with LPS (untreated, 5 minutes, or 30 minutes) and lysed in native lysis buffer (Tris pH 7.5, salt, protease inhibitors, phosphatase inhibitors, PARP inhibitor, PARG inhibitor) and fractioned by size exclusion chromatography (SEC). High molecular weight (HMW) or low molecular weight (LMW) fractions were collected and treated with snake venom phosphodiesterase (SVP) to simplify polymeric and monomeric ADP-ribosylated sites to phosphoribose, and phosphopeptides were co-enriched alongside phosphoribosylated peptides using IMAC. Eluted peptides were identified by LC-MS/MS.',
                      br(),
                      br(),
                      'DB1_mouse_pRSites- Two different mouse macrophage like cells (bone marrow derived macrophages, or Raw264.7 cells) were stimulated with LPS for a timecourse and analyzed for their PTMs using the method from Daniels et al (JPR 2015). A phosphoribose site (212.01 daltons) represents the ADP-ribosylation PTM that was intact prior to digestion by snake venom phosphodiesterase (SVP).',
                      br(),
                      br(),
                      'DB1_mouse_phospho- Two different mouse macrophage like cells (bone marrow derived macrophages, or Raw264.7 cells) were stimulated with LPS for a timecourse and analyzed for their PTMs using the method from Daniels et al (JPR 2015).',
                      br(),
                      br(),
                      'PARP9_IP- U937 cells were treated with drug (vehicle vs PJ34) or stimulus (vehicle vs LPS) and enriched with PARP9 antibody (or IgG isotype control). The PARP9 interactome was determined from 2 replicates, and is reported here.',
                      br(),
                      br(),
                      'PARP9_IP_phospho- phosphorylation site ID from proteins enriched with PARP9 from U937 cells.',
                      br(),
                      br(),
                      'PARP9_IP_pR- ADP-ribosylation site ID from proteins enriched with PARP9 from U937 cells',
                      br(),
                      br(),
                      'ASK2_IP- Proteins included in the interactome of ASK2 are based on purification of HA-V5 tagged ASK2 from U937 cells, using an anti-HA antibody. 8 unique pulldowns were performed, with multiple conditions for each, and this interactome was assembled based on identification of each protein by at least 2 peptides, identification in at least 3 out of 8 replicates, exclusion from the IgG control, and inclusion in the CRAPome no more than 25 times.',
                      br(),
                      br(),
                      'ASK2_IP_phospho- phosphorylation site ID from proteins enriched with ASK2 from U937 cells',
                      br(),
                      br(),
                      'ASK2_IP_pR- ADP-ribosylation site ID from proteins enriched with ASK2 from U937 cells',
                      br(),
                      br(),
                      'Modules- What module a protein was placed into via WGCNA clustering',
                      br(),
                      br()
               ),
               width = 3
  ),
  mainPanel( 
    fluidRow(
      column(12, uiOutput('mytabs') 
             )
      )
  )
)# end Bootstrap
)# end htmlTemplate

##############
# End of UI
##############

# This contains the search fucntion and fucntion the make tabs reactive

server = function(input, output, session){
  observeEvent(input$Show_Data,{ 
    # The list of databases. If you add a database add it here
    databases.list <- c("DB1_human_pR",
                        "DB1_human_phospho",
                        "DB2_human_phospho",
                        "DB2_human_pR",
                        "DB3_proteins",
                        "DB4_proteins",
                        "DB4_phospho",
                        "DB4_pR",
                        "DB1_mouse_pRSites",
                        "DB1_mouse_phospho",
                        "PARP9_IP",
                        "PARP9_IP_phospho",
                        "PARP9_IP_pR",
                        "ASK2_IP",
                        "ASK2_IP_phospho",
                        "ASK2_IP_pR",
                        "modules"
    )
    
    
    # Search Fucntion the input for the search becomes gene.name  
    gene.name <- input$Offical_Gene_Symbol
    
    #This searches the databases for the names
    
    for (d in 1:length(databases.list)) {
      database.name <- databases.list[d]
      
      database.filter <- get(database.name)
      if(gene.name!= ""){
        database.filter <- filter(database.filter, toupper(Gene)==toupper(gene.name))
      }
      
      assign(paste0(database.name, " filtered"), database.filter)
    }
    
    
    #####List database that should be shown
    
    db.names.shown <- c()
    for (d in 1:length(databases.list)) {
      database.name <- get(paste0(databases.list[d], " filtered"))
      if(nrow(database.name)!=0){
        db.names.shown <- c(db.names.shown, paste0(databases.list[d], " filtered"))
      }  
      else {db.names.shown <- db.names.shown}}
    
    
    # End of search function
    
    # This is selecting the tabs to be shown
    gene.name <- input$Offical_Gene_Symbol
    
    output$mytabs = renderUI({
      
      
      
      for (d in 1:length(databases.list)) {
        database.name <- databases.list[d]
        
        database.filter <- get(database.name)
        if(gene.name!= ""){
          database.filter <- filter(database.filter, toupper(Gene)==toupper(gene.name))
        }
        
        assign(paste0(database.name, " filtered"), database.filter) # Adds the name filtered to database name
      }
      
      
      #####List database that should be shown
      
      db.names.shown <- c()
      for (d in 1:length(databases.list)) {
        database.name <- get(paste0(databases.list[d], " filtered"))
        if(nrow(database.name)!=0){
          db.names.shown <- c(db.names.shown, paste0(databases.list[d], " filtered"))
        }  
        else {db.names.shown <- db.names.shown}}
      myTabs = lapply(seq_len(length(db.names.shown)), function(i) {
        tabPanel(paste0(db.names.shown[i]),
                 DT::dataTableOutput(paste0(db.names.shown[i]))
        )
        
      })
      # myTabs = lapply(db.names.shown, tabPanel)
      do.call(tabsetPanel, myTabs)
    })
    observe(
      lapply(seq_len(length(db.names.shown)), function(j) {
        output[[paste0(db.names.shown[j])]] <- DT::renderDataTable({
          as.data.frame(get(db.names.shown[j]))
        })
      })  
    )
    
  })
  
}

# Runs ui and server fucntion
shinyApp(ui, server)

