# Macrophage ADP-ribosylation, Phosphorylation, and Complex Dynamics (MAPCD)

This is an Rshiny app to accompany Dr. Casey Daniel's project.
As of now it will contain a table and is containerized with docker.
