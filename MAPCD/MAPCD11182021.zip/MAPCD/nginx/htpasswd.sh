#!/bin/sh

set -e

<<-EndOfMessage

This script automates creation of .htpasswd that stores a list of website users and their encrypted passwords.
The generated file is included into the NGINX configuration that enables basic password authentication for the application website.
This script produces a single file that is shared between all staging environments.
Original usernames and passwords are stored securely in and can be retrieved from the SSM Parameter Store.

CREATING USERS

It is assumed that user and password pairs are stored at the SSM Parameter path '/mapcd/users' in the Monarch PROD environment. 
The parameters can be created via the Monarch CLI command ''monarch ssm-ps'.

Example: 

monarch ssm-ps -e prod -p /mapcd/users/demo1=MySecurePassw0rd


UPDATING NGINX PASSWORD FILE

Once all user accounts have been added to the Parameter Store run this script from the repository root to update nginx/.htpasswd:

nginx/htpasswd.sh

EndOfMessage

env='prod'
passwd_file="nginx/.htpasswd"

[[ -f $passwd_file ]] && rm $passwd_file

echo "Retrieving SSM Parameters with user accounts..."
u_list=$(monarch ssm-ps -e $env -l | grep users)

[[ -z $u_list ]] && echo "No users at the SSM Parameter path /mapcd/users/!" && exit 1

for record in $u_list; do
    echo "Adding user ${record##*/}..."
    passwd=$(monarch ssm-ps -e $env -g $record)
    echo "${record##*/}:$(openssl passwd -apr1 $passwd)" >> $passwd_file
done

echo "Done! Don't forget to commit and push the updated .htpasswd to the GitHub server!"
