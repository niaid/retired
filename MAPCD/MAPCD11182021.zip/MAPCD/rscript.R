pkgs = c('dplyr', 'stringr', "DT")

install.packages(pkgs, repos='https://cran.rstudio.com/')
